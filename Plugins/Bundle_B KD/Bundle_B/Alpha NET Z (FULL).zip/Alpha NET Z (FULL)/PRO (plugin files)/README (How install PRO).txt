Copy files from "To your project" folder to your project root directory

Single plugin file Alpha_NETZ.js used for both versions of RPG Maker (MV and MZ)

More information 
https://github.com/KageDesu/Alpha-NET-Z/wiki/Download-and-install-guide



