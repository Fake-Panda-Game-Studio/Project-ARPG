Plugin webpage
https://kdworkshop.net/plugins/animax/

Help and support
https://kdworkshop.net/discord-server/


How install

If you using RPG Maker MV, use plugin file PKD_AnimaX_MV.js
If you using RPG Maker MZ, use plugin file PKD_AnimaX_MZ.js


