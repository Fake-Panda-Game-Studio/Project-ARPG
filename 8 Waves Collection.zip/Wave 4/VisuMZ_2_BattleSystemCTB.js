//=============================================================================
// VisuStella MZ - Battle System CTB - Charge Turn Battle
// VisuMZ_2_BattleSystemCTB.js
//=============================================================================

var Imported = Imported || {};
Imported.VisuMZ_2_BattleSystemCTB = true;

var VisuMZ = VisuMZ || {};
VisuMZ.BattleSystemCTB = VisuMZ.BattleSystemCTB || {};
VisuMZ.BattleSystemCTB.version = 1.20;

//=============================================================================
 /*:
 * @target MZ
 * @plugindesc [RPG Maker MZ] [Tier 2] [Version 1.20] [BattleSystemCTB]
 * @author VisuStella
 * @url http://www.yanfly.moe/wiki/Battle_System_-_CTB_VisuStella_MZ
 * @base VisuMZ_0_CoreEngine
 * @base VisuMZ_1_BattleCore
 * @orderAfter VisuMZ_1_BattleCore
 *
 * @help
 * ============================================================================
 * Introduction
 * ============================================================================
 *
 * This plugin creates a Charge Turn Battle (CTB) system using RPG Maker MZ's
 * TPB as a base. CTB functions by calculating the speed of every battler and
 * balancing them relative to one another. When it's a battler's turn, the
 * battler will either choose an action to perform immediately or charge it
 * for later depending if the skill requires charging.
 * 
 * This is a battle system where agility plays an important factor in the
 * progress of battle where higher agility values give battlers more advantage
 * and additional turns over lower agility values, which give battlers less
 * advantage and less turns.
 * 
 * A turn order display will appear to compensate for the removal of gauges.
 * The turn order display will show a preview of what the turn order could
 * possibly be like. This turn order display is variable and can be changed
 * due to player and enemy influence by using different action speeds, effects
 * provided by this plugin that alter the turn order, and more!
 * 
 * *NOTE* To use this battle system, you will need the updated version of
 * VisuStella's Core Engine. Go into its Plugin Parameters and change the
 * "Battle System" plugin parameter to "ctb".
 *
 * Features include all (but not limited to) the following:
 * 
 * * Full control over the TPB integrated mechanics converted for CTB such as
 *   speed, calculations, etc.
 * * No more waiting for gauges to show up! In fact, you won't even see the
 *   TPB gauge in-game.
 * * A turn order display that previews a potential lineup for how the
 *   participating battlers in battle will play out.
 * * Notetags that give skills and items access to manipulating a battler's
 *   CTB speed.
 * * Notetags that give skills and items access to directly manipulate a target
 *   batter's position on the Turn Order display.
 * * These mechanics are separate from ATB and TPB itself, so you can still use
 *   either battle system without affecting both of them.
 * * Through the Core Engine, you can switch in and out of CTB for a different
 *   battle system.
 *
 * ============================================================================
 * Requirements
 * ============================================================================
 *
 * This plugin is made for RPG Maker MZ. This will not work in other iterations
 * of RPG Maker.
 *
 * ------ Required Plugin List ------
 *
 * * VisuMZ_0_CoreEngine
 * * VisuMZ_1_BattleCore
 *
 * This plugin requires the above listed plugins to be installed inside your
 * game's Plugin Manager list in order to work. You cannot start your game with
 * this plugin enabled without the listed plugins.
 *
 * ------ Tier 2 ------
 *
 * This plugin is a Tier 2 plugin. Place it under other plugins of lower tier
 * value on your Plugin Manager list (ie: 0, 1, 2, 3, 4, 5). This is to ensure
 * that your plugins will have the best compatibility with the rest of the
 * VisuStella MZ library.
 * 
 * *NOTE* To use this battle system, you will need the updated version of
 * VisuStella's Core Engine. Go into its Plugin Parameters and change the
 * "Battle System" plugin parameter to "ctb".
 *
 * ============================================================================
 * Major Changes
 * ============================================================================
 *
 * This plugin adds some new hard-coded features to RPG Maker MZ's functions.
 * The following is a list of them.
 *
 * ---
 * 
 * Turn Order Display
 * 
 * Despite the fact that the Battle System CTB plugin uses RPG Maker MZ's TPB
 * as a base, it does not have any gauges to depict the time it takes for a
 * battler's turn to appear. Instead, a turn order display appears on the
 * screen (you pick where it can appear: top, bottom, left, or right) and shows
 * a possible preview of the battler turn order.
 * 
 * This is only a preview of what can happen because lots of different things
 * can influence the position and ordering of the turn order display, ranging
 * from skill/item speeds, notetag effects, changes in AGI, etc. What is seen
 * on the turn order display is the most likely possibility instead of the
 * exact order to occur due to the external influences.
 * 
 * ---
 * 
 * Skill & Item Speeds
 * 
 * With TPB, skills and items with negative speed values will cause the battler
 * to enter a "casting" state, meaning they have to wait extra time before the
 * action takes off. With this delayed action execution, one might assume that
 * if there is a positive speed value, the battler would require less time for
 * their next turn.
 * 
 * However, this isn't the case with RPG Maker MZ's TPB. By changing it to CTB,
 * skills and items with positive speed values will have an impact on how full
 * their CTB Speed will be in the following turn. A value of 2000 will put the
 * turn at 50% ready, 1000 will put the gauge at 25% ready, 500 will put it at
 * 12.5% ready, and so on. Notetags can also be used to influence this.
 * 
 * ---
 * 
 * JS Calculation Mechanics
 * 
 * While the calculation mechanics aren't changed from their original RPG Maker
 * MZ formulas, the functions for them have been overwritten to allow you, the
 * game developer, to alter them as you see fit.
 * 
 * ---
 *
 * ============================================================================
 * Notetags
 * ============================================================================
 *
 * The following are notetags that have been added through this plugin. These
 * notetags will not work with your game if this plugin is OFF or not present.
 *
 * ---
 * 
 * === General CTB-Related Notetags ===
 * 
 * These notetags are general purpose notetags that have became available
 * through this plugin.
 * 
 * ---
 * 
 * <CTB Help>
 *  description
 *  description
 * </CTB Help>
 *
 * - Used for: Skill, Item Notetags
 * - If your game happens to support the ability to change battle systems, this
 *   notetag lets you change how the skill/item's help description text will
 *   look under CTB.
 * - This is primarily used if the skill behaves differently in CTB versus any
 *   other battle system.
 * - Replace 'description' with help text that's only displayed if the game's
 *   battle system is set to CTB.
 *
 * ---
 * 
 * === CTB Turn Order Display-Related Notetags ===
 * 
 * These notetags affect the CTB Turn Order Display
 * 
 * ---
 *
 * <CTB Turn Order Icon: x>
 *
 * - Used for: Actor, Enemy Notetags
 * - Changes the slot graphic used for the battler to a specific icon.
 * - Replace 'x' with the icon index to be used.
 * 
 * ---
 *
 * <CTB Turn Order Face: filename, index>
 *
 * - Used for: Actor, Enemy Notetags
 * - Changes the slot graphic used for the enemy to a specific face.
 * - Replace 'filename' with the filename of the image.
 *   - Do not include the file extension.
 * - Replace 'index' with the index of the face. Index values start at 0.
 * - Example: <CTB Turn Order Face: Monster, 1>
 * 
 * ---
 * 
 * === CTB Speed Manipulation-Related Notetags ===
 * 
 * These notetags are used for CTB Speed manipulation purposes.
 * 
 * ---
 *
 * <CTB Set Order: x>
 *
 * - Used for: Skill, Item Notetags
 * - Sets the target's CTB Turn Order position to exactly x.
 * - Replace 'x' with a number value depicting the exact position of the turn
 *   order position. 0 is the currently active battler and cannot be used.
 *   1 is closest to taking a turn. Higher numbers are further away.
 * - This does not affect the currently active battler.
 *
 * ---
 *
 * <CTB Change Order: +x>
 * <CTB Change Order: -x>
 *
 * - Used for: Skill, Item Notetags
 * - Sets the target's CTB Turn Order position by x slots.
 * - Replace 'x' with a number value indicating the increase or decrease.
 *   Negative values decrease the turns needed to wait while positive values
 *   increase the turns needed.
 * - This does not affect the currently active battler.
 *
 * ---
 *
 * <CTB After Speed: x%>
 *
 * - Used for: Skill, Item Notetags
 * - After using the skill/item, the user's CTB Speed will be set to x%.
 * - Replace 'x' with a percentile value representing the amount you want the
 *   CTB Speed to reset to after the skill/item's usage.
 * 
 * ---
 * 
 * <CTB Charge Speed: x%>
 * <CTB Charge Speed: +x%>
 * <CTB Charge Speed: -x%>
 *
 * - Used for: Skill, Item Notetags
 * - If the target is in a charging state, change the target's speed amount to
 *   x% or by x% (if using the +/- variants).
 * - Replace 'x' with a percentile value representing the amount of the CTB
 *   Speed you wish to alter it to/by.
 * - This only affects targets who are in a charging state.
 * 
 * ---
 * 
 * <CTB Cast Speed: x%>
 * <CTB Cast Speed: +x%>
 * <CTB Cast Speed: -x%>
 *
 * - Used for: Skill, Item Notetags
 * - If the target is in a casting state, change the target's speed amount to
 *   x% or by x% (if using the +/- variants).
 * - Replace 'x' with a percentile value representing the amount of the CTB
 *   Speed you wish to alter it to/by.
 * - This only affects targets who are in a casting state.
 * 
 * ---
 * 
 * === JavaScript Notetags: CTB Speed Manipulation ===
 *
 * The following are notetags made for users with JavaScript knowledge to
 * give more control over conditional CTB Speed Manipulation.
 * 
 * ---
 * 
 * <JS CTB Order>
 *  code
 *  code
 *  order = code;
 * </JS CTB Order>
 *
 * - Used for: Skill, Item Notetags
 * - Replace 'code' with JavaScript code to determine where to set the target's
 *   order on the CTB Turn Order Display to.
 * - The 'order' variable represents the final position on the Turn Order
 *   Display to place the target.
 * - The 'position' variable represents the target's current position on the
 *   Turn Order Display.
 * - This does not affect the currently active battler.
 * 
 * ---
 * 
 * <JS CTB Charge Speed>
 *  code
 *  code
 *  rate = code;
 * </JS CTB Charge Speed>
 *
 * - Used for: Skill, Item Notetags
 * - Replace 'code' with JavaScript code to determine how much to change the
 *   CTB Speed to if the target is in a charging state.
 * - The 'rate' variable represents rate value the CTB Speed will change to
 *   between the values of 0 and 1.
 * - The 'rate' variable will default to the target's current CTB Speed rate
 *   if the target is in a charging state.
 * 
 * ---
 * 
 * <JS CTB Cast Speed>
 *  code
 *  code
 *  rate = code;
 * </JS CTB Cast Speed>
 *
 * - Used for: Skill, Item Notetags
 * - Replace 'code' with JavaScript code to determine how much to change the
 *   CTB Speed to if the target is in a casting state.
 * - The 'rate' variable represents rate value the CTB Speed will change to
 *   between the values of 0 and 1.
 * - The 'rate' variable will default to the target's current CTB Speed rate
 *   if the target is in a casting state.
 * 
 * ---
 * 
 * <JS CTB After Speed>
 *  code
 *  code
 *  rate = code;
 * </JS CTB After Speed>
 *
 * - Used for: Skill, Item Notetags
 * - Replace 'code' with JavaScript code to determine how much to change the
 *   CTB Speed to after performing this skill/item action.
 * - The 'rate' variable represents rate value the CTB Speed will change to
 *   between the values of 0 and 1.
 * - The 'rate' variable will default to 0.
 * 
 * ---
 *
 * ============================================================================
 * Plugin Commands
 * ============================================================================
 *
 * The following are Plugin Commands that come with this plugin. They can be
 * accessed through the Plugin Command event command.
 *
 * ---
 * 
 * === Actor Plugin Commands ===
 * 
 * ---
 *
 * Actor: Change CTB Turn Order Icon
 * - Changes the icons used for the specific actor(s) on the CTB Turn Order.
 *
 *   Actor ID(s):
 *   - Select which Actor ID(s) to affect.
 *
 *   Icon:
 *   - Changes the graphic to this icon.
 *
 * ---
 * 
 * Actor: Change CTB Turn Order Face
 * - Changes the faces used for the specific actor(s) on the CTB Turn Order.
 * 
 *   Actor ID(s):
 *   - Select which Actor ID(s) to affect.
 * 
 *   Face Name:
 *   - This is the filename for the target face graphic.
 * 
 *   Face Index:
 *   - This is the index for the target face graphic.
 * 
 * ---
 *
 * Actor: Clear CTB Turn Order Graphic
 * - Clears the CTB Turn Order graphics for the actor(s).
 * - The settings will revert to the Plugin Parameter settings.
 *
 *   Actor ID(s):
 *   - Select which Actor ID(s) to affect.
 *
 * ---
 * 
 * === Enemy Plugin Commands ===
 * 
 * ---
 *
 * Enemy: Change CTB Turn Order Icon
 * - Changes the icons used for the specific enemy(ies) on the CTB Turn Order.
 *
 *   Enemy Index(es):
 *   - Select which enemy index(es) to affect.
 *
 *   Icon:
 *   - Changes the graphic to this icon.
 *
 * ---
 *
 * Enemy: Change CTB Turn Order Face
 * - Changes the faces used for the specific enemy(ies) on the CTB Turn Order.
 *
 *   Enemy Index(es):
 *   - Select which enemy index(es) to affect.
 *
 *   Face Name:
 *   - This is the filename for the target face graphic.
 *
 *   Face Index:
 *   - This is the index for the target face graphic.
 *
 * ---
 *
 * Enemy: Clear CTB Turn Order Graphic
 * - Clears the CTB Turn Order graphics for the enemy(ies).
 * - The settings will revert to the Plugin Parameter settings.
 *
 *   Enemy Index(es):
 *   - Select which enemy index(es) to affect.
 *
 * ---
 * 
 * === System Plugin Commands ===
 * 
 * ---
 * 
 * System: CTB Turn Order Visibility
 * - Determine the visibility of the CTB Turn Order Display.
 * 
 *   Visibility:
 *   - Changes the visibility of the CTB Turn Order Display.
 * 
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Mechanics Settings
 * ============================================================================
 *
 * Mechanics settings used for Battle System CTB. The majority of these are
 * JavaScript-based and will require knowledge of JavaScript to fully utilize
 * the plugin parameters.
 *
 * ---
 *
 * General
 * 
 *   Device Friendly:
 *   - Make the calculations more device friendly?
 *   - Or make it for desktop at full strength?
 * 
 *   Escape Fail Penalty:
 *   - Gauge penalty if an escape attempt fails.
 *
 * ---
 *
 * JavaScript
 * 
 *   JS: Initial Speed:
 *   - JavaScript code to determine how much speed to give each battler at the
 *     start of battle.
 * 
 *   JS: Speed:
 *   - JavaScript code to determine how much speed a battler has.
 * 
 *   JS: Base Speed:
 *   - JavaScript code to determine how much base speed a battler has.
 * 
 *   JS: Relative Speed:
 *   - JavaScript code to determine what is the relative speed of a battler.
 * 
 *   JS: Acceleration:
 *   - JavaScript code to determine how much gauges accelerate by relative to
 *     reference time.
 * 
 *   JS: Cast Time:
 *   - JavaScript code to determine how much cast time is used for skills/items
 *     with negative speed modifiers.
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Order Change Effects Settings
 * ============================================================================
 * 
 * Whenever the turn order a battler is changed by a CTB Order notetag, play
 * these effects on the target battler. These effects do not play if the order
 * was changed due to speed changes and only through the specific notetags.
 *
 * ---
 *
 * Delay Turn Order > Animation
 * 
 *   Animation ID:
 *   - Play this animation when the effect activates.
 *   - Occurs when the turn order is delayed.
 * 
 *   Mirror Animation:
 *   - Mirror the effect animation?
 *   - Occurs when the turn order is delayed.
 * 
 *   Mute Animation:
 *   - Mute the effect animation?
 *   - Occurs when the turn order is delayed.
 *
 * ---
 *
 * Delay Turn Order > Popups
 * 
 *   Text:
 *   - Text displayed upon the effect activating.
 *   - Occurs when the turn order is delayed.
 * 
 *   Text Color:
 *   - Use #rrggbb for custom colors or regular numbers for text colors from
 *     the Window Skin.
 * 
 *   Flash Color:
 *   - Adjust the popup's flash color.
 *   - Format: [red, green, blue, alpha]
 * 
 *   Flash Duration:
 *   - What is the frame duration of the flash effect?
 *
 * ---
 *
 * Rush Turn Order > Animation
 * 
 *   Animation ID:
 *   - Play this animation when the effect activates.
 *   - Occurs when the turn order is rushed.
 * 
 *   Mirror Animation:
 *   - Mirror the effect animation?
 *   - Occurs when the turn order is rushed.
 * 
 *   Mute Animation:
 *   - Mute the effect animation?
 *   - Occurs when the turn order is rushed.
 *
 * ---
 *
 * Rush Turn Order > Popups
 * 
 *   Text:
 *   - Text displayed upon the effect activating.
 *   - Occurs when the turn order is rushed.
 * 
 *   Text Color:
 *   - Use #rrggbb for custom colors or regular numbers for text colors from
 *     the Window Skin.
 * 
 *   Flash Color:
 *   - Adjust the popup's flash color.
 *   - Format: [red, green, blue, alpha]
 * 
 *   Flash Duration:
 *   - What is the frame duration of the flash effect?
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Turn Order Display Settings
 * ============================================================================
 *
 * Turn Order Display settings used for Battle System CTB. These adjust how the
 * visible turn order appears in-game.
 *
 * ---
 *
 * General
 * 
 *   Display Position:
 *   - Select where the Turn Order will appear on the screen.
 * 
 *     Offset X:
 *     - How much to offset the X coordinate by.
 *     - Negative: left. Positive: right.
 * 
 *     Offset Y:
 *     - How much to offset the Y coordinate by.
 *     - Negative: up. Positive: down.
 * 
 *   Reposition for Help?:
 *   - If the display position is at the top, reposition the display when the
 *     help window is open?
 * 
 *   Reposition Log?:
 *   - If the display position is at the top, reposition the Battle Log Window
 *     to be lower?
 * 
 *   Forward Direction:
 *   - Decide on the direction of the Turn Order.
 *   - Settings may vary depending on position.
 *   - Left to Right / Down to Up
 *   - Right to Left / Up to Down
 * 
 *   Subject Distance:
 *   - How far do you want the currently active battler to distance itself from
 *     the rest of the Turn Order?
 * 
 *   Screen Buffer:
 *   - What distance do you want the display to be away from the edge of the
 *     screen by?
 *
 * ---
 *
 * Reposition For Help
 * 
 *   Repostion X By:
 *   Repostion Y By:
 *   - Reposition the display's coordinates by this much when the Help Window
 *     is visible.
 *
 * ---
 *
 * Slots
 * 
 *   Total Horizontal:
 *   - How many slots do you want to display for top and bottom Turn Order
 *     Display positions?
 * 
 *   Total Vertical:
 *   - How many slots do you want to display for left and right Turn Order
 *     Display positions?
 * 
 *   Length:
 *   - How many pixels long should the slots be on the Turn Order display?
 * 
 *   Thin:
 *   - How many pixels thin should the slots be on the Turn Order display?
 * 
 *   Update Frames:
 *   - How many frames should it take for the slots to update their
 *     positions by?
 *
 * ---
 *
 * Slot Border
 * 
 *   Show Border?:
 *   - Show borders for the slot sprites?
 * 
 *   Border Thickness:
 *   - How many pixels thick should the colored portion of the border be?
 * 
 *   Actors
 *   Enemies
 * 
 *     Border Color:
 *     - Use #rrggbb for custom colors or regular numbers for text colors
 *       from the Window Skin.
 * 
 *     Border Skin:
 *     - Optional. Place a skin on the actor/enemy borders instead of
 *       rendering them?
 *
 * ---
 *
 * Slot Sprites
 * 
 *   Actors
 * 
 *     Sprite Type:
 *     - Select the type of sprite used for the actor graphic.
 *     - Face Graphic - Show the actor's face.
 *     - Icon - Show a specified icon.
 *     - Sideview Actor - Show the actor's sideview battler.
 * 
 *     Default Icon:
 *     - Which icon do you want to use for actors by default?
 * 
 *   Enemies
 * 
 *     Sprite Type:
 *     - Select the type of sprite used for the enemy graphic.
 *     - Face Graphic - Show a specified face graphic.
 *     - Icon - Show a specified icon.
 *     - Enemy - Show the enemy's graphic or sideview battler.
 * 
 *     Default Face Name:
 *     - Use this default face graphic if there is no specified face.
 * 
 *     Default Face Index:
 *     - Use this default face index if there is no specified index.
 * 
 *     Default Icon:
 *     - Which icon do you want to use for enemies by default?
 * 
 *     Match Hue?:
 *     - Match the hue for enemy battlers?
 *     - Does not apply if there's a sideview battler.
 *
 * ---
 *
 * Slot Letter
 * 
 *   Show Enemy Letter?:
 *   - Show the enemy's letter on the slot sprite?
 * 
 *   Font Name:
 *   - The font name used for the text of the Letter.
 *   - Leave empty to use the default game's font.
 * 
 *   Font Size:
 *   - The font size used for the text of the Letter.
 *
 * ---
 *
 * Slot Background
 * 
 *   Show Background?:
 *   - Show the background on the slot sprite?
 * 
 *   Actors
 *   Enemies
 * 
 *     Background Color 1:
 *     Background Color 2:
 *     - Use #rrggbb for custom colors or regular numbers for text colors
 *       from the Window Skin.
 * 
 *     Background Skin:
 *     - Optional. Use a skin for the actor background instead of
 *       rendering them?
 *
 * ---
 *
 * ============================================================================
 * Terms of Use
 * ============================================================================
 *
 * 1. These plugins may be used in free or commercial games provided that they
 * have been acquired through legitimate means at VisuStella.com and/or any
 * other official approved VisuStella sources. Exceptions and special
 * circumstances that may prohibit usage will be listed on VisuStella.com.
 * 
 * 2. All of the listed coders found in the Credits section of this plugin must
 * be given credit in your games or credited as a collective under the name:
 * "VisuStella".
 * 
 * 3. You may edit the source code to suit your needs, so long as you do not
 * claim the source code belongs to you. VisuStella also does not take
 * responsibility for the plugin if any changes have been made to the plugin's
 * code, nor does VisuStella take responsibility for user-provided custom code
 * used for custom control effects including advanced JavaScript notetags
 * and/or plugin parameters that allow custom JavaScript code.
 * 
 * 4. You may NOT redistribute these plugins nor take code from this plugin to
 * use as your own. These plugins and their code are only to be downloaded from
 * VisuStella.com and other official/approved VisuStella sources. A list of
 * official/approved sources can also be found on VisuStella.com.
 *
 * 5. VisuStella is not responsible for problems found in your game due to
 * unintended usage, incompatibility problems with plugins outside of the
 * VisuStella MZ library, plugin versions that aren't up to date, nor
 * responsible for the proper working of compatibility patches made by any
 * third parties. VisuStella is not responsible for errors caused by any
 * user-provided custom code used for custom control effects including advanced
 * JavaScript notetags and/or plugin parameters that allow JavaScript code.
 *
 * 6. If a compatibility patch needs to be made through a third party that is
 * unaffiliated with VisuStella that involves using code from the VisuStella MZ
 * library, contact must be made with a member from VisuStella and have it
 * approved. The patch would be placed on VisuStella.com as a free download
 * to the public. Such patches cannot be sold for monetary gain, including
 * commissions, crowdfunding, and/or donations.
 * 
 * 7. If this VisuStella MZ plugin is a paid product, all project team members
 * must purchase their own individual copies of the paid product if they are to
 * use it. Usage includes working on related game mechanics, managing related
 * code, and/or using related Plugin Commands and features. Redistribution of
 * the plugin and/or its code to other members of the team is NOT allowed
 * unless they own the plugin itself as that conflicts with Article 4.
 * 
 * 8. Any extensions and/or addendums made to this plugin's Terms of Use can be
 * found on VisuStella.com and must be followed.
 *
 * ============================================================================
 * Credits
 * ============================================================================
 * 
 * If you are using this plugin, credit the following people in your game:
 * 
 * Team VisuStella
 * * Yanfly
 * * Arisu
 * * Olivia
 * * Irina
 *
 * ============================================================================
 * Changelog
 * ============================================================================
 * 
 * Version 1.20: August 18, 2022
 * * Bug Fixes!
 * ** Fixed bugs that caused the CTB Turn Order faces and icons to not change
 *    properly for actors and enemies. Fix made by Olivia.
 * 
 * Version 1.19: July 7, 2022
 * * Compatibility Update!
 * ** Plugin is now updated to support larger than 8 troop sizes.
 * 
 * Version 1.18: June 2, 2022
 * * Bug Fixes!
 * ** Notetag effect for <CTB After Speed: x%> should now be working properly.
 *    Fix made by Olivia.
 * ** Notetag effect for <JS CTB After Speed> should now be working properly.
 *    Fix made by Olivia.
 * 
 * Version 1.17: May 2, 2022
 * * Optimization Update!
 * ** Plugin should run more optimized.
 * 
 * Version 1.16: April 28, 2022
 * * Feature Update!
 * ** Added update for CTB-specific idle time to allow a more consistent turn
 *    end processing for actors and enemies with higher than normal AGI values.
 *    Update made by Olivia.
 * 
 * Version 1.15: April 21, 2022
 * * Bug Fixes!
 * ** The endless softlock has been fixed! Much thanks to AndyL for providing a
 *    project that can easily replicate it! Fix made by Yanfly.
 * * Feature Update!
 * ** Slightly more accurate turn order forecasting. However, there is only so
 *    much I can do due to JavaScript's "accuracy" with decimal values. Update
 *    made by Yanfly.
 * 
 * Version 1.14: March 31, 2022
 * * Feature Update!
 * ** Updated anti-softlock check at 180 frames (3 seconds) to automatically
 *    clear any battle states to see if they're the cause of the hangup.
 * ** Updated anti-softlock check at 300 frames (5 seconds) to automatically
 *    clear all states to see if they're the cause of the hangup.
 * ** Updated anti-softlock check at 600 frames (10 seconds) to automatically
 *    abort the battle to salvage the game from freezing.
 * 
 * Version 1.13: March 3, 2022
 * * Feature Update!
 * ** Reserved common events for non-action sequence skills now function
 *    separately from one another when used by a battler with Action Times+.
 *    Update made by Olivia.
 * 
 * Version 1.12: February 17, 2022
 * * Optimization Update!
 * ** Plugin should run more optimized.
 * 
 * Version 1.11: October 28, 2021
 * * Bug Fixes!
 * ** Turn Order display will no longer appear at differing X and Y positions
 *    when using specific battle layouts. Update made by Olivia.
 * 
 * Version 1.10: June 18, 2021
 * * Bug Fixes!
 * ** Fixed turn order icon reappearing for a dying battler. Fix made by Irina.
 * * Documentation Update!
 * ** Help file updated with new features.
 * * New Features!
 * ** New Plugin Parameters added by Arisu!
 * *** Plugin Parameters > Mechanics > General > Device Friendly
 * **** Make the calculations more device friendly? Or make it for desktop at
 *      full strength?
 * 
 * Version 1.09: June 11, 2021
 * * Bug Fixes!
 * ** Plugin Command: "Enemy: Change CTB Turn Order Face" should now properly
 *    change to the correct face index. Fix made by Arisu.
 * 
 * Version 1.08: April 23, 2021
 * * Feature Update!
 * ** When using 100% for After Speed notetag, no other battler is able to
 *    interrupt the action. Update made by Olivia.
 * 
 * Version 1.07: March 19, 2021
 * * Feature Update!
 * ** Turn Order Window calculations slightly tweaked for times when the window
 *    layer is bigger than it should be. Update made by Olivia.
 * 
 * Version 1.06: January 22, 2021
 * * Feature Update!
 * ** A different kind of end battle check is now made to determine hiding the
 *    turn order display. Update made by Olivia.
 * ** Added in a built-in anti-softlock check.
 * 
 * Version 1.05: January 1, 2021
 * * Compatibility Update
 * ** Added compatibility functionality for future plugins.
 * 
 * Version 1.04: November 15, 2020
 * * Optimization Update!
 * ** Plugin should run more optimized.
 * 
 * Version 1.03: November 1, 2020
 * * Documentation Update!
 * ** Help file updated with new features.
 * * Optimization Update!
 * ** Uses less resources for turn order display.
 * * New Features!
 * ** New Plugin Command by Irina!
 * *** Actor: Change CTB Turn Order Face
 * **** Changes the faces used for the specific actor(s) on the CTB Turn Order.
 * 
 * Version 1.02: October 25, 2020
 * * Bug Fixes!
 * ** Turn Order icons no longer stay invisible after rotating out completely.
 *    Fix made by Irina.
 * * Documentation Update!
 * ** Help file updated with new features.
 * * Feature Update!
 * ** <CTB Turn Order Face: filename, index> notetag now works with actors.
 *    Update made by Irina.
 * 
 * Version 1.01: October 18, 2020
 * * Bug Fixes!
 * ** Action times + should no longer freeze the game. Fix made by Yanfly.
 * ** Actors and enemies without actions will no longer softlock the game.
 *    Fix made by Yanfly.
 * ** Auto-battle during CTB should no longer lock the game! Fix by Yanfly.
 * ** Enemies without any actions should no longer cause endless loops.
 *    Fix made by Yanfly.
 * ** SV_Actor graphics on the Turn Order display are now centered.
 *    Fix made by Yanfly.
 *
 * Version 1.00 Official Release: October 19, 2020
 * * Finished Plugin!
 *
 * ============================================================================
 * End of Helpfile
 * ============================================================================
 *
 * @ --------------------------------------------------------------------------
 *
 * @command CtbTurnOrderActorIcon
 * @text Actor: Change CTB Turn Order Icon
 * @desc Changes the icons used for the specific actor(s) on the CTB Turn Order.
 *
 * @arg Actors:arraynum
 * @text Actor ID(s)
 * @type actor[]
 * @desc Select which Actor ID(s) to affect.
 * @default ["1"]
 *
 * @arg IconIndex:num
 * @text Icon
 * @desc Changes the graphic to this icon.
 * @default 84
 *
 * @ --------------------------------------------------------------------------
 *
 * @command CtbTurnOrderActorFace
 * @text Actor: Change CTB Turn Order Face
 * @desc Changes the faces used for the specific actor(s) on the CTB Turn Order.
 *
 * @arg Actors:arraynum
 * @text Actor ID(s)
 * @type actor[]
 * @desc Select which Actor ID(s) to affect.
 * @default ["1"]
 *
 * @arg FaceName:str
 * @text Face Name
 * @type file
 * @dir img/faces/
 * @desc This is the filename for the target face graphic.
 * @default Actor1
 *
 * @arg FaceIndex:num
 * @text Face Index
 * @type number
 * @desc This is the index for the target face graphic.
 * @default 0
 *
 * @ --------------------------------------------------------------------------
 *
 * @command CtbTurnOrderClearActorGraphic
 * @text Actor: Clear CTB Turn Order Graphic
 * @desc Clears the CTB Turn Order graphics for the actor(s).
 * The settings will revert to the Plugin Parameter settings.
 *
 * @arg Actors:arraynum
 * @text Actor ID(s)
 * @type actor[]
 * @desc Select which Actor ID(s) to affect.
 * @default ["1"]
 *
 * @ --------------------------------------------------------------------------
 *
 * @command CtbTurnOrderEnemyIcon
 * @text Enemy: Change CTB Turn Order Icon
 * @desc Changes the icons used for the specific enemy(ies) on the CTB Turn Order.
 *
 * @arg Enemies:arraynum
 * @text Enemy Index(es)
 * @type number[]
 * @desc Select which enemy index(es) to affect.
 * @default ["1"]
 *
 * @arg IconIndex:num
 * @text Icon
 * @desc Changes the graphic to this icon.
 * @default 298
 *
 * @ --------------------------------------------------------------------------
 *
 * @command CtbTurnOrderEnemyFace
 * @text Enemy: Change CTB Turn Order Face
 * @desc Changes the faces used for the specific enemy(ies) on the CTB Turn Order.
 *
 * @arg Enemies:arraynum
 * @text Enemy Index(es)
 * @type number[]
 * @desc Select which enemy index(es) to affect.
 * @default ["1"]
 *
 * @arg FaceName:str
 * @text Face Name
 * @parent EnemySprite
 * @type file
 * @dir img/faces/
 * @desc This is the filename for the target face graphic.
 * @default Monster
 *
 * @arg FaceIndex:num
 * @text Face Index
 * @parent EnemySprite
 * @type number
 * @desc This is the index for the target face graphic.
 * @default 1
 *
 * @ --------------------------------------------------------------------------
 *
 * @command CtbTurnOrderClearEnemyGraphic
 * @text Enemy: Clear CTB Turn Order Graphic
 * @desc Clears the CTB Turn Order graphics for the enemy(ies).
 * The settings will revert to the Plugin Parameter settings.
 *
 * @arg Enemies:arraynum
 * @text Enemy Index(es)
 * @type number[]
 * @desc Select which enemy index(es) to affect.
 * @default ["1"]
 *
 * @ --------------------------------------------------------------------------
 *
 * @command SystemTurnOrderVisibility
 * @text System: CTB Turn Order Visibility
 * @desc Determine the visibility of the CTB Turn Order Display.
 *
 * @arg Visible:eval
 * @text Visibility
 * @type boolean
 * @on Visible
 * @off Hidden
 * @desc Changes the visibility of the CTB Turn Order Display.
 * @default true
 *
 * @ --------------------------------------------------------------------------
 *
 * @ ==========================================================================
 * @ Plugin Parameters
 * @ ==========================================================================
 *
 * @param BreakHead
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param BattleSystemCTB
 * @default Plugin Parameters
 *
 * @param ATTENTION
 * @default READ THE HELP FILE
 *
 * @param BreakSettings
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param Mechanics:struct
 * @text Mechanics Settings
 * @type struct<Mechanics>
 * @desc Mechanics settings used for Battle System CTB.
 * @default {"General":"","EscapeFailPenalty:num":"-1.00","JavaScript":"","InitialGaugeJS:str":"Math.random() * 0.50","TpbSpeedCalcJS:func":"\"// Declare Constants\\nconst user = this;\\n\\n// Process Calculation\\nlet speed = Math.sqrt(user.agi) + 1;\\n\\n// Return Value\\nreturn speed;\"","TpbBaseSpeedCalcJS:func":"\"// Declare Constants\\nconst user = this;\\nconst baseAgility = user.paramBasePlus(6);\\n\\n// Process Calculation\\nlet speed = Math.sqrt(baseAgility) + 1;\\n\\n// Return Value\\nreturn speed;\"","BattlerRelativeSpeedJS:func":"\"// Declare Constants\\nconst user = this;\\nconst speed = user.tpbSpeed()\\nconst partyBaseSpeed = $gameParty.tpbBaseSpeed();\\n\\n// Process Calculation\\nlet relativeSpeed = speed / partyBaseSpeed;\\n\\n// Return Value\\nreturn relativeSpeed;\"","TpbAccelerationJS:func":"\"// Declare Constants\\nconst user = this;\\nconst speed = user.tpbRelativeSpeed();\\nconst referenceTime = $gameParty.tpbReferenceTime();\\n\\n// Process Calculation\\nlet acceleration = speed / referenceTime;\\n\\n// Return Value\\nreturn acceleration;\"","TpbCastTimeJS:func":"\"// Declare Constants\\nconst user = this;\\nconst actions = user._actions.filter(action => action.isValid());\\nconst items = actions.map(action => action.item());\\nconst delay = items.reduce((r, item) => r + Math.max(0, -item.speed), 0);\\n\\n// Process Calculation\\nlet time = Math.sqrt(delay) / user.tpbSpeed();\\n\\n// Return Value\\nreturn time;\""}
 *
 * @param Effect:struct
 * @text Order Change Effects
 * @type struct<Effect>
 * @desc Effects to play when the Turn Order is changed in CTB.
 * @default {"Delay":"","DelayAnimation":"","DelayAnimationID:num":"54","DelayMirror:eval":"false","DelayMute:eval":"false","DelayPopups":"","DelayPopupText:str":"DELAY","DelayTextColor:str":"25","DelayFlashColor:eval":"[255, 0, 0, 160]","DelayFlashDuration:num":"60","Rush":"","RushAnimation":"","RushAnimationID:num":"51","RushMirror:eval":"false","RushMute:eval":"false","RushPopups":"","RushPopupText:str":"RUSH","RushTextColor:str":"24","RushFlashColor:eval":"[0, 255, 0, 160]","RushFlashDuration:num":"60"}
 *
 * @param TurnOrder:struct
 * @text Turn Order Display
 * @type struct<TurnOrder>
 * @desc Turn Order Display settings used for Battle System CTB.
 * @default {"General":"","DisplayPosition:str":"top","DisplayOffsetX:num":"0","DisplayOffsetY:num":"0","RepositionTopForHelp:eval":"true","RepositionLogWindow:eval":"true","OrderDirection:eval":"true","SubjectDistance:num":"8","ScreenBuffer:num":"20","Reposition":"","RepositionTopHelpX:num":"0","RepositionTopHelpY:num":"96","Slots":"","TotalHorzSprites:num":"16","TotalVertSprites:num":"10","SpriteLength:num":"72","SpriteThin:num":"36","UpdateFrames:num":"24","Border":"","ShowMarkerBorder:eval":"true","BorderActor":"","ActorBorderColor:str":"4","ActorSystemBorder:str":"","BorderEnemy":"","EnemyBorderColor:str":"2","EnemySystemBorder:str":"","BorderThickness:num":"2","Sprite":"","ActorSprite":"","ActorBattlerType:str":"face","ActorBattlerIcon:num":"84","EnemySprite":"","EnemyBattlerType:str":"enemy","EnemyBattlerFaceName:str":"Monster","EnemyBattlerFaceIndex:num":"1","EnemyBattlerIcon:num":"298","EnemyBattlerMatchHue:eval":"true","Letter":"","EnemyBattlerDrawLetter:eval":"true","EnemyBattlerFontFace:str":"","EnemyBattlerFontSize:num":"16","Background":"","ShowMarkerBg:eval":"true","BackgroundActor":"","ActorBgColor1:str":"19","ActorBgColor2:str":"9","ActorSystemBg:str":"","BackgroundEnemy":"","EnemyBgColor1:str":"19","EnemyBgColor2:str":"18","EnemySystemBg:str":""}
 *
 * @param BreakEnd1
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param End Of
 * @default Plugin Parameters
 *
 * @param BreakEnd2
 * @text --------------------------
 * @default ----------------------------------
 *
 */
/* ----------------------------------------------------------------------------
 * Mechanics Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Mechanics:
 *
 * @param General
 *
 * @param DeviceFriendly:eval
 * @text Device Friendly
 * @parent General
 * @type boolean
 * @on Device Friendly
 * @off For Desktops
 * @desc Make the calculations more device friendly?
 * Or make it for desktop at full strength?
 * @default false
 * 
 * @param EscapeFailPenalty:num
 * @text Escape Fail Penalty
 * @parent General
 * @desc Gauge penalty if an escape attempt fails.
 * @default -1.00
 *
 * @param JavaScript
 *
 * @param InitialGaugeJS:str
 * @text JS: Initial Speed
 * @parent JavaScript
 * @desc JavaScript code to determine how much speed to give
 * each battler at the start of battle.
 * @default Math.random() * 0.5
 *
 * @param TpbSpeedCalcJS:func
 * @text JS: Speed
 * @parent JavaScript
 * @type note
 * @desc JavaScript code to determine how much speed a battler has.
 * @default "// Declare Constants\nconst user = this;\n\n// Process Calculation\nlet speed = Math.sqrt(user.agi) + 1;\n\n// Return Value\nreturn speed;"
 * 
 * @param TpbBaseSpeedCalcJS:func
 * @text JS: Base Speed
 * @parent JavaScript
 * @type note
 * @desc JavaScript code to determine how much base speed a battler has.
 * @default "// Declare Constants\nconst user = this;\nconst baseAgility = user.paramBasePlus(6);\n\n// Process Calculation\nlet speed = Math.sqrt(baseAgility) + 1;\n\n// Return Value\nreturn speed;"
 * 
 * @param BattlerRelativeSpeedJS:func
 * @text JS: Relative Speed
 * @parent JavaScript
 * @type note
 * @desc JavaScript code to determine what is the relative speed of a battler.
 * @default "// Declare Constants\nconst user = this;\nconst speed = user.tpbSpeed()\nconst partyBaseSpeed = $gameParty.tpbBaseSpeed();\n\n// Process Calculation\nlet relativeSpeed = speed / partyBaseSpeed;\n\n// Return Value\nreturn relativeSpeed;"
 * 
 * @param TpbAccelerationJS:func
 * @text JS: Acceleration
 * @parent JavaScript
 * @type note
 * @desc JavaScript code to determine how much gauges accelerate by relative to reference time.
 * @default "// Declare Constants\nconst user = this;\nconst speed = user.tpbRelativeSpeed();\nconst referenceTime = $gameParty.tpbReferenceTime();\n\n// Process Calculation\nlet acceleration = speed / referenceTime;\n\n// Return Value\nreturn acceleration;"
 * 
 * @param TpbCastTimeJS:func
 * @text JS: Cast Time
 * @parent JavaScript
 * @type note
 * @desc JavaScript code to determine how much cast time is used for skills/items with negative speed modifiers.
 * @default "// Declare Constants\nconst user = this;\nconst actions = user._actions.filter(action => action.isValid());\nconst items = actions.map(action => action.item());\nconst delay = items.reduce((r, item) => r + Math.max(0, -item.speed), 0);\n\n// Process Calculation\nlet time = Math.sqrt(delay) / user.tpbSpeed();\n\n// Return Value\nreturn time;"
 * 
 */
/* ----------------------------------------------------------------------------
 * Effect Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Effect:
 *
 * @param Delay
 * @text Delay Turn Order
 * 
 * @param DelayAnimation
 * @text Animation
 * @parent Delay
 *
 * @param DelayAnimationID:num
 * @text Animation ID
 * @parent DelayAnimation
 * @type animation
 * @desc Play this animation when the effect activates.
 * Occurs when the turn order is delayed.
 * @default 54
 *
 * @param DelayMirror:eval
 * @text Mirror Animation
 * @parent DelayAnimation
 * @type boolean
 * @on Mirror
 * @off Normal
 * @desc Mirror the effect animation?
 * Occurs when the turn order is delayed.
 * @default false
 *
 * @param DelayMute:eval
 * @text Mute Animation
 * @parent DelayAnimation
 * @type boolean
 * @on Mute
 * @off Normal
 * @desc Mute the effect animation?
 * Occurs when the turn order is delayed.
 * @default false
 *
 * @param DelayPopups
 * @text Popups
 * @parent Delay
 *
 * @param DelayPopupText:str
 * @text Text
 * @parent DelayPopups
 * @desc Text displayed upon the effect activating.
 * Occurs when the turn order is delayed.
 * @default DELAY
 *
 * @param DelayTextColor:str
 * @text Text Color
 * @parent DelayPopups
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 25
 *
 * @param DelayFlashColor:eval
 * @text Flash Color
 * @parent DelayPopups
 * @desc Adjust the popup's flash color.
 * Format: [red, green, blue, alpha]
 * @default [255, 0, 0, 160]
 * 
 * @param DelayFlashDuration:num
 * @text Flash Duration
 * @parent DelayPopups
 * @type number
 * @desc What is the frame duration of the flash effect?
 * @default 60
 *
 * @param Rush
 * @text Rush Turn Order
 * 
 * @param RushAnimation
 * @text Animation
 * @parent Rush
 *
 * @param RushAnimationID:num
 * @text Animation ID
 * @parent RushAnimation
 * @type animation
 * @desc Play this animation when the effect activates.
 * Occurs when the turn order is rushed.
 * @default 51
 *
 * @param RushMirror:eval
 * @text Mirror Animation
 * @parent RushAnimation
 * @type boolean
 * @on Mirror
 * @off Normal
 * @desc Mirror the effect animation?
 * Occurs when the turn order is rushed.
 * @default false
 *
 * @param RushMute:eval
 * @text Mute Animation
 * @parent RushAnimation
 * @type boolean
 * @on Mute
 * @off Normal
 * @desc Mute the effect animation?
 * Occurs when the turn order is rushed.
 * @default false
 *
 * @param RushPopups
 * @text Popups
 * @parent Rush
 *
 * @param RushPopupText:str
 * @text Text
 * @parent RushPopups
 * @desc Text displayed upon the effect activating.
 * Occurs when the turn order is rushed.
 * @default RUSH
 *
 * @param RushTextColor:str
 * @text Text Color
 * @parent RushPopups
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 24
 *
 * @param RushFlashColor:eval
 * @text Flash Color
 * @parent RushPopups
 * @desc Adjust the popup's flash color.
 * Format: [red, green, blue, alpha]
 * @default [0, 255, 0, 160]
 * 
 * @param RushFlashDuration:num
 * @text Flash Duration
 * @parent RushPopups
 * @type number
 * @desc What is the frame duration of the flash effect?
 * @default 60
 *
 */
/* ----------------------------------------------------------------------------
 * Turn Order Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~TurnOrder:
 *
 * @param General
 *
 * @param DisplayPosition:str
 * @text Display Position
 * @parent General
 * @type select
 * @option top
 * @option bottom
 * @option left
 * @option right
 * @desc Select where the Turn Order will appear on the screen.
 * @default top
 * 
 * @param DisplayOffsetX:num
 * @text Offset X
 * @parent DisplayPosition:str
 * @desc How much to offset the X coordinate by.
 * Negative: left. Positive: right.
 * @default 0
 * 
 * @param DisplayOffsetY:num
 * @text Offset Y
 * @parent DisplayPosition:str
 * @desc How much to offset the Y coordinate by.
 * Negative: up. Positive: down.
 * @default 0
 *
 * @param RepositionTopForHelp:eval
 * @text Reposition for Help?
 * @parent DisplayPosition:str
 * @type boolean
 * @on Reposition
 * @off Stay
 * @desc If the display position is at the top, reposition the
 * display when the help window is open?
 * @default true
 *
 * @param RepositionLogWindow:eval
 * @text Reposition Log?
 * @parent DisplayPosition:str
 * @type boolean
 * @on Reposition
 * @off Stay
 * @desc If the display position is at the top, reposition the
 * Battle Log Window to be lower?
 * @default true
 *
 * @param OrderDirection:eval
 * @text Forward Direction
 * @parent General
 * @type boolean
 * @on Left to Right / Down to Up
 * @off Right to Left / Up to Down
 * @desc Decide on the direction of the Turn Order.
 * Settings may vary depending on position.
 * @default true
 *
 * @param SubjectDistance:num
 * @text Subject Distance
 * @parent General
 * @type number
 * @desc How far do you want the currently active battler to
 * distance itself from the rest of the Turn Order?
 * @default 8
 *
 * @param ScreenBuffer:num
 * @text Screen Buffer
 * @parent General
 * @type number
 * @desc What distance do you want the display to be away
 * from the edge of the screen by?
 * @default 20
 * 
 * @param Reposition
 * @text Reposition For Help
 *
 * @param RepositionTopHelpX:num
 * @text Repostion X By
 * @parent Reposition
 * @desc Reposition the display's X coordinates by this much when
 * the Help Window is visible.
 * @default 0
 *
 * @param RepositionTopHelpY:num
 * @text Repostion Y By
 * @parent Reposition
 * @desc Reposition the display's Y coordinates by this much when
 * the Help Window is visible.
 * @default 96
 * 
 * @param Slots
 *
 * @param TotalHorzSprites:num
 * @text Total Horizontal
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many slots do you want to display for top and
 * bottom Turn Order Display positions?
 * @default 16
 *
 * @param TotalVertSprites:num
 * @text Total Vertical
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many slots do you want to display for left and
 * right Turn Order Display positions?
 * @default 10
 *
 * @param SpriteLength:num
 * @text Length
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many pixels long should the slots be on the
 * Turn Order display?
 * @default 72
 *
 * @param SpriteThin:num
 * @text Thin
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many pixels thin should the slots be on the
 * Turn Order display?
 * @default 36
 *
 * @param UpdateFrames:num
 * @text Update Frames
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many frames should it take for the slots to
 * update their positions by?
 * @default 24
 *
 * @param Border
 * @text Slot Border
 *
 * @param ShowMarkerBorder:eval
 * @text Show Border?
 * @parent Border
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show borders for the slot sprites?
 * @default true
 *
 * @param BorderThickness:num
 * @text Border Thickness
 * @parent Markers
 * @type number
 * @min 1
 * @desc How many pixels thick should the colored portion of the border be?
 * @default 2
 *
 * @param BorderActor
 * @text Actors
 * @parent Border
 *
 * @param ActorBorderColor:str
 * @text Border Color
 * @parent BorderActor
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 4
 *
 * @param ActorSystemBorder:str
 * @text Border Skin
 * @parent BorderActor
 * @type file
 * @dir img/system/
 * @desc Optional. Place a skin on the actor borders instead of rendering them?
 * @default 
 *
 * @param BorderEnemy
 * @text Enemies
 * @parent Border
 *
 * @param EnemyBorderColor:str
 * @text Border Color
 * @parent BorderEnemy
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 2
 *
 * @param EnemySystemBorder:str
 * @text Border Skin
 * @parent BorderEnemy
 * @type file
 * @dir img/system/
 * @desc Optional. Place a skin on the enemy borders instead of rendering them?
 * @default 
 *
 * @param Sprite
 * @text Slot Sprites
 *
 * @param ActorSprite
 * @text Actors
 * @parent Sprite
 *
 * @param ActorBattlerType:str
 * @text Sprite Type
 * @parent ActorSprite
 * @type select
 * @option Face Graphic - Show the actor's face.
 * @value face
 * @option Icon - Show a specified icon.
 * @value icon
 * @option Sideview Actor - Show the actor's sideview battler.
 * @value svactor
 * @desc Select the type of sprite used for the actor graphic.
 * @default face
 *
 * @param ActorBattlerIcon:num
 * @text Default Icon
 * @parent ActorSprite
 * @desc Which icon do you want to use for actors by default?
 * @default 84
 *
 * @param EnemySprite
 * @text Enemies
 * @parent Sprite
 *
 * @param EnemyBattlerType:str
 * @text Sprite Type
 * @parent EnemySprite
 * @type select
 * @option Face Graphic - Show a specified face graphic.
 * @value face
 * @option Icon - Show a specified icon.
 * @value icon
 * @option Enemy - Show the enemy's graphic or sideview battler.
 * @value enemy
 * @desc Select the type of sprite used for the enemy graphic.
 * @default enemy
 *
 * @param EnemyBattlerFaceName:str
 * @text Default Face Name
 * @parent EnemySprite
 * @type file
 * @dir img/faces/
 * @desc Use this default face graphic if there is no specified face.
 * @default Monster
 *
 * @param EnemyBattlerFaceIndex:num
 * @text Default Face Index
 * @parent EnemySprite
 * @type number
 * @desc Use this default face index if there is no specified index.
 * @default 1
 *
 * @param EnemyBattlerIcon:num
 * @text Default Icon
 * @parent EnemySprite
 * @desc Which icon do you want to use for enemies by default?
 * @default 298
 *
 * @param EnemyBattlerMatchHue:eval
 * @text Match Hue?
 * @parent EnemySprite
 * @type boolean
 * @on Match
 * @off Don't Match
 * @desc Match the hue for enemy battlers?
 * Does not apply if there's a sideview battler.
 * @default true
 *
 * @param Letter
 * @text Slot Letter
 *
 * @param EnemyBattlerDrawLetter:eval
 * @text Show Enemy Letter?
 * @parent Letter
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show the enemy's letter on the slot sprite?
 * @default true
 *
 * @param EnemyBattlerFontFace:str
 * @text Font Name
 * @parent Letter
 * @desc The font name used for the text of the Letter.
 * Leave empty to use the default game's font.
 * @default 
 *
 * @param EnemyBattlerFontSize:num
 * @text Font Size
 * @parent Letter
 * @min 1
 * @desc The font size used for the text of the Letter.
 * @default 16
 *
 * @param Background
 * @text Slot Background
 *
 * @param ShowMarkerBg:eval
 * @text Show Background?
 * @parent Background
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show the background on the slot sprite?
 * @default true
 *
 * @param BackgroundActor
 * @text Actors
 * @parent Background
 *
 * @param ActorBgColor1:str
 * @text Background Color 1
 * @parent BackgroundActor
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 19
 *
 * @param ActorBgColor2:str
 * @text Background Color 2
 * @parent BackgroundActor
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 9
 *
 * @param ActorSystemBg:str
 * @text Background Skin
 * @parent BackgroundActor
 * @type file
 * @dir img/system/
 * @desc Optional. Use a skin for the actor background instead of rendering them?
 * @default 
 *
 * @param BackgroundEnemy
 * @text Enemies
 * @parent Background
 *
 * @param EnemyBgColor1:str
 * @text Background Color 1
 * @parent BackgroundEnemy
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 19
 *
 * @param EnemyBgColor2:str
 * @text Background Color 2
 * @parent BackgroundEnemy
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 18
 *
 * @param EnemySystemBg:str
 * @text Background Skin
 * @parent BackgroundEnemy
 * @type file
 * @dir img/system/
 * @desc Optional. Use a skin for the enemy background instead of rendering them?
 * @default 
 *
 */
//=============================================================================

function _0x3c53(){const _0x31e866=['iIfkG','iconWidth','KIqgp','CWqQK','CtbTurnOrderActorFace','isTpbReady','TpbBaseSpeedCalcJS','763217kzjKRq','Enemies','TpbAccelerationJS','checkOpacity','xXKYF','match','nqPQb','Game_Battler_initTpbChargeTime','processCtbAntiSoftlock','BattlerRelativeSpeedJS','hzadr','JXzNq','lGWJs','min','wUehf','processTurnOrderChangeCTB','ParseSkillNotetags','registerCommand','includes','_blendColor','changeCtbCastTime','wngat','setTurnOrderCTB','createOrderJS','applyBattleSystemCTBUserEffect','description','AmXSE','JUnZj','_subject','battleSys','SubjectDistance','dCnIH','%1BgColor1','%1SystemBg','%1\x27s\x20version\x20does\x20not\x20match\x20plugin\x27s.\x20Please\x20update\x20it\x20in\x20the\x20Plugin\x20Manager.','#000000','Cast','DisplayPosition','axPJy','currentAction','TpbSpeedCalcJS','opacity','AMbDK','processUpdateGraphic','Game_Battler_tpbRequiredCastTime','faceIndex','91JWeWhW','_helpWindow','CtbTurnOrderEnemyFace','center','getCtbCastTimeRate','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20//\x20Declare\x20Variables\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20user\x20=\x20arguments[0];\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20target\x20=\x20arguments[1];\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20keyType\x20=\x20\x27%2\x27;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20let\x20position\x20=\x20target.getCurrentTurnOrderPositionCTB();\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20let\x20order\x20=\x20position;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20//\x20Process\x20Code\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20try\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20%1\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x20catch\x20(e)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if\x20($gameTemp.isPlaytest())\x20console.log(e);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20//\x20NaN\x20Check\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if\x20(isNaN(order)){\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if\x20($gameTemp.isPlaytest())\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20console.log(\x27NaN\x20rate\x20created\x20by\x20%2\x27.format(\x27\x27,obj.name));\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20console.log(\x27Restoring\x20rate\x20to\x20%2\x27.format(\x27\x27,originalValue));\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20order\x20=\x20position;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20//\x20Return\x20Value\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20order;\x0a\x20\x20\x20\x20\x20\x20\x20\x20','bitmapHeight','isDead','getCurrentTurnOrderPositionCTB','hide','RepositionTopHelpY','oVqDb','filter','oxnbN','clearTpbChargeTimeCTB','createChildren','isCtbChargingState','numActions','CtbTurnOrderEnemyIcon','_graphicIconIndex','createKeyJS','313161sQtTrO','DeviceFriendly','tpbChargeTime','initMembers','Game_Battler_tpbSpeed','onRestrict','updateAllTpbBattlers','DisplayOffsetY','svactor','version','item','BattleSystemCTB','mainFontFace','fillRect','rxyfo','_backgroundSprite','Game_Battler_updateTpb','yDyZF','_dupe','BattleManager_isActiveTpb','EnemyBattlerFaceIndex','removeCurrentAction','Scene_Boot_onDatabaseLoaded','face','SilEd','bXylb','_graphicEnemy','MAX_SAFE_INTEGER','FaceName','right','NUM','Game_Battler_updateTpbCastTime','CtbTurnOrderClearEnemyGraphic','XTnEz','isSceneBattle','startFade','setCTBGraphicIconIndex','PGcoC','isActiveTpb','Fwsbr','ARRAYEVAL','_plural','Charge','createBattlerSprites','initialize','process_VisuMZ_BattleSystemCTB_CreateRegExp','InitialGaugeJS','updateOpacity','tpbAcceleration','%1PopupText','updatePosition','isPassCTB','BXIdy','BattleManager_isTpb','TurnOrderCTBGraphicFaceName','nLpzL','RepositionTopHelpX','width','_positionDuration','round','isActing','updateTpbCastTimeCTB','initBattleSystemCTB','YZhuo','isHorz','createBorderSprite','casting','Ticks\x20to\x20Goal:\x20','processTurnCTB','Game_BattlerBase_appear','sort','CtbTurnOrderClearActorGraphic','status','fontFace','oRJDT','_graphicFaceName','updateTurnOrder','_position','changeFaceGraphicBitmap','NlmRO','6SgDrbb','battlerName','EVAL','fontSize','_letter','TurnOrder','ctbTicksToGoal','NbwZR','_letterSprite','RegExp','rotateDupeNumber','EnemyBattlerIcon','containerWindow','createCTBTurnOrderWindow','Armor-%1-%2','Effect','createTurnOrderCTBGraphicType','BattleManager_endAction','pRXdF','repositionLogWindowCTB','isSideView','XpSBw','Skill-%1-%2','viniy','updateTpb','KugaR','constructor','createLetterSprite','rotateCTBSprites','%1AnimationID','_tpbIdleTime','EvFQs','3612897HYusuE','updateAllTpbBattlersCTB','%1Mirror','updateTurn','onDatabaseLoaded','addChildAt','SpriteLength','(?:CTB)','processAbort','ticksLeft','cEymv','name','Game_Battler_applyTpbPenalty','_actionBattlers','EnemyBattlerFontSize','onCtbOrderChange','wWkmX','WPDPZ','185XPyrYA','updateGraphic','onTpbCharged','%1Mute','applyTpbPenalty','PpCmF','toUpperCase','25139410kdkZoS','bhgNg','setText','<JS\x20%2\x20%1\x20%3>\x5cs*([\x5cs\x5cS]*)\x5cs*<\x5c/JS\x20%2\x20%1\x20%3>','_fadeTarget','clearTpbChargeTime','ParseItemNotetags','return\x200','bcjVB','yDyni','BattleManager_battleSys','%1BgColor2','_ctbTurnOrderVisible','note','JSON','anchor','PFFaK','isPlaytest','TurnOrderCTBGraphicType','_turnOrderContainer','BGheL','Game_Battler_tpbAcceleration','push','bind','Parse_Notetags_CreateJS','startBattle','Game_Battler_clearTpbChargeTime','Bunui','concat','getColor','isAppeared','Item-%1-%2','onBattleStart','TotalHorzSprites','ConvertParams','faceWidth','faceHeight','Game_Battler_updateTpbIdleTime','Scene_Battle_createAllWindows','UpdateFrames','_fadeDuration','applyItemBattleSystemCTBUserEffect','FENFV','_debutCTB','39608AyyzIc','_autoBattle','%1SystemBorder','dCFtT','createBackgroundSprite','Mechanics','_ctbTurnOrderFaceIndex','_unit','prototype','loadSvEnemy','tpbRelativeSpeed','isInputting','applyGlobalBattleSystemCTBEffects','updateTpbIdleTime','logCtbData','_actionState','svActorHorzCells','2781016sGKeKm','exit','enemy','Class-%1-%2','Actors','iEvAx','endAction','boxWidth','BattleManager_startBattle','_graphicSv','Enemy','bitmapWidth','changeTurnOrderByCTB','createAllWindows','BorderThickness','getBattleSystem','PtSiR','nxuos','IconIndex','updateVisibility','CTB','changeIconGraphicBitmap','othEF','_onRestrictBypassCtbReset','acting','members','createInitialPositions','addInnerChild','svActorVertCells','blt','TurnOrderCTBGraphicFaceIndex','isCtbCastingState','HJzie','LHgUL','update','icon','addLoadListener','allBattleMembers','clearTurnOrderCTBGraphics','Settings','Game_System_initialize','FOJKJ','map','_ctbAfterSpeed','ready','_tpbCastTime','max','initTpbChargeTimeCTB','maxBattleMembers','setBattleSystemCTBTurnOrderVisible','cumgD','VisuMZ_0_CoreEngine','applyItemUserEffect','log','loadEnemy','isAlive','time','EnemyBattlerFaceName','updateTpbIdleTimeCTB','_ctbTurnOrderFaceName','_graphicFaceIndex','startAction','CPeQi','xcqCS','postEndActionCTB','RepositionTopForHelp','XxNOK','BattleManager_updateTurn','speed','UqBQs','changeSvActorGraphicBitmap','hqWsl','ctbHasInstantActionAfter','getChildIndex','KhoyO','_logWindow','_ogWindowLayerX','svBattlerName','reduce','setCtbChargeTime','battlerHue','bitmap','YFZAs','isActor','YkSVj','mainSprite','%1FlashDuration','%1BorderColor','CtbTurnOrderActorIcon','iconHeight','faceName','windowRect','height','turn','WLBzL','compareBattlerSprites','iEiFN','_ogWindowLayerY','applyGlobal','isCTB','IconSet','addChild','_tpbTurnCount','actor','bBOjb','checkCtbAntiSoftlock','STRUCT','createRateJS','DisplayOffsetX','Weapon-%1-%2','_index','_isAlive','After','TwkcR','iqLot','_homeX','drawText','isCommonEventReserved','Enemy-%1-%2','%1TextColor','11oObCLE','charging','setCtbAfterSpeed','getStateTooltipBattler','ARRAYSTR','removeBattleStates','_ctbTurnOrderWindow','_isBattleOver','_tpbState','skills','UjxlY','_isAppeared','battler','Game_BattlerBase_hide','XdYYJ','_positionTargetY','_forcing','ActorBattlerIcon','ARRAYJSON','isAttack','indexOf','TurnOrderCTBGraphicIconIndex','hasSvBattler','checkPosition','setItem','createTurnOrderCTBGraphicIconIndex','FUNC','Visible','floor','tpbRequiredCastTime','create','VkJwT','OrderJS','VGexQ','subject','gradientFillRect','EnemyBattlerFontFace','tpbBaseSpeed','top','_anti_CTB_SoftlockCount','clamp','battleEnd','updateTpbChargeTimeCTB','eCzFE','_statusWindow','YImxM','setActionState','_graphicType','applyCTBPenalty','isValid','bottom','_inputting','ShowMarkerBorder','traitObjects','OrderDirection','LOUny','_graphicSprite','isAnyBattlerReadyCTB','loadSvActor','createGraphicSprite','_graphicHue','Game_Action_applyGlobal','canMove','updateSelectionEffect','createTurnOrderCTBGraphicFaceName','Fjcqz','ceil','boxHeight','Game_Action_applyItemUserEffect','format','Window_StatusBase_placeGauge','zFguA','Game_Battler_updateTpbChargeTime','_windowLayer','prepare','visible','changeEnemyGraphicBitmap','clear','call','oIcMs','Actor-%1-%2','EnemyBattlerDrawLetter','isTpb','liAPV','_positionTargetX','loadSystem','tpbSpeed','updateBattleContainerOrder','_phase','vYrHM','requestFauxAnimation','parse','_homeY','ActorBattlerType','preEndActionCTB','process_VisuMZ_BattleSystemCTB_JS_Notetags','TpbCastTimeJS','setHue','updateTpbCastTime','isEnemy','containerPosition','(?:GAUGE|TIME|SPEED)','171156MyZDXG','xDodM','lePiK','_tpbChargeTime','processTurn','RepositionLogWindow','clearStates','trim','LaSyE','createTurnOrderCTBGraphicFaceIndex','ASwdQ','updateTurnOrderCTB','ScreenBuffer','setCtbCastTime','_turnOrderInnerSprite','BattleManager_updateAllTpbBattlers','defaultPosition','SpriteThin','find','Aborting\x20Battle.\x20Softlock\x20cannot\x20be\x20fixed.','Delay','aYuNa','updateTurnCTB','length','fjdTn','PxVeo','EEEha','Actor','changeCtbChargeTime','ARRAYFUNC','Game_Battler_tpbRelativeSpeed','children','TotalVertSprites','ParseAllNotetags','BattleManager_processTurn','setupTextPopup','Window_Help_setItem','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20//\x20Declare\x20Variables\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20user\x20=\x20arguments[0];\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20target\x20=\x20arguments[1];\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20keyType\x20=\x20\x27%2\x27;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20let\x20rate\x20=\x200;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if\x20(keyType\x20===\x20\x27Charge\x27)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20rate\x20=\x20target._tpbChargeTime;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x20else\x20if\x20(keyType\x20===\x20\x27Cast\x27)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20rate\x20=\x20target._tpbCastTime\x20/\x20Math.max(target.tpbRequiredCastTime(),\x201);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20let\x20originalValue\x20=\x20rate;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20//\x20Process\x20Code\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20try\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20%1\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x20catch\x20(e)\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if\x20($gameTemp.isPlaytest())\x20console.log(e);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20//\x20NaN\x20Check\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if\x20(isNaN(rate)){\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20if\x20($gameTemp.isPlaytest())\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20console.log(\x27NaN\x20rate\x20created\x20by\x20%2\x27.format(\x27\x27,obj.name));\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20console.log(\x27Restoring\x20rate\x20to\x20%2\x27.format(\x27\x27,originalValue));\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20rate\x20=\x20originalValue;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20//\x20Return\x20Value\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20return\x20rate;\x0a\x20\x20\x20\x20\x20\x20\x20\x20','undecided','_ctbTurnOrderGraphicType','STR','jBciF','some','_scene','otherCtbChecksPassed','qFVjv','Order','padding','RlUKl','MIN_SAFE_INTEGER','FaceIndex','placeGauge','_ctbTurnOrderIconIndex'];_0x3c53=function(){return _0x31e866;};return _0x3c53();}const _0x485a45=_0x50fa;function _0x50fa(_0x44e993,_0x389d9a){const _0x3c53be=_0x3c53();return _0x50fa=function(_0x50fa19,_0x28adb9){_0x50fa19=_0x50fa19-0x13e;let _0x70e38c=_0x3c53be[_0x50fa19];return _0x70e38c;},_0x50fa(_0x44e993,_0x389d9a);}(function(_0x4c5475,_0x13dde7){const _0x2b4552=_0x50fa,_0x503819=_0x4c5475();while(!![]){try{const _0x39bdf2=-parseInt(_0x2b4552(0x22a))/0x1+parseInt(_0x2b4552(0x2bd))/0x2*(-parseInt(_0x2b4552(0x26d))/0x3)+parseInt(_0x2b4552(0x333))/0x4+-parseInt(_0x2b4552(0x2ef))/0x5*(parseInt(_0x2b4552(0x1ee))/0x6)+parseInt(_0x2b4552(0x258))/0x7*(-parseInt(_0x2b4552(0x322))/0x8)+-parseInt(_0x2b4552(0x2dd))/0x9+-parseInt(_0x2b4552(0x2f6))/0xa*(-parseInt(_0x2b4552(0x188))/0xb);if(_0x39bdf2===_0x13dde7)break;else _0x503819['push'](_0x503819['shift']());}catch(_0x5190a4){_0x503819['push'](_0x503819['shift']());}}}(_0x3c53,0x954e7));var label='BattleSystemCTB',tier=tier||0x0,dependencies=[_0x485a45(0x143),'VisuMZ_1_BattleCore'],pluginData=$plugins['filter'](function(_0x489b71){const _0xb02674=_0x485a45;return _0x489b71[_0xb02674(0x2b5)]&&_0x489b71['description'][_0xb02674(0x23c)]('['+label+']');})[0x0];VisuMZ[label]['Settings']=VisuMZ[label][_0x485a45(0x35a)]||{},VisuMZ[_0x485a45(0x318)]=function(_0x4c94c5,_0x897ac){const _0xc80524=_0x485a45;for(const _0xf3fdf9 in _0x897ac){if(_0xf3fdf9[_0xc80524(0x22f)](/(.*):(.*)/i)){if(_0xc80524(0x15a)!==_0xc80524(0x181)){const _0x3581de=String(RegExp['$1']),_0x2fb151=String(RegExp['$2'])[_0xc80524(0x2f5)]()[_0xc80524(0x1f5)]();let _0x3a3b4b,_0x812b5f,_0x4fcdff;switch(_0x2fb151){case _0xc80524(0x28b):_0x3a3b4b=_0x897ac[_0xf3fdf9]!==''?Number(_0x897ac[_0xf3fdf9]):0x0;break;case'ARRAYNUM':_0x812b5f=_0x897ac[_0xf3fdf9]!==''?JSON['parse'](_0x897ac[_0xf3fdf9]):[],_0x3a3b4b=_0x812b5f[_0xc80524(0x35d)](_0x1b31fb=>Number(_0x1b31fb));break;case _0xc80524(0x2bf):_0x3a3b4b=_0x897ac[_0xf3fdf9]!==''?eval(_0x897ac[_0xf3fdf9]):null;break;case _0xc80524(0x295):_0x812b5f=_0x897ac[_0xf3fdf9]!==''?JSON[_0xc80524(0x1e3)](_0x897ac[_0xf3fdf9]):[],_0x3a3b4b=_0x812b5f['map'](_0x2d0ef6=>eval(_0x2d0ef6));break;case _0xc80524(0x304):_0x3a3b4b=_0x897ac[_0xf3fdf9]!==''?JSON[_0xc80524(0x1e3)](_0x897ac[_0xf3fdf9]):'';break;case _0xc80524(0x19a):_0x812b5f=_0x897ac[_0xf3fdf9]!==''?JSON[_0xc80524(0x1e3)](_0x897ac[_0xf3fdf9]):[],_0x3a3b4b=_0x812b5f[_0xc80524(0x35d)](_0x1292ef=>JSON['parse'](_0x1292ef));break;case _0xc80524(0x1a2):_0x3a3b4b=_0x897ac[_0xf3fdf9]!==''?new Function(JSON['parse'](_0x897ac[_0xf3fdf9])):new Function(_0xc80524(0x2fd));break;case _0xc80524(0x20b):_0x812b5f=_0x897ac[_0xf3fdf9]!==''?JSON[_0xc80524(0x1e3)](_0x897ac[_0xf3fdf9]):[],_0x3a3b4b=_0x812b5f[_0xc80524(0x35d)](_0x512dc4=>new Function(JSON['parse'](_0x512dc4)));break;case _0xc80524(0x216):_0x3a3b4b=_0x897ac[_0xf3fdf9]!==''?String(_0x897ac[_0xf3fdf9]):'';break;case _0xc80524(0x18c):_0x812b5f=_0x897ac[_0xf3fdf9]!==''?JSON[_0xc80524(0x1e3)](_0x897ac[_0xf3fdf9]):[],_0x3a3b4b=_0x812b5f[_0xc80524(0x35d)](_0x52d688=>String(_0x52d688));break;case _0xc80524(0x17a):_0x4fcdff=_0x897ac[_0xf3fdf9]!==''?JSON['parse'](_0x897ac[_0xf3fdf9]):{},_0x3a3b4b=VisuMZ[_0xc80524(0x318)]({},_0x4fcdff);break;case'ARRAYSTRUCT':_0x812b5f=_0x897ac[_0xf3fdf9]!==''?JSON[_0xc80524(0x1e3)](_0x897ac[_0xf3fdf9]):[],_0x3a3b4b=_0x812b5f['map'](_0x341207=>VisuMZ[_0xc80524(0x318)]({},JSON[_0xc80524(0x1e3)](_0x341207)));break;default:continue;}_0x4c94c5[_0x3581de]=_0x3a3b4b;}else{if(this[_0xc80524(0x246)])return!![];if(this[_0xc80524(0x1e0)]!==_0xc80524(0x16d))return!![];if(this[_0xc80524(0x323)])return![];const _0xdddf27=this['allBattleMembers']()[_0xc80524(0x264)](_0x52ae92=>_0x52ae92&&_0x52ae92['isAppeared']());return _0xdddf27[_0xc80524(0x218)](_0x54a2cb=>_0x54a2cb['isPassCTB']());}}}return _0x4c94c5;},(_0x22d26d=>{const _0x25eb9c=_0x485a45,_0x43db1b=_0x22d26d['name'];for(const _0x4d9f23 of dependencies){if(!Imported[_0x4d9f23]){if(_0x25eb9c(0x294)!==_0x25eb9c(0x294))return _0x193d0f[_0x25eb9c(0x35a)][_0x25eb9c(0x149)];else{alert('%1\x20is\x20missing\x20a\x20required\x20plugin.\x0aPlease\x20install\x20%2\x20into\x20the\x20Plugin\x20Manager.'[_0x25eb9c(0x1cd)](_0x43db1b,_0x4d9f23)),SceneManager[_0x25eb9c(0x334)]();break;}}}const _0x124fa4=_0x22d26d[_0x25eb9c(0x243)];if(_0x124fa4['match'](/\[Version[ ](.*?)\]/i)){if(_0x25eb9c(0x230)===_0x25eb9c(0x155))_0x438ead[_0x25eb9c(0x18d)](),_0x4dc00d[_0x25eb9c(0x18d)][_0x25eb9c(0x1d6)](_0x25cccf);else{const _0x531b32=Number(RegExp['$1']);if(_0x531b32!==VisuMZ[label][_0x25eb9c(0x276)]){if('FDbfS'!==_0x25eb9c(0x27e))alert(_0x25eb9c(0x24c)[_0x25eb9c(0x1cd)](_0x43db1b,_0x531b32)),SceneManager[_0x25eb9c(0x334)]();else{const _0x1c065b=this[_0x25eb9c(0x14c)],_0x25de73=this[_0x25eb9c(0x33e)](),_0x22a30a=this['bitmapHeight'](),_0xa9a3b8=_0x53bbaf['max'](_0x25de73,_0x22a30a);this[_0x25eb9c(0x1c0)]['bitmap']=new _0x458223(_0x25de73,_0x22a30a);const _0x35d9a3=this[_0x25eb9c(0x1c0)][_0x25eb9c(0x161)],_0x227b4c=_0x7c7786[_0x25eb9c(0x319)],_0x584e6f=_0x4e4433[_0x25eb9c(0x31a)],_0x1f9c4c=_0xa9a3b8/_0x2a193b['max'](_0x227b4c,_0x584e6f),_0x343e67=_0x50524f['faceWidth'],_0x5296ab=_0x71db44['faceHeight'],_0x4352f1=_0x1c065b%0x4*_0x227b4c+(_0x227b4c-_0x343e67)/0x2,_0x4c60de=_0x1df3a7[_0x25eb9c(0x1a4)](_0x1c065b/0x4)*_0x584e6f+(_0x584e6f-_0x5296ab)/0x2,_0x15ba08=(_0x25de73-_0x227b4c*_0x1f9c4c)/0x2,_0x360c91=(_0x22a30a-_0x584e6f*_0x1f9c4c)/0x2;_0x35d9a3['blt'](_0x520355,_0x4352f1,_0x4c60de,_0x343e67,_0x5296ab,_0x15ba08,_0x360c91,_0xa9a3b8,_0xa9a3b8);}}}}if(_0x124fa4[_0x25eb9c(0x22f)](/\[Tier[ ](\d+)\]/i)){const _0x5e99c2=Number(RegExp['$1']);_0x5e99c2<tier?(alert('%1\x20is\x20incorrectly\x20placed\x20on\x20the\x20plugin\x20list.\x0aIt\x20is\x20a\x20Tier\x20%2\x20plugin\x20placed\x20over\x20other\x20Tier\x20%3\x20plugins.\x0aPlease\x20reorder\x20the\x20plugin\x20list\x20from\x20smallest\x20to\x20largest\x20tier\x20numbers.'[_0x25eb9c(0x1cd)](_0x43db1b,_0x5e99c2,tier)),SceneManager['exit']()):tier=Math[_0x25eb9c(0x13e)](_0x5e99c2,tier);}VisuMZ[_0x25eb9c(0x318)](VisuMZ[label]['Settings'],_0x22d26d['parameters']);})(pluginData),PluginManager[_0x485a45(0x23b)](pluginData[_0x485a45(0x2e8)],_0x485a45(0x168),_0x972ac5=>{const _0x4580c=_0x485a45;VisuMZ[_0x4580c(0x318)](_0x972ac5,_0x972ac5);const _0x57a681=_0x972ac5[_0x4580c(0x337)],_0x2382ae=_0x972ac5['IconIndex'];for(const _0x14c7da of _0x57a681){if(_0x4580c(0x245)===_0x4580c(0x170)){const _0x3fd39e=this[_0x4580c(0x1ec)]();if(this[_0x4580c(0x2ba)]===_0x3fd39e)return;this['_position']=_0x3fd39e;const _0x12589f=_0x402ac3['Settings'],_0x30c895=this[_0x4580c(0x2ad)](),_0x48928c=_0x12589f[_0x4580c(0x1be)],_0x22c951=_0x12589f['SubjectDistance'],_0x11109c=_0x58a1e4[_0x4580c(0x219)][_0x4580c(0x18e)];if(!_0x11109c)return;this[_0x4580c(0x2a7)]=_0x12589f[_0x4580c(0x31d)],this[_0x4580c(0x1dc)]=_0x30c895?_0x12589f[_0x4580c(0x1ff)]*_0x3fd39e:0x0,this[_0x4580c(0x197)]=_0x30c895?0x0:_0x12589f['SpriteThin']*_0x3fd39e,_0x3fd39e>0x0&&(this[_0x4580c(0x1dc)]+=_0x30c895?_0x22c951:0x0,this[_0x4580c(0x197)]+=_0x30c895?0x0:_0x22c951),_0x48928c?this[_0x4580c(0x1dc)]=_0x30c895?_0x11109c[_0x4580c(0x2a6)]-this[_0x4580c(0x1dc)]-_0x12589f[_0x4580c(0x1ff)]:0x0:this[_0x4580c(0x197)]=_0x30c895?0x0:_0x11109c[_0x4580c(0x16c)]-this[_0x4580c(0x197)]-_0x12589f[_0x4580c(0x1ff)];}else{const _0x2ff3dc=$gameActors[_0x4580c(0x177)](_0x14c7da);if(!_0x2ff3dc)continue;_0x2ff3dc[_0x4580c(0x215)]=_0x4580c(0x356),_0x2ff3dc[_0x4580c(0x222)]=_0x2382ae;}}}),PluginManager['registerCommand'](pluginData['name'],_0x485a45(0x227),_0x12b3b0=>{const _0x4c91de=_0x485a45;VisuMZ[_0x4c91de(0x318)](_0x12b3b0,_0x12b3b0);const _0x54405a=_0x12b3b0[_0x4c91de(0x337)],_0x42250b=_0x12b3b0[_0x4c91de(0x289)],_0x1dbf5e=_0x12b3b0[_0x4c91de(0x220)];for(const _0x13f5a8 of _0x54405a){const _0x1219b2=$gameActors[_0x4c91de(0x177)](_0x13f5a8);if(!_0x1219b2)continue;_0x1219b2['_ctbTurnOrderGraphicType']=_0x4c91de(0x284),_0x1219b2[_0x4c91de(0x14b)]=_0x42250b,_0x1219b2[_0x4c91de(0x328)]=_0x1dbf5e;}}),PluginManager[_0x485a45(0x23b)](pluginData['name'],_0x485a45(0x2b4),_0x1e50d4=>{const _0x36801f=_0x485a45;VisuMZ[_0x36801f(0x318)](_0x1e50d4,_0x1e50d4);const _0x2f7a2c=_0x1e50d4[_0x36801f(0x337)];for(const _0x330cb1 of _0x2f7a2c){const _0x456efd=$gameActors[_0x36801f(0x177)](_0x330cb1);if(!_0x456efd)continue;_0x456efd[_0x36801f(0x359)]();}}),PluginManager['registerCommand'](pluginData[_0x485a45(0x2e8)],_0x485a45(0x26a),_0x1613eb=>{const _0x14ed11=_0x485a45;VisuMZ[_0x14ed11(0x318)](_0x1613eb,_0x1613eb);const _0x19d652=_0x1613eb[_0x14ed11(0x22b)],_0x516bdc=_0x1613eb[_0x14ed11(0x345)];for(const _0x5efcd0 of _0x19d652){const _0x31b26b=$gameTroop[_0x14ed11(0x34c)]()[_0x5efcd0];if(!_0x31b26b)continue;_0x31b26b[_0x14ed11(0x215)]='icon',_0x31b26b['_ctbTurnOrderIconIndex']=_0x516bdc;}}),PluginManager[_0x485a45(0x23b)](pluginData[_0x485a45(0x2e8)],_0x485a45(0x25a),_0x27861a=>{const _0x5adbed=_0x485a45;VisuMZ['ConvertParams'](_0x27861a,_0x27861a);const _0x14a055=_0x27861a['Enemies'],_0x1c2a71=_0x27861a[_0x5adbed(0x289)],_0x3fd3fe=_0x27861a[_0x5adbed(0x220)];for(const _0x4fa453 of _0x14a055){if(_0x5adbed(0x2ff)!=='yDyni'){if(this[_0x5adbed(0x33c)]!==_0x3013e6[_0x5adbed(0x2be)]())return this[_0x5adbed(0x255)]();}else{const _0x5bba68=$gameTroop['members']()[_0x4fa453];if(!_0x5bba68)continue;_0x5bba68[_0x5adbed(0x215)]=_0x5adbed(0x284),_0x5bba68['_ctbTurnOrderFaceName']=_0x1c2a71,_0x5bba68['_ctbTurnOrderFaceIndex']=_0x3fd3fe;}}}),PluginManager['registerCommand'](pluginData[_0x485a45(0x2e8)],_0x485a45(0x28d),_0x3a9a4c=>{const _0x3235ae=_0x485a45;VisuMZ[_0x3235ae(0x318)](_0x3a9a4c,_0x3a9a4c);const _0x37f102=_0x3a9a4c[_0x3235ae(0x22b)];for(const _0x14b909 of _0x37f102){const _0x389a61=$gameTroop[_0x3235ae(0x34c)]()[_0x14b909];if(!_0x389a61)continue;_0x389a61[_0x3235ae(0x359)]();}}),PluginManager[_0x485a45(0x23b)](pluginData[_0x485a45(0x2e8)],'SystemTurnOrderVisibility',_0x97a976=>{const _0x117c53=_0x485a45;VisuMZ[_0x117c53(0x318)](_0x97a976,_0x97a976);const _0x4fe053=_0x97a976[_0x117c53(0x1a3)];$gameSystem[_0x117c53(0x141)](_0x4fe053);}),VisuMZ['BattleSystemCTB'][_0x485a45(0x283)]=Scene_Boot['prototype'][_0x485a45(0x2e1)],Scene_Boot['prototype'][_0x485a45(0x2e1)]=function(){const _0x58f0bc=_0x485a45;this['process_VisuMZ_BattleSystemCTB_CreateRegExp'](),VisuMZ[_0x58f0bc(0x278)]['Scene_Boot_onDatabaseLoaded'][_0x58f0bc(0x1d6)](this),this[_0x58f0bc(0x1e7)]();},VisuMZ[_0x485a45(0x278)][_0x485a45(0x2c6)]={},Scene_Boot[_0x485a45(0x32a)][_0x485a45(0x29a)]=function(){const _0x324a1d=_0x485a45,_0x5c79ee=VisuMZ[_0x324a1d(0x278)][_0x324a1d(0x2c6)],_0x7664fe=_0x324a1d(0x2f9),_0x1a8317=[_0x324a1d(0x297),'Cast',_0x324a1d(0x180)];for(const _0x251eea of _0x1a8317){const _0x59f092=_0x7664fe[_0x324a1d(0x1cd)](_0x251eea[_0x324a1d(0x2f5)]()[_0x324a1d(0x1f5)](),_0x324a1d(0x2e4),_0x324a1d(0x1ed)),_0x24bb7b=new RegExp(_0x59f092,'i');VisuMZ[_0x324a1d(0x278)][_0x324a1d(0x2c6)][_0x251eea]=_0x24bb7b;}VisuMZ[_0x324a1d(0x278)][_0x324a1d(0x2c6)][_0x324a1d(0x1a8)]=/<JS (?:CTB) (?:ORDER|DELAY|RUSH|SHIFT)>\s*([\s\S]*)\s*<\/JS (?:CTB) (?:ORDER|DELAY|RUSH|SHIFT)>/i;},Scene_Boot[_0x485a45(0x32a)]['process_VisuMZ_BattleSystemCTB_JS_Notetags']=function(){const _0x16dc2b=_0x485a45;if(VisuMZ[_0x16dc2b(0x20f)])return;const _0x3262fb=$dataSkills[_0x16dc2b(0x312)]($dataItems);for(const _0x296bae of _0x3262fb){if(_0x16dc2b(0x265)!==_0x16dc2b(0x265))this[_0x16dc2b(0x29a)](),_0x421d71['BattleSystemCTB']['Scene_Boot_onDatabaseLoaded'][_0x16dc2b(0x1d6)](this),this[_0x16dc2b(0x1e7)]();else{if(!_0x296bae)continue;VisuMZ[_0x16dc2b(0x278)][_0x16dc2b(0x30e)](_0x296bae);}}},VisuMZ[_0x485a45(0x278)]['ParseSkillNotetags']=VisuMZ[_0x485a45(0x23a)],VisuMZ['ParseSkillNotetags']=function(_0x4a118c){const _0xadfd22=_0x485a45;VisuMZ[_0xadfd22(0x278)]['ParseSkillNotetags'][_0xadfd22(0x1d6)](this,_0x4a118c),VisuMZ[_0xadfd22(0x278)]['Parse_Notetags_CreateJS'](_0x4a118c);},VisuMZ['BattleSystemCTB']['ParseItemNotetags']=VisuMZ[_0x485a45(0x2fc)],VisuMZ['ParseItemNotetags']=function(_0xc99b2){const _0x959b2c=_0x485a45;VisuMZ[_0x959b2c(0x278)][_0x959b2c(0x2fc)][_0x959b2c(0x1d6)](this,_0xc99b2),VisuMZ['BattleSystemCTB'][_0x959b2c(0x30e)](_0xc99b2);},VisuMZ[_0x485a45(0x278)]['Parse_Notetags_CreateJS']=function(_0x542fd0){const _0x4d1571=_0x485a45,_0x1861b4=[_0x4d1571(0x297),'Cast','After'];for(const _0x586e74 of _0x1861b4){VisuMZ[_0x4d1571(0x278)][_0x4d1571(0x17b)](_0x542fd0,_0x586e74);}VisuMZ[_0x4d1571(0x278)][_0x4d1571(0x241)](_0x542fd0,_0x4d1571(0x21c));},VisuMZ[_0x485a45(0x278)]['JS']={},VisuMZ[_0x485a45(0x278)]['createRateJS']=function(_0x1c10ae,_0x4fde07){const _0x381733=_0x485a45,_0x12b19f=_0x1c10ae[_0x381733(0x303)];if(_0x12b19f[_0x381733(0x22f)](VisuMZ[_0x381733(0x278)][_0x381733(0x2c6)][_0x4fde07])){const _0x4f2236=String(RegExp['$1']),_0x35a554=_0x381733(0x213)[_0x381733(0x1cd)](_0x4f2236,_0x4fde07),_0x1a32a5=VisuMZ[_0x381733(0x278)]['createKeyJS'](_0x1c10ae,_0x4fde07);VisuMZ[_0x381733(0x278)]['JS'][_0x1a32a5]=new Function(_0x35a554);}},VisuMZ[_0x485a45(0x278)]['createOrderJS']=function(_0x411e44,_0x14d78a){const _0x3ab98d=_0x485a45,_0x4c569b=_0x411e44['note'];if(_0x4c569b[_0x3ab98d(0x22f)](VisuMZ[_0x3ab98d(0x278)][_0x3ab98d(0x2c6)]['OrderJS'])){const _0x4a1751=String(RegExp['$1']),_0x314c11=_0x3ab98d(0x25d)['format'](_0x4a1751,_0x14d78a),_0x1eb37e=VisuMZ[_0x3ab98d(0x278)][_0x3ab98d(0x26c)](_0x411e44,_0x14d78a);VisuMZ[_0x3ab98d(0x278)]['JS'][_0x1eb37e]=new Function(_0x314c11);}},VisuMZ['BattleSystemCTB'][_0x485a45(0x26c)]=function(_0x36dc61,_0x579cc8){const _0x5da1b1=_0x485a45;if(VisuMZ[_0x5da1b1(0x26c)])return VisuMZ[_0x5da1b1(0x26c)](_0x36dc61,_0x579cc8);let _0x4bcb70='';if($dataActors[_0x5da1b1(0x23c)](_0x36dc61))_0x4bcb70=_0x5da1b1(0x1d8)[_0x5da1b1(0x1cd)](_0x36dc61['id'],_0x579cc8);if($dataClasses[_0x5da1b1(0x23c)](_0x36dc61))_0x4bcb70=_0x5da1b1(0x336)[_0x5da1b1(0x1cd)](_0x36dc61['id'],_0x579cc8);if($dataSkills['includes'](_0x36dc61))_0x4bcb70=_0x5da1b1(0x2d3)['format'](_0x36dc61['id'],_0x579cc8);if($dataItems[_0x5da1b1(0x23c)](_0x36dc61))_0x4bcb70=_0x5da1b1(0x315)['format'](_0x36dc61['id'],_0x579cc8);if($dataWeapons['includes'](_0x36dc61))_0x4bcb70=_0x5da1b1(0x17d)['format'](_0x36dc61['id'],_0x579cc8);if($dataArmors[_0x5da1b1(0x23c)](_0x36dc61))_0x4bcb70=_0x5da1b1(0x2cb)[_0x5da1b1(0x1cd)](_0x36dc61['id'],_0x579cc8);if($dataEnemies[_0x5da1b1(0x23c)](_0x36dc61))_0x4bcb70=_0x5da1b1(0x186)['format'](_0x36dc61['id'],_0x579cc8);if($dataStates[_0x5da1b1(0x23c)](_0x36dc61))_0x4bcb70='State-%1-%2'[_0x5da1b1(0x1cd)](_0x36dc61['id'],_0x579cc8);return _0x4bcb70;},ImageManager[_0x485a45(0x332)]=ImageManager[_0x485a45(0x332)]||0x9,ImageManager[_0x485a45(0x34f)]=ImageManager[_0x485a45(0x34f)]||0x6,VisuMZ['BattleSystemCTB'][_0x485a45(0x300)]=BattleManager[_0x485a45(0x247)],BattleManager[_0x485a45(0x247)]=function(){const _0x1a83dd=_0x485a45;if(this[_0x1a83dd(0x173)]())return _0x1a83dd(0x347);return VisuMZ[_0x1a83dd(0x278)]['BattleManager_battleSys'][_0x1a83dd(0x1d6)](this);},BattleManager[_0x485a45(0x173)]=function(){const _0x21d447=_0x485a45;return $gameSystem[_0x21d447(0x342)]()==='CTB';},VisuMZ[_0x485a45(0x278)][_0x485a45(0x2a2)]=BattleManager[_0x485a45(0x1da)],BattleManager[_0x485a45(0x1da)]=function(){const _0x22fe30=_0x485a45;if(this[_0x22fe30(0x173)]())return!![];return VisuMZ[_0x22fe30(0x278)][_0x22fe30(0x2a2)][_0x22fe30(0x1d6)](this);},VisuMZ['BattleSystemCTB']['BattleManager_isActiveTpb']=BattleManager[_0x485a45(0x293)],BattleManager[_0x485a45(0x293)]=function(){const _0x1a6994=_0x485a45;if(this[_0x1a6994(0x173)]())return![];return VisuMZ[_0x1a6994(0x278)][_0x1a6994(0x280)][_0x1a6994(0x1d6)](this);},VisuMZ[_0x485a45(0x278)][_0x485a45(0x153)]=BattleManager[_0x485a45(0x2e0)],BattleManager[_0x485a45(0x2e0)]=function(_0x417a1f){const _0x376729=_0x485a45;this[_0x376729(0x173)]()?this[_0x376729(0x204)](_0x417a1f):VisuMZ[_0x376729(0x278)][_0x376729(0x153)]['call'](this,_0x417a1f);},BattleManager[_0x485a45(0x204)]=function(_0x1fcc90){const _0x322fc5=_0x485a45;return VisuMZ['BattleSystemCTB'][_0x322fc5(0x153)][_0x322fc5(0x1d6)](this,_0x1fcc90);},VisuMZ[_0x485a45(0x278)][_0x485a45(0x210)]=BattleManager[_0x485a45(0x1f2)],BattleManager['processTurn']=function(){const _0x272d72=_0x485a45;this[_0x272d72(0x173)]()?this[_0x272d72(0x2b1)]():VisuMZ[_0x272d72(0x278)][_0x272d72(0x210)]['call'](this);},BattleManager[_0x485a45(0x2b1)]=function(){const _0x5785aa=_0x485a45,_0x59eee8=this[_0x5785aa(0x246)],_0x169774=_0x59eee8['currentAction']();if(_0x169774){_0x169774[_0x5785aa(0x1d2)]();if(_0x169774[_0x5785aa(0x1b9)]()){if(_0x5785aa(0x2cf)!==_0x5785aa(0x2cf))return _0x5785aa(0x356);else this[_0x5785aa(0x14d)]();}_0x59eee8[_0x5785aa(0x282)]();}else{if('PFFaK'===_0x5785aa(0x306))_0x59eee8[_0x5785aa(0x18a)](0x0),this['endAction'](),this[_0x5785aa(0x246)]=null;else{if(!_0x1a8034['isCTB']())return;if(!_0x4ce3e2['isSceneBattle']())return;if(this===_0x363bcc[_0x5785aa(0x177)]())return;if(this===_0x4569ac['_subject'])return;const _0xe4cbd4=this[_0x5785aa(0x260)]();if(_0xe4cbd4<0x0)return;this[_0x5785aa(0x240)](_0xe4cbd4+_0x725a56);}}},BattleManager[_0x485a45(0x1c1)]=function(){const _0x30e672=_0x485a45;if(this[_0x30e672(0x246)])return!![];if(this[_0x30e672(0x1e0)]!=='turn')return!![];if(this[_0x30e672(0x323)])return![];const _0x4e81fd=this[_0x30e672(0x358)]()[_0x30e672(0x264)](_0x27ac91=>_0x27ac91&&_0x27ac91['isAppeared']());return _0x4e81fd[_0x30e672(0x218)](_0x360e6a=>_0x360e6a[_0x30e672(0x2a0)]());},Game_Battler['prototype'][_0x485a45(0x2a0)]=function(){const _0x1ce065=_0x485a45;if(this['isTpbCharged']())return!![];if(this[_0x1ce065(0x228)]())return!![];if(this[_0x1ce065(0x2a9)]())return!![];return![];},BattleManager[_0x485a45(0x179)]=function(){const _0x1db9d1=_0x485a45;let _0x5db38e=VisuMZ[_0x1db9d1(0x278)]['Settings'][_0x1db9d1(0x327)][_0x1db9d1(0x26e)]?0x1e:0xa;this[_0x1db9d1(0x1c1)]()&&this[_0x1db9d1(0x21a)]()?_0x1db9d1(0x234)===_0x1db9d1(0x234)?(this[_0x1db9d1(0x1af)]=this[_0x1db9d1(0x1af)]||0x0,this['_anti_CTB_SoftlockCount']++,this[_0x1db9d1(0x1af)]>=_0x5db38e&&this[_0x1db9d1(0x232)]()):this[_0x1db9d1(0x215)]=this[_0x1db9d1(0x2cd)]():_0x1db9d1(0x14e)!=='CPeQi'?(this[_0x1db9d1(0x287)]=_0x27b45f[_0x1db9d1(0x2be)](),_0x475eea=_0x3e9d20[_0x1db9d1(0x32b)](this[_0x1db9d1(0x287)]),_0x597a8d[_0x1db9d1(0x357)](this['changeEnemyGraphicBitmap'][_0x1db9d1(0x30d)](this,_0x53d932))):this[_0x1db9d1(0x1af)]=0x0;},BattleManager['otherCtbChecksPassed']=function(){const _0x47897a=_0x485a45;if(this[_0x47897a(0x246)])return![];if(this[_0x47897a(0x1e0)]!==_0x47897a(0x16d))return![];if(this[_0x47897a(0x32d)]())return![];return!![];},BattleManager[_0x485a45(0x232)]=function(){const _0x252185=_0x485a45;$gameTemp[_0x252185(0x307)]()&&this['_anti_CTB_SoftlockCount']>=0x14&&console[_0x252185(0x145)]('Anti-CTB\x20Softlock\x20Count:',this[_0x252185(0x1af)]);this[_0x252185(0x246)]=null,this[_0x252185(0x1e0)]='turn',this[_0x252185(0x1bb)]=![],this[_0x252185(0x321)]=!![];for(const _0x379f0b of this[_0x252185(0x358)]()){if(_0x252185(0x23f)!==_0x252185(0x1f0)){if(!_0x379f0b)continue;if(_0x379f0b['isAlive']()){_0x379f0b[_0x252185(0x1b6)](_0x252185(0x214)),_0x379f0b['_tpbState']=_0x252185(0x189);const _0x1f72a1=_0x379f0b[_0x252185(0x176)],_0x303dd9=_0x379f0b[_0x252185(0x1f1)]||0x0;_0x379f0b[_0x252185(0x316)](![]),_0x379f0b['_tpbTurnCount']=_0x1f72a1,_0x379f0b['_tpbChargeTime']=Math[_0x252185(0x237)](_0x303dd9,0.99),_0x379f0b['updateTpb']();}}else{const _0x507a35=_0x1133a6['Settings'];if(_0x507a35['DisplayPosition']!==_0x252185(0x1ae))return;if(!_0x507a35['RepositionTopForHelp'])return;const _0x21d87f=_0x36ddab[_0x252185(0x219)][_0x252185(0x259)];if(!_0x21d87f)return;_0x21d87f[_0x252185(0x1d3)]?(this['x']=this[_0x252185(0x183)]+(_0x507a35[_0x252185(0x2a5)]||0x0),this['y']=this[_0x252185(0x1e4)]+(_0x507a35['RepositionTopHelpY']||0x0)):(this['x']=this[_0x252185(0x183)],this['y']=this[_0x252185(0x1e4)]);const _0x32a68a=_0x298fd1[_0x252185(0x219)]['_windowLayer'];_0x3dabac[_0x252185(0x15c)]===_0x4d48f0&&(_0x64c41b['_ogWindowLayerX']=_0x4f5d80['round']((_0x54239c[_0x252185(0x2a6)]-_0x5f59e5['min'](_0x338faa[_0x252185(0x33a)],_0x32a68a['width']))/0x2),_0x5f01c5[_0x252185(0x171)]=_0x4162df[_0x252185(0x2a8)]((_0x4c2539['height']-_0x9df4eb[_0x252185(0x237)](_0x34d7a4[_0x252185(0x1cb)],_0x32a68a[_0x252185(0x16c)]))/0x2)),this['x']+=_0x32a68a['x']-_0x4da94c[_0x252185(0x15c)],this['y']+=_0x32a68a['y']-_0x53f105['_ogWindowLayerY'];}}this[_0x252185(0x1af)]===0xb4&&($gameParty['removeBattleStates'](),$gameParty[_0x252185(0x18d)][_0x252185(0x1d6)]($gameTroop));if(this[_0x252185(0x1af)]===0x12c)for(const _0x5bb815 of this[_0x252185(0x358)]()){if(_0x252185(0x1f8)===_0x252185(0x325))this['processTurnCTB']();else{if(!_0x5bb815)continue;if(_0x5bb815[_0x252185(0x25f)]())continue;_0x5bb815[_0x252185(0x1f4)]();}}this['_anti_CTB_SoftlockCount']>=0x258&&(BattleManager[_0x252185(0x2e5)](),$gameTemp[_0x252185(0x307)]()&&console[_0x252185(0x145)](_0x252185(0x201)));},VisuMZ[_0x485a45(0x278)]['BattleManager_updateAllTpbBattlers']=BattleManager[_0x485a45(0x273)],BattleManager[_0x485a45(0x273)]=function(){const _0x392a4a=_0x485a45;this['isCTB']()?_0x392a4a(0x1f6)!==_0x392a4a(0x343)?this[_0x392a4a(0x2de)]():(this[_0x392a4a(0x287)]=_0x46d0b4[_0x392a4a(0x2be)](),_0x4584d9=_0x560ace[_0x392a4a(0x146)](this[_0x392a4a(0x287)]),_0x604f97[_0x392a4a(0x357)](this[_0x392a4a(0x1d4)]['bind'](this,_0x343fe3))):VisuMZ[_0x392a4a(0x278)]['BattleManager_updateAllTpbBattlers'][_0x392a4a(0x1d6)](this);},BattleManager[_0x485a45(0x2de)]=function(){const _0x561bec=_0x485a45,_0x55983a=this[_0x561bec(0x358)]();_0x55983a[_0x561bec(0x2b3)]((_0x1d03b8,_0x1467cc)=>{const _0x572a47=_0x561bec;return _0x1d03b8['ctbTicksToGoal'](0x1)-_0x1467cc[_0x572a47(0x2c3)](0x1);});for(const _0x253abd of _0x55983a){if(_0x561bec(0x1a7)!==_0x561bec(0x238))this['updateTpbBattler'](_0x253abd);else{if(_0x39c686[_0x561bec(0x158)](this))return;_0x54e88e[_0x561bec(0x278)][_0x561bec(0x27d)][_0x561bec(0x1d6)](this);}}},VisuMZ[_0x485a45(0x278)][_0x485a45(0x33b)]=BattleManager[_0x485a45(0x30f)],BattleManager['startBattle']=function(){const _0x3872e5=_0x485a45;VisuMZ['BattleSystemCTB'][_0x3872e5(0x33b)][_0x3872e5(0x1d6)](this),this['updateTurnOrderCTB'](!![]);},VisuMZ[_0x485a45(0x278)]['BattleManager_endAction']=BattleManager[_0x485a45(0x339)],BattleManager['endAction']=function(){const _0x483fbb=_0x485a45;this[_0x483fbb(0x1e6)](),VisuMZ['BattleSystemCTB'][_0x483fbb(0x2ce)][_0x483fbb(0x1d6)](this),this[_0x483fbb(0x150)]();},BattleManager[_0x485a45(0x1e6)]=function(){const _0x302441=_0x485a45;if(!this[_0x302441(0x173)]())return;this[_0x302441(0x246)]&&this[_0x302441(0x246)][_0x302441(0x269)]()<=0x0&&(this['rotateCTBSprites'](),this[_0x302441(0x246)][_0x302441(0x1b6)](_0x302441(0x214)));},BattleManager[_0x485a45(0x150)]=function(){const _0x39922c=_0x485a45;if(!this[_0x39922c(0x173)]())return;if(this['_subject']&&$gameTemp[_0x39922c(0x185)]()){this[_0x39922c(0x246)][_0x39922c(0x190)]='ready',this[_0x39922c(0x246)][_0x39922c(0x331)]=_0x39922c(0x34b);return;}this[_0x39922c(0x1f9)](),this[_0x39922c(0x246)]&&(_0x39922c(0x1c9)!==_0x39922c(0x1c9)?_0x508c11[_0x39922c(0x173)]()?this[_0x39922c(0x1b8)]():_0x2a58dc['BattleSystemCTB']['Game_Battler_applyTpbPenalty'][_0x39922c(0x1d6)](this):this['processTurn']());},VisuMZ[_0x485a45(0x278)]['BattleManager_startActorInput']=BattleManager['startActorInput'],BattleManager['startActorInput']=function(){const _0x2b9e55=_0x485a45;this[_0x2b9e55(0x1f9)](),VisuMZ[_0x2b9e55(0x278)]['BattleManager_startActorInput'][_0x2b9e55(0x1d6)](this);},BattleManager[_0x485a45(0x1f9)]=function(_0x41bc9d){const _0x5b5615=_0x485a45;if(!this[_0x5b5615(0x173)]())return;const _0x1f8ff2=SceneManager[_0x5b5615(0x219)][_0x5b5615(0x18e)];if(!_0x1f8ff2)return;_0x1f8ff2[_0x5b5615(0x2b9)](_0x41bc9d);},BattleManager[_0x485a45(0x2d9)]=function(){const _0x3d6df7=_0x485a45;if(!this[_0x3d6df7(0x173)]())return;const _0x1760d9=SceneManager[_0x3d6df7(0x219)][_0x3d6df7(0x18e)];if(!_0x1760d9)return;_0x1760d9['rotateCTBSprite'](this[_0x3d6df7(0x246)]);},BattleManager[_0x485a45(0x330)]=function(){const _0x86a68=_0x485a45,_0x324fec=this[_0x86a68(0x358)]()[_0x86a68(0x35d)](_0x3d6540=>String([_0x3d6540[_0x86a68(0x2e8)](),_0x86a68(0x2b0)+_0x3d6540[_0x86a68(0x2c3)](0x1)]));console[_0x86a68(0x145)](_0x324fec);},VisuMZ[_0x485a45(0x278)][_0x485a45(0x35b)]=Game_System[_0x485a45(0x32a)][_0x485a45(0x299)],Game_System[_0x485a45(0x32a)][_0x485a45(0x299)]=function(){const _0xb70056=_0x485a45;VisuMZ[_0xb70056(0x278)][_0xb70056(0x35b)][_0xb70056(0x1d6)](this),this['initBattleSystemCTB']();},Game_System[_0x485a45(0x32a)][_0x485a45(0x2ab)]=function(){const _0xfbf3ca=_0x485a45;this[_0xfbf3ca(0x302)]=!![];},Game_System[_0x485a45(0x32a)]['isBattleSystemCTBTurnOrderVisible']=function(){const _0x14c3ef=_0x485a45;return this[_0x14c3ef(0x302)]===undefined&&(_0x14c3ef(0x192)===_0x14c3ef(0x250)?this['_tpbChargeTime']=0x0:this[_0x14c3ef(0x2ab)]()),this[_0x14c3ef(0x302)];},Game_System[_0x485a45(0x32a)][_0x485a45(0x141)]=function(_0x25228e){const _0x5371f3=_0x485a45;this[_0x5371f3(0x302)]===undefined&&this['initBattleSystemCTB'](),this[_0x5371f3(0x302)]=_0x25228e;},VisuMZ[_0x485a45(0x278)][_0x485a45(0x1cc)]=Game_Action['prototype'][_0x485a45(0x144)],Game_Action['prototype'][_0x485a45(0x144)]=function(_0xae1144){const _0x4179da=_0x485a45;VisuMZ['BattleSystemCTB'][_0x4179da(0x1cc)][_0x4179da(0x1d6)](this,_0xae1144),this[_0x4179da(0x242)](_0xae1144);},Game_Action[_0x485a45(0x32a)][_0x485a45(0x242)]=function(_0xfdbce3){const _0x185324=_0x485a45;if(!SceneManager['isSceneBattle']())return;if(!BattleManager[_0x185324(0x173)]())return;if(this['item']())this['applyItemBattleSystemCTBUserEffect'](_0xfdbce3);},Game_Action[_0x485a45(0x32a)][_0x485a45(0x31f)]=function(_0x1b032f){const _0x56a648=_0x485a45,_0x5efcbd=this[_0x56a648(0x277)]()[_0x56a648(0x303)];if(_0x1b032f['isCtbChargingState']()){const _0xd35c2f=VisuMZ[_0x56a648(0x278)][_0x56a648(0x26c)](this['item'](),'Charge');if(VisuMZ[_0x56a648(0x278)]['JS'][_0xd35c2f]){const _0x4844ec=VisuMZ[_0x56a648(0x278)]['JS'][_0xd35c2f][_0x56a648(0x1d6)](this,this['subject'](),_0x1b032f);_0x1b032f[_0x56a648(0x15f)](_0x4844ec);}if(_0x5efcbd[_0x56a648(0x22f)](/<(?:CTB) CHARGE (?:GAUGE|TIME|SPEED):[ ](\d+)([%％])>/i)){if('gnJHX'!==_0x56a648(0x285))_0x1b032f['setCtbChargeTime'](Number(RegExp['$1'])*0.01);else return _0x11c54b['BattleSystemCTB'][_0x56a648(0x271)][_0x56a648(0x1d6)](this);}_0x5efcbd[_0x56a648(0x22f)](/<(?:CTB) CHARGE (?:GAUGE|TIME|SPEED):[ ]([\+\-]\d+)([%％])>/i)&&_0x1b032f['changeCtbChargeTime'](Number(RegExp['$1'])*0.01);}else{if(_0x1b032f[_0x56a648(0x352)]()){const _0xdc22f1=VisuMZ['BattleSystemCTB'][_0x56a648(0x26c)](this[_0x56a648(0x277)](),_0x56a648(0x24e));if(VisuMZ['BattleSystemCTB']['JS'][_0xdc22f1]){const _0x288d7f=VisuMZ[_0x56a648(0x278)]['JS'][_0xdc22f1][_0x56a648(0x1d6)](this,this[_0x56a648(0x1aa)](),_0x1b032f);_0x1b032f[_0x56a648(0x1fb)](_0x288d7f);}_0x5efcbd[_0x56a648(0x22f)](/<(?:CTB) CAST (?:GAUGE|TIME|SPEED):[ ](\d+)([%％])>/i)&&_0x1b032f[_0x56a648(0x1fb)](Number(RegExp['$1'])*0.01),_0x5efcbd[_0x56a648(0x22f)](/<(?:CTB) CAST (?:GAUGE|TIME|SPEED):[ ]([\+\-]\d+)([%％])>/i)&&_0x1b032f[_0x56a648(0x23e)](Number(RegExp['$1'])*0.01);}}const _0x11a71a=VisuMZ[_0x56a648(0x278)][_0x56a648(0x26c)](this[_0x56a648(0x277)](),_0x56a648(0x21c));if(VisuMZ[_0x56a648(0x278)]['JS'][_0x11a71a]){if(_0x56a648(0x16e)!==_0x56a648(0x16e)){const _0xe0937=_0x825cf7['BattleSystemCTB'][_0x56a648(0x26c)](this['item'](),'Cast');if(_0x302645['BattleSystemCTB']['JS'][_0xe0937]){const _0x3c2783=_0x945979[_0x56a648(0x278)]['JS'][_0xe0937]['call'](this,this['subject'](),_0x3a7241);_0x1d716a['setCtbCastTime'](_0x3c2783);}_0x219dfc[_0x56a648(0x22f)](/<(?:CTB) CAST (?:GAUGE|TIME|SPEED):[ ](\d+)([%％])>/i)&&_0x2efd19[_0x56a648(0x1fb)](_0x22ad3f(_0x5c9f87['$1'])*0.01),_0x2cc13e[_0x56a648(0x22f)](/<(?:CTB) CAST (?:GAUGE|TIME|SPEED):[ ]([\+\-]\d+)([%％])>/i)&&_0x4cb108[_0x56a648(0x23e)](_0x1512b0(_0x27d7f8['$1'])*0.01);}else{const _0x184049=VisuMZ['BattleSystemCTB']['JS'][_0x11a71a][_0x56a648(0x1d6)](this,this[_0x56a648(0x1aa)](),_0x1b032f);_0x1b032f[_0x56a648(0x240)](_0x184049);}}if(_0x5efcbd['match'](/<(?:CTB) (?:SET|MAKE|EXACT) ORDER:[ ](\d+)>/i)){if(_0x56a648(0x217)!==_0x56a648(0x206))_0x1b032f[_0x56a648(0x240)](Number(RegExp['$1']));else{const _0x17e22b=_0x476284[_0x56a648(0x35a)];this['_fadeDuration']=_0x17e22b['UpdateFrames'],this[_0x56a648(0x2fa)]=_0x49cbf4;}}_0x5efcbd[_0x56a648(0x22f)](/<(?:CTB) (?:CHANGE|DELAY|RUSH|SHIFT) ORDER:[ ]([\+\-]\d+)>/i)&&_0x1b032f['changeTurnOrderByCTB'](Number(RegExp['$1']));},VisuMZ[_0x485a45(0x278)][_0x485a45(0x1c5)]=Game_Action[_0x485a45(0x32a)][_0x485a45(0x172)],Game_Action[_0x485a45(0x32a)][_0x485a45(0x172)]=function(){const _0xd50b13=_0x485a45;VisuMZ[_0xd50b13(0x278)][_0xd50b13(0x1c5)][_0xd50b13(0x1d6)](this),this['applyGlobalBattleSystemCTBEffects']();},Game_Action[_0x485a45(0x32a)][_0x485a45(0x32e)]=function(){const _0x183946=_0x485a45;if(!this[_0x183946(0x277)]())return;if(!BattleManager[_0x183946(0x173)]())return;const _0x3cbb2a=this[_0x183946(0x277)]()[_0x183946(0x303)];let _0x5563ae=0x0;this[_0x183946(0x198)]&&(_0x5563ae=this[_0x183946(0x1aa)]()[_0x183946(0x1f1)]);const _0x522f6b=VisuMZ[_0x183946(0x278)][_0x183946(0x26c)](this[_0x183946(0x277)](),_0x183946(0x180));VisuMZ['BattleSystemCTB']['JS'][_0x522f6b]&&(_0x5563ae=VisuMZ[_0x183946(0x278)]['JS'][_0x522f6b][_0x183946(0x1d6)](this,this[_0x183946(0x1aa)](),this[_0x183946(0x1aa)]()));let _0x4b287b=this['item']()['speed']>0x0?this[_0x183946(0x277)]()[_0x183946(0x154)]:0x0;if(this[_0x183946(0x19b)]())_0x4b287b+=this[_0x183946(0x1aa)]()['attackSpeed']();_0x5563ae+=(_0x4b287b/0xfa0)[_0x183946(0x1b0)](0x0,0x1);if(_0x3cbb2a[_0x183946(0x22f)](/<(?:CTB) AFTER (?:GAUGE|TIME|SPEED):[ ](\d+)([%％])>/i)){if(_0x183946(0x1ef)==='XMZFf'){const _0x52609a=_0x3d1a1e[_0x183946(0x35a)],_0x3a9a8a=[_0x183946(0x1ae),_0x183946(0x1ba)][_0x183946(0x23c)](_0x52609a[_0x183946(0x24f)]);return _0x3a9a8a;}else _0x5563ae=Number(RegExp['$1'])*0.01;}const _0x32e4fd=this[_0x183946(0x1aa)]()[_0x183946(0x1bd)]()[_0x183946(0x312)](this[_0x183946(0x1aa)]()['skills']()),_0x5a02b3=/<(?:CTB) AFTER (?:GAUGE|TIME|SPEED):[ ]([\+\-]\d+)([%％])>/i,_0x1f895d=_0x32e4fd[_0x183946(0x35d)](_0x4bf11f=>_0x4bf11f&&_0x4bf11f[_0x183946(0x303)][_0x183946(0x22f)](_0x5a02b3)?Number(RegExp['$1'])*0.01:0x0);_0x5563ae=_0x1f895d[_0x183946(0x15e)]((_0x2c1213,_0x33ca20)=>_0x2c1213+_0x33ca20,_0x5563ae),this['subject']()[_0x183946(0x18a)](_0x5563ae);},Game_BattlerBase[_0x485a45(0x32a)][_0x485a45(0x15f)]=function(_0x5bddb2){this['_tpbChargeTime']=_0x5bddb2;},Game_BattlerBase['prototype'][_0x485a45(0x20a)]=function(_0x41baf0){const _0x5ab57c=_0x485a45;this[_0x5ab57c(0x15f)](this['_tpbChargeTime']+_0x41baf0);},Game_BattlerBase['prototype'][_0x485a45(0x1fb)]=function(_0x53cab8){const _0x548f84=_0x485a45,_0x27e47c=this[_0x548f84(0x1a5)]();this['_tpbCastTime']=_0x27e47c*_0x53cab8;},Game_BattlerBase['prototype']['changeCtbCastTime']=function(_0xbc4e18){const _0xe106de=_0x485a45,_0x5712b3=this[_0xe106de(0x1a5)](),_0x5e9412=_0x5712b3*_0xbc4e18;this[_0xe106de(0x360)]=this[_0xe106de(0x360)]+_0x5e9412;},VisuMZ[_0x485a45(0x278)][_0x485a45(0x2b2)]=Game_BattlerBase['prototype']['appear'],Game_BattlerBase[_0x485a45(0x32a)]['appear']=function(){const _0x23fd52=_0x485a45;VisuMZ['BattleSystemCTB'][_0x23fd52(0x2b2)][_0x23fd52(0x1d6)](this),BattleManager[_0x23fd52(0x1f9)]();},VisuMZ['BattleSystemCTB'][_0x485a45(0x195)]=Game_BattlerBase['prototype'][_0x485a45(0x261)],Game_BattlerBase[_0x485a45(0x32a)][_0x485a45(0x261)]=function(){const _0x2facf7=_0x485a45;VisuMZ[_0x2facf7(0x278)][_0x2facf7(0x195)]['call'](this),BattleManager[_0x2facf7(0x1f9)]();},Game_BattlerBase[_0x485a45(0x32a)]['clearTurnOrderCTBGraphics']=function(){const _0x960b47=_0x485a45;delete this['_ctbTurnOrderGraphicType'],delete this['_ctbTurnOrderFaceName'],delete this[_0x960b47(0x328)],delete this['_ctbTurnOrderIconIndex'];},Game_BattlerBase[_0x485a45(0x32a)][_0x485a45(0x308)]=function(){const _0x59ab3d=_0x485a45;return this['_ctbTurnOrderGraphicType']===undefined&&(this['_ctbTurnOrderGraphicType']=this[_0x59ab3d(0x2cd)]()),this[_0x59ab3d(0x215)];},Game_BattlerBase[_0x485a45(0x32a)][_0x485a45(0x2cd)]=function(){const _0x2b7586=_0x485a45;return Window_CTB_TurnOrder[_0x2b7586(0x35a)]['EnemyBattlerType'];},Game_BattlerBase[_0x485a45(0x32a)]['TurnOrderCTBGraphicFaceName']=function(){const _0x2d9537=_0x485a45;return this['_ctbTurnOrderFaceName']===undefined&&(this['_ctbTurnOrderFaceName']=this[_0x2d9537(0x1c8)]()),this['_ctbTurnOrderFaceName'];},Game_BattlerBase[_0x485a45(0x32a)][_0x485a45(0x1c8)]=function(){const _0x55262b=_0x485a45;return Window_CTB_TurnOrder[_0x55262b(0x35a)][_0x55262b(0x149)];},Game_BattlerBase['prototype'][_0x485a45(0x351)]=function(){const _0xfb2044=_0x485a45;return this['_ctbTurnOrderFaceIndex']===undefined&&(this[_0xfb2044(0x328)]=this[_0xfb2044(0x1f7)]()),this['_ctbTurnOrderFaceIndex'];},Game_BattlerBase[_0x485a45(0x32a)][_0x485a45(0x1f7)]=function(){const _0x292202=_0x485a45;return Window_CTB_TurnOrder[_0x292202(0x35a)][_0x292202(0x281)];},Game_BattlerBase['prototype'][_0x485a45(0x19d)]=function(){const _0x2f8bee=_0x485a45;return this[_0x2f8bee(0x222)]===undefined&&(this[_0x2f8bee(0x222)]=this[_0x2f8bee(0x1a1)]()),this['_ctbTurnOrderIconIndex'];},Game_BattlerBase[_0x485a45(0x32a)]['createTurnOrderCTBGraphicIconIndex']=function(){const _0x1295af=_0x485a45;return Window_CTB_TurnOrder[_0x1295af(0x35a)][_0x1295af(0x2c8)];},Game_BattlerBase['prototype'][_0x485a45(0x291)]=function(_0x59a020){const _0x3bd2ce=_0x485a45;this[_0x3bd2ce(0x222)]=_0x59a020;},Game_BattlerBase[_0x485a45(0x32a)][_0x485a45(0x2c3)]=function(_0xc069ee,_0x5365f7){const _0x1ac44e=_0x485a45;if(this[_0x1ac44e(0x25f)]())return Number['MAX_SAFE_INTEGER'];if(!this[_0x1ac44e(0x314)]())return Number[_0x1ac44e(0x288)];const _0x27d90c=0x1;_0xc069ee*=_0x27d90c;if(_0xc069ee===_0x27d90c&&!_0x5365f7){if(this===BattleManager[_0x1ac44e(0x246)]){if(_0x1ac44e(0x2f4)!==_0x1ac44e(0x2ee))return Number[_0x1ac44e(0x21f)]/0xa;else{const _0x28d97a=new _0x3a4a00(_0x1f05cf,_0x2a8e64,_0x28a71c);this[_0x1ac44e(0x1fc)][_0x1ac44e(0x175)](_0x28d97a),this[_0x1ac44e(0x309)][_0x1ac44e(0x30c)](_0x28d97a);}}if(this===BattleManager['actor']()){if(_0x1ac44e(0x2b7)==='oRJDT')return Number['MIN_SAFE_INTEGER']/0xa;else{if(!_0x413d54[_0x1ac44e(0x28f)]())return;if(!_0x1291fc[_0x1ac44e(0x173)]())return;if(this[_0x1ac44e(0x277)]())this['applyItemBattleSystemCTBUserEffect'](_0x289c90);}}if(BattleManager[_0x1ac44e(0x2ea)]&&BattleManager[_0x1ac44e(0x2ea)]['includes'](this)){if(_0x1ac44e(0x349)===_0x1ac44e(0x349)){let _0x372584=Number[_0x1ac44e(0x21f)]/0x1388;return _0x372584+=BattleManager[_0x1ac44e(0x2ea)][_0x1ac44e(0x19c)](this)*0x5,_0x372584;}else this['x']=this[_0x1ac44e(0x183)]+(_0xd200ea[_0x1ac44e(0x2a5)]||0x0),this['y']=this[_0x1ac44e(0x1e4)]+(_0x1c4c7d[_0x1ac44e(0x262)]||0x0);}if(this[_0x1ac44e(0x190)]==='casting'){if(_0x1ac44e(0x182)===_0x1ac44e(0x1db)){if(this[_0x1ac44e(0x246)])return![];if(this['_phase']!=='turn')return![];if(this['isInputting']())return![];return!![];}else return(this[_0x1ac44e(0x1a5)]()*_0x27d90c-this[_0x1ac44e(0x360)])/this['tpbAcceleration']();}}return _0xc069ee-=this[_0x1ac44e(0x26f)]()*_0x27d90c,_0xc069ee/=this[_0x1ac44e(0x29d)]()*_0x27d90c,_0xc069ee||0x0;},Game_BattlerBase[_0x485a45(0x32a)]['ctbTicksToGoalAddedCastTime']=function(){const _0x22a01b=_0x485a45;if(this[_0x22a01b(0x190)]==='casting'){if(_0x22a01b(0x353)===_0x22a01b(0x353))return(this[_0x22a01b(0x1a5)]()-this[_0x22a01b(0x360)])/this[_0x22a01b(0x29d)]();else{const _0x5d4647=new _0x5487f3(_0x5cf048,_0x355103,_0x1606f2);this['_turnOrderInnerSprite'][_0x22a01b(0x175)](_0x5d4647),this[_0x22a01b(0x309)][_0x22a01b(0x30c)](_0x5d4647);}}else{if(_0x22a01b(0x2d6)==='LyCDK')_0x21cfe6[_0x22a01b(0x278)][_0x22a01b(0x33b)][_0x22a01b(0x1d6)](this),this[_0x22a01b(0x1f9)](!![]);else return 0x0;}},VisuMZ[_0x485a45(0x278)][_0x485a45(0x231)]=Game_Battler['prototype']['initTpbChargeTime'],Game_Battler[_0x485a45(0x32a)]['initTpbChargeTime']=function(_0x116151){const _0x510be3=_0x485a45;if(BattleManager[_0x510be3(0x173)]()){if(_0x510be3(0x263)===_0x510be3(0x263))this[_0x510be3(0x13f)](_0x116151);else{const _0x359d89=_0x5a85b5['Settings'];return this[_0x510be3(0x2ad)]()?_0x359d89['SpriteLength']:_0x359d89[_0x510be3(0x1ff)];}}else{if(_0x510be3(0x226)===_0x510be3(0x226))VisuMZ[_0x510be3(0x278)][_0x510be3(0x231)][_0x510be3(0x1d6)](this,_0x116151);else{const _0x81e344=_0x11d662[_0x510be3(0x303)];if(_0x81e344[_0x510be3(0x22f)](_0x1ba056[_0x510be3(0x278)][_0x510be3(0x2c6)][_0x510be3(0x1a8)])){const _0x5d6a2f=_0x434f25(_0x1450c2['$1']),_0x5b8a58=_0x510be3(0x25d)[_0x510be3(0x1cd)](_0x5d6a2f,_0x39ce0c),_0xf6d3ab=_0x1b82b3[_0x510be3(0x278)]['createKeyJS'](_0x10eb0a,_0x58e288);_0x2bbd94[_0x510be3(0x278)]['JS'][_0xf6d3ab]=new _0x3c6aae(_0x5b8a58);}}}},Game_Battler[_0x485a45(0x32a)][_0x485a45(0x13f)]=function(_0x524ba7){const _0x4ef539=_0x485a45,_0x17609b=VisuMZ[_0x4ef539(0x278)][_0x4ef539(0x35a)][_0x4ef539(0x327)];let _0x426145=this['tpbRelativeSpeed']()*eval(_0x17609b[_0x4ef539(0x29b)]);const _0x4bf871=this[_0x4ef539(0x1bd)]()[_0x4ef539(0x312)](this[_0x4ef539(0x191)]()),_0x191f4f=/<(?:CTB) (?:BATTLE START|START) (?:GAUGE|TIME|SPEED): ([\+\-]\d+)([%％])>/i,_0x4041bd=_0x4bf871[_0x4ef539(0x35d)](_0x522125=>_0x522125&&_0x522125['note'][_0x4ef539(0x22f)](_0x191f4f)?Number(RegExp['$1'])*0.01:0x0);_0x426145=_0x4041bd[_0x4ef539(0x15e)]((_0x37e3ce,_0xb86c2c)=>_0x37e3ce+_0xb86c2c,_0x426145),this['_tpbState']=_0x4ef539(0x189),this['_tpbChargeTime']=(_0x524ba7?0x1:_0x426145)[_0x4ef539(0x1b0)](0x0,0x1);if(this['isRestricted']()){if(_0x4ef539(0x30a)!==_0x4ef539(0x320))this['_tpbChargeTime']=0x0;else return _0x15d3ee[_0x4ef539(0x21f)]/0xa;}},Game_Battler[_0x485a45(0x32a)][_0x485a45(0x268)]=function(){const _0x6eea7=_0x485a45;return this[_0x6eea7(0x190)]===_0x6eea7(0x189);},Game_Battler['prototype'][_0x485a45(0x352)]=function(){const _0x31b18e=_0x485a45;return this['_tpbState']==='casting'&&this[_0x31b18e(0x251)]()&&this[_0x31b18e(0x251)]()[_0x31b18e(0x277)]()&&this[_0x31b18e(0x251)]()['item']()[_0x31b18e(0x154)]<0x0;},Game_BattlerBase[_0x485a45(0x32a)][_0x485a45(0x25c)]=function(){const _0xc34ab7=_0x485a45;if(this[_0xc34ab7(0x352)]()){if('NFAgG'===_0xc34ab7(0x2c4)){const _0x39cfdf=this[_0xc34ab7(0x335)]()[_0xc34ab7(0x303)];if(_0x39cfdf[_0xc34ab7(0x22f)](/<CTB TURN ORDER ICON:[ ](\d+)>/i))return _0x3ce58a(_0x48bec4['$1']);return _0x5e16bf[_0xc34ab7(0x35a)][_0xc34ab7(0x2c8)];}else return this[_0xc34ab7(0x360)]/this[_0xc34ab7(0x1a5)]();}else{if(_0xc34ab7(0x1b5)!=='YImxM'){const _0x581658=_0x5e9d6c[_0xc34ab7(0x219)]['_ctbTurnOrderWindow'];if(!_0x581658)return-0x1;const _0x789480=_0x581658['_turnOrderContainer'];if(!_0x789480)return-0x1;const _0x51b1c8=_0x789480[_0xc34ab7(0x200)](_0x45a2ac=>_0x45a2ac[_0xc34ab7(0x194)]()===this);return _0x789480['indexOf'](_0x51b1c8);}else return 0x0;}},Game_Battler[_0x485a45(0x32a)]['ctbStopped']=function(){return!this['canMove']();},Game_Battler['prototype']['setCtbAfterSpeed']=function(_0x111194){const _0x5c8270=_0x485a45;this[_0x5c8270(0x35e)]=_0x111194;},VisuMZ['BattleSystemCTB'][_0x485a45(0x31b)]=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x32f)],Game_Battler[_0x485a45(0x32a)][_0x485a45(0x32f)]=function(){const _0x406a43=_0x485a45;if(BattleManager['isCTB']())_0x406a43(0x162)===_0x406a43(0x162)?this[_0x406a43(0x14a)]():this['setText'](_0x3ba020(_0x561af1['$1']));else{if('PGcoC'===_0x406a43(0x292))VisuMZ[_0x406a43(0x278)]['Game_Battler_updateTpbIdleTime'][_0x406a43(0x1d6)](this);else return _0x447b1f(_0x6044b7['$1']);}},Game_Battler['prototype'][_0x485a45(0x14a)]=function(){const _0x4aa6e3=_0x485a45;if(!this[_0x4aa6e3(0x1c6)]()){if(_0x4aa6e3(0x178)===_0x4aa6e3(0x236)){const _0xf40a57=this[_0x4aa6e3(0x194)]();if(!_0xf40a57)return _0x5c1be6[_0x4aa6e3(0x288)];const _0x26d282=0x1*(this[_0x4aa6e3(0x27f)]+0x1);return _0xf40a57['ctbTicksToGoal'](_0x26d282,_0x24d08b);}else this[_0x4aa6e3(0x2db)]+=this['tpbAcceleration']();}},VisuMZ[_0x485a45(0x278)]['Game_Battler_onRestrict']=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x272)],Game_Battler[_0x485a45(0x32a)][_0x485a45(0x272)]=function(){const _0x5c3fd9=_0x485a45;this[_0x5c3fd9(0x34a)]=BattleManager[_0x5c3fd9(0x173)](),VisuMZ[_0x5c3fd9(0x278)]['Game_Battler_onRestrict'][_0x5c3fd9(0x1d6)](this),this[_0x5c3fd9(0x34a)]=undefined;},VisuMZ[_0x485a45(0x278)][_0x485a45(0x310)]=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x2fb)],Game_Battler[_0x485a45(0x32a)]['clearTpbChargeTime']=function(){const _0x5b9361=_0x485a45;BattleManager['isCTB']()?this[_0x5b9361(0x266)]():VisuMZ[_0x5b9361(0x278)][_0x5b9361(0x310)][_0x5b9361(0x1d6)](this);},Game_Battler[_0x485a45(0x32a)][_0x485a45(0x266)]=function(){const _0x371dd0=_0x485a45;if(this[_0x371dd0(0x34a)])return;this[_0x371dd0(0x190)]=_0x371dd0(0x189),this[_0x371dd0(0x1f1)]-=0x1,this[_0x371dd0(0x1f1)]+=this[_0x371dd0(0x35e)]||0x0;},VisuMZ['BattleSystemCTB'][_0x485a45(0x2e9)]=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x2f3)],Game_Battler['prototype'][_0x485a45(0x2f3)]=function(){const _0x4486d9=_0x485a45;if(BattleManager['isCTB']()){if('KIqgp'!==_0x4486d9(0x225))return 0x0;else this[_0x4486d9(0x1b8)]();}else VisuMZ[_0x4486d9(0x278)]['Game_Battler_applyTpbPenalty'][_0x4486d9(0x1d6)](this);},Game_Battler[_0x485a45(0x32a)]['applyCTBPenalty']=function(){const _0x1bf376=_0x485a45;this[_0x1bf376(0x190)]='charging',this[_0x1bf376(0x1f1)]+=VisuMZ[_0x1bf376(0x278)][_0x1bf376(0x35a)]['Mechanics']['EscapeFailPenalty']||0x0;},VisuMZ[_0x485a45(0x278)][_0x485a45(0x271)]=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x1de)],Game_Battler[_0x485a45(0x32a)][_0x485a45(0x1de)]=function(){const _0x3db1f8=_0x485a45;if(BattleManager[_0x3db1f8(0x173)]()){if(_0x3db1f8(0x2fe)===_0x3db1f8(0x2d4))_0x2d74d6['bitmap']=_0x2ce963[_0x3db1f8(0x1dd)](_0x3cef42[_0x159d4d]);else return VisuMZ[_0x3db1f8(0x278)][_0x3db1f8(0x35a)][_0x3db1f8(0x327)][_0x3db1f8(0x252)]['call'](this,this);}else return VisuMZ['BattleSystemCTB']['Game_Battler_tpbSpeed'][_0x3db1f8(0x1d6)](this);},VisuMZ[_0x485a45(0x278)]['Game_Battler_tpbBaseSpeed']=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x1ad)],Game_Battler['prototype'][_0x485a45(0x1ad)]=function(){const _0x4368a4=_0x485a45;return BattleManager[_0x4368a4(0x173)]()?VisuMZ[_0x4368a4(0x278)]['Settings']['Mechanics'][_0x4368a4(0x229)]['call'](this,this):VisuMZ[_0x4368a4(0x278)]['Game_Battler_tpbBaseSpeed']['call'](this);},VisuMZ[_0x485a45(0x278)]['Game_Battler_tpbRelativeSpeed']=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x32c)],Game_Battler[_0x485a45(0x32a)][_0x485a45(0x32c)]=function(){const _0x406c60=_0x485a45;if(BattleManager[_0x406c60(0x173)]()){if(_0x406c60(0x311)!==_0x406c60(0x142))return VisuMZ[_0x406c60(0x278)][_0x406c60(0x35a)][_0x406c60(0x327)][_0x406c60(0x233)][_0x406c60(0x1d6)](this,this);else _0x352612+=0x1;}else{if(_0x406c60(0x235)!==_0x406c60(0x1e1))return VisuMZ['BattleSystemCTB'][_0x406c60(0x20c)][_0x406c60(0x1d6)](this);else this['_tpbState']===_0x406c60(0x189)&&(this[_0x406c60(0x1f1)]+=this[_0x406c60(0x29d)](),this['_tpbChargeTime']>=0x1&&this[_0x406c60(0x2f1)]());}},VisuMZ[_0x485a45(0x278)]['Game_Battler_tpbAcceleration']=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x29d)],Game_Battler['prototype'][_0x485a45(0x29d)]=function(){const _0x17e2e4=_0x485a45;if(BattleManager[_0x17e2e4(0x173)]()){let _0x14fe2f=VisuMZ['BattleSystemCTB']['Settings'][_0x17e2e4(0x327)][_0x17e2e4(0x22c)][_0x17e2e4(0x1d6)](this,this);const _0x352604=0x0;return _0x14fe2f+_0x352604;}else return VisuMZ[_0x17e2e4(0x278)][_0x17e2e4(0x30b)]['call'](this);},VisuMZ['BattleSystemCTB'][_0x485a45(0x256)]=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x1a5)],Game_Battler[_0x485a45(0x32a)]['tpbRequiredCastTime']=function(){const _0x68f51a=_0x485a45;if(BattleManager[_0x68f51a(0x173)]()){if(_0x68f51a(0x164)===_0x68f51a(0x164))return VisuMZ[_0x68f51a(0x278)][_0x68f51a(0x35a)][_0x68f51a(0x327)][_0x68f51a(0x1e8)]['call'](this,this);else _0x3c70f6[_0x68f51a(0x278)][_0x68f51a(0x212)][_0x68f51a(0x1d6)](this,_0x58852f);}else return VisuMZ['BattleSystemCTB'][_0x68f51a(0x256)][_0x68f51a(0x1d6)](this);},Game_Battler[_0x485a45(0x32a)][_0x485a45(0x260)]=function(){const _0x121a3d=_0x485a45,_0x503ef0=SceneManager[_0x121a3d(0x219)][_0x121a3d(0x18e)];if(!_0x503ef0)return-0x1;const _0x4edebe=_0x503ef0[_0x121a3d(0x309)];if(!_0x4edebe)return-0x1;const _0x53fb82=_0x4edebe[_0x121a3d(0x200)](_0x5a9482=>_0x5a9482[_0x121a3d(0x194)]()===this);return _0x4edebe[_0x121a3d(0x19c)](_0x53fb82);},Game_Battler[_0x485a45(0x32a)][_0x485a45(0x33f)]=function(_0x123a69){const _0x5b20bc=_0x485a45;if(!BattleManager[_0x5b20bc(0x173)]())return;if(!SceneManager['isSceneBattle']())return;if(this===BattleManager[_0x5b20bc(0x177)]())return;if(this===BattleManager[_0x5b20bc(0x246)])return;const _0x1ce71b=this[_0x5b20bc(0x260)]();if(_0x1ce71b<0x0)return;this[_0x5b20bc(0x240)](_0x1ce71b+_0x123a69);},Game_Battler['prototype'][_0x485a45(0x240)]=function(_0x1a74d5){const _0x4f1925=_0x485a45;if(!BattleManager[_0x4f1925(0x173)]())return;if(!SceneManager[_0x4f1925(0x28f)]())return;if(this===BattleManager['actor']())return;if(this===BattleManager[_0x4f1925(0x246)])return;_0x1a74d5=Math['max'](_0x1a74d5,0x1),this[_0x4f1925(0x239)](_0x1a74d5);},Game_Battler[_0x485a45(0x32a)][_0x485a45(0x239)]=function(_0x139349){const _0x2fe29b=_0x485a45;if(!BattleManager[_0x2fe29b(0x173)]())return;if(!SceneManager[_0x2fe29b(0x28f)]())return;if(this===BattleManager['actor']())return;if(this===BattleManager[_0x2fe29b(0x246)])return;const _0x72131b=SceneManager[_0x2fe29b(0x219)]['_ctbTurnOrderWindow'];if(!_0x72131b)return;const _0x5f0d3f=_0x72131b[_0x2fe29b(0x309)];if(!_0x5f0d3f)return;const _0x17fa8f=this['getCurrentTurnOrderPositionCTB']();_0x17fa8f!==_0x139349&&this['onCtbOrderChange'](_0x139349-_0x17fa8f);let _0x2fad07=_0x139349,_0x133c22=_0x139349;_0x17fa8f>_0x139349?_0x2fad07-=0x1:_0x133c22+=0x1;const _0x45596d=_0x5f0d3f[_0x2fad07][_0x2fe29b(0x2e6)](!![]),_0x275088=_0x5f0d3f[_0x133c22]['ticksLeft'](!![]),_0x1a044b=(_0x45596d+_0x275088)/0x2;let _0x270486=_0x1a044b*this['tpbAcceleration']();if(this[_0x2fe29b(0x190)]===_0x2fe29b(0x189))this[_0x2fe29b(0x1f1)]=0x1-_0x270486;else this[_0x2fe29b(0x190)]===_0x2fe29b(0x2af)&&(this[_0x2fe29b(0x360)]=this[_0x2fe29b(0x1a5)]()-_0x270486);BattleManager['_actionBattlers']=[],BattleManager[_0x2fe29b(0x1f9)]();},Game_Battler['prototype'][_0x485a45(0x2ec)]=function(_0x477d7d){const _0xbb4afd=_0x485a45,_0x5cb2a6=VisuMZ[_0xbb4afd(0x278)][_0xbb4afd(0x35a)][_0xbb4afd(0x2cc)],_0x2a8c1a=_0x477d7d>0x0?_0xbb4afd(0x202):'Rush';if(_0x5cb2a6['%1AnimationID'[_0xbb4afd(0x1cd)](_0x2a8c1a)]){const _0x4a671f=_0x5cb2a6[_0xbb4afd(0x2da)[_0xbb4afd(0x1cd)](_0x2a8c1a)],_0x243943=_0x5cb2a6[_0xbb4afd(0x2df)[_0xbb4afd(0x1cd)](_0x2a8c1a)],_0xbae238=_0x5cb2a6[_0xbb4afd(0x2f2)[_0xbb4afd(0x1cd)](_0x2a8c1a)];$gameTemp[_0xbb4afd(0x1e2)]([this],_0x4a671f,_0x243943,_0xbae238);}if(this[_0xbb4afd(0x194)]()&&_0x5cb2a6['%1PopupText'['format'](_0x2a8c1a)][_0xbb4afd(0x205)]>0x0){const _0x4df51f=_0x5cb2a6['%1PopupText'[_0xbb4afd(0x1cd)](_0x2a8c1a)],_0x53e6a5={'textColor':ColorManager['getColor'](_0x5cb2a6[_0xbb4afd(0x187)[_0xbb4afd(0x1cd)](_0x2a8c1a)]),'flashColor':_0x5cb2a6['%1FlashColor'[_0xbb4afd(0x1cd)](_0x2a8c1a)],'flashDuration':_0x5cb2a6[_0xbb4afd(0x166)[_0xbb4afd(0x1cd)](_0x2a8c1a)]};this['setupTextPopup'](_0x4df51f,_0x53e6a5);}},VisuMZ[_0x485a45(0x278)][_0x485a45(0x27d)]=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x2d5)],Game_Battler['prototype'][_0x485a45(0x2d5)]=function(){const _0x5c64f1=_0x485a45;if(BattleManager['ctbHasInstantActionAfter'](this))return;VisuMZ['BattleSystemCTB'][_0x5c64f1(0x27d)][_0x5c64f1(0x1d6)](this);},BattleManager[_0x485a45(0x158)]=function(_0x30c59e){const _0x41349d=_0x485a45;return BattleManager['allBattleMembers']()[_0x41349d(0x264)](_0x5a98ea=>_0x5a98ea!==_0x30c59e)[_0x41349d(0x218)](_0x272750=>_0x272750[_0x41349d(0x147)]()&&_0x272750['canMove']()&&_0x272750[_0x41349d(0x35e)]>=0x1);},VisuMZ[_0x485a45(0x278)][_0x485a45(0x1d0)]=Game_Battler['prototype']['updateTpbChargeTime'],Game_Battler[_0x485a45(0x32a)]['updateTpbChargeTime']=function(){const _0x4cebc1=_0x485a45;BattleManager[_0x4cebc1(0x173)]()?this[_0x4cebc1(0x1b2)]():VisuMZ[_0x4cebc1(0x278)][_0x4cebc1(0x1d0)][_0x4cebc1(0x1d6)](this);},Game_Battler[_0x485a45(0x32a)][_0x485a45(0x1b2)]=function(){const _0x9268f4=_0x485a45;if(this[_0x9268f4(0x190)]===_0x9268f4(0x189)){this[_0x9268f4(0x1f1)]+=this[_0x9268f4(0x29d)]();if(this[_0x9268f4(0x1f1)]>=0x1){if(_0x9268f4(0x244)!==_0x9268f4(0x27b))this[_0x9268f4(0x2f1)]();else{let _0x1c3ff8=this[_0x9268f4(0x33e)](),_0x598a8a=this[_0x9268f4(0x25e)](),_0x5d463d=_0x310c0d[_0x9268f4(0x341)];_0x19fda3[_0x9268f4(0x161)]=new _0x191e0e(_0x1c3ff8,_0x598a8a);const _0x418f92=_0x9268f4(0x24d),_0x35231e=_0x1fc8b1[_0x9268f4(0x313)](_0x4694b3[_0x9268f4(0x167)[_0x9268f4(0x1cd)](_0x50699c)]);_0x2e1333[_0x9268f4(0x161)][_0x9268f4(0x27a)](0x0,0x0,_0x1c3ff8,_0x598a8a,_0x418f92),_0x1c3ff8-=0x2,_0x598a8a-=0x2,_0xdc4db9['bitmap'][_0x9268f4(0x27a)](0x1,0x1,_0x1c3ff8,_0x598a8a,_0x35231e),_0x1c3ff8-=_0x5d463d*0x2,_0x598a8a-=_0x5d463d*0x2,_0x97d739['bitmap']['fillRect'](0x1+_0x5d463d,0x1+_0x5d463d,_0x1c3ff8,_0x598a8a,_0x418f92),_0x1c3ff8-=0x2,_0x598a8a-=0x2,_0x5d463d+=0x1,_0x52c3c4[_0x9268f4(0x161)]['clearRect'](0x1+_0x5d463d,0x1+_0x5d463d,_0x1c3ff8,_0x598a8a);}}}},VisuMZ[_0x485a45(0x278)][_0x485a45(0x28c)]=Game_Battler[_0x485a45(0x32a)][_0x485a45(0x1ea)],Game_Battler['prototype'][_0x485a45(0x1ea)]=function(){const _0x1acf12=_0x485a45;if(BattleManager['isCTB']()){if(_0x1acf12(0x1b3)==='ZAqxD')return _0x32fb17[_0x1acf12(0x278)]['Game_Battler_tpbBaseSpeed'][_0x1acf12(0x1d6)](this);else this[_0x1acf12(0x2aa)]();}else{if('CFfjk'!==_0x1acf12(0x2a4))VisuMZ[_0x1acf12(0x278)][_0x1acf12(0x28c)][_0x1acf12(0x1d6)](this);else return this[_0x1acf12(0x360)]/this[_0x1acf12(0x1a5)]();}},Game_Battler['prototype'][_0x485a45(0x2aa)]=function(){const _0x10c21b=_0x485a45;if(this[_0x10c21b(0x190)]===_0x10c21b(0x2af)){if(_0x10c21b(0x152)==='dvnvG'){const _0xf5a5e5=_0x4c1bf0['%1AnimationID'[_0x10c21b(0x1cd)](_0x246139)],_0x2ab059=_0x373fd1[_0x10c21b(0x2df)[_0x10c21b(0x1cd)](_0x421b55)],_0x263f7e=_0x1e3370['%1Mute'[_0x10c21b(0x1cd)](_0xc493af)];_0x27259a[_0x10c21b(0x1e2)]([this],_0xf5a5e5,_0x2ab059,_0x263f7e);}else this['_tpbCastTime']+=this['tpbAcceleration'](),this['_tpbCastTime']>=this['tpbRequiredCastTime']()&&(this['_tpbState']=_0x10c21b(0x35f));}},Game_Actor[_0x485a45(0x32a)]['createTurnOrderCTBGraphicType']=function(){const _0x213d51=_0x485a45,_0x5956fe=this['actor']()['note'];if(_0x5956fe[_0x213d51(0x22f)](/<CTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i)){if(_0x213d51(0x354)===_0x213d51(0x354))return _0x213d51(0x284);else _0xf31767=_0x213d51(0x284);}else{if(_0x5956fe['match'](/<CTB TURN ORDER ICON:[ ](\d+)>/i))return'icon';}return Window_CTB_TurnOrder[_0x213d51(0x35a)][_0x213d51(0x1e5)];},Game_Actor[_0x485a45(0x32a)][_0x485a45(0x1c8)]=function(){const _0x473d5f=_0x485a45,_0x188718=this[_0x473d5f(0x177)]()[_0x473d5f(0x303)];if(_0x188718[_0x473d5f(0x22f)](/<CTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return'NlmRO'!==_0x473d5f(0x2bc)?_0x297abf['x']-_0x18e8fc['x']:String(RegExp['$1']);return this[_0x473d5f(0x16a)]();},Game_Actor[_0x485a45(0x32a)][_0x485a45(0x1f7)]=function(){const _0x1e1c31=_0x485a45,_0x30b239=this[_0x1e1c31(0x177)]()[_0x1e1c31(0x303)];if(_0x30b239[_0x1e1c31(0x22f)](/<CTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i)){if('iEvAx'===_0x1e1c31(0x338))return Number(RegExp['$2']);else{const _0x5ac2e6=this[_0x1e1c31(0x194)]();if(!_0x5ac2e6)return;if(this[_0x1e1c31(0x17f)]===_0x5ac2e6[_0x1e1c31(0x147)]()&&this[_0x1e1c31(0x193)]===_0x5ac2e6[_0x1e1c31(0x314)]())return;this[_0x1e1c31(0x17f)]=_0x5ac2e6[_0x1e1c31(0x147)](),this[_0x1e1c31(0x193)]=_0x5ac2e6[_0x1e1c31(0x314)]();let _0x2b0ddd=this['_isAlive']&&this[_0x1e1c31(0x193)]?0xff:0x0;this[_0x1e1c31(0x290)](_0x2b0ddd);}}return this[_0x1e1c31(0x257)]();},Game_Actor[_0x485a45(0x32a)][_0x485a45(0x1a1)]=function(){const _0x3c0a57=_0x485a45,_0x3b9706=this[_0x3c0a57(0x177)]()['note'];if(_0x3b9706[_0x3c0a57(0x22f)](/<CTB TURN ORDER ICON:[ ](\d+)>/i))return Number(RegExp['$1']);return Window_CTB_TurnOrder[_0x3c0a57(0x35a)][_0x3c0a57(0x199)];},Game_Enemy[_0x485a45(0x32a)][_0x485a45(0x2cd)]=function(){const _0x2ab492=_0x485a45,_0x1f42f8=this[_0x2ab492(0x335)]()[_0x2ab492(0x303)];if(_0x1f42f8[_0x2ab492(0x22f)](/<CTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i)){if('EEEha'===_0x2ab492(0x208))return _0x2ab492(0x284);else{if(!_0x315924[_0x2ab492(0x173)]())return;this[_0x2ab492(0x18e)]=new _0x23e22a();const _0x17582c=this[_0x2ab492(0x159)](this[_0x2ab492(0x1d1)]);this[_0x2ab492(0x2e2)](this[_0x2ab492(0x18e)],_0x17582c),this[_0x2ab492(0x2d0)](),_0x494ca5[_0x2ab492(0x1f9)](!![]);}}else{if(_0x1f42f8['match'](/<CTB TURN ORDER ICON:[ ](\d+)>/i))return'TIzsJ'!==_0x2ab492(0x14f)?'icon':_0x32bbeb['BattleSystemCTB'][_0x2ab492(0x256)]['call'](this);}return Window_CTB_TurnOrder[_0x2ab492(0x35a)]['EnemyBattlerType'];},Game_Enemy[_0x485a45(0x32a)]['createTurnOrderCTBGraphicFaceName']=function(){const _0x46b332=_0x485a45,_0x32b170=this['enemy']()['note'];if(_0x32b170[_0x46b332(0x22f)](/<CTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return String(RegExp['$1']);return Window_CTB_TurnOrder['Settings'][_0x46b332(0x149)];},Game_Enemy[_0x485a45(0x32a)][_0x485a45(0x1f7)]=function(){const _0x2d5514=_0x485a45,_0x590f58=this[_0x2d5514(0x335)]()[_0x2d5514(0x303)];if(_0x590f58['match'](/<CTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return Number(RegExp['$2']);return Window_CTB_TurnOrder[_0x2d5514(0x35a)]['EnemyBattlerFaceIndex'];},Game_Enemy['prototype']['createTurnOrderCTBGraphicIconIndex']=function(){const _0x35954f=_0x485a45,_0x383e42=this[_0x35954f(0x335)]()['note'];if(_0x383e42['match'](/<CTB TURN ORDER ICON:[ ](\d+)>/i))return Number(RegExp['$1']);return Window_CTB_TurnOrder[_0x35954f(0x35a)][_0x35954f(0x2c8)];},VisuMZ[_0x485a45(0x278)]['Scene_Battle_createAllWindows']=Scene_Battle[_0x485a45(0x32a)][_0x485a45(0x340)],Scene_Battle[_0x485a45(0x32a)]['createAllWindows']=function(){const _0x157b06=_0x485a45;VisuMZ[_0x157b06(0x278)][_0x157b06(0x31c)]['call'](this),this[_0x157b06(0x2ca)]();},Scene_Battle[_0x485a45(0x32a)][_0x485a45(0x2ca)]=function(){const _0x26e4af=_0x485a45;if(!BattleManager[_0x26e4af(0x173)]())return;this['_ctbTurnOrderWindow']=new Window_CTB_TurnOrder();const _0x38b777=this[_0x26e4af(0x159)](this[_0x26e4af(0x1d1)]);this[_0x26e4af(0x2e2)](this['_ctbTurnOrderWindow'],_0x38b777),this[_0x26e4af(0x2d0)](),BattleManager[_0x26e4af(0x1f9)](!![]);},Scene_Battle[_0x485a45(0x32a)]['repositionLogWindowCTB']=function(){const _0x516703=_0x485a45,_0x42cfb7=Window_CTB_TurnOrder[_0x516703(0x35a)];if(_0x42cfb7['DisplayPosition']!=='top')return;if(!_0x42cfb7[_0x516703(0x1f3)])return;if(!this[_0x516703(0x15b)])return;const _0x5594de=this[_0x516703(0x18e)]['y']-Math['round']((Graphics[_0x516703(0x16c)]-Graphics[_0x516703(0x1cb)])/0x2),_0x339718=_0x5594de+this[_0x516703(0x18e)]['height'];this[_0x516703(0x15b)]['y']=_0x339718+_0x42cfb7[_0x516703(0x1fa)];};function Sprite_CTB_TurnOrder_Battler(){this['initialize'](...arguments);}Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)]=Object['create'](Sprite_Clickable[_0x485a45(0x32a)]),Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)]['constructor']=Sprite_CTB_TurnOrder_Battler,Sprite_CTB_TurnOrder_Battler['prototype']['initialize']=function(_0x22c3bf,_0x27aa9d,_0x4b6387){const _0x3dde85=_0x485a45;this['initMembers'](_0x22c3bf,_0x27aa9d,_0x4b6387),Sprite_Clickable[_0x3dde85(0x32a)][_0x3dde85(0x299)]['call'](this),this[_0x3dde85(0x267)]();},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x270)]=function(_0x206b01,_0x4bd85b,_0x37d742){const _0x4492d0=_0x485a45;this[_0x4492d0(0x329)]=_0x206b01,this[_0x4492d0(0x17e)]=_0x4bd85b,this[_0x4492d0(0x27f)]=_0x37d742;const _0x4fbcc2=Window_CTB_TurnOrder[_0x4492d0(0x35a)],_0x1a0f94=this['isHorz'](),_0x206370=this[_0x4492d0(0x1fe)]();this[_0x4492d0(0x2a7)]=0x0,this[_0x4492d0(0x1dc)]=_0x1a0f94?_0x4fbcc2['SpriteThin']*_0x206370:0x0,this[_0x4492d0(0x197)]=_0x1a0f94?0x0:_0x4fbcc2[_0x4492d0(0x1ff)]*_0x206370,this[_0x4492d0(0x31e)]=0x0,this['_fadeTarget']=0xff,this[_0x4492d0(0x17f)]=!![],this[_0x4492d0(0x193)]=!![];},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)]['createChildren']=function(){const _0x1f6be1=_0x485a45;this[_0x1f6be1(0x34d)](),this['createBackgroundSprite'](),this[_0x1f6be1(0x1c3)](),this[_0x1f6be1(0x2ae)](),this[_0x1f6be1(0x2d8)]();},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x34d)]=function(){const _0x3953eb=_0x485a45;this['x']=this[_0x3953eb(0x1dc)],this['y']=this[_0x3953eb(0x197)];},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x2ad)]=function(){const _0x3d622c=_0x485a45,_0x2c61c0=Window_CTB_TurnOrder[_0x3d622c(0x35a)],_0x4ab458=[_0x3d622c(0x1ae),_0x3d622c(0x1ba)][_0x3d622c(0x23c)](_0x2c61c0[_0x3d622c(0x24f)]);return _0x4ab458;},Sprite_CTB_TurnOrder_Battler['prototype'][_0x485a45(0x33e)]=function(){const _0xbe6473=_0x485a45,_0x25f7b1=Window_CTB_TurnOrder[_0xbe6473(0x35a)];return this[_0xbe6473(0x2ad)]()?_0x25f7b1[_0xbe6473(0x1ff)]:_0x25f7b1[_0xbe6473(0x2e3)];},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x25e)]=function(){const _0x136fb6=_0x485a45,_0x269afe=Window_CTB_TurnOrder['Settings'];return this['isHorz']()?_0x269afe[_0x136fb6(0x2e3)]:_0x269afe['SpriteThin'];},Sprite_CTB_TurnOrder_Battler['prototype']['createTestBitmap']=function(){const _0x1ea94e=_0x485a45;this[_0x1ea94e(0x161)]=new Bitmap(0x48,0x24);const _0x3ac8cc=this[_0x1ea94e(0x194)]()?this[_0x1ea94e(0x194)]()['name']():'%1\x20%2\x20%3'['format'](this[_0x1ea94e(0x329)],this[_0x1ea94e(0x17e)],this[_0x1ea94e(0x27f)]);this['bitmap'][_0x1ea94e(0x184)](_0x3ac8cc,0x0,0x0,0x48,0x24,_0x1ea94e(0x25b));},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x326)]=function(){const _0x3a936f=_0x485a45;if(!Window_CTB_TurnOrder[_0x3a936f(0x35a)]['ShowMarkerBg'])return;const _0x35f5c4=Window_CTB_TurnOrder[_0x3a936f(0x35a)],_0x3778a4=this['_unit']===$gameParty?_0x3a936f(0x209):'Enemy',_0xc02ab8=_0x3a936f(0x24b)['format'](_0x3778a4),_0x1da651=new Sprite();_0x1da651[_0x3a936f(0x305)]['x']=this[_0x3a936f(0x305)]['x'],_0x1da651[_0x3a936f(0x305)]['y']=this[_0x3a936f(0x305)]['y'];if(_0x35f5c4[_0xc02ab8])_0x1da651[_0x3a936f(0x161)]=ImageManager['loadSystem'](_0x35f5c4[_0xc02ab8]);else{const _0x23a36f=this[_0x3a936f(0x33e)](),_0x57bc78=this[_0x3a936f(0x25e)]();_0x1da651['bitmap']=new Bitmap(_0x23a36f,_0x57bc78);const _0xfcd25e=ColorManager['getColor'](_0x35f5c4[_0x3a936f(0x24a)[_0x3a936f(0x1cd)](_0x3778a4)]),_0x82f3ce=ColorManager['getColor'](_0x35f5c4[_0x3a936f(0x301)['format'](_0x3778a4)]);_0x1da651[_0x3a936f(0x161)]['gradientFillRect'](0x0,0x0,_0x23a36f,_0x57bc78,_0xfcd25e,_0x82f3ce,!![]);}this[_0x3a936f(0x27c)]=_0x1da651,this[_0x3a936f(0x175)](this[_0x3a936f(0x27c)]),this[_0x3a936f(0x2a6)]=this[_0x3a936f(0x27c)][_0x3a936f(0x2a6)],this[_0x3a936f(0x16c)]=this[_0x3a936f(0x27c)]['height'];},Sprite_CTB_TurnOrder_Battler['prototype']['createGraphicSprite']=function(){const _0x4c6483=_0x485a45,_0x1168ce=new Sprite();_0x1168ce[_0x4c6483(0x305)]['x']=this[_0x4c6483(0x305)]['x'],_0x1168ce[_0x4c6483(0x305)]['y']=this['anchor']['y'],this[_0x4c6483(0x1c0)]=_0x1168ce,this[_0x4c6483(0x175)](this['_graphicSprite']),this[_0x4c6483(0x255)]();},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)]['createBorderSprite']=function(){const _0x424a03=_0x485a45;if(!Window_CTB_TurnOrder['Settings'][_0x424a03(0x1bc)])return;const _0x2c17ed=Window_CTB_TurnOrder[_0x424a03(0x35a)],_0x2e1c0d=this['_unit']===$gameParty?_0x424a03(0x209):_0x424a03(0x33d),_0x4e339d=_0x424a03(0x324)['format'](_0x2e1c0d),_0xe1594d=new Sprite();_0xe1594d['anchor']['x']=this['anchor']['x'],_0xe1594d['anchor']['y']=this[_0x424a03(0x305)]['y'];if(_0x2c17ed[_0x4e339d]){if(_0x424a03(0x207)==='PxVeo')_0xe1594d[_0x424a03(0x161)]=ImageManager[_0x424a03(0x1dd)](_0x2c17ed[_0x4e339d]);else{const _0x576127=this[_0x424a03(0x194)]();if(!_0x576127)return;if(!_0x576127[_0x424a03(0x1eb)]())return;if(this[_0x424a03(0x1c4)]===_0x576127[_0x424a03(0x160)]())return;this[_0x424a03(0x1c4)]=_0x576127[_0x424a03(0x160)]();if(_0x576127['hasSvBattler']())this[_0x424a03(0x1c4)]=0x0;this['_graphicSprite']['setHue'](this[_0x424a03(0x1c4)]);}}else{if(_0x424a03(0x203)!==_0x424a03(0x2e7)){let _0x30b30b=this['bitmapWidth'](),_0x4aa83d=this[_0x424a03(0x25e)](),_0x3e2ed0=_0x2c17ed['BorderThickness'];_0xe1594d[_0x424a03(0x161)]=new Bitmap(_0x30b30b,_0x4aa83d);const _0x2fa621='#000000',_0x540828=ColorManager[_0x424a03(0x313)](_0x2c17ed['%1BorderColor'[_0x424a03(0x1cd)](_0x2e1c0d)]);_0xe1594d[_0x424a03(0x161)][_0x424a03(0x27a)](0x0,0x0,_0x30b30b,_0x4aa83d,_0x2fa621),_0x30b30b-=0x2,_0x4aa83d-=0x2,_0xe1594d[_0x424a03(0x161)]['fillRect'](0x1,0x1,_0x30b30b,_0x4aa83d,_0x540828),_0x30b30b-=_0x3e2ed0*0x2,_0x4aa83d-=_0x3e2ed0*0x2,_0xe1594d[_0x424a03(0x161)][_0x424a03(0x27a)](0x1+_0x3e2ed0,0x1+_0x3e2ed0,_0x30b30b,_0x4aa83d,_0x2fa621),_0x30b30b-=0x2,_0x4aa83d-=0x2,_0x3e2ed0+=0x1,_0xe1594d[_0x424a03(0x161)]['clearRect'](0x1+_0x3e2ed0,0x1+_0x3e2ed0,_0x30b30b,_0x4aa83d);}else this[_0x424a03(0x34a)]=_0x40398c['isCTB'](),_0x18f3f4[_0x424a03(0x278)]['Game_Battler_onRestrict'][_0x424a03(0x1d6)](this),this[_0x424a03(0x34a)]=_0x170752;}this['_backgroundSprite']=_0xe1594d,this[_0x424a03(0x175)](this['_backgroundSprite']);},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x2d8)]=function(){const _0x5f5b57=_0x485a45,_0x2f32c5=Window_CTB_TurnOrder['Settings'];if(!_0x2f32c5[_0x5f5b57(0x1d9)])return;if(this[_0x5f5b57(0x329)]===$gameParty)return;const _0x123b84=this[_0x5f5b57(0x33e)](),_0x319f7a=this[_0x5f5b57(0x25e)](),_0x42a2b6=new Sprite();_0x42a2b6['anchor']['x']=this[_0x5f5b57(0x305)]['x'],_0x42a2b6[_0x5f5b57(0x305)]['y']=this[_0x5f5b57(0x305)]['y'],_0x42a2b6['bitmap']=new Bitmap(_0x123b84,_0x319f7a),this[_0x5f5b57(0x2c5)]=_0x42a2b6,this[_0x5f5b57(0x175)](this[_0x5f5b57(0x2c5)]);},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x194)]=function(){const _0x5b0791=_0x485a45;return this[_0x5b0791(0x329)]?this[_0x5b0791(0x329)]['members']()[this[_0x5b0791(0x17e)]]:null;},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)]['ticksLeft']=function(_0x1f0929){const _0x165d35=_0x485a45,_0x1ab8ca=this[_0x165d35(0x194)]();if(!_0x1ab8ca)return Number[_0x165d35(0x288)];const _0x431c42=0x1*(this[_0x165d35(0x27f)]+0x1);return _0x1ab8ca[_0x165d35(0x2c3)](_0x431c42,_0x1f0929);},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x355)]=function(){const _0x31fb3d=_0x485a45;Sprite_Clickable[_0x31fb3d(0x32a)]['update'][_0x31fb3d(0x1d6)](this),this[_0x31fb3d(0x19f)](),this[_0x31fb3d(0x29f)](),this[_0x31fb3d(0x22d)](),this[_0x31fb3d(0x29c)](),this[_0x31fb3d(0x2f0)](),this['updateGraphicHue'](),this['updateLetter'](),this[_0x31fb3d(0x1c7)]();},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)]['checkPosition']=function(){const _0x58cb78=_0x485a45,_0x3e8018=this[_0x58cb78(0x1ec)]();if(this[_0x58cb78(0x2ba)]===_0x3e8018)return;this[_0x58cb78(0x2ba)]=_0x3e8018;const _0x35cc3e=Window_CTB_TurnOrder['Settings'],_0x24db87=this[_0x58cb78(0x2ad)](),_0x26f19e=_0x35cc3e[_0x58cb78(0x1be)],_0x2fc4c5=_0x35cc3e[_0x58cb78(0x248)],_0x436e10=SceneManager[_0x58cb78(0x219)][_0x58cb78(0x18e)];if(!_0x436e10)return;this[_0x58cb78(0x2a7)]=_0x35cc3e[_0x58cb78(0x31d)],this[_0x58cb78(0x1dc)]=_0x24db87?_0x35cc3e[_0x58cb78(0x1ff)]*_0x3e8018:0x0,this[_0x58cb78(0x197)]=_0x24db87?0x0:_0x35cc3e[_0x58cb78(0x1ff)]*_0x3e8018,_0x3e8018>0x0&&(this[_0x58cb78(0x1dc)]+=_0x24db87?_0x2fc4c5:0x0,this['_positionTargetY']+=_0x24db87?0x0:_0x2fc4c5),_0x26f19e?this[_0x58cb78(0x1dc)]=_0x24db87?_0x436e10[_0x58cb78(0x2a6)]-this[_0x58cb78(0x1dc)]-_0x35cc3e[_0x58cb78(0x1ff)]:0x0:_0x58cb78(0x196)!==_0x58cb78(0x2dc)?this[_0x58cb78(0x197)]=_0x24db87?0x0:_0x436e10[_0x58cb78(0x16c)]-this[_0x58cb78(0x197)]-_0x35cc3e[_0x58cb78(0x1ff)]:_0x4519fe['BattleSystemCTB']['Game_Battler_applyTpbPenalty']['call'](this);},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)]['updatePosition']=function(){const _0x224c9a=_0x485a45;if(this[_0x224c9a(0x31e)]>0x0)return;if(this[_0x224c9a(0x2a7)]>0x0){const _0x29f64b=this[_0x224c9a(0x2a7)];this['x']=(this['x']*(_0x29f64b-0x1)+this[_0x224c9a(0x1dc)])/_0x29f64b,this['y']=(this['y']*(_0x29f64b-0x1)+this[_0x224c9a(0x197)])/_0x29f64b,this['_positionDuration']--;}if(this[_0x224c9a(0x2a7)]<=0x0&&this[_0x224c9a(0x17f)]){if(_0x224c9a(0x2f7)!==_0x224c9a(0x2f7)){const _0x45c0e=this['bitmapWidth'](),_0x9d858c=this[_0x224c9a(0x25e)]();_0x5a9f5e['bitmap']=new _0x19bba5(_0x45c0e,_0x9d858c);const _0x29a88e=_0x5ac236[_0x224c9a(0x313)](_0x150e37[_0x224c9a(0x24a)['format'](_0x373329)]),_0x327977=_0x1c26ca[_0x224c9a(0x313)](_0x4001e2['%1BgColor2'[_0x224c9a(0x1cd)](_0x55904a)]);_0x3e3dad[_0x224c9a(0x161)][_0x224c9a(0x1ab)](0x0,0x0,_0x45c0e,_0x9d858c,_0x29a88e,_0x327977,!![]);}else{this['x']=this[_0x224c9a(0x1dc)],this['y']=this[_0x224c9a(0x197)];if(this['opacity']<=0x0&&!this[_0x224c9a(0x18f)]){if(_0x224c9a(0x2d2)===_0x224c9a(0x2d2))this[_0x224c9a(0x290)](0xff);else return _0x1dffa4[_0x224c9a(0x278)]['Settings']['Mechanics'][_0x224c9a(0x233)][_0x224c9a(0x1d6)](this,this);}}}},Sprite_CTB_TurnOrder_Battler['prototype'][_0x485a45(0x1fe)]=function(){const _0x571cba=_0x485a45;return Window_CTB_TurnOrder[_0x571cba(0x35a)][_0x571cba(0x317)]*0x14;},Sprite_CTB_TurnOrder_Battler['prototype'][_0x485a45(0x2c9)]=function(){const _0x26c5d7=_0x485a45;return SceneManager[_0x26c5d7(0x219)][_0x26c5d7(0x18e)];},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x1ec)]=function(){const _0x405eef=_0x485a45;if(!this[_0x405eef(0x2c9)]())return this[_0x405eef(0x1fe)]();const _0x32be15=this[_0x405eef(0x2c9)]()[_0x405eef(0x309)];return _0x32be15[_0x405eef(0x19c)](this);},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x2c7)]=function(){const _0x32409b=_0x485a45,_0x4db2e0=Window_CTB_TurnOrder[_0x32409b(0x35a)],_0x2124d9=this[_0x32409b(0x2ad)](),_0x342a64=_0x2124d9?_0x4db2e0['TotalHorzSprites']:_0x4db2e0[_0x32409b(0x20e)];this[_0x32409b(0x27f)]-=0x1,this[_0x32409b(0x27f)]<0x0&&(_0x32409b(0x21b)!=='qFVjv'?this['isCTB']()?this[_0x32409b(0x2b1)]():_0x2f7554['BattleSystemCTB']['BattleManager_processTurn']['call'](this):(this[_0x32409b(0x27f)]=_0x342a64-0x1,this['startFade'](0x0)));},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x290)]=function(_0x252c5a){const _0x32720b=_0x485a45,_0x14853e=Window_CTB_TurnOrder[_0x32720b(0x35a)];this[_0x32720b(0x31e)]=_0x14853e[_0x32720b(0x31d)],this[_0x32720b(0x2fa)]=_0x252c5a;},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x22d)]=function(){const _0xe63e33=_0x485a45,_0x19ab77=this[_0xe63e33(0x194)]();if(!_0x19ab77)return;if(this[_0xe63e33(0x17f)]===_0x19ab77['isAlive']()&&this[_0xe63e33(0x193)]===_0x19ab77[_0xe63e33(0x314)]())return;this['_isAlive']=_0x19ab77[_0xe63e33(0x147)](),this[_0xe63e33(0x193)]=_0x19ab77[_0xe63e33(0x314)]();let _0x3c5592=this[_0xe63e33(0x17f)]&&this[_0xe63e33(0x193)]?0xff:0x0;this['startFade'](_0x3c5592);},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x29c)]=function(){const _0x30f4b3=_0x485a45;if(this[_0x30f4b3(0x31e)]>0x0){const _0x491bf5=this[_0x30f4b3(0x31e)];this['opacity']=(this['opacity']*(_0x491bf5-0x1)+this[_0x30f4b3(0x2fa)])/_0x491bf5,this[_0x30f4b3(0x31e)]--,this[_0x30f4b3(0x31e)]<=0x0&&(this[_0x30f4b3(0x19f)](),this[_0x30f4b3(0x2a7)]=0x0,this[_0x30f4b3(0x29f)](),this[_0x30f4b3(0x253)]=this[_0x30f4b3(0x2fa)]);}if(this['_isBattleOver'])return;BattleManager[_0x30f4b3(0x1e0)]===_0x30f4b3(0x1b1)&&(this[_0x30f4b3(0x18f)]=!![],this[_0x30f4b3(0x290)](0x0));},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x2f0)]=function(){const _0x3297ed=_0x485a45,_0x5cace1=this[_0x3297ed(0x194)]();if(!_0x5cace1)return;const _0x58f344=Window_CTB_TurnOrder[_0x3297ed(0x35a)],_0x486883=this['_unit']===$gameParty?_0x3297ed(0x209):_0x3297ed(0x33d);let _0x3bd246=_0x5cace1[_0x3297ed(0x308)]();if(_0x5cace1[_0x3297ed(0x163)]()&&_0x3bd246===_0x3297ed(0x335))_0x3bd246=_0x3297ed(0x284);else{if(_0x5cace1[_0x3297ed(0x1eb)]()&&_0x3bd246===_0x3297ed(0x275)){if(_0x3297ed(0x2ac)!=='YZhuo'){const _0x4c3d89=_0x1e9959[_0x3297ed(0x278)][_0x3297ed(0x35a)]['Effect'],_0x604d0b=_0x11d351>0x0?_0x3297ed(0x202):'Rush';if(_0x4c3d89[_0x3297ed(0x2da)[_0x3297ed(0x1cd)](_0x604d0b)]){const _0x290e24=_0x4c3d89[_0x3297ed(0x2da)[_0x3297ed(0x1cd)](_0x604d0b)],_0x1b1e3c=_0x4c3d89[_0x3297ed(0x2df)['format'](_0x604d0b)],_0x26cd28=_0x4c3d89[_0x3297ed(0x2f2)[_0x3297ed(0x1cd)](_0x604d0b)];_0x129cae[_0x3297ed(0x1e2)]([this],_0x290e24,_0x1b1e3c,_0x26cd28);}if(this[_0x3297ed(0x194)]()&&_0x4c3d89[_0x3297ed(0x29e)[_0x3297ed(0x1cd)](_0x604d0b)][_0x3297ed(0x205)]>0x0){const _0x3d5778=_0x4c3d89[_0x3297ed(0x29e)['format'](_0x604d0b)],_0x3ecdec={'textColor':_0x5c64f0[_0x3297ed(0x313)](_0x4c3d89[_0x3297ed(0x187)[_0x3297ed(0x1cd)](_0x604d0b)]),'flashColor':_0x4c3d89['%1FlashColor'[_0x3297ed(0x1cd)](_0x604d0b)],'flashDuration':_0x4c3d89[_0x3297ed(0x166)[_0x3297ed(0x1cd)](_0x604d0b)]};this[_0x3297ed(0x211)](_0x3d5778,_0x3ecdec);}}else _0x3bd246=_0x3297ed(0x335);}}if(this[_0x3297ed(0x1b7)]!==_0x3bd246)return _0x3297ed(0x1a9)===_0x3297ed(0x2a1)?_0xdea14f[_0x3297ed(0x278)][_0x3297ed(0x35a)][_0x3297ed(0x327)][_0x3297ed(0x252)][_0x3297ed(0x1d6)](this,this):this[_0x3297ed(0x255)]();switch(this['_graphicType']){case'face':if(this['_graphicFaceName']!==_0x5cace1['TurnOrderCTBGraphicFaceName']()){if(_0x3297ed(0x1d7)!==_0x3297ed(0x1d7)){this['_unit']=_0x1d8f6f,this[_0x3297ed(0x17e)]=_0x4bdb71,this[_0x3297ed(0x27f)]=_0x5e3ff4;const _0xb2757=_0x3079fe['Settings'],_0x3fae31=this[_0x3297ed(0x2ad)](),_0x3c1dbb=this['defaultPosition']();this[_0x3297ed(0x2a7)]=0x0,this[_0x3297ed(0x1dc)]=_0x3fae31?_0xb2757[_0x3297ed(0x1ff)]*_0x3c1dbb:0x0,this[_0x3297ed(0x197)]=_0x3fae31?0x0:_0xb2757[_0x3297ed(0x1ff)]*_0x3c1dbb,this[_0x3297ed(0x31e)]=0x0,this[_0x3297ed(0x2fa)]=0xff,this[_0x3297ed(0x17f)]=!![],this['_isAppeared']=!![];}else return this[_0x3297ed(0x255)]();}if(this[_0x3297ed(0x14c)]!==_0x5cace1[_0x3297ed(0x351)]()){if('hineK'==='hineK')return this['processUpdateGraphic']();else{if(!_0x51a10c[_0x3297ed(0x173)]())return;if(!_0x448cb3[_0x3297ed(0x28f)]())return;if(this===_0x330e41[_0x3297ed(0x177)]())return;if(this===_0x316e78[_0x3297ed(0x246)])return;_0x9fe454=_0x2cf912[_0x3297ed(0x13e)](_0x3260b5,0x1),this['processTurnOrderChangeCTB'](_0x379ba4);}}break;case'icon':if(this[_0x3297ed(0x26b)]!==_0x5cace1['TurnOrderCTBGraphicIconIndex']())return'tmzoS'!=='tmzoS'?_0x309ca8[_0x3297ed(0x278)]['Settings']['Mechanics']['TpbCastTimeJS'][_0x3297ed(0x1d6)](this,this):this[_0x3297ed(0x255)]();break;case _0x3297ed(0x335):if(_0x5cace1['hasSvBattler']()){if(_0x3297ed(0x344)!==_0x3297ed(0x1bf)){if(this[_0x3297ed(0x33c)]!==_0x5cace1['svBattlerName']())return this[_0x3297ed(0x255)]();}else this[_0x3297ed(0x360)]+=this['tpbAcceleration'](),this['_tpbCastTime']>=this[_0x3297ed(0x1a5)]()&&(this['_tpbState']='ready');}else{if(this[_0x3297ed(0x287)]!==_0x5cace1[_0x3297ed(0x2be)]())return this['processUpdateGraphic']();}break;case'svactor':if(_0x5cace1[_0x3297ed(0x163)]()){if(this[_0x3297ed(0x33c)]!==_0x5cace1['battlerName']())return this[_0x3297ed(0x255)]();}else{if(this['_graphicEnemy']!==_0x5cace1['battlerName']())return this[_0x3297ed(0x255)]();}break;}},Sprite_CTB_TurnOrder_Battler['prototype'][_0x485a45(0x255)]=function(){const _0x21ef99=_0x485a45,_0x1c2d93=this['battler']();if(!_0x1c2d93)return;this['_graphicType']=_0x1c2d93[_0x21ef99(0x308)]();if(_0x1c2d93[_0x21ef99(0x163)]()&&this[_0x21ef99(0x1b7)]===_0x21ef99(0x335))this[_0x21ef99(0x1b7)]=_0x21ef99(0x284);else _0x1c2d93[_0x21ef99(0x1eb)]()&&this[_0x21ef99(0x1b7)]===_0x21ef99(0x275)&&(_0x21ef99(0x1cf)!==_0x21ef99(0x1cf)?this[_0x21ef99(0x173)]()?this[_0x21ef99(0x2de)]():_0x4238a3[_0x21ef99(0x278)][_0x21ef99(0x1fd)][_0x21ef99(0x1d6)](this):this[_0x21ef99(0x1b7)]='enemy');let _0x53ebe5;switch(this[_0x21ef99(0x1b7)]){case _0x21ef99(0x284):this[_0x21ef99(0x2b8)]=_0x1c2d93[_0x21ef99(0x2a3)](),this[_0x21ef99(0x14c)]=_0x1c2d93['TurnOrderCTBGraphicFaceIndex'](),_0x53ebe5=ImageManager['loadFace'](this[_0x21ef99(0x2b8)]),_0x53ebe5[_0x21ef99(0x357)](this[_0x21ef99(0x2bb)][_0x21ef99(0x30d)](this,_0x53ebe5));break;case _0x21ef99(0x356):this[_0x21ef99(0x26b)]=_0x1c2d93[_0x21ef99(0x1a1)](),_0x53ebe5=ImageManager['loadSystem'](_0x21ef99(0x174)),_0x53ebe5[_0x21ef99(0x357)](this[_0x21ef99(0x348)]['bind'](this,_0x53ebe5));break;case _0x21ef99(0x335):if(_0x1c2d93[_0x21ef99(0x19e)]())this[_0x21ef99(0x33c)]=_0x1c2d93[_0x21ef99(0x15d)](),_0x53ebe5=ImageManager[_0x21ef99(0x1c2)](this[_0x21ef99(0x33c)]),_0x53ebe5[_0x21ef99(0x357)](this[_0x21ef99(0x156)][_0x21ef99(0x30d)](this,_0x53ebe5));else{if($gameSystem[_0x21ef99(0x2d1)]()){if(_0x21ef99(0x35c)!==_0x21ef99(0x35c))return this[_0x21ef99(0x222)]===_0x26da32&&(this['_ctbTurnOrderIconIndex']=this['createTurnOrderCTBGraphicIconIndex']()),this['_ctbTurnOrderIconIndex'];else this[_0x21ef99(0x287)]=_0x1c2d93[_0x21ef99(0x2be)](),_0x53ebe5=ImageManager[_0x21ef99(0x32b)](this[_0x21ef99(0x287)]),_0x53ebe5[_0x21ef99(0x357)](this['changeEnemyGraphicBitmap']['bind'](this,_0x53ebe5));}else'peLsT'!=='kfEOS'?(this[_0x21ef99(0x287)]=_0x1c2d93['battlerName'](),_0x53ebe5=ImageManager[_0x21ef99(0x146)](this[_0x21ef99(0x287)]),_0x53ebe5[_0x21ef99(0x357)](this[_0x21ef99(0x1d4)][_0x21ef99(0x30d)](this,_0x53ebe5))):(this[_0x21ef99(0x34d)](),this['createBackgroundSprite'](),this[_0x21ef99(0x1c3)](),this[_0x21ef99(0x2ae)](),this['createLetterSprite']());}break;case'svactor':this[_0x21ef99(0x33c)]=_0x1c2d93[_0x21ef99(0x2be)](),_0x53ebe5=ImageManager['loadSvActor'](this[_0x21ef99(0x33c)]),_0x53ebe5[_0x21ef99(0x357)](this[_0x21ef99(0x156)][_0x21ef99(0x30d)](this,_0x53ebe5));break;}},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)]['changeFaceGraphicBitmap']=function(_0x5a3abc){const _0x5c8233=_0x485a45,_0x5b4eaa=this[_0x5c8233(0x14c)],_0x5961d7=this['bitmapWidth'](),_0x16556c=this[_0x5c8233(0x25e)](),_0x37b083=Math[_0x5c8233(0x13e)](_0x5961d7,_0x16556c);this['_graphicSprite']['bitmap']=new Bitmap(_0x5961d7,_0x16556c);const _0x15f1ba=this[_0x5c8233(0x1c0)][_0x5c8233(0x161)],_0x2a31f2=ImageManager[_0x5c8233(0x319)],_0x2d9c70=ImageManager['faceHeight'],_0x248808=_0x37b083/Math[_0x5c8233(0x13e)](_0x2a31f2,_0x2d9c70),_0x4e068a=ImageManager[_0x5c8233(0x319)],_0x3b117b=ImageManager[_0x5c8233(0x31a)],_0x579cb8=_0x5b4eaa%0x4*_0x2a31f2+(_0x2a31f2-_0x4e068a)/0x2,_0x221e51=Math[_0x5c8233(0x1a4)](_0x5b4eaa/0x4)*_0x2d9c70+(_0x2d9c70-_0x3b117b)/0x2,_0x400fb2=(_0x5961d7-_0x2a31f2*_0x248808)/0x2,_0x410bad=(_0x16556c-_0x2d9c70*_0x248808)/0x2;_0x15f1ba['blt'](_0x5a3abc,_0x579cb8,_0x221e51,_0x4e068a,_0x3b117b,_0x400fb2,_0x410bad,_0x37b083,_0x37b083);},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x348)]=function(_0x20d48f){const _0x408154=_0x485a45,_0xca6d27=this[_0x408154(0x26b)],_0x37e2a8=this[_0x408154(0x33e)](),_0x232f44=this['bitmapHeight']();this[_0x408154(0x1c0)]['bitmap']=new Bitmap(_0x37e2a8,_0x232f44);const _0x5e346a=this[_0x408154(0x1c0)][_0x408154(0x161)],_0xd3b956=ImageManager[_0x408154(0x224)],_0x593786=ImageManager[_0x408154(0x169)],_0x5c1efb=Math['min'](_0xd3b956,_0x593786,_0x37e2a8,_0x232f44),_0x17aa61=_0xca6d27%0x10*_0xd3b956,_0x41f62c=Math[_0x408154(0x1a4)](_0xca6d27/0x10)*_0x593786,_0x23c47d=Math[_0x408154(0x1a4)](Math[_0x408154(0x13e)](_0x37e2a8-_0x5c1efb,0x0)/0x2),_0x274333=Math[_0x408154(0x1a4)](Math[_0x408154(0x13e)](_0x232f44-_0x5c1efb,0x0)/0x2);_0x5e346a[_0x408154(0x350)](_0x20d48f,_0x17aa61,_0x41f62c,_0xd3b956,_0x593786,_0x23c47d,_0x274333,_0x5c1efb,_0x5c1efb);},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x156)]=function(_0x39af52){const _0x500ccd=_0x485a45,_0x25b127=this[_0x500ccd(0x33e)](),_0x425979=this[_0x500ccd(0x25e)](),_0x244ba9=Math[_0x500ccd(0x237)](_0x25b127,_0x425979);this[_0x500ccd(0x1c0)][_0x500ccd(0x161)]=new Bitmap(_0x25b127,_0x425979);const _0x500d80=this[_0x500ccd(0x1c0)]['bitmap'],_0x658d2c=this['_graphicSv'][_0x500ccd(0x22f)](/\$/i),_0x4786e1=_0x658d2c?0x1:ImageManager[_0x500ccd(0x332)],_0x4cfe67=_0x658d2c?0x1:ImageManager[_0x500ccd(0x34f)],_0xb5a83a=_0x39af52[_0x500ccd(0x2a6)]/_0x4786e1,_0xfdbad5=_0x39af52[_0x500ccd(0x16c)]/_0x4cfe67,_0x1bc374=Math[_0x500ccd(0x237)](0x1,_0x244ba9/_0xb5a83a,_0x244ba9/_0xfdbad5),_0x12f8de=_0xb5a83a*_0x1bc374,_0x5e6092=_0xfdbad5*_0x1bc374,_0xbe6f=Math[_0x500ccd(0x2a8)]((_0x25b127-_0x12f8de)/0x2),_0x28a6a5=Math[_0x500ccd(0x2a8)]((_0x425979-_0x5e6092)/0x2);_0x500d80['blt'](_0x39af52,0x0,0x0,_0xb5a83a,_0xfdbad5,_0xbe6f,_0x28a6a5,_0x12f8de,_0x5e6092);},Sprite_CTB_TurnOrder_Battler['prototype'][_0x485a45(0x1d4)]=function(_0x4219c5){const _0x5edaf6=_0x485a45,_0x58106c=Window_CTB_TurnOrder[_0x5edaf6(0x35a)],_0x268376=this['bitmapWidth'](),_0x5712be=this[_0x5edaf6(0x25e)](),_0x21e4f9=Math['min'](_0x268376,_0x5712be);this['_graphicSprite'][_0x5edaf6(0x161)]=new Bitmap(_0x268376,_0x5712be);const _0x24cbe5=this['_graphicSprite'][_0x5edaf6(0x161)],_0x101218=Math[_0x5edaf6(0x237)](0x1,_0x21e4f9/_0x4219c5[_0x5edaf6(0x2a6)],_0x21e4f9/_0x4219c5[_0x5edaf6(0x16c)]),_0x4975ef=_0x4219c5['width']*_0x101218,_0x5a779f=_0x4219c5['height']*_0x101218,_0x8a8ce2=Math['round']((_0x268376-_0x4975ef)/0x2),_0x274034=Math['round']((_0x5712be-_0x5a779f)/0x2);_0x24cbe5[_0x5edaf6(0x350)](_0x4219c5,0x0,0x0,_0x4219c5[_0x5edaf6(0x2a6)],_0x4219c5['height'],_0x8a8ce2,_0x274034,_0x4975ef,_0x5a779f);},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)]['updateGraphicHue']=function(){const _0x1f0e0e=_0x485a45,_0x2c5e79=this[_0x1f0e0e(0x194)]();if(!_0x2c5e79)return;if(!_0x2c5e79[_0x1f0e0e(0x1eb)]())return;if(this[_0x1f0e0e(0x1c4)]===_0x2c5e79[_0x1f0e0e(0x160)]())return;this[_0x1f0e0e(0x1c4)]=_0x2c5e79['battlerHue']();if(_0x2c5e79[_0x1f0e0e(0x19e)]())this[_0x1f0e0e(0x1c4)]=0x0;this[_0x1f0e0e(0x1c0)][_0x1f0e0e(0x1e9)](this[_0x1f0e0e(0x1c4)]);},Sprite_CTB_TurnOrder_Battler['prototype']['updateLetter']=function(){const _0xa2440c=_0x485a45;if(!this[_0xa2440c(0x2c5)])return;const _0x2e2c08=this[_0xa2440c(0x194)]();if(!_0x2e2c08)return;if(this[_0xa2440c(0x2c1)]===_0x2e2c08['_letter']&&this['_plural']===_0x2e2c08[_0xa2440c(0x296)])return;this[_0xa2440c(0x2c1)]=_0x2e2c08['_letter'],this[_0xa2440c(0x296)]=_0x2e2c08[_0xa2440c(0x296)];const _0x52c801=Window_CTB_TurnOrder[_0xa2440c(0x35a)],_0x3bec85=this[_0xa2440c(0x2ad)](),_0x35cb5e=this[_0xa2440c(0x33e)](),_0x3e0459=this[_0xa2440c(0x25e)](),_0x249740=this[_0xa2440c(0x2c5)][_0xa2440c(0x161)];_0x249740[_0xa2440c(0x1d5)]();if(!this[_0xa2440c(0x296)])return;_0x249740[_0xa2440c(0x2b6)]=_0x52c801[_0xa2440c(0x1ac)]||$gameSystem[_0xa2440c(0x279)](),_0x249740[_0xa2440c(0x2c0)]=_0x52c801[_0xa2440c(0x2eb)]||0x10,_0x3bec85?_0x249740['drawText'](this[_0xa2440c(0x2c1)][_0xa2440c(0x1f5)](),0x0,_0x3e0459/0x2,_0x35cb5e,_0x3e0459/0x2,_0xa2440c(0x25b)):_0x249740[_0xa2440c(0x184)](this[_0xa2440c(0x2c1)][_0xa2440c(0x1f5)](),0x0,0x2,_0x35cb5e-0x8,_0x3e0459-0x4,_0xa2440c(0x28a));},Sprite_CTB_TurnOrder_Battler['prototype']['updateSelectionEffect']=function(){const _0x591741=_0x485a45,_0x26193c=this[_0x591741(0x194)]();if(!_0x26193c)return;const _0x548068=_0x26193c[_0x591741(0x194)]();if(!_0x548068)return;const _0x1fe90d=_0x548068[_0x591741(0x165)]();if(!_0x1fe90d)return;this['setBlendColor'](_0x1fe90d[_0x591741(0x23d)]);},Sprite_CTB_TurnOrder_Battler[_0x485a45(0x32a)][_0x485a45(0x18b)]=function(){return this['battler']();},VisuMZ[_0x485a45(0x278)][_0x485a45(0x212)]=Window_Help[_0x485a45(0x32a)][_0x485a45(0x1a0)],Window_Help[_0x485a45(0x32a)][_0x485a45(0x1a0)]=function(_0xcad5b3){const _0x57105c=_0x485a45;BattleManager['isCTB']()&&_0xcad5b3&&_0xcad5b3[_0x57105c(0x303)]&&_0xcad5b3[_0x57105c(0x303)][_0x57105c(0x22f)](/<(?:CTB) HELP>\s*([\s\S]*)\s*<\/(?:CTB) HELP>/i)?this[_0x57105c(0x2f8)](String(RegExp['$1'])):VisuMZ[_0x57105c(0x278)]['Window_Help_setItem'][_0x57105c(0x1d6)](this,_0xcad5b3);},VisuMZ[_0x485a45(0x278)][_0x485a45(0x1ce)]=Window_StatusBase[_0x485a45(0x32a)]['placeGauge'],Window_StatusBase[_0x485a45(0x32a)][_0x485a45(0x221)]=function(_0x4766dd,_0x5801b3,_0x3fd6ae,_0x40ba66){const _0x5cc3e7=_0x485a45;if(BattleManager[_0x5cc3e7(0x173)]()&&_0x5801b3===_0x5cc3e7(0x148))return;VisuMZ['BattleSystemCTB'][_0x5cc3e7(0x1ce)][_0x5cc3e7(0x1d6)](this,_0x4766dd,_0x5801b3,_0x3fd6ae,_0x40ba66);};function Window_CTB_TurnOrder(){const _0x15af0d=_0x485a45;this[_0x15af0d(0x299)](...arguments);}Window_CTB_TurnOrder[_0x485a45(0x32a)]=Object[_0x485a45(0x1a6)](Window_Base[_0x485a45(0x32a)]),Window_CTB_TurnOrder[_0x485a45(0x32a)][_0x485a45(0x2d7)]=Window_CTB_TurnOrder,Window_CTB_TurnOrder['Settings']=VisuMZ[_0x485a45(0x278)][_0x485a45(0x35a)][_0x485a45(0x2c2)],Window_CTB_TurnOrder[_0x485a45(0x32a)]['initialize']=function(){const _0xa5583f=_0x485a45,_0x52be96=this[_0xa5583f(0x16b)]();this[_0xa5583f(0x183)]=_0x52be96['x'],this['_homeY']=_0x52be96['y'],Window_Base[_0xa5583f(0x32a)][_0xa5583f(0x299)][_0xa5583f(0x1d6)](this,_0x52be96),this['createBattlerSprites'](),this[_0xa5583f(0x346)](),this[_0xa5583f(0x253)]=0x0;},Window_CTB_TurnOrder[_0x485a45(0x32a)][_0x485a45(0x16b)]=function(){const _0x3353c7=_0x485a45,_0x45f1ad=Window_CTB_TurnOrder[_0x3353c7(0x35a)],_0x532c95=SceneManager['_scene'][_0x3353c7(0x1b4)]['height'],_0x4e511b=SceneManager[_0x3353c7(0x219)]['_helpWindow'][_0x3353c7(0x16c)],_0x370cc1=_0x45f1ad[_0x3353c7(0x248)];let _0x408ac1=0x0,_0x34c627=0x0,_0x4c18d9=0x0,_0x577cfe=0x0;switch(_0x45f1ad[_0x3353c7(0x24f)]){case _0x3353c7(0x1ae):_0x408ac1=_0x45f1ad['SpriteThin']*_0x45f1ad[_0x3353c7(0x317)]+_0x370cc1,_0x34c627=_0x45f1ad['SpriteLength'],_0x4c18d9=Math[_0x3353c7(0x1ca)]((Graphics['width']-_0x408ac1)/0x2),_0x577cfe=_0x45f1ad[_0x3353c7(0x1fa)];break;case _0x3353c7(0x1ba):_0x408ac1=_0x45f1ad[_0x3353c7(0x1ff)]*_0x45f1ad[_0x3353c7(0x317)]+_0x370cc1,_0x34c627=_0x45f1ad[_0x3353c7(0x2e3)],_0x4c18d9=Math[_0x3353c7(0x1ca)]((Graphics[_0x3353c7(0x2a6)]-_0x408ac1)/0x2),_0x577cfe=Graphics['height']-_0x532c95-_0x34c627-_0x45f1ad[_0x3353c7(0x1fa)];break;case'left':_0x408ac1=_0x45f1ad[_0x3353c7(0x2e3)],_0x34c627=_0x45f1ad[_0x3353c7(0x1ff)]*_0x45f1ad['TotalVertSprites']+_0x370cc1,_0x4c18d9=_0x45f1ad[_0x3353c7(0x1fa)],_0x577cfe=Math[_0x3353c7(0x1ca)]((Graphics[_0x3353c7(0x16c)]-_0x532c95+_0x4e511b-_0x34c627)/0x2);break;case'right':_0x408ac1=_0x45f1ad['SpriteLength'],_0x34c627=_0x45f1ad[_0x3353c7(0x1ff)]*_0x45f1ad[_0x3353c7(0x20e)]+_0x370cc1,_0x4c18d9=Graphics[_0x3353c7(0x2a6)]-_0x408ac1-_0x45f1ad[_0x3353c7(0x1fa)],_0x577cfe=Math[_0x3353c7(0x1ca)]((Graphics['height']-_0x532c95+_0x4e511b-_0x34c627)/0x2);break;}return _0x4c18d9+=_0x45f1ad[_0x3353c7(0x17c)],_0x577cfe+=_0x45f1ad[_0x3353c7(0x274)],new Rectangle(_0x4c18d9,_0x577cfe,_0x408ac1,_0x34c627);},Window_CTB_TurnOrder[_0x485a45(0x32a)]['updatePadding']=function(){const _0x4421dd=_0x485a45;this[_0x4421dd(0x21d)]=0x0;},Window_CTB_TurnOrder[_0x485a45(0x32a)]['isHorz']=function(){const _0x4fe012=_0x485a45,_0x8e41f7=Window_CTB_TurnOrder[_0x4fe012(0x35a)],_0x2739d7=[_0x4fe012(0x1ae),_0x4fe012(0x1ba)][_0x4fe012(0x23c)](_0x8e41f7[_0x4fe012(0x24f)]);return _0x2739d7;},Window_CTB_TurnOrder[_0x485a45(0x32a)][_0x485a45(0x298)]=function(){const _0x413f32=_0x485a45,_0x764b04=Window_CTB_TurnOrder[_0x413f32(0x35a)],_0x11350b=this['isHorz'](),_0xa4028d=_0x11350b?_0x764b04[_0x413f32(0x317)]:_0x764b04[_0x413f32(0x20e)];this[_0x413f32(0x1fc)]=new Sprite(),this[_0x413f32(0x34e)](this['_turnOrderInnerSprite']),this[_0x413f32(0x309)]=[];for(let _0x3383ce=0x0;_0x3383ce<$gameParty[_0x413f32(0x140)]();_0x3383ce++){for(let _0x4e5d8f=0x0;_0x4e5d8f<_0xa4028d;_0x4e5d8f++){if(_0x413f32(0x223)!==_0x413f32(0x223))_0x46d71d='enemy';else{const _0xf95382=new Sprite_CTB_TurnOrder_Battler($gameParty,_0x3383ce,_0x4e5d8f);this[_0x413f32(0x1fc)]['addChild'](_0xf95382),this[_0x413f32(0x309)][_0x413f32(0x30c)](_0xf95382);}}}for(let _0x2fbbd9=0x0;_0x2fbbd9<$gameTroop[_0x413f32(0x34c)]()[_0x413f32(0x205)];_0x2fbbd9++){for(let _0x2a6f25=0x0;_0x2a6f25<_0xa4028d;_0x2a6f25++){if('EaFmi'!==_0x413f32(0x28e)){const _0x463180=new Sprite_CTB_TurnOrder_Battler($gameTroop,_0x2fbbd9,_0x2a6f25);this[_0x413f32(0x1fc)][_0x413f32(0x175)](_0x463180),this[_0x413f32(0x309)][_0x413f32(0x30c)](_0x463180);}else this[_0x413f32(0x1af)]=0x0;}}},Window_CTB_TurnOrder[_0x485a45(0x32a)][_0x485a45(0x355)]=function(){const _0x51717=_0x485a45;Window_Base['prototype'][_0x51717(0x355)]['call'](this),this['updatePosition'](),this[_0x51717(0x346)]();},Window_CTB_TurnOrder['prototype']['updatePosition']=function(){const _0xca7cfc=_0x485a45,_0x1379c3=Window_CTB_TurnOrder[_0xca7cfc(0x35a)];if(_0x1379c3['DisplayPosition']!=='top')return;if(!_0x1379c3[_0xca7cfc(0x151)])return;const _0x2d57e3=SceneManager['_scene'][_0xca7cfc(0x259)];if(!_0x2d57e3)return;if(_0x2d57e3[_0xca7cfc(0x1d3)]){if(_0xca7cfc(0x157)!==_0xca7cfc(0x21e))this['x']=this[_0xca7cfc(0x183)]+(_0x1379c3[_0xca7cfc(0x2a5)]||0x0),this['y']=this['_homeY']+(_0x1379c3[_0xca7cfc(0x262)]||0x0);else{this[_0xca7cfc(0x161)]=new _0x288ce2(0x48,0x24);const _0x5da017=this['battler']()?this[_0xca7cfc(0x194)]()[_0xca7cfc(0x2e8)]():'%1\x20%2\x20%3'[_0xca7cfc(0x1cd)](this[_0xca7cfc(0x329)],this[_0xca7cfc(0x17e)],this['_dupe']);this['bitmap'][_0xca7cfc(0x184)](_0x5da017,0x0,0x0,0x48,0x24,_0xca7cfc(0x25b));}}else this['x']=this[_0xca7cfc(0x183)],this['y']=this[_0xca7cfc(0x1e4)];const _0x2bcf70=SceneManager['_scene'][_0xca7cfc(0x1d1)];Window_CTB_TurnOrder[_0xca7cfc(0x15c)]===undefined&&(Window_CTB_TurnOrder[_0xca7cfc(0x15c)]=Math[_0xca7cfc(0x2a8)]((Graphics['width']-Math[_0xca7cfc(0x237)](Graphics['boxWidth'],_0x2bcf70[_0xca7cfc(0x2a6)]))/0x2),Window_CTB_TurnOrder[_0xca7cfc(0x171)]=Math[_0xca7cfc(0x2a8)]((Graphics['height']-Math['min'](Graphics[_0xca7cfc(0x1cb)],_0x2bcf70[_0xca7cfc(0x16c)]))/0x2)),this['x']+=_0x2bcf70['x']-Window_CTB_TurnOrder[_0xca7cfc(0x15c)],this['y']+=_0x2bcf70['y']-Window_CTB_TurnOrder['_ogWindowLayerY'];},Window_CTB_TurnOrder[_0x485a45(0x32a)][_0x485a45(0x1df)]=function(){const _0x48878e=_0x485a45;if(!this[_0x48878e(0x1fc)])return;const _0x5ba4d5=this['_turnOrderInnerSprite'][_0x48878e(0x20d)];if(!_0x5ba4d5)return;_0x5ba4d5[_0x48878e(0x2b3)](this[_0x48878e(0x16f)][_0x48878e(0x30d)](this));},Window_CTB_TurnOrder[_0x485a45(0x32a)]['compareBattlerSprites']=function(_0x392e3e,_0x16b2e5){const _0x2b2572=_0x485a45,_0x5e6a70=this[_0x2b2572(0x2ad)](),_0x513d71=Window_CTB_TurnOrder[_0x2b2572(0x35a)]['OrderDirection'];if(_0x5e6a70&&!_0x513d71){if('SXyjq'==='SXyjq')return _0x392e3e['x']-_0x16b2e5['x'];else _0x3c1d63=_0x39fb67(_0x2b8a85['$1'])*0.01;}else{if(_0x5e6a70&&_0x513d71)return _0x16b2e5['x']-_0x392e3e['x'];else{if(!_0x5e6a70&&_0x513d71){if(_0x2b2572(0x2ed)!==_0x2b2572(0x286))return _0x392e3e['y']-_0x16b2e5['y'];else this[_0x2b2572(0x232)]();}else{if(!_0x5e6a70&&!_0x513d71)return _0x16b2e5['y']-_0x392e3e['y'];}}}},Window_CTB_TurnOrder[_0x485a45(0x32a)][_0x485a45(0x346)]=function(){this['visible']=$gameSystem['isBattleSystemCTBTurnOrderVisible']();},Window_CTB_TurnOrder[_0x485a45(0x32a)][_0x485a45(0x2b9)]=function(_0x103993){const _0x3ed649=_0x485a45;this[_0x3ed649(0x1df)](),this[_0x3ed649(0x309)][_0x3ed649(0x2b3)]((_0x1b84f5,_0x22525f)=>{const _0x4bcbd5=_0x3ed649;return _0x4bcbd5(0x249)===_0x4bcbd5(0x249)?_0x1b84f5['ticksLeft']()-_0x22525f['ticksLeft']():this[_0x4bcbd5(0x194)]();});if(!_0x103993)return;for(const _0x278ebc of this[_0x3ed649(0x309)]){if(_0x3ed649(0x254)!==_0x3ed649(0x254))this[_0x3ed649(0x27f)]=_0x518072-0x1,this[_0x3ed649(0x290)](0x0);else{if(!_0x278ebc)continue;_0x278ebc[_0x3ed649(0x355)](),_0x278ebc[_0x3ed649(0x2a7)]=0x0;}}},Window_CTB_TurnOrder[_0x485a45(0x32a)]['rotateCTBSprite']=function(_0x14fd1a){const _0x5dfbf9=_0x485a45;for(const _0x4cd60c of this['_turnOrderContainer']){if(_0x5dfbf9(0x22e)!=='xXKYF')this['preEndActionCTB'](),_0x2e7b4f[_0x5dfbf9(0x278)][_0x5dfbf9(0x2ce)][_0x5dfbf9(0x1d6)](this),this['postEndActionCTB']();else{if(!_0x4cd60c)continue;if(_0x4cd60c[_0x5dfbf9(0x194)]()!==_0x14fd1a)continue;_0x4cd60c[_0x5dfbf9(0x2c7)]();}}};