//=============================================================================
// VisuStella MZ - Battle System - STB - Standard Turn Battle
// VisuMZ_2_BattleSystemSTB.js
//=============================================================================

var Imported = Imported || {};
Imported.VisuMZ_2_BattleSystemSTB = true;

var VisuMZ = VisuMZ || {};
VisuMZ.BattleSystemSTB = VisuMZ.BattleSystemSTB || {};
VisuMZ.BattleSystemSTB.version = 1.17;

//=============================================================================
 /*:
 * @target MZ
 * @plugindesc [RPG Maker MZ] [Tier 2] [Version 1.17] [BattleSystemSTB]
 * @author VisuStella
 * @url http://www.yanfly.moe/wiki/Battle_System_-_STB_VisuStella_MZ
 * @base VisuMZ_0_CoreEngine
 * @base VisuMZ_1_BattleCore
 * @orderAfter VisuMZ_1_BattleCore
 *
 * @help
 * ============================================================================
 * Introduction
 * ============================================================================
 *
 * The Standard Turn Battle (STB) system uses RPG Maker MZ's default non-TPB
 * battle system as a base. Action orders are determined by the battler's AGI
 * values and they go from highest to lowest. However, actions are not selected
 * at the start of the turn. Instead, as the turn progresses, actions are then
 * picked as each battler's turn comes up and is executed immediately.
 * 
 * Optional to the battle system but fine tuned to it is the Exploit System.
 * When landing an elemental weakness or critical hit against a foe, the
 * battler can gain bonuses as well as an extra turn while the foe will become
 * stunned or gain any desired state(s). When all enemies are exploited in a
 * single turn, a common event can also be played, too.
 * 
 * A Turn Order Display will also appear on the screen to show the order the
 * battlers will take their turns in. This lets the player plan in advance on
 * how to go about the rest of the turn.
 * 
 * *NOTE* To use this battle system, you will need the updated version of
 * VisuStella's Core Engine. Go into its Plugin Parameters and change the
 * "Battle System" plugin parameter to "stb".
 *
 * Features include all (but not limited to) the following:
 * 
 * * Utilizes the balanced AGI nature of the Default Turn Battle system.
 * * Allows for actions to execute immediately upon selection.
 * * A Turn Order Display to show the player when each battler will have its
 *   turn to perform an action.
 * * Skills and Items can have an "Instant Use" effect, which allows them to
 *   perform an action immediately without using up a turn.
 * * An optional Exploit System that can be disabled if desired, but otherwise,
 *   fine tuned to make use of STB's highly compatible nature.
 * * Landing an elemental weakness or critical hit can allow the active battler
 *   to gain bonuses, ranging from states to extra actions to custom effects
 *   that can be added on through JavaScript plugin parameters.
 * * An exploited enemy can suffer from states and/or custom effects added
 *   through JavaScript plugin parameters.
 * * If all enemies are exploited, a common event can run to allow for a custom
 *   follow up action.
 *
 * ============================================================================
 * Requirements
 * ============================================================================
 *
 * This plugin is made for RPG Maker MZ. This will not work in other iterations
 * of RPG Maker.
 *
 * ------ Required Plugin List ------
 *
 * * VisuMZ_0_CoreEngine
 * * VisuMZ_1_BattleCore
 *
 * This plugin requires the above listed plugins to be installed inside your
 * game's Plugin Manager list in order to work. You cannot start your game with
 * this plugin enabled without the listed plugins.
 *
 * ------ Tier 2 ------
 *
 * This plugin is a Tier 2 plugin. Place it under other plugins of lower tier
 * value on your Plugin Manager list (ie: 0, 1, 2, 3, 4, 5). This is to ensure
 * that your plugins will have the best compatibility with the rest of the
 * VisuStella MZ library.
 *
 * ============================================================================
 * Major Changes
 * ============================================================================
 *
 * This plugin adds some new hard-coded features to RPG Maker MZ's functions.
 * The following is a list of them.
 *
 * ---
 * 
 * Turn Order Display
 * 
 * The Turn Order Display will capture the battle's currently active battler
 * and any battlers found in the active battlers array for the BattleManager.
 * This does not overwrite any functions, but the Turn Order Display may or may
 * not conflict with any existing HUD elements that are already positioned on
 * the screen. If so, you can choose to offset the Turn Order Display or move
 * it to a different part of the screen through the plugin parameters.
 * 
 * ---
 *
 * Action Speed
 * 
 * For skills and items, action speeds now behave differently now. Because
 * actions are now decided after a turn starts, positioning will no longer be
 * decided from the selected skill/item's action speed for the current turn.
 * 
 * Instead, the action speed used by a skill or item will determine the bonus
 * speed (or speed penalty if negative) for the following turn. Using a Guard
 * action with a +2000 Action Speed will raise the following turn's speed by
 * +2000, whereas what is originally a long charge time skill with -1000 speed
 * will decrease the following action's speed by -1000.
 * 
 * You can also customize how speed is calculated through JS Plugin Parameters
 * found in the Mechanics Settings.
 *
 * ---
 * 
 * Instant Use
 * 
 * Skills and Items can have an "Instant Use" property which allows them to be
 * used immediately without consuming a turn. This can be used for actions that
 * otherwise do not warrant a whole turn. These can be used for minor buffs,
 * debuffs, toggles, etc.
 * 
 * ---
 * 
 * Exploit System
 * 
 * This is an optional system. If you wish to turn it off, you can do so in the
 * plugin parameters.
 * 
 * There are two main ways that battlers can be exploited. One is by receiving
 * damage that strikes an elemental weakness. The other is by receiving damage
 * from a Critical Hit. Exploited battlers can receive penalty states. These
 * states can be adjusted in the plugin parameters. The default penalty state
 * is the Stunned state.
 * 
 * The battler doing the exploiting can receive bonuses instead. This is to
 * reward a power play. These bonuses can range from added states to receiving
 * an extra action and allowing the active battler to immediately attack again.
 * 
 * Each battler can only be exploited once per turn. This means if an enemy
 * would receive multiple attacks to its elemental weakness(es), the exploited
 * effect will only occur once per turn, meaning the penalty states won't stack
 * multiple times over. This limitation is for the sake of game balance, but if
 * you so wish, you can turn off this limitation in the plugin parameters.
 * 
 * Each action can also exploit only once per use and against an unexploited
 * target. This means battlers cannot use the same elemental attacks against
 * the same foes over and over to stack up an infinite amount of turns. If the
 * player wants to gain more bonuses, the player would have to strike against
 * unexploited foes. This limitation is for the sake of game balance, but if
 * you so wish, you can turn off this limitation in the plugin parameters.
 * 
 * When all members of a party/troop are exploited, a common event can be
 * triggered to run, allowing for potential follow up actions. How you wish to
 * make these common events is up to you.
 * 
 * ---
 *
 * ============================================================================
 * VisuStella MZ Compatibility
 * ============================================================================
 *
 * While this plugin is compatible with the majority of the VisuStella MZ
 * plugin library, it is not compatible with specific plugins. Here is a list
 * of the ones this plugin is not compatible with.
 *
 * ---
 *
 * VisuMZ_4_BreakShields
 * 
 * The Break Shields plugin can be used together with Battle System - STB.
 * However, it cannot be used together with the STB Exploit system. This is
 * because both Break Shields and the Exploit system function under similar
 * mechanics and will conflict. However, if STB's Exploit system is turned off,
 * then you can use all of the Break Shield plugin's features fully.
 *
 * ---
 *
 * ============================================================================
 * Notetags
 * ============================================================================
 *
 * The following are notetags that have been added through this plugin. These
 * notetags will not work with your game if this plugin is OFF or not present.
 *
 * ---
 * 
 * === General STB-Related Notetags ===
 * 
 * These notetags are general purpose notetags that have became available
 * through this plugin.
 * 
 * ---
 * 
 * <STB Help>
 *  description
 *  description
 * </STB Help>
 *
 * - Used for: Skill, Item Notetags
 * - If your game happens to support the ability to change battle systems, this
 *   notetag lets you change how the skill/item's help description text will
 *   look under STB.
 * - This is primarily used if the skill behaves differently in STB versus any
 *   other battle system.
 * - Replace 'description' with help text that's only displayed if the game's
 *   battle system is set to STB.
 *
 * ---
 * 
 * === STB Turn Order Display-Related Notetags ===
 * 
 * These notetags affect the STB Turn Order Display
 * 
 * ---
 *
 * <STB Turn Order Icon: x>
 *
 * - Used for: Actor, Enemy Notetags
 * - Changes the slot graphic used for the battler to a specific icon.
 * - Replace 'x' with the icon index to be used.
 * 
 * ---
 *
 * <STB Turn Order Face: filename, index>
 *
 * - Used for: Actor, Enemy Notetags
 * - Changes the slot graphic used for the enemy to a specific face.
 * - Replace 'filename' with the filename of the image.
 *   - Do not include the file extension.
 * - Replace 'index' with the index of the face. Index values start at 0.
 * - Example: <STB Turn Order Face: Monster, 1>
 * 
 * ---
 * 
 * === Instant Use-Related Notetags ===
 * 
 * ---
 *
 * <STB Instant>
 * <STB Instant Use>
 * <STB Instant Cast>
 *
 * - Used for: Skill, Item Notetags
 * - Allows the skill/item to be used immediately without consuming a turn.
 *
 * ---
 * 
 * === Exploit-Related Notetags ===
 * 
 * ---
 *
 * <STB Exploited Gain State: id>
 * <STB Exploited Gain State: id, id, id>
 * 
 * <STB Exploited Gain State: name>
 * <STB Exploited Gain State: name, name, name>
 *
 * - Used for: Class, Enemy Notetags
 * - If an actor (with the specified class) or enemy is exploited via elemental
 *   weaknesses or critical hits, apply the listed penalty state(s).
 * - Replace 'id' with a number representing the penalty state ID's you wish
 *   to apply to the exploited battler.
 * - Insert multiple 'id' values to apply multiple penalty states at once.
 * - Replace 'name' with the name of the penalty state you wish to apply to the
 *   exploited battler.
 * - Insert multiple 'name' entries to apply multiple penalty states at once.
 *
 * ---
 *
 * <STB Cannot Be Exploited>
 *
 * - Used for: Actor, Class, Weapon, Armor, Enemy, State Notetags
 * - This prevents the affected battler from being exploited via elemental
 *   weaknesses or critical hits.
 *
 * ---
 *
 * <STB Exploiter Gain State: id>
 * <STB Exploiter Gain State: id, id, id>
 * 
 * <STB Exploiter Gain State: name>
 * <STB Exploiter Gain State: name, name, name>
 *
 * - Used for: Class, Enemy Notetags
 * - If an actor (with the specified class) or enemy exploits an opponent with
 *   an elemental weakness or critical hit, apply the listed bonus state(s).
 * - Replace 'id' with a number representing the bonus state ID's you wish
 *   to apply to the exploited battler.
 * - Insert multiple 'id' values to apply multiple bonus states at once.
 * - Replace 'name' with the name of the bonus state you wish to apply to the
 *   exploited battler.
 * - Insert multiple 'name' entries to apply multiple bonus states at once.
 *
 * ---
 *
 * <STB Cannot Be Exploiter>
 *
 * - Used for: Actor, Class, Weapon, Armor, Enemy, State Notetags
 * - This prevents the affected battler from exploiting any opponents via
 *   elemental weaknesses or critical hits.
 *
 * ---
 *
 * ============================================================================
 * Plugin Commands
 * ============================================================================
 *
 * The following are Plugin Commands that come with this plugin. They can be
 * accessed through the Plugin Command event command.
 *
 * ---
 * 
 * === Actor Plugin Commands ===
 * 
 * ---
 *
 * Actor: Change STB Turn Order Icon
 * - Changes the icons used for the specific actor(s) on the STB Turn Order.
 *
 *   Actor ID(s):
 *   - Select which Actor ID(s) to affect.
 *
 *   Icon:
 *   - Changes the graphic to this icon.
 *
 * ---
 *
 * Actor: Change STB Turn Order Face
 * - Changes the faces used for the specific actor(s) on the STB Turn Order.
 *
 *   Actor ID(s):
 *   - Select which Actor ID(s) to affect.
 *
 *   Face Name:
 *   - This is the filename for the target face graphic.
 *
 *   Face Index:
 *   - This is the index for the target face graphic.
 *
 * ---
 *
 * Actor: Clear STB Turn Order Graphic
 * - Clears the STB Turn Order graphics for the actor(s).
 * - The settings will revert to the Plugin Parameter settings.
 *
 *   Actor ID(s):
 *   - Select which Actor ID(s) to affect.
 *
 * ---
 * 
 * === Enemy Plugin Commands ===
 * 
 * ---
 *
 * Enemy: Change STB Turn Order Icon
 * - Changes the icons used for the specific enemy(ies) on the STB Turn Order.
 *
 *   Enemy Index(es):
 *   - Select which enemy index(es) to affect.
 *
 *   Icon:
 *   - Changes the graphic to this icon.
 *
 * ---
 *
 * Enemy: Change STB Turn Order Face
 * - Changes the faces used for the specific enemy(ies) on the STB Turn Order.
 *
 *   Enemy Index(es):
 *   - Select which enemy index(es) to affect.
 *
 *   Face Name:
 *   - This is the filename for the target face graphic.
 *
 *   Face Index:
 *   - This is the index for the target face graphic.
 *
 * ---
 *
 * Enemy: Clear STB Turn Order Graphic
 * - Clears the STB Turn Order graphics for the enemy(ies).
 * - The settings will revert to the Plugin Parameter settings.
 *
 *   Enemy Index(es):
 *   - Select which enemy index(es) to affect.
 *
 * ---
 * 
 * === System Plugin Commands ===
 * 
 * ---
 *
 * System: STB Turn Order Visibility
 * - Determine the visibility of the STB Turn Order Display.
 *
 *   Visibility:
 *   - Changes the visibility of the STB Turn Order Display.
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Mechanics Settings
 * ============================================================================
 *
 * Determines the mechanics of the STB Battle System.
 *
 * ---
 *
 * Speed
 * 
 *   JS: Finalized Speed:
 *   - Code used to calculate the finalized speed at the start of each turn.
 * 
 *   JS: Next Turn Speed:
 *   - Code used to calculate speed for a following turn.
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Exploit System Settings
 * ============================================================================
 *
 * Here, you can adjust the main settings for the Exploit System, including
 * where you can turn it on/off. The Exploited and Exploiter settings are
 * extensions of the Exploit System and are better off with their own sections.
 *
 * ---
 *
 * Settings
 * 
 *   Enable System?:
 *   - Enable the exploit system? 
 *   - If disabled, ignore all the  mechanics regarding the Exploit System.
 * 
 *   Critical Hits:
 *   - Do critical hits exploit the opponent?
 * 
 *   Elemental Weakness:
 *   - Do elemental weaknesses exploit the opponent?
 * 
 *     Minimum Rate:
 *     - What's the minimum rate needed to count as an elemental weakness?
 * 
 *   Forced Actions:
 *   - Apply exploit system to Forced Actions?
 *   - We added this function because forced actions can disrupt player
 *     strategies when used with the exploit system.
 * 
 *   Reset Each Turn:
 *   - Reset exploits at the end of each turn?
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Exploited Effects Settings
 * ============================================================================
 *
 * These are effects for the exploited battlers (the receiving end). Change how
 * you want exploited battlers to behave here.
 *
 * ---
 *
 * Mechanics
 * 
 *   Added States:
 *   - A list of the states that are added when a target is exploited.
 * 
 *   Full Exploit Events:
 *   vs Actors Event:
 *   vs Enemies Event:
 *   - If all actors/enemies have been fully exploited, run this common event.
 *   - Does not work with unlimited exploits.
 * 
 *   Unlimited Exploits:
 *   - Can battlers be exploited endlessly?
 * 
 *   JS: On Exploited:
 *   - Code used when the target has been exploited.
 *
 * ---
 *
 * Animation
 * 
 *   Animation ID:
 *   - Play this animation when the effect activates.
 * 
 *   Mirror Animation:
 *   - Mirror the effect animation?
 * 
 *   Mute Animation:
 *   - Mute the effect animation?
 *
 * ---
 *
 * Popups
 * 
 *   Text:
 *   - Text displayed upon the effect activating.
 * 
 *   Text Color:
 *   - Use #rrggbb for custom colors or regular numbers for text colors from
 *     the Window Skin.
 * 
 *   Flash Color:
 *   - Adjust the popup's flash color.
 *   - Format: [red, green, blue, alpha]
 * 
 *   Flash Duration:
 *   - What is the frame duration of the flash effect?
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Exploiter Effects Settings
 * ============================================================================
 *
 * These are effects for the battlers doing the exploiting. Change how you want
 * exploiter battlers to behave here.
 *
 * ---
 *
 * Mechanics
 * 
 *   Added States:
 *   - A list of the states that are added when a user exploits a foe.
 * 
 *   Extra Actions:
 *   - Successfully exploiting an enemy will grant the user this many
 *     extra actions.
 * 
 *   Multiple Exploits:
 *   - Can battlers exploit opponents multiple times with one action?
 * 
 *   JS: On Exploiting:
 *   - Code used when the user is exploiting a foe's weakness.
 *
 * ---
 *
 * Animation
 * 
 *   Animation ID:
 *   - Play this animation when the effect activates.
 * 
 *   Mirror Animation:
 *   - Mirror the effect animation?
 * 
 *   Mute Animation:
 *   - Mute the effect animation?
 *
 * ---
 *
 * Popups
 * 
 *   Text:
 *   - Text displayed upon the effect activating.
 * 
 *   Text Color:
 *   - Use #rrggbb for custom colors or regular numbers for text colors from
 *     the Window Skin.
 * 
 *   Flash Color:
 *   - Adjust the popup's flash color.
 *   - Format: [red, green, blue, alpha]
 * 
 *   Flash Duration:
 *   - What is the frame duration of the flash effect?
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Turn Order Settings
 * ============================================================================
 *
 * Turn Order Display settings used for Battle System STB. These adjust how the
 * visible turn order appears in-game.
 *
 * ---
 *
 * General
 * 
 *   Display Position:
 *   - Select where the Turn Order will appear on the screen.
 * 
 *     Offset X:
 *     - How much to offset the X coordinate by.
 *     - Negative: left. Positive: right.
 * 
 *     Offset Y:
 *     - How much to offset the Y coordinate by.
 *     - Negative: up. Positive: down.
 * 
 *   Center Horizontal?:
 *   - Reposition the Turn Order Display to always be centered if it is a
 *     'top' or 'bottom' position?
 * 
 *   Reposition for Help?:
 *   - If the display position is at the top, reposition the display when the
 *     help window is open?
 * 
 *   Reposition Log?:
 *   - If the display position is at the top, reposition the Battle Log Window
 *     to be lower?
 * 
 *   Forward Direction:
 *   - Decide on the direction of the Turn Order.
 *   - Settings may vary depending on position.
 *   - Left to Right / Down to Up
 *   - Right to Left / Up to Down
 * 
 *   Subject Distance:
 *   - How far do you want the currently active battler to distance itself from
 *     the rest of the Turn Order?
 * 
 *   Screen Buffer:
 *   - What distance do you want the display to be away from the edge of the
 *     screen by?
 *
 * ---
 *
 * Reposition For Help
 * 
 *   Repostion X By:
 *   Repostion Y By:
 *   - Reposition the display's coordinates by this much when the Help Window
 *     is visible.
 *
 * ---
 *
 * Slots
 * 
 *   Max Horizontal:
 *   - Maximum slots you want to display for top and bottom Turn Order Display
 *     positions?
 * 
 *   Max Vertical:
 *   - Maximum slots you want to display for left and right Turn Order Display
 *     positions?
 * 
 *   Length:
 *   - How many pixels long should the slots be on the Turn Order display?
 * 
 *   Thin:
 *   - How many pixels thin should the slots be on the Turn Order display?
 * 
 *   Update Frames:
 *   - How many frames should it take for the slots to update their
 *     positions by?
 *
 * ---
 *
 * Slot Border
 * 
 *   Show Border?:
 *   - Show borders for the slot sprites?
 * 
 *   Border Thickness:
 *   - How many pixels thick should the colored portion of the border be?
 * 
 *   Actors
 *   Enemies
 * 
 *     Border Color:
 *     - Use #rrggbb for custom colors or regular numbers for text colors
 *       from the Window Skin.
 * 
 *     Border Skin:
 *     - Optional. Place a skin on the actor/enemy borders instead of
 *       rendering them?
 *
 * ---
 *
 * Slot Sprites
 * 
 *   Actors
 * 
 *     Sprite Type:
 *     - Select the type of sprite used for the actor graphic.
 *     - Face Graphic - Show the actor's face.
 *     - Icon - Show a specified icon.
 *     - Sideview Actor - Show the actor's sideview battler.
 * 
 *     Default Icon:
 *     - Which icon do you want to use for actors by default?
 * 
 *   Enemies
 * 
 *     Sprite Type:
 *     - Select the type of sprite used for the enemy graphic.
 *     - Face Graphic - Show a specified face graphic.
 *     - Icon - Show a specified icon.
 *     - Enemy - Show the enemy's graphic or sideview battler.
 * 
 *     Default Face Name:
 *     - Use this default face graphic if there is no specified face.
 * 
 *     Default Face Index:
 *     - Use this default face index if there is no specified index.
 * 
 *     Default Icon:
 *     - Which icon do you want to use for enemies by default?
 * 
 *     Match Hue?:
 *     - Match the hue for enemy battlers?
 *     - Does not apply if there's a sideview battler.
 *
 * ---
 *
 * Slot Letter
 * 
 *   Show Enemy Letter?:
 *   - Show the enemy's letter on the slot sprite?
 * 
 *   Font Name:
 *   - The font name used for the text of the Letter.
 *   - Leave empty to use the default game's font.
 * 
 *   Font Size:
 *   - The font size used for the text of the Letter.
 *
 * ---
 *
 * Slot Background
 * 
 *   Show Background?:
 *   - Show the background on the slot sprite?
 * 
 *   Actors
 *   Enemies
 * 
 *     Background Color 1:
 *     Background Color 2:
 *     - Use #rrggbb for custom colors or regular numbers for text colors
 *       from the Window Skin.
 * 
 *     Background Skin:
 *     - Optional. Use a skin for the actor background instead of
 *       rendering them?
 *
 * ---
 *
 * ============================================================================
 * Terms of Use
 * ============================================================================
 *
 * 1. These plugins may be used in free or commercial games provided that they
 * have been acquired through legitimate means at VisuStella.com and/or any
 * other official approved VisuStella sources. Exceptions and special
 * circumstances that may prohibit usage will be listed on VisuStella.com.
 * 
 * 2. All of the listed coders found in the Credits section of this plugin must
 * be given credit in your games or credited as a collective under the name:
 * "VisuStella".
 * 
 * 3. You may edit the source code to suit your needs, so long as you do not
 * claim the source code belongs to you. VisuStella also does not take
 * responsibility for the plugin if any changes have been made to the plugin's
 * code, nor does VisuStella take responsibility for user-provided custom code
 * used for custom control effects including advanced JavaScript notetags
 * and/or plugin parameters that allow custom JavaScript code.
 * 
 * 4. You may NOT redistribute these plugins nor take code from this plugin to
 * use as your own. These plugins and their code are only to be downloaded from
 * VisuStella.com and other official/approved VisuStella sources. A list of
 * official/approved sources can also be found on VisuStella.com.
 *
 * 5. VisuStella is not responsible for problems found in your game due to
 * unintended usage, incompatibility problems with plugins outside of the
 * VisuStella MZ library, plugin versions that aren't up to date, nor
 * responsible for the proper working of compatibility patches made by any
 * third parties. VisuStella is not responsible for errors caused by any
 * user-provided custom code used for custom control effects including advanced
 * JavaScript notetags and/or plugin parameters that allow JavaScript code.
 *
 * 6. If a compatibility patch needs to be made through a third party that is
 * unaffiliated with VisuStella that involves using code from the VisuStella MZ
 * library, contact must be made with a member from VisuStella and have it
 * approved. The patch would be placed on VisuStella.com as a free download
 * to the public. Such patches cannot be sold for monetary gain, including
 * commissions, crowdfunding, and/or donations.
 * 
 * 7. If this VisuStella MZ plugin is a paid product, all project team members
 * must purchase their own individual copies of the paid product if they are to
 * use it. Usage includes working on related game mechanics, managing related
 * code, and/or using related Plugin Commands and features. Redistribution of
 * the plugin and/or its code to other members of the team is NOT allowed
 * unless they own the plugin itself as that conflicts with Article 4.
 * 
 * 8. Any extensions and/or addendums made to this plugin's Terms of Use can be
 * found on VisuStella.com and must be followed.
 *
 * ============================================================================
 * Credits
 * ============================================================================
 * 
 * If you are using this plugin, credit the following people in your game:
 * 
 * Team VisuStella
 * * Yanfly
 * * Arisu
 * * Olivia
 * * Irina
 *
 * ============================================================================
 * Changelog
 * ============================================================================
 * 
 * Version 1.17: August 18, 2022
 * * Bug Fixes!
 * ** Fixed bugs that caused the BTB Turn Order faces and icons to not change
 *    properly for actors and enemies. Fix made by Olivia.
 * 
 * Version 1.16: July 7, 2022
 * * Compatibility Update!
 * ** Plugin is now updated to support larger than 8 troop sizes.
 * 
 * Version 1.15: June 9, 2022
 * * Documentation Update!
 * ** Help file updated for new features.
 * * New Features!
 * ** New Plugin Parameter added by Olivia:
 * *** Plugin Parameters > Exploit System Settings > Forced Actions
 * **** Apply exploit system to Forced Actions?
 * **** We added this function because forced actions can disrupt player
 *      strategies when used with the exploit system.
 * 
 * Version 1.14: March 3, 2022
 * * Optimization Update!
 * ** Plugin should run more optimized.
 * 
 * Version 1.13: November 11, 2021
 * * Bug Fixes!
 * ** Critical hits for enemies with only one action per turn should now
 *    properly allow for the exploited effect to occur. Fix made by Olivia.
 * 
 * Version 1.12: October 28, 2021
 * * Bug Fixes!
 * ** Turn Order display will no longer appear at differing X and Y positions
 *    when using specific battle layouts. Update made by Olivia.
 * 
 * Version 1.11: July 23, 2021
 * * Bug Fixes!
 * ** Fixed a bug that altered the current action choice when enemies are using
 *    a skill that utilizes instants when there is only enough MP left for one
 *    of those actions. Fix made by Olivia.
 * 
 * Version 1.10: July 2, 2021
 * * Bug Fixes!
 * ** Dead battlers will no longer reappear in the turn order on subsequent
 *    turns. Fix made by Olivia.
 * * Documentation Update!
 * ** Help file updated for updated features.
 * * Feature Update!
 * ** "Mechanics Settings" Plugin Parameters has been updated into
 *    "Speed Mechanics" with updated formulas that will now correlate any
 *    adjusted AGI changes made to battlers to alter the following turn
 *    properly. Update made by Olivia.
 * 
 * Version 1.09: March 26, 2021
 * * Bug Fixes!
 * ** Enemy exploit actions should now associate A.I. properly. Fix by Yanfly.
 * * Documentation Update!
 * ** Added "VisuStella MZ Compatibility" section for detailed compatibility
 *    explanations with the VisuMZ_4_BreakShields plugin.
 * 
 * Version 1.08: March 19, 2021
 * * Feature Update!
 * ** Turn Order Window calculations slightly tweaked for times when the window
 *    layer is bigger than it should be. Update made by Olivia.
 * * Optimization Update!
 * ** Plugin should run more optimized.
 * 
 * Version 1.07: January 22, 2021
 * * Feature Update!
 * ** A different kind of end battle check is now made to determine hiding the
 *    turn order display. Update made by Olivia.
 * 
 * Version 1.06: January 1, 2021
 * * Compatibility Update
 * ** Added compatibility functionality for future plugins.
 * 
 * Version 1.05: December 25, 2020
 * * Bug Fixes!
 * ** Starting battle from a surprise attack will no longer skip turn 1. And
 *    starting battle without any inputtable actors will no longer skip turn 1.
 *    Fix made by Yanfly.
 * 
 * Version 1.04: December 18, 2020
 * * Feature Update!
 * ** Enemies can now benefit from <STB Instant> skills. Update made by Olivia.
 * ** Action End States updating are now handled by Skills and States Core
 *    v1.07+ for proper intended usage. Change from Battle System - STB v1.02
 *    is reverted here to prevent triggering the update twice.
 * 
 * Version 1.03: December 4, 2020
 * * Bug Fixes!
 * ** Select Next Command no longer returns undefined. Fix made by Olivia.
 * 
 * Version 1.02: November 22, 2020
 * * Bug Fixes!
 * ** Action End States now update at the end of each individual action.
 *    Fix made by Yanfly.
 * 
 * Version 1.01: November 15, 2020
 * * Bug Fixes!
 * ** Now compatible with Party Command Window Disable from the Battle Core.
 *    Fix made by Yanfly.
 *
 * Version 1.00 Official Release Date: November 23, 2020
 * * Finished Plugin!
 *
 * ============================================================================
 * End of Helpfile
 * ============================================================================
 *
 * @ --------------------------------------------------------------------------
 *
 * @command StbTurnOrderActorIcon
 * @text Actor: Change STB Turn Order Icon
 * @desc Changes the icons used for the specific actor(s) on the STB Turn Order.
 *
 * @arg Actors:arraynum
 * @text Actor ID(s)
 * @type actor[]
 * @desc Select which Actor ID(s) to affect.
 * @default ["1"]
 *
 * @arg IconIndex:num
 * @text Icon
 * @desc Changes the graphic to this icon.
 * @default 84
 *
 * @ --------------------------------------------------------------------------
 *
 * @command StbTurnOrderActorFace
 * @text Actor: Change STB Turn Order Face
 * @desc Changes the faces used for the specific actor(s) on the STB Turn Order.
 *
 * @arg Actors:arraynum
 * @text Actor ID(s)
 * @type actor[]
 * @desc Select which Actor ID(s) to affect.
 * @default ["1"]
 *
 * @arg FaceName:str
 * @text Face Name
 * @type file
 * @dir img/faces/
 * @desc This is the filename for the target face graphic.
 * @default Actor1
 *
 * @arg FaceIndex:num
 * @text Face Index
 * @type number
 * @desc This is the index for the target face graphic.
 * @default 0
 *
 * @ --------------------------------------------------------------------------
 *
 * @command StbTurnOrderClearActorGraphic
 * @text Actor: Clear STB Turn Order Graphic
 * @desc Clears the STB Turn Order graphics for the actor(s).
 * The settings will revert to the Plugin Parameter settings.
 *
 * @arg Actors:arraynum
 * @text Actor ID(s)
 * @type actor[]
 * @desc Select which Actor ID(s) to affect.
 * @default ["1"]
 *
 * @ --------------------------------------------------------------------------
 *
 * @command StbTurnOrderEnemyIcon
 * @text Enemy: Change STB Turn Order Icon
 * @desc Changes the icons used for the specific enemy(ies) on the STB Turn Order.
 *
 * @arg Enemies:arraynum
 * @text Enemy Index(es)
 * @type number[]
 * @desc Select which enemy index(es) to affect.
 * @default ["1"]
 *
 * @arg IconIndex:num
 * @text Icon
 * @desc Changes the graphic to this icon.
 * @default 298
 *
 * @ --------------------------------------------------------------------------
 *
 * @command StbTurnOrderEnemyFace
 * @text Enemy: Change STB Turn Order Face
 * @desc Changes the faces used for the specific enemy(ies) on the STB Turn Order.
 *
 * @arg Enemies:arraynum
 * @text Enemy Index(es)
 * @type number[]
 * @desc Select which enemy index(es) to affect.
 * @default ["1"]
 *
 * @arg FaceName:str
 * @text Face Name
 * @parent EnemySprite
 * @type file
 * @dir img/faces/
 * @desc This is the filename for the target face graphic.
 * @default Monster
 *
 * @arg FaceIndex:num
 * @text Face Index
 * @parent EnemySprite
 * @type number
 * @desc This is the index for the target face graphic.
 * @default 1
 *
 * @ --------------------------------------------------------------------------
 *
 * @command StbTurnOrderClearEnemyGraphic
 * @text Enemy: Clear STB Turn Order Graphic
 * @desc Clears the STB Turn Order graphics for the enemy(ies).
 * The settings will revert to the Plugin Parameter settings.
 *
 * @arg Enemies:arraynum
 * @text Enemy Index(es)
 * @type number[]
 * @desc Select which enemy index(es) to affect.
 * @default ["1"]
 *
 * @ --------------------------------------------------------------------------
 *
 * @command SystemTurnOrderVisibility
 * @text System: STB Turn Order Visibility
 * @desc Determine the visibility of the STB Turn Order Display.
 *
 * @arg Visible:eval
 * @text Visibility
 * @type boolean
 * @on Visible
 * @off Hidden
 * @desc Changes the visibility of the STB Turn Order Display.
 * @default true
 *
 * @ --------------------------------------------------------------------------
 *
 * @ ==========================================================================
 * @ Plugin Parameters
 * @ ==========================================================================
 *
 * @param BreakHead
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param BattleSystemSTB
 * @default Plugin Parameters
 *
 * @param ATTENTION
 * @default READ THE HELP FILE
 *
 * @param BreakSettings
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param Speed:struct
 * @text Speed Mechanics
 * @type struct<Speed>
 * @desc Determines the mechanics of the STB Battle System.
 * @default {"Speed":"","InitialSpeedJS:func":"\"// Declare Constants\\nconst user = this;\\nconst agi = user.agi;\\n\\n// Create Base Speed\\nlet speed = agi;\\n\\n// Random Speed Check\\nif (user.allowRandomSpeed()) {\\n    speed += Math.randomInt(Math.floor(5 + agi / 4));\\n}\\n\\n// Add Saved Speed Modifiers from Previous Round\\nspeed += user.getSTBNextTurnSpeed();\\n\\n// Return Speed\\nreturn speed;\"","NextTurnSavedSpeedJS:func":"\"// Create Speed\\nconst action = this;\\nlet speed = 0;\\n\\n// Check Object\\nif (action.item()) {\\n    speed += action.item().speed;\\n}\\n\\n// Check Attack\\nif (action.isAttack()) {\\n    speed += action.subject().attackSpeed();\\n}\\n\\n// Return Speed\\nreturn speed;\""}
 *
 * @param Exploit:struct
 * @text Exploit System
 * @type struct<Exploit>
 * @desc Settings for the STB's Exploit System.
 * @default {"EnableExploit:eval":"true","ExploitCritical:eval":"true","ExploitEleWeakness:eval":"true","ExploitEleRate:num":"1.05","TurnResetExploits:eval":"true"}
 *
 * @param Exploited:struct
 * @text Exploited Effects
 * @parent Exploit:struct
 * @type struct<Exploited>
 * @desc Settings for targets being Exploited.
 * @default {"Mechanics":"","AddedStates:arraynum":"[\"13\"]","FullExploitEvents":"","vsActorsFullExploit:num":"0","vsEnemiesFullExploit:num":"0","UnlimitedExploits:eval":"false","CustomJS:func":"\"// Declare Constants\\nconst target = this;\\nconst user = arguments[0];\\nconst action = arguments[1];\\n\\n// Perform Actions\\n\"","Animation":"","AnimationID:num":"0","Mirror:eval":"false","Mute:eval":"false","Popups":"","PopupText:str":"","TextColor:str":"0","FlashColor:eval":"[255, 255, 255, 160]","FlashDuration:num":"60"}
 *
 * @param Exploiter:struct
 * @text Exploiter Effects
 * @parent Exploit:struct
 * @type struct<Exploiter>
 * @desc Settings for users doing the Exploiting.
 * @default {"Mechanics":"","AddedStates:arraynum":"[]","ExtraActions:num":"1","MultipleExploits:eval":"false","CustomJS:func":"\"// Declare Constants\\nconst user = this;\\nconst target = arguments[0];\\nconst action = arguments[1];\\n\\n// Perform Actions\\n\"","Animation":"","AnimationID:num":"12","Mirror:eval":"false","Mute:eval":"false","Popups":"","PopupText:str":"ONE MORE!","TextColor:str":"0","FlashColor:eval":"[255, 255, 128, 160]","FlashDuration:num":"60"}
 *
 * @param TurnOrder:struct
 * @text Turn Order Display
 * @type struct<TurnOrder>
 * @desc Turn Order Display settings used for Battle System STB.
 * @default {"General":"","DisplayPosition:str":"top","DisplayOffsetX:num":"0","DisplayOffsetY:num":"0","CenterHorz:eval":"true","RepositionTopForHelp:eval":"true","RepositionLogWindow:eval":"true","OrderDirection:eval":"true","SubjectDistance:num":"8","ScreenBuffer:num":"20","Reposition":"","RepositionTopHelpX:num":"0","RepositionTopHelpY:num":"96","Slots":"","MaxHorzSprites:num":"16","MaxVertSprites:num":"10","SpriteLength:num":"72","SpriteThin:num":"36","UpdateFrames:num":"24","Border":"","ShowMarkerBorder:eval":"true","BorderActor":"","ActorBorderColor:str":"4","ActorSystemBorder:str":"","BorderEnemy":"","EnemyBorderColor:str":"2","EnemySystemBorder:str":"","BorderThickness:num":"2","Sprite":"","ActorSprite":"","ActorBattlerType:str":"face","ActorBattlerIcon:num":"84","EnemySprite":"","EnemyBattlerType:str":"enemy","EnemyBattlerFaceName:str":"Monster","EnemyBattlerFaceIndex:num":"1","EnemyBattlerIcon:num":"298","EnemyBattlerMatchHue:eval":"true","Letter":"","EnemyBattlerDrawLetter:eval":"true","EnemyBattlerFontFace:str":"","EnemyBattlerFontSize:num":"16","Background":"","ShowMarkerBg:eval":"true","BackgroundActor":"","ActorBgColor1:str":"19","ActorBgColor2:str":"9","ActorSystemBg:str":"","BackgroundEnemy":"","EnemyBgColor1:str":"19","EnemyBgColor2:str":"18","EnemySystemBg:str":""}
 *
 * @param BreakEnd1
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param End Of
 * @default Plugin Parameters
 *
 * @param BreakEnd2
 * @text --------------------------
 * @default ----------------------------------
 *
 */
/* ----------------------------------------------------------------------------
 * Speed Mechanics Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Speed:
 *
 * @param Speed
 *
 * @param InitialSpeedJS:func
 * @text JS: Finalized Speed
 * @parent Speed
 * @type note
 * @desc Code used to calculate initial speed at the start of battle.
 * @default "// Declare Constants\nconst user = this;\nconst agi = user.agi;\n\n// Create Base Speed\nlet speed = agi;\n\n// Random Speed Check\nif (user.allowRandomSpeed()) {\n    speed += Math.randomInt(Math.floor(5 + agi / 4));\n}\n\n// Add Saved Speed Modifiers from Previous Round\nspeed += user.getSTBNextTurnSpeed();\n\n// Return Speed\nreturn speed;"
 *
 * @param NextTurnSavedSpeedJS:func
 * @text JS: Next Turn Speed
 * @parent Speed
 * @type note
 * @desc Code used to calculate speed for a following turn.
 * @default "// Create Speed\nconst action = this;\nlet speed = 0;\n\n// Check Object\nif (action.item()) {\n    speed += action.item().speed;\n}\n\n// Check Attack\nif (action.isAttack()) {\n    speed += action.subject().attackSpeed();\n}\n\n// Return Speed\nreturn speed;"
 * 
 */
/* ----------------------------------------------------------------------------
 * Exploit System Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Exploit:
 *
 * @param EnableExploit:eval
 * @text Enable System?
 * @parent Exploit
 * @type boolean
 * @on Enable
 * @off Disable
 * @desc Enable the exploit system? If disabled, ignore all the 
 * mechanics regarding the Exploit System.
 * @default true
 *
 * @param ExploitCritical:eval
 * @text Critical Hits
 * @parent Exploit
 * @type boolean
 * @on Exploit
 * @off Don't Exploit
 * @desc Do critical hits exploit the opponent?
 * @default true
 *
 * @param ExploitEleWeakness:eval
 * @text Elemental Weakness
 * @parent Exploit
 * @type boolean
 * @on Exploit
 * @off Don't Exploit
 * @desc Do elemental weaknesses exploit the opponent?
 * @default true
 *
 * @param ExploitEleRate:num
 * @text Minimum Rate
 * @parent ExploitEleWeakness:eval
 * @desc What's the minimum rate needed to count as an elemental weakness?
 * @default 1.05
 *
 * @param ForcedActions:eval
 * @text Forced Actions
 * @parent Exploit
 * @type boolean
 * @on Apply
 * @off Don't Apply
 * @desc Apply exploit system to Forced Actions?
 * @default false
 *
 * @param TurnResetExploits:eval
 * @text Reset Each Turn
 * @parent Exploit
 * @type boolean
 * @on Reset Exploits
 * @off Don't Reset
 * @desc Reset exploits at the end of each turn?
 * @default true
 *
 */
/* ----------------------------------------------------------------------------
 * Exploited Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Exploited:
 *
 * @param Mechanics
 * 
 * @param AddedStates:arraynum
 * @text Added States
 * @parent Mechanics
 * @type state[]
 * @desc A list of the states that are added when a target is exploited.
 * @default ["13"]
 * 
 * @param FullExploitEvents
 * @text Full Exploit Events
 * @parent Mechanics
 * 
 * @param vsActorsFullExploit:num
 * @text vs Actors Event
 * @parent FullExploitEvents
 * @type common_event
 * @desc If all actors have been fully exploited, run this common
 * event. Does not work with unlimited exploits.
 * @default 0
 * 
 * @param vsEnemiesFullExploit:num
 * @text vs Enemies Event
 * @parent FullExploitEvents
 * @type common_event
 * @desc If all enemies have been fully exploited, run this common
 * event. Does not work with unlimited exploits.
 * @default 0
 *
 * @param UnlimitedExploits:eval
 * @text Unlimited Exploits
 * @parent Mechanics
 * @type boolean
 * @on Unlimited
 * @off Once Per Turn
 * @desc Can battlers be exploited endlessly?
 * @default false
 *
 * @param CustomJS:func
 * @text JS: On Exploited
 * @parent Mechanics
 * @type note
 * @desc Code used when the target has been exploited.
 * @default "// Declare Constants\nconst target = this;\nconst user = arguments[0];\nconst action = arguments[1];\n\n// Perform Actions\n"
 *
 * @param Animation
 *
 * @param AnimationID:num
 * @text Animation ID
 * @parent Animation
 * @type animation
 * @desc Play this animation when the effect activates.
 * @default 0
 *
 * @param Mirror:eval
 * @text Mirror Animation
 * @parent Animation
 * @type boolean
 * @on Mirror
 * @off Normal
 * @desc Mirror the effect animation?
 * @default false
 *
 * @param Mute:eval
 * @text Mute Animation
 * @parent Animation
 * @type boolean
 * @on Mute
 * @off Normal
 * @desc Mute the effect animation?
 * @default false
 *
 * @param Popups
 *
 * @param PopupText:str
 * @text Text
 * @parent Popups
 * @desc Text displayed upon the effect activating.
 * @default 
 *
 * @param TextColor:str
 * @text Text Color
 * @parent Popups
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 0
 *
 * @param FlashColor:eval
 * @text Flash Color
 * @parent Popups
 * @desc Adjust the popup's flash color.
 * Format: [red, green, blue, alpha]
 * @default [255, 255, 255, 160]
 * 
 * @param FlashDuration:num
 * @text Flash Duration
 * @parent Popups
 * @type number
 * @desc What is the frame duration of the flash effect?
 * @default 60
 *
 */
/* ----------------------------------------------------------------------------
 * Exploiter Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Exploiter:
 *
 * @param Mechanics
 * 
 * @param AddedStates:arraynum
 * @text Added States
 * @parent Mechanics
 * @type state[]
 * @desc A list of the states that are added when a user exploits a foe.
 * @default []
 * 
 * @param ExtraActions:num
 * @text Extra Actions
 * @parent Mechanics
 * @type number
 * @desc Successfully exploiting an enemy will grant the user this many extra actions.
 * @default 1
 *
 * @param MultipleExploits:eval
 * @text Multiple Exploits
 * @parent Mechanics
 * @type boolean
 * @on Multiple
 * @off Once Per Action
 * @desc Can battlers exploit opponents multiple times with one action?
 * @default false
 *
 * @param CustomJS:func
 * @text JS: On Exploiting
 * @parent Mechanics
 * @type note
 * @desc Code used when the user is exploiting a foe's weakness.
 * @default ""
 *
 * @param Animation
 *
 * @param AnimationID:num
 * @text Animation ID
 * @parent Animation
 * @type animation
 * @desc Play this animation when the effect activates.
 * @default 12
 *
 * @param Mirror:eval
 * @text Mirror Animation
 * @parent Animation
 * @type boolean
 * @on Mirror
 * @off Normal
 * @desc Mirror the effect animation?
 * @default false
 *
 * @param Mute:eval
 * @text Mute Animation
 * @parent Animation
 * @type boolean
 * @on Mute
 * @off Normal
 * @desc Mute the effect animation?
 * @default false
 *
 * @param Popups
 *
 * @param PopupText:str
 * @text Text
 * @parent Popups
 * @desc Text displayed upon the effect activating.
 * @default ONE MORE!
 *
 * @param TextColor:str
 * @text Text Color
 * @parent Popups
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 0
 *
 * @param FlashColor:eval
 * @text Flash Color
 * @parent Popups
 * @desc Adjust the popup's flash color.
 * Format: [red, green, blue, alpha]
 * @default [255, 255, 128, 160]
 * 
 * @param FlashDuration:num
 * @text Flash Duration
 * @parent Popups
 * @type number
 * @desc What is the frame duration of the flash effect?
 * @default 60
 *
 */
/* ----------------------------------------------------------------------------
 * Turn Order Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~TurnOrder:
 *
 * @param General
 *
 * @param DisplayPosition:str
 * @text Display Position
 * @parent General
 * @type select
 * @option top
 * @option bottom
 * @option left
 * @option right
 * @desc Select where the Turn Order will appear on the screen.
 * @default top
 * 
 * @param DisplayOffsetX:num
 * @text Offset X
 * @parent DisplayPosition:str
 * @desc How much to offset the X coordinate by.
 * Negative: left. Positive: right.
 * @default 0
 * 
 * @param DisplayOffsetY:num
 * @text Offset Y
 * @parent DisplayPosition:str
 * @desc How much to offset the Y coordinate by.
 * Negative: up. Positive: down.
 * @default 0
 *
 * @param CenterHorz:eval
 * @text Center Horizontal?
 * @parent DisplayPosition:str
 * @type boolean
 * @on Center
 * @off Stay
 * @desc Reposition the Turn Order Display to always be centered
 * if it is a 'top' or 'bottom' position?
 * @default true
 *
 * @param RepositionTopForHelp:eval
 * @text Reposition for Help?
 * @parent DisplayPosition:str
 * @type boolean
 * @on Reposition
 * @off Stay
 * @desc If the display position is at the top, reposition the
 * display when the help window is open?
 * @default true
 *
 * @param RepositionLogWindow:eval
 * @text Reposition Log?
 * @parent DisplayPosition:str
 * @type boolean
 * @on Reposition
 * @off Stay
 * @desc If the display position is at the top, reposition the
 * Battle Log Window to be lower?
 * @default true
 *
 * @param OrderDirection:eval
 * @text Forward Direction
 * @parent General
 * @type boolean
 * @on Left to Right / Down to Up
 * @off Right to Left / Up to Down
 * @desc Decide on the direction of the Turn Order.
 * Settings may vary depending on position.
 * @default true
 *
 * @param SubjectDistance:num
 * @text Subject Distance
 * @parent General
 * @type number
 * @desc How far do you want the currently active battler to
 * distance itself from the rest of the Turn Order?
 * @default 8
 *
 * @param ScreenBuffer:num
 * @text Screen Buffer
 * @parent General
 * @type number
 * @desc What distance do you want the display to be away
 * from the edge of the screen by?
 * @default 20
 * 
 * @param Reposition
 * @text Reposition For Help
 *
 * @param RepositionTopHelpX:num
 * @text Repostion X By
 * @parent Reposition
 * @desc Reposition the display's X coordinates by this much when
 * the Help Window is visible.
 * @default 0
 *
 * @param RepositionTopHelpY:num
 * @text Repostion Y By
 * @parent Reposition
 * @desc Reposition the display's Y coordinates by this much when
 * the Help Window is visible.
 * @default 96
 * 
 * @param Slots
 *
 * @param MaxHorzSprites:num
 * @text Max Horizontal
 * @parent Slots
 * @type number
 * @min 1
 * @desc Maximum slots you want to display for top and
 * bottom Turn Order Display positions?
 * @default 16
 *
 * @param MaxVertSprites:num
 * @text Max Vertical
 * @parent Slots
 * @type number
 * @min 1
 * @desc Maximum slots you want to display for left and
 * right Turn Order Display positions?
 * @default 10
 *
 * @param SpriteLength:num
 * @text Length
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many pixels long should the slots be on the
 * Turn Order display?
 * @default 72
 *
 * @param SpriteThin:num
 * @text Thin
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many pixels thin should the slots be on the
 * Turn Order display?
 * @default 36
 *
 * @param UpdateFrames:num
 * @text Update Frames
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many frames should it take for the slots to
 * update their positions by?
 * @default 24
 *
 * @param Border
 * @text Slot Border
 *
 * @param ShowMarkerBorder:eval
 * @text Show Border?
 * @parent Border
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show borders for the slot sprites?
 * @default true
 *
 * @param BorderThickness:num
 * @text Border Thickness
 * @parent Markers
 * @type number
 * @min 1
 * @desc How many pixels thick should the colored portion of the border be?
 * @default 2
 *
 * @param BorderActor
 * @text Actors
 * @parent Border
 *
 * @param ActorBorderColor:str
 * @text Border Color
 * @parent BorderActor
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 4
 *
 * @param ActorSystemBorder:str
 * @text Border Skin
 * @parent BorderActor
 * @type file
 * @dir img/system/
 * @desc Optional. Place a skin on the actor borders instead of rendering them?
 * @default 
 *
 * @param BorderEnemy
 * @text Enemies
 * @parent Border
 *
 * @param EnemyBorderColor:str
 * @text Border Color
 * @parent BorderEnemy
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 2
 *
 * @param EnemySystemBorder:str
 * @text Border Skin
 * @parent BorderEnemy
 * @type file
 * @dir img/system/
 * @desc Optional. Place a skin on the enemy borders instead of rendering them?
 * @default 
 *
 * @param Sprite
 * @text Slot Sprites
 *
 * @param ActorSprite
 * @text Actors
 * @parent Sprite
 *
 * @param ActorBattlerType:str
 * @text Sprite Type
 * @parent ActorSprite
 * @type select
 * @option Face Graphic - Show the actor's face.
 * @value face
 * @option Icon - Show a specified icon.
 * @value icon
 * @option Sideview Actor - Show the actor's sideview battler.
 * @value svactor
 * @desc Select the type of sprite used for the actor graphic.
 * @default face
 *
 * @param ActorBattlerIcon:num
 * @text Default Icon
 * @parent ActorSprite
 * @desc Which icon do you want to use for actors by default?
 * @default 84
 *
 * @param EnemySprite
 * @text Enemies
 * @parent Sprite
 *
 * @param EnemyBattlerType:str
 * @text Sprite Type
 * @parent EnemySprite
 * @type select
 * @option Face Graphic - Show a specified face graphic.
 * @value face
 * @option Icon - Show a specified icon.
 * @value icon
 * @option Enemy - Show the enemy's graphic or sideview battler.
 * @value enemy
 * @desc Select the type of sprite used for the enemy graphic.
 * @default enemy
 *
 * @param EnemyBattlerFaceName:str
 * @text Default Face Name
 * @parent EnemySprite
 * @type file
 * @dir img/faces/
 * @desc Use this default face graphic if there is no specified face.
 * @default Monster
 *
 * @param EnemyBattlerFaceIndex:num
 * @text Default Face Index
 * @parent EnemySprite
 * @type number
 * @desc Use this default face index if there is no specified index.
 * @default 1
 *
 * @param EnemyBattlerIcon:num
 * @text Default Icon
 * @parent EnemySprite
 * @desc Which icon do you want to use for enemies by default?
 * @default 298
 *
 * @param EnemyBattlerMatchHue:eval
 * @text Match Hue?
 * @parent EnemySprite
 * @type boolean
 * @on Match
 * @off Don't Match
 * @desc Match the hue for enemy battlers?
 * Does not apply if there's a sideview battler.
 * @default true
 *
 * @param Letter
 * @text Slot Letter
 *
 * @param EnemyBattlerDrawLetter:eval
 * @text Show Enemy Letter?
 * @parent Letter
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show the enemy's letter on the slot sprite?
 * @default true
 *
 * @param EnemyBattlerFontFace:str
 * @text Font Name
 * @parent Letter
 * @desc The font name used for the text of the Letter.
 * Leave empty to use the default game's font.
 * @default 
 *
 * @param EnemyBattlerFontSize:num
 * @text Font Size
 * @parent Letter
 * @min 1
 * @desc The font size used for the text of the Letter.
 * @default 16
 *
 * @param Background
 * @text Slot Background
 *
 * @param ShowMarkerBg:eval
 * @text Show Background?
 * @parent Background
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show the background on the slot sprite?
 * @default true
 *
 * @param BackgroundActor
 * @text Actors
 * @parent Background
 *
 * @param ActorBgColor1:str
 * @text Background Color 1
 * @parent BackgroundActor
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 19
 *
 * @param ActorBgColor2:str
 * @text Background Color 2
 * @parent BackgroundActor
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 9
 *
 * @param ActorSystemBg:str
 * @text Background Skin
 * @parent BackgroundActor
 * @type file
 * @dir img/system/
 * @desc Optional. Use a skin for the actor background instead of rendering them?
 * @default 
 *
 * @param BackgroundEnemy
 * @text Enemies
 * @parent Background
 *
 * @param EnemyBgColor1:str
 * @text Background Color 1
 * @parent BackgroundEnemy
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 19
 *
 * @param EnemyBgColor2:str
 * @text Background Color 2
 * @parent BackgroundEnemy
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 18
 *
 * @param EnemySystemBg:str
 * @text Background Skin
 * @parent BackgroundEnemy
 * @type file
 * @dir img/system/
 * @desc Optional. Use a skin for the enemy background instead of rendering them?
 * @default 
 *
 */
//=============================================================================

function _0x3325(_0x113e56,_0x479010){const _0xfd4ad7=_0xfd4a();return _0x3325=function(_0x33252d,_0x4afb36){_0x33252d=_0x33252d-0x1f1;let _0x2d82fd=_0xfd4ad7[_0x33252d];return _0x2d82fd;},_0x3325(_0x113e56,_0x479010);}const _0x28da48=_0x3325;(function(_0x47543f,_0x553cc6){const _0x14489c=_0x3325,_0x50cfc1=_0x47543f();while(!![]){try{const _0x45b9b6=parseInt(_0x14489c(0x3be))/0x1+-parseInt(_0x14489c(0x2b6))/0x2*(parseInt(_0x14489c(0x2ba))/0x3)+parseInt(_0x14489c(0x39b))/0x4+parseInt(_0x14489c(0x3ae))/0x5*(parseInt(_0x14489c(0x239))/0x6)+parseInt(_0x14489c(0x24e))/0x7*(parseInt(_0x14489c(0x3ac))/0x8)+parseInt(_0x14489c(0x214))/0x9*(parseInt(_0x14489c(0x262))/0xa)+-parseInt(_0x14489c(0x308))/0xb*(parseInt(_0x14489c(0x238))/0xc);if(_0x45b9b6===_0x553cc6)break;else _0x50cfc1['push'](_0x50cfc1['shift']());}catch(_0x4107c6){_0x50cfc1['push'](_0x50cfc1['shift']());}}}(_0xfd4a,0xa4c05));var label='BattleSystemSTB',tier=tier||0x0,dependencies=[],pluginData=$plugins['filter'](function(_0x529839){const _0x168af8=_0x3325;return _0x529839[_0x168af8(0x3ef)]&&_0x529839[_0x168af8(0x229)][_0x168af8(0x249)]('['+label+']');})[0x0];function _0xfd4a(){const _0x56fdd0=['removeActionBattlersSTB','jVIbC','max','_letter','endAction','jajDm','_graphicSprite','_graphicFaceIndex','ExploitEleWeakness','battleSys','registerCommand','battleEnd','unshift','aVRxd','endActionSTB','Actor','result','_stbTurnOrderFaceName','%1BgColor2','onTurnEnd','makeSpeed','EnemyBattlerFaceIndex','close','Game_Battler_performCollapse','onBattleStart','_unit','iVxMC','FlashColor','QEuEr','bottom','canInput','getColor','toUpperCase','%1BorderColor','_turnOrderInnerSprite','fIMvY','MaxVertSprites','initMembers','ScreenBuffer','icon','recalculateHome','_positionTargetY','getSTBNextTurnSpeed','KaFXl','isBattleSystemSTBTurnOrderVisible','Mute','removeActor','setSTBExploitedFlag','NPdoe','isTurnBased','Exploited','Mirror','getBattleSystem','makeSTBSpeed','Game_Battler_onTurnEnd','zyrnw','fDWrU','startActorCommandSelection','Exploiter','brgiW','bitmap','commandCancel','defaultPosition','JSON','checkPosition','88OJFNon','_stbTurnOrderFaceIndex','isHorz','hksAw','BattleManager_battleSys','isSTBExploited','jMMrK','Instant','_isAppeared','addChildAt','TurnOrder','_scene','startFade','loadSvEnemy','bitmapHeight','isActor','BattleManager_isTurnBased','TurnOrderSTBGraphicFaceIndex','_index','isSTB','TEAoc','BattleManager_isTpb','shift','BYHec','bMhXb','map','_stbNextTurnSpeed','_ogWindowLayerX','ARRAYJSON','_helpWindow','StbTurnOrderEnemyIcon','mainSprite','Visible','_graphicType','agpfb','%1\x27s\x20version\x20does\x20not\x20match\x20plugin\x27s.\x20Please\x20update\x20it\x20in\x20the\x20Plugin\x20Manager.','createTurnOrderSTBGraphicFaceName','Game_Battler_onBattleStart','call','_containerWidth','traitObjects','BorderThickness','format','ABdNv','XGBFK','Game_BattlerBase_appear','createTestBitmap','_graphicSv','fillRect','isSideView','createTurnOrderSTBGraphicIconIndex','ZmhnX','EnemyBattlerFaceName','Enemy','processTurnSTB','hasSTBExploited','%1SystemBorder','updateGraphicHue','Enemies','ceil','createGraphicSprite','startTurn','currentAction','BattleManager_selectNextActor','mainFontFace','svActorVertCells','TurnOrderSTBGraphicType','isAppeared','updateSidePosition','tZDTQ','ExploitCritical','_actions','create','checkOpacity','initialize','loadSystem','VOqEg','createBackgroundSprite','clearSTBExploit','requestFauxAnimation','aliveMembers','update','svActorHorzCells','EnemyBattlerFontSize','fontFace','getChildIndex','ConvertParams','fgtpT','FaceIndex','Settings','eldgN','iOWsz','clear','IconIndex','addLoadListener','%1\x20is\x20missing\x20a\x20required\x20plugin.\x0aPlease\x20install\x20%2\x20into\x20the\x20Plugin\x20Manager.','BattleManager_endAction','ExploiterStates','setup','CIEis','_positionDuration','Scene_Battle_createActorCommandWindow','lMzvO','addState','updateLetter','sort','ARRAYNUM','StbTurnOrderClearActorGraphic','rEbmH','%1\x20%2\x20%3','startInputSTB','performCollapse','min','createTurnOrderSTBGraphicType','StbTurnOrderClearEnemyGraphic','NextTurnSavedSpeedJS','xUENv','becomeSTBExploited','CannotBeExploited','selectNextActor','_fadeTarget','_backgroundSprite','qmGch','applyGlobal','numActions','sIfzo','TextColor','TurnOrderSTBGraphicFaceName','startInput','STR','WNQtM','%1BgColor1','_plural','_graphicFaceName','ioclj','isActionValid','QVlTB','floor','_blendColor','_windowLayer','iconWidth','_positionTargetX','gradientFillRect','VDHkF','StbTurnOrderEnemyFace','_graphicIconIndex','_isAlive','2256956OEwoVO','_forcedBattlers','PopupText','updateGraphic','vsjQa','_fullWidth','finishActorInput','YKxdc','actor','getStateTooltipBattler','isSTBExploitSystemEnabled','test','dEOwz','length','OibYY','kcyZP','fOnDL','16oqwMfV','processUpdateGraphic','5gqIXNf','_position','bind','enemy','Game_BattlerBase_hide','_graphicHue','setText','iconHeight','_turnOrderContainer','hCDOO','UpdateFrames','bhtgc','svBattlerName','setBattleSystemSTBTurnOrderVisible','uTSsy','reserveCommonEvent','91690arSwNo','_stbExploited','remove','Game_Battler_performActionEnd','svactor','WONXu','BattleManager_makeActionOrders','STB','Game_Action_applyGlobal','canMove','BattleManager_finishActorInput','parse','_stateIDs','sAJDP','right','setSTBNextTurnSpeed','match','RepositionTopHelpY','Game_System_initialize','_subject','BattleManager_processTurn','ixnBe','_fadeDuration','_targetHomeX','ShowMarkerBg','NOcvp','Window_Help_setItem','_logWindow','fontSize','selectNextActorSTB','faceIndex','InitialSpeedJS','_actionBattlers','_letterSprite','isSceneBattle','Exploit','some','opacity','height','critical','prototype','BzXfQ','areAllActorsExploited','allowRandomSpeed','CannotBeExploiter','updateBattleContainerOrder','bitmapWidth','width','processTurn','status','constructor','executeDamageSTB','filter','faceHeight','createActorCommandWindow','OvqsF','EVAL','round','performActionEndSTB','RepositionTopHelpX','eExVV','left','getNextSubject','AllowRandomSpeed','name','isAlive','members','hide','loadEnemy','actions','selectNextCommand','clearSTB','_stbTurnOrderWindow','faceName','calculateTargetPositions','BattleManager_startInput','Game_Battler_makeSpeed','createTurnOrderSTBGraphicFaceIndex','RegExp','applyGlobalBattleSystemSTB','FhUVY','anchor','_handlers','Scene_Battle_commandFight','exbib','battlerHue','center','DisplayPosition','465579hWBvUO','compareBattlerSprites','changeIconGraphicBitmap','HDkhh','containerWindow','CenterHorz','updateTurnOrderSTB','createChildren','ARRAYEVAL','ExploitEleRate','initMembersBattleSystemSTB','parameters','GIFSB','EnableExploit','hnxfb','changeEnemyGraphicBitmap','CustomJS','NUM','Game_Actor_selectNextCommand','performActionEnd','_forceAction','description','_currentActor','push','areAllEnemiesExploited','_containerHeight','stbGainInstant','speed','boxHeight','JNLzq','vsActorsFullExploit','SpriteThin','face','updateTurnOrder','isTpb','Game_Action_clear','2646624XHCWjZ','7512534mHjxZT','blt','getStateIdWithName','_homeDuration','drawText','stbCannotBeExploiter','changeSvActorGraphicBitmap','createBattlerSprites','_homeX','IsmCm','AddedStates','AUMgx','children','onBattleStartSTB','BxUeZ','FUNC','includes','BattleSystemSTB','allBattleMembers','_homeY','MaxHorzSprites','3577791hNGFxM','createLetterSprite','_ogWindowLayerY','_targetHomeY','makeActionOrders','initBattleSystemSTB','DisplayOffsetX','_stbTurnOrderGraphicType','XOnVs','addChild','BattleManager_isActiveTpb','mDpxO','stbExploitedStates','createBorderSprite','_isBattleOver','_stbTurnOrderIconIndex','visible','Actors','hasSvBattler','EnemyBattlerFontFace','80NzuRzB','TurnResetExploits','OrderDirection','indexOf','Mechanics','stbCannotBeExploited','jgBIh','Dcntu','gClXJ','faceWidth','stepForward','updatePadding','utiQS','SubjectDistance','Game_BattlerBase_initMembers','TurnOrderSTBGraphicIconIndex','initHomePositions','stbExploiterStates','appear','clearNextTurnSpeedSTB','sxwwj','_stbExploitAdvantageFlag','isPartyCommandWindowDisabled','Scene_Battle_commandCancel','updateHomePosition','battler','Scene_Battle_createAllWindows','kLitC','ParseStateData','selectAllActions','setItem','Game_Action_speed','BzIwP','top','ForcedActions','RepositionLogWindow','StbTurnOrderActorIcon','exit','loadSvActor','isEnemy','_inputting','Game_Action_executeDamage','startActorInput','%1SystemBg','jPbOj','FlashDuration','AnimationID','_graphicEnemy','setBlendColor','addSTBNextTurnSpeed','EnemyBattlerIcon','EnemyBattlerType','friendsUnit','ueHcB','ARRAYFUNC','executeDamage','subject','Speed','displayExploitedEffects','createBattlerRect','clearRect','battlerName','trim','currentClass','createSTBTurnOrderWindow','isActiveTpb','updatePosition','note','createActorCommandWindowSTB','createAllWindows','repositionLogWindowSTB','_actorCommandWindow','version','addInnerChild','EqSLI','commandFight','clearTurnOrderSTBGraphics','lWcLv','_phase','return\x200','commandCancelSTB','ExtraActions','windowRect','performSTBExploiter','2vNJMIs','BattleCore','_stbTurnOrderVisible','maxBattleMembers','2714565eDpOEX','MfOYy','changeFaceGraphicBitmap','bLNGq','updateVisibility','STRUCT','SpriteLength','pjyuv','setHue','VWdBD','containerPosition','updateOpacity','_partyCommandWindow'];_0xfd4a=function(){return _0x56fdd0;};return _0xfd4a();}VisuMZ[label][_0x28da48(0x361)]=VisuMZ[label]['Settings']||{},VisuMZ[_0x28da48(0x35e)]=function(_0x3f5d3e,_0x2ebf86){const _0x4969dd=_0x28da48;for(const _0x1f9fb1 in _0x2ebf86){if(_0x1f9fb1[_0x4969dd(0x3ce)](/(.*):(.*)/i)){const _0x361917=String(RegExp['$1']),_0x3134b2=String(RegExp['$2'])[_0x4969dd(0x2e7)]()[_0x4969dd(0x2a0)]();let _0x3f4cb6,_0x75e09,_0x3e0ed6;switch(_0x3134b2){case _0x4969dd(0x225):_0x3f4cb6=_0x2ebf86[_0x1f9fb1]!==''?Number(_0x2ebf86[_0x1f9fb1]):0x0;break;case _0x4969dd(0x372):_0x75e09=_0x2ebf86[_0x1f9fb1]!==''?JSON['parse'](_0x2ebf86[_0x1f9fb1]):[],_0x3f4cb6=_0x75e09[_0x4969dd(0x321)](_0xb59ded=>Number(_0xb59ded));break;case _0x4969dd(0x1f4):_0x3f4cb6=_0x2ebf86[_0x1f9fb1]!==''?eval(_0x2ebf86[_0x1f9fb1]):null;break;case _0x4969dd(0x21c):_0x75e09=_0x2ebf86[_0x1f9fb1]!==''?JSON[_0x4969dd(0x3c9)](_0x2ebf86[_0x1f9fb1]):[],_0x3f4cb6=_0x75e09['map'](_0x498427=>eval(_0x498427));break;case _0x4969dd(0x306):_0x3f4cb6=_0x2ebf86[_0x1f9fb1]!==''?JSON[_0x4969dd(0x3c9)](_0x2ebf86[_0x1f9fb1]):'';break;case _0x4969dd(0x324):_0x75e09=_0x2ebf86[_0x1f9fb1]!==''?JSON[_0x4969dd(0x3c9)](_0x2ebf86[_0x1f9fb1]):[],_0x3f4cb6=_0x75e09[_0x4969dd(0x321)](_0x47f572=>JSON[_0x4969dd(0x3c9)](_0x47f572));break;case _0x4969dd(0x248):_0x3f4cb6=_0x2ebf86[_0x1f9fb1]!==''?new Function(JSON[_0x4969dd(0x3c9)](_0x2ebf86[_0x1f9fb1])):new Function(_0x4969dd(0x2b1));break;case _0x4969dd(0x298):_0x75e09=_0x2ebf86[_0x1f9fb1]!==''?JSON[_0x4969dd(0x3c9)](_0x2ebf86[_0x1f9fb1]):[],_0x3f4cb6=_0x75e09[_0x4969dd(0x321)](_0x240eca=>new Function(JSON[_0x4969dd(0x3c9)](_0x240eca)));break;case _0x4969dd(0x389):_0x3f4cb6=_0x2ebf86[_0x1f9fb1]!==''?String(_0x2ebf86[_0x1f9fb1]):'';break;case'ARRAYSTR':_0x75e09=_0x2ebf86[_0x1f9fb1]!==''?JSON[_0x4969dd(0x3c9)](_0x2ebf86[_0x1f9fb1]):[],_0x3f4cb6=_0x75e09[_0x4969dd(0x321)](_0x2dcc45=>String(_0x2dcc45));break;case _0x4969dd(0x2bf):_0x3e0ed6=_0x2ebf86[_0x1f9fb1]!==''?JSON[_0x4969dd(0x3c9)](_0x2ebf86[_0x1f9fb1]):{},_0x3f4cb6=VisuMZ['ConvertParams']({},_0x3e0ed6);break;case'ARRAYSTRUCT':_0x75e09=_0x2ebf86[_0x1f9fb1]!==''?JSON[_0x4969dd(0x3c9)](_0x2ebf86[_0x1f9fb1]):[],_0x3f4cb6=_0x75e09[_0x4969dd(0x321)](_0x3eb095=>VisuMZ[_0x4969dd(0x35e)]({},JSON['parse'](_0x3eb095)));break;default:continue;}_0x3f5d3e[_0x361917]=_0x3f4cb6;}}return _0x3f5d3e;},(_0x3e2734=>{const _0x18f083=_0x28da48,_0x4c1688=_0x3e2734['name'];for(const _0x5993ab of dependencies){if(!Imported[_0x5993ab]){alert(_0x18f083(0x367)[_0x18f083(0x332)](_0x4c1688,_0x5993ab)),SceneManager[_0x18f083(0x287)]();break;}}const _0x3f4b42=_0x3e2734[_0x18f083(0x229)];if(_0x3f4b42['match'](/\[Version[ ](.*?)\]/i)){const _0x5313c2=Number(RegExp['$1']);_0x5313c2!==VisuMZ[label][_0x18f083(0x2aa)]&&(alert(_0x18f083(0x32b)[_0x18f083(0x332)](_0x4c1688,_0x5313c2)),SceneManager['exit']());}if(_0x3f4b42['match'](/\[Tier[ ](\d+)\]/i)){if(_0x18f083(0x2e3)===_0x18f083(0x2e3)){const _0x2876d1=Number(RegExp['$1']);_0x2876d1<tier?(alert('%1\x20is\x20incorrectly\x20placed\x20on\x20the\x20plugin\x20list.\x0aIt\x20is\x20a\x20Tier\x20%2\x20plugin\x20placed\x20over\x20other\x20Tier\x20%3\x20plugins.\x0aPlease\x20reorder\x20the\x20plugin\x20list\x20from\x20smallest\x20to\x20largest\x20tier\x20numbers.'[_0x18f083(0x332)](_0x4c1688,_0x2876d1,tier)),SceneManager[_0x18f083(0x287)]()):'IsmCm'===_0x18f083(0x242)?tier=Math['max'](_0x2876d1,tier):this[_0x18f083(0x31b)]()?_0x55dcd7[_0x18f083(0x24a)][_0x18f083(0x3d2)][_0x18f083(0x32e)](this):_0x1140ae[_0x18f083(0x24a)][_0x18f083(0x3c8)][_0x18f083(0x32e)](this);}else{const _0x313c48=this[_0x18f083(0x3a3)]()[_0x18f083(0x2a5)];if(_0x313c48[_0x18f083(0x3ce)](/<STB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return _0x164191(_0x5d6532['$2']);return this[_0x18f083(0x3dc)]();}}VisuMZ['ConvertParams'](VisuMZ[label][_0x18f083(0x361)],_0x3e2734[_0x18f083(0x21f)]);})(pluginData),PluginManager[_0x28da48(0x2d1)](pluginData['name'],_0x28da48(0x286),_0x24a181=>{const _0x2b9d91=_0x28da48;VisuMZ[_0x2b9d91(0x35e)](_0x24a181,_0x24a181);const _0x54f0fa=_0x24a181[_0x2b9d91(0x25f)],_0x183fd7=_0x24a181[_0x2b9d91(0x365)];for(const _0x253493 of _0x54f0fa){if(_0x2b9d91(0x28e)!==_0x2b9d91(0x28e))_0x5cff21[_0x2b9d91(0x224)][_0x2b9d91(0x32e)](this,_0x2f0bf8,_0x591a87);else{const _0x23b93f=$gameActors[_0x2b9d91(0x3a3)](_0x253493);if(!_0x23b93f)continue;_0x23b93f[_0x2b9d91(0x255)]='icon',_0x23b93f[_0x2b9d91(0x25d)]=_0x183fd7;}}}),PluginManager[_0x28da48(0x2d1)](pluginData[_0x28da48(0x1fc)],'StbTurnOrderActorFace',_0x54855a=>{const _0x192107=_0x28da48;VisuMZ[_0x192107(0x35e)](_0x54855a,_0x54855a);const _0x4e418e=_0x54855a[_0x192107(0x25f)],_0x4839a1=_0x54855a['FaceName'],_0x5b34f0=_0x54855a[_0x192107(0x360)];for(const _0x513bdb of _0x4e418e){if('XtEmc'!=='XtEmc'){const _0xf512f7=_0x4eb4c2[_0x192107(0x39c)];if(_0xf512f7[_0x192107(0x3a8)]>0x0&&_0xf512f7[0x0]!==this)return;const _0x5b200f=this[_0x192107(0x27b)]();if(_0x5b200f)_0x5b200f[_0x192107(0x26c)]();}else{const _0x43cbc7=$gameActors[_0x192107(0x3a3)](_0x513bdb);if(!_0x43cbc7)continue;_0x43cbc7['_stbTurnOrderGraphicType']='face',_0x43cbc7[_0x192107(0x2d8)]=_0x4839a1,_0x43cbc7[_0x192107(0x309)]=_0x5b34f0;}}}),PluginManager['registerCommand'](pluginData[_0x28da48(0x1fc)],_0x28da48(0x373),_0xb29251=>{const _0x4fbcf7=_0x28da48;VisuMZ[_0x4fbcf7(0x35e)](_0xb29251,_0xb29251);const _0x125a17=_0xb29251[_0x4fbcf7(0x25f)];for(const _0x28e6be of _0x125a17){const _0x5bf386=$gameActors[_0x4fbcf7(0x3a3)](_0x28e6be);if(!_0x5bf386)continue;_0x5bf386[_0x4fbcf7(0x2ae)]();}}),PluginManager['registerCommand'](pluginData[_0x28da48(0x1fc)],_0x28da48(0x326),_0x25f8ce=>{const _0x39ceac=_0x28da48;VisuMZ[_0x39ceac(0x35e)](_0x25f8ce,_0x25f8ce);const _0x212396=_0x25f8ce['Enemies'],_0x50fbc7=_0x25f8ce[_0x39ceac(0x365)];for(const _0xc1e706 of _0x212396){if(_0x39ceac(0x390)==='QVlTB'){const _0x433afc=$gameTroop[_0x39ceac(0x1fe)]()[_0xc1e706];if(!_0x433afc)continue;_0x433afc[_0x39ceac(0x255)]=_0x39ceac(0x2ee),_0x433afc['_stbTurnOrderIconIndex']=_0x50fbc7;}else _0x15361f=!![];}}),PluginManager[_0x28da48(0x2d1)](pluginData[_0x28da48(0x1fc)],_0x28da48(0x398),_0x58bc59=>{const _0xa4f08c=_0x28da48;VisuMZ[_0xa4f08c(0x35e)](_0x58bc59,_0x58bc59);const _0x419146=_0x58bc59[_0xa4f08c(0x342)],_0x10c177=_0x58bc59['FaceName'],_0x5d2797=_0x58bc59['FaceIndex'];for(const _0x3f8cbb of _0x419146){if(_0xa4f08c(0x2c3)===_0xa4f08c(0x2c3)){const _0x1f0722=$gameTroop[_0xa4f08c(0x1fe)]()[_0x3f8cbb];if(!_0x1f0722)continue;_0x1f0722[_0xa4f08c(0x255)]=_0xa4f08c(0x234),_0x1f0722[_0xa4f08c(0x2d8)]=_0x10c177,_0x1f0722[_0xa4f08c(0x309)]=_0x5d2797;}else return 0x0;}}),PluginManager[_0x28da48(0x2d1)](pluginData[_0x28da48(0x1fc)],_0x28da48(0x37a),_0xff5c91=>{const _0x283047=_0x28da48;VisuMZ['ConvertParams'](_0xff5c91,_0xff5c91);const _0x1a5e05=_0xff5c91[_0x283047(0x342)];for(const _0x2e9554 of _0x1a5e05){const _0x8c86a9=$gameTroop['members']()[_0x2e9554];if(!_0x8c86a9)continue;_0x8c86a9['clearTurnOrderSTBGraphics']();}}),PluginManager['registerCommand'](pluginData[_0x28da48(0x1fc)],'SystemTurnOrderVisibility',_0x2a0a5c=>{const _0x1c2b3d=_0x28da48;VisuMZ['ConvertParams'](_0x2a0a5c,_0x2a0a5c);const _0x46ad2a=_0x2a0a5c[_0x1c2b3d(0x328)];$gameSystem[_0x1c2b3d(0x3bb)](_0x46ad2a);}),VisuMZ[_0x28da48(0x24a)]['RegExp']={'Instant':/<STB (?:INSTANT|INSTANT CAST|Instant Use)>/i,'CannotBeExploited':/<STB CANNOT BE EXPLOITED>/i,'CannotBeExploiter':/<STB CANNOT BE EXPLOITER>/i,'ExploitedStates':/<STB EXPLOITED GAIN (?:STATE|STATES):[ ](.*)>/i,'ExploiterStates':/<STB EXPLOITER GAIN (?:STATE|STATES):[ ](.*)>/i},DataManager[_0x28da48(0x23b)]=function(_0x5bb9af){const _0x564cd5=_0x28da48;_0x5bb9af=_0x5bb9af['toUpperCase']()[_0x564cd5(0x2a0)](),this[_0x564cd5(0x3ca)]=this[_0x564cd5(0x3ca)]||{};if(this[_0x564cd5(0x3ca)][_0x5bb9af])return this[_0x564cd5(0x3ca)][_0x5bb9af];for(const _0x4ab643 of $dataStates){if(!_0x4ab643)continue;this['_stateIDs'][_0x4ab643[_0x564cd5(0x1fc)][_0x564cd5(0x2e7)]()['trim']()]=_0x4ab643['id'];}return this[_0x564cd5(0x3ca)][_0x5bb9af]||0x0;},ImageManager['svActorHorzCells']=ImageManager[_0x28da48(0x35a)]||0x9,ImageManager[_0x28da48(0x349)]=ImageManager[_0x28da48(0x349)]||0x6,SceneManager[_0x28da48(0x3e0)]=function(){const _0x31bc0e=_0x28da48;return this[_0x31bc0e(0x313)]&&this['_scene'][_0x31bc0e(0x3f0)]===Scene_Battle;},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x30c)]=BattleManager[_0x28da48(0x2d0)],BattleManager[_0x28da48(0x2d0)]=function(){const _0x729585=_0x28da48;if(this[_0x729585(0x31b)]())return _0x729585(0x3c5);return VisuMZ[_0x729585(0x24a)][_0x729585(0x30c)][_0x729585(0x32e)](this);},BattleManager[_0x28da48(0x31b)]=function(){const _0x5457eb=_0x28da48;return $gameSystem[_0x5457eb(0x2fb)]()===_0x5457eb(0x3c5);},VisuMZ[_0x28da48(0x24a)]['BattleManager_isTpb']=BattleManager[_0x28da48(0x236)],BattleManager['isTpb']=function(){const _0x145dbe=_0x28da48;if(this[_0x145dbe(0x31b)]())return![];return VisuMZ[_0x145dbe(0x24a)][_0x145dbe(0x31d)][_0x145dbe(0x32e)](this);},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x258)]=BattleManager[_0x28da48(0x2a3)],BattleManager[_0x28da48(0x2a3)]=function(){const _0x59bbef=_0x28da48;if(this[_0x59bbef(0x31b)]())return![];return VisuMZ[_0x59bbef(0x24a)]['BattleManager_isActiveTpb'][_0x59bbef(0x32e)](this);},VisuMZ['BattleSystemSTB'][_0x28da48(0x318)]=BattleManager['isTurnBased'],BattleManager[_0x28da48(0x2f8)]=function(){const _0x2d569d=_0x28da48;if(this[_0x2d569d(0x31b)]())return!![];return VisuMZ['BattleSystemSTB']['BattleManager_isTurnBased']['call'](this);},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x207)]=BattleManager['startInput'],BattleManager[_0x28da48(0x388)]=function(){const _0x443095=_0x28da48;VisuMZ['BattleSystemSTB'][_0x443095(0x207)]['call'](this);if(this[_0x443095(0x31b)]()&&$gameParty[_0x443095(0x2e5)]()&&!this['_surprise'])this[_0x443095(0x376)]();},BattleManager[_0x28da48(0x376)]=function(){const _0x3f3f2c=_0x28da48;this[_0x3f3f2c(0x345)]();},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x3d2)]=BattleManager['processTurn'],BattleManager[_0x28da48(0x3ee)]=function(){const _0x509811=_0x28da48;this[_0x509811(0x31b)]()?this[_0x509811(0x33e)]():VisuMZ[_0x509811(0x24a)][_0x509811(0x3d2)][_0x509811(0x32e)](this);},BattleManager[_0x28da48(0x33e)]=function(){const _0x235a53=_0x28da48,_0x310545=this['_subject'];if(_0x310545[_0x235a53(0x317)]()&&_0x310545[_0x235a53(0x2e5)]()){if(_0x235a53(0x27d)!==_0x235a53(0x26e)){const _0x1c95f3=_0x310545[_0x235a53(0x346)]();if(!_0x1c95f3)_0x235a53(0x397)==='VDHkF'?VisuMZ[_0x235a53(0x24a)][_0x235a53(0x3d2)]['call'](this):this[_0x235a53(0x21e)]();else{if(_0x1c95f3[_0x235a53(0x228)]){if(_0x235a53(0x3b7)!==_0x235a53(0x244))VisuMZ['BattleSystemSTB'][_0x235a53(0x3d2)][_0x235a53(0x32e)](this);else return this['_stbExploited']===_0x44da58&&this['initMembersBattleSystemSTB'](),this[_0x235a53(0x3bf)];}else this[_0x235a53(0x22a)]=_0x310545,this[_0x235a53(0x28c)]();}}else _0x27340c=_0x235a53(0x3b1);}else{if('lKBis'!==_0x235a53(0x276))VisuMZ['BattleSystemSTB'][_0x235a53(0x3d2)][_0x235a53(0x32e)](this);else return _0x54f10d(_0x3f6c08['$1']);}},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x3c8)]=BattleManager[_0x28da48(0x3a1)],BattleManager['finishActorInput']=function(){const _0x2eb0c6=_0x28da48;if(this['isSTB']()){if(_0x2eb0c6(0x3a7)!==_0x2eb0c6(0x2fe))VisuMZ[_0x2eb0c6(0x24a)][_0x2eb0c6(0x3d2)][_0x2eb0c6(0x32e)](this);else{const _0x18eb52=this[_0x2eb0c6(0x27b)]();if(!_0x18eb52)return this['defaultPosition']();if(_0x18eb52===_0x3e4141[_0x2eb0c6(0x3d1)])return 0x0;if(_0xab507f[_0x2eb0c6(0x3de)][_0x2eb0c6(0x249)](_0x18eb52)){const _0x42c90e=_0x388537[_0x2eb0c6(0x3de)][_0x2eb0c6(0x265)](_0x18eb52)+0x1;return _0x42c90e;}return this[_0x2eb0c6(0x305)]();}}else VisuMZ[_0x2eb0c6(0x24a)][_0x2eb0c6(0x3c8)][_0x2eb0c6(0x32e)](this);},VisuMZ['BattleSystemSTB']['BattleManager_selectNextActor']=BattleManager['selectNextActor'],BattleManager[_0x28da48(0x37f)]=function(){const _0x3a5253=_0x28da48;if(this[_0x3a5253(0x31b)]()){if(_0x3a5253(0x333)===_0x3a5253(0x374)){_0x2779ff=(_0x265cf0(_0x5a90ac)||'')['trim']();const _0x585d39=/^\d+$/['test'](_0x47ec3a);_0x585d39?_0x113c12[_0x3a5253(0x22b)](_0x23a905(_0x2a16eb)):_0x15a629[_0x3a5253(0x22b)](_0x2d06a7[_0x3a5253(0x23b)](_0x5ef1a8));}else this[_0x3a5253(0x3db)]();}else _0x3a5253(0x1f3)!==_0x3a5253(0x362)?VisuMZ['BattleSystemSTB'][_0x3a5253(0x347)][_0x3a5253(0x32e)](this):(this[_0x3a5253(0x29a)]()[_0x3a5253(0x2b5)](_0x4b2da2,this),_0x172977[_0x3a5253(0x37d)](this[_0x3a5253(0x29a)](),this));},BattleManager['selectNextActorSTB']=function(){const _0x2d67a0=_0x28da48;this[_0x2d67a0(0x22a)]=null,this[_0x2d67a0(0x28a)]=![];},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x368)]=BattleManager[_0x28da48(0x2cb)],BattleManager[_0x28da48(0x2cb)]=function(){const _0x3b36af=_0x28da48;VisuMZ[_0x3b36af(0x24a)][_0x3b36af(0x368)][_0x3b36af(0x32e)](this),this[_0x3b36af(0x2d5)]();},BattleManager[_0x28da48(0x2d5)]=function(){const _0x579d0b=_0x28da48;if(!this['isSTB']())return;this[_0x579d0b(0x2c7)]();this['_forcedBattlers'][_0x579d0b(0x3a8)]>0x0&&(this[_0x579d0b(0x3d1)]&&(!this[_0x579d0b(0x3de)][_0x579d0b(0x249)](this[_0x579d0b(0x3d1)])&&this[_0x579d0b(0x3de)][_0x579d0b(0x2d3)](this[_0x579d0b(0x3d1)])),this['_subject']=this[_0x579d0b(0x1fa)]());;},BattleManager[_0x28da48(0x3a5)]=function(){const _0x4ab56d=_0x28da48;return VisuMZ[_0x4ab56d(0x24a)][_0x4ab56d(0x361)]['Exploit']['EnableExploit'];},BattleManager[_0x28da48(0x3e8)]=function(){const _0xcc4b1d=_0x28da48,_0x4f4ded=$gameParty['aliveMembers']()[_0xcc4b1d(0x3f2)](_0x131f6f=>_0x131f6f['isAppeared']()),_0x2e5699=_0x4f4ded[_0xcc4b1d(0x3f2)](_0x13970a=>_0x13970a[_0xcc4b1d(0x30d)]());return _0x4f4ded[_0xcc4b1d(0x3a8)]===_0x2e5699[_0xcc4b1d(0x3a8)];},BattleManager[_0x28da48(0x22c)]=function(){const _0x4acc1f=_0x28da48,_0x39ef83=$gameTroop[_0x4acc1f(0x358)]()[_0x4acc1f(0x3f2)](_0x1c6841=>_0x1c6841[_0x4acc1f(0x34b)]()),_0x5f1be6=_0x39ef83['filter'](_0x181432=>_0x181432[_0x4acc1f(0x30d)]());return _0x39ef83[_0x4acc1f(0x3a8)]===_0x5f1be6[_0x4acc1f(0x3a8)];},VisuMZ[_0x28da48(0x24a)]['BattleManager_makeActionOrders']=BattleManager['makeActionOrders'],BattleManager[_0x28da48(0x252)]=function(){const _0x1a3eec=_0x28da48;VisuMZ[_0x1a3eec(0x24a)][_0x1a3eec(0x3c4)][_0x1a3eec(0x32e)](this);if(this[_0x1a3eec(0x31b)]()){if('kcyZP'===_0x1a3eec(0x3aa))this[_0x1a3eec(0x2c7)](),this['updateTurnOrderSTB'](),this[_0x1a3eec(0x275)]();else{const _0x9c9176=this['actor']()[_0x1a3eec(0x2a5)];if(_0x9c9176['match'](/<STB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return _0x5baba7(_0x121780['$1']);return this[_0x1a3eec(0x205)]();}}},BattleManager['removeActionBattlersSTB']=function(){const _0x3c717b=_0x28da48;if(!this[_0x3c717b(0x31b)]())return;this[_0x3c717b(0x3de)]=this[_0x3c717b(0x3de)]||[],this[_0x3c717b(0x3de)]=this[_0x3c717b(0x3de)][_0x3c717b(0x3f2)](_0x4d375a=>_0x4d375a&&_0x4d375a[_0x3c717b(0x34b)]()&&_0x4d375a['isAlive']()),this[_0x3c717b(0x21a)]();},BattleManager[_0x28da48(0x21a)]=function(_0x5c9942){const _0x396d3=_0x28da48;if(!this['isSTB']())return;const _0x1e1cd2=SceneManager[_0x396d3(0x313)][_0x396d3(0x204)];if(!_0x1e1cd2)return;_0x1e1cd2[_0x396d3(0x235)](_0x5c9942);},BattleManager[_0x28da48(0x275)]=function(){const _0x20cfec=_0x28da48;for(const _0x387a6e of this[_0x20cfec(0x24b)]()){if(!_0x387a6e)continue;_0x387a6e[_0x20cfec(0x3cd)](0x0);}},VisuMZ['BattleSystemSTB'][_0x28da48(0x3d0)]=Game_System[_0x28da48(0x3e6)][_0x28da48(0x352)],Game_System['prototype']['initialize']=function(){const _0xe05fe5=_0x28da48;VisuMZ[_0xe05fe5(0x24a)][_0xe05fe5(0x3d0)][_0xe05fe5(0x32e)](this),this[_0xe05fe5(0x253)]();},Game_System[_0x28da48(0x3e6)][_0x28da48(0x253)]=function(){this['_stbTurnOrderVisible']=!![];},Game_System[_0x28da48(0x3e6)][_0x28da48(0x2f3)]=function(){const _0x1a65fe=_0x28da48;return this[_0x1a65fe(0x2b8)]===undefined&&this['initBattleSystemSTB'](),this[_0x1a65fe(0x2b8)];},Game_System[_0x28da48(0x3e6)][_0x28da48(0x3bb)]=function(_0x45936f){const _0x301668=_0x28da48;if(this[_0x301668(0x2b8)]===undefined){if(_0x301668(0x30b)===_0x301668(0x30b))this[_0x301668(0x253)]();else{const _0x54318c=new _0x38b9ef(_0x15b6e5,_0x5f038d);this[_0x301668(0x2e9)][_0x301668(0x257)](_0x54318c),this[_0x301668(0x3b6)][_0x301668(0x22b)](_0x54318c);}}this['_stbTurnOrderVisible']=_0x45936f;},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x281)]=Game_Action[_0x28da48(0x3e6)][_0x28da48(0x22f)],Game_Action['prototype'][_0x28da48(0x22f)]=function(){const _0x5a47c4=_0x28da48;if(BattleManager[_0x5a47c4(0x31b)]())return 0x0;else{if(_0x5a47c4(0x2af)!==_0x5a47c4(0x3ab))return VisuMZ['BattleSystemSTB'][_0x5a47c4(0x281)]['call'](this);else this[_0x5a47c4(0x395)]+=_0x1b5c6f?_0x44dde1:0x0,this['_positionTargetY']+=_0x2ce8ed?0x0:_0x4a6d79;}},VisuMZ['BattleSystemSTB'][_0x28da48(0x3c6)]=Game_Action['prototype'][_0x28da48(0x383)],Game_Action[_0x28da48(0x3e6)][_0x28da48(0x383)]=function(){const _0x81acc7=_0x28da48;VisuMZ[_0x81acc7(0x24a)]['Game_Action_applyGlobal'][_0x81acc7(0x32e)](this),this['applyGlobalBattleSystemSTB']();},Game_Action['prototype'][_0x28da48(0x20b)]=function(){const _0x3b4030=_0x28da48;if(!SceneManager[_0x3b4030(0x3e0)]())return;if(!BattleManager['isSTB']())return;const _0x1bb4ab=this['item'](),_0x4e5640=VisuMZ[_0x3b4030(0x24a)][_0x3b4030(0x20a)],_0x4835fd=VisuMZ[_0x3b4030(0x24a)]['Settings'][_0x3b4030(0x29b)];_0x1bb4ab&&_0x1bb4ab['note'][_0x3b4030(0x3ce)](_0x4e5640[_0x3b4030(0x30f)])&&this[_0x3b4030(0x29a)]()[_0x3b4030(0x22e)](0x1);const _0x18307f=_0x4835fd[_0x3b4030(0x37b)][_0x3b4030(0x32e)](this);this[_0x3b4030(0x29a)]()['addSTBNextTurnSpeed'](_0x18307f);},VisuMZ['BattleSystemSTB'][_0x28da48(0x237)]=Game_Action[_0x28da48(0x3e6)][_0x28da48(0x364)],Game_Action[_0x28da48(0x3e6)][_0x28da48(0x364)]=function(){const _0x46a9d4=_0x28da48;VisuMZ[_0x46a9d4(0x24a)][_0x46a9d4(0x237)][_0x46a9d4(0x32e)](this),this[_0x46a9d4(0x203)]();},Game_Action[_0x28da48(0x3e6)][_0x28da48(0x203)]=function(){const _0x5b3e5a=_0x28da48;this[_0x5b3e5a(0x277)]=![];},Game_Action[_0x28da48(0x3e6)][_0x28da48(0x33f)]=function(){const _0x430ee0=_0x28da48;if(this[_0x430ee0(0x277)]===undefined){if('mcbEg'!==_0x430ee0(0x2ea))this[_0x430ee0(0x203)]();else{if(!_0x5651b7['isSTB']())return;this[_0x430ee0(0x204)]=new _0x157ceb();const _0x15c050=this[_0x430ee0(0x35d)](this[_0x430ee0(0x393)]);this[_0x430ee0(0x311)](this[_0x430ee0(0x204)],_0x15c050),this[_0x430ee0(0x2a8)](),_0xdd663b[_0x430ee0(0x21a)](!![]);}}return this[_0x430ee0(0x277)];},Game_Action['prototype'][_0x28da48(0x2f6)]=function(_0x4e8d68){const _0x35ccac=_0x28da48;this[_0x35ccac(0x277)]===undefined&&(_0x35ccac(0x385)!==_0x35ccac(0x385)?this['performActionEndSTB']():this[_0x35ccac(0x203)]()),this[_0x35ccac(0x277)]=_0x4e8d68;},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x28b)]=Game_Action[_0x28da48(0x3e6)][_0x28da48(0x299)],Game_Action['prototype'][_0x28da48(0x299)]=function(_0xcfd55a,_0x368a41){const _0x4abed1=_0x28da48;VisuMZ[_0x4abed1(0x24a)][_0x4abed1(0x28b)][_0x4abed1(0x32e)](this,_0xcfd55a,_0x368a41),this[_0x4abed1(0x3f1)](_0xcfd55a);},Game_Action[_0x28da48(0x3e6)][_0x28da48(0x3f1)]=function(_0x2615f6){const _0x59ea65=_0x28da48;if(!SceneManager[_0x59ea65(0x3e0)]())return;if(!BattleManager[_0x59ea65(0x31b)]())return;if(!BattleManager['isSTBExploitSystemEnabled']())return;if(_0x2615f6[_0x59ea65(0x296)]()===this[_0x59ea65(0x29a)]()[_0x59ea65(0x296)]())return;const _0x200963=VisuMZ['BattleSystemSTB']['Settings'][_0x59ea65(0x3e1)],_0xdee589=_0x2615f6[_0x59ea65(0x2d7)]();if(!_0x200963[_0x59ea65(0x284)]&&this['_forcing'])return;_0x200963[_0x59ea65(0x34e)]&&_0xdee589[_0x59ea65(0x3e5)]&&(this[_0x59ea65(0x29a)]()['performSTBExploiter'](_0x2615f6,this),_0x2615f6[_0x59ea65(0x37d)](this[_0x59ea65(0x29a)](),this));if(_0x200963[_0x59ea65(0x2cf)]){const _0x26b0da=this['calcElementRate'](_0x2615f6);_0x26b0da>=_0x200963[_0x59ea65(0x21d)]&&(this[_0x59ea65(0x29a)]()[_0x59ea65(0x2b5)](_0x2615f6,this),_0x2615f6['becomeSTBExploited'](this['subject'](),this));}},VisuMZ[_0x28da48(0x24a)]['Game_BattlerBase_initMembers']=Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x2ec)],Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x2ec)]=function(){const _0xfb1beb=_0x28da48;VisuMZ[_0xfb1beb(0x24a)][_0xfb1beb(0x270)][_0xfb1beb(0x32e)](this),this['initMembersBattleSystemSTB']();},Game_BattlerBase[_0x28da48(0x3e6)]['initMembersBattleSystemSTB']=function(){this['clearSTBNextTurnSpeed'](),this['clearSTBExploit']();},Game_BattlerBase[_0x28da48(0x3e6)]['clearSTBNextTurnSpeed']=function(){const _0x145a13=_0x28da48;this[_0x145a13(0x322)]=0x0;},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x2f1)]=function(){const _0x4a0f94=_0x28da48;return this[_0x4a0f94(0x322)]===undefined&&this[_0x4a0f94(0x21e)](),this[_0x4a0f94(0x322)];},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x3cd)]=function(_0x4eb26f){const _0x120da8=_0x28da48;this[_0x120da8(0x322)]===undefined&&(_0x120da8(0x3c3)!==_0x120da8(0x3c3)?(this[_0x120da8(0x22a)]=null,this[_0x120da8(0x28a)]=![]):this[_0x120da8(0x21e)]()),this[_0x120da8(0x322)]=_0x4eb26f;},Game_BattlerBase['prototype'][_0x28da48(0x293)]=function(_0x679425){const _0x4b395e=_0x28da48;if(this['_stbNextTurnSpeed']===undefined){if(_0x4b395e(0x334)!==_0x4b395e(0x269))this['initMembersBattleSystemSTB']();else{const _0x4a562d=this['_graphicFaceIndex'],_0x4e17eb=this[_0x4b395e(0x3ec)](),_0x40ace0=this[_0x4b395e(0x316)](),_0x1bb86b=_0x768324[_0x4b395e(0x2c9)](_0x4e17eb,_0x40ace0);this[_0x4b395e(0x2cd)]['bitmap']=new _0x5923b0(_0x4e17eb,_0x40ace0);const _0x364e6b=this['_graphicSprite'][_0x4b395e(0x303)],_0x53d8f6=_0xe3b9cd[_0x4b395e(0x26b)],_0x377e25=_0x547014['faceHeight'],_0x1c829e=_0x1bb86b/_0x30bab6[_0x4b395e(0x2c9)](_0x53d8f6,_0x377e25),_0x44c378=_0x4f87f1[_0x4b395e(0x26b)],_0x4fbc70=_0x140551[_0x4b395e(0x1f1)],_0x173f3f=_0x4a562d%0x4*_0x53d8f6+(_0x53d8f6-_0x44c378)/0x2,_0x58e5fe=_0x585ddd[_0x4b395e(0x391)](_0x4a562d/0x4)*_0x377e25+(_0x377e25-_0x4fbc70)/0x2,_0x2cdee8=(_0x4e17eb-_0x53d8f6*_0x1c829e)/0x2,_0x44d041=(_0x40ace0-_0x377e25*_0x1c829e)/0x2;_0x364e6b[_0x4b395e(0x23a)](_0x17b7df,_0x173f3f,_0x58e5fe,_0x44c378,_0x4fbc70,_0x2cdee8,_0x44d041,_0x1bb86b,_0x1bb86b);}}_0x679425+=this['getSTBNextTurnSpeed'](),this[_0x4b395e(0x3cd)](_0x679425);},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x356)]=function(){const _0x254563=_0x28da48;this[_0x254563(0x3bf)]=![];},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x30d)]=function(){const _0x5c0505=_0x28da48;return this['_stbExploited']===undefined&&this[_0x5c0505(0x21e)](),this['_stbExploited'];},Game_BattlerBase[_0x28da48(0x3e6)]['setSTBExploited']=function(_0xa789c8){const _0x4efed0=_0x28da48;this[_0x4efed0(0x3bf)]===undefined&&this[_0x4efed0(0x21e)](),this['_stbExploited']=_0xa789c8;},Game_BattlerBase[_0x28da48(0x3e6)]['stbCannotBeExploited']=function(){const _0x59a4e3=_0x28da48,_0x50210c=VisuMZ[_0x59a4e3(0x24a)][_0x59a4e3(0x20a)][_0x59a4e3(0x37e)];return this['traitObjects']()[_0x59a4e3(0x3e2)](_0x4d70dd=>_0x4d70dd[_0x59a4e3(0x2a5)][_0x59a4e3(0x3ce)](_0x50210c));},Game_BattlerBase['prototype'][_0x28da48(0x23e)]=function(){const _0x2e869a=_0x28da48,_0x28264d=VisuMZ[_0x2e869a(0x24a)]['RegExp'][_0x2e869a(0x3ea)];return this[_0x2e869a(0x330)]()[_0x2e869a(0x3e2)](_0x576ec4=>_0x576ec4[_0x2e869a(0x2a5)][_0x2e869a(0x3ce)](_0x28264d));},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x2ae)]=function(){const _0x6ffa25=_0x28da48;delete this[_0x6ffa25(0x255)],delete this[_0x6ffa25(0x2d8)],delete this[_0x6ffa25(0x309)],delete this[_0x6ffa25(0x25d)];},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x34a)]=function(){const _0x55d4d3=_0x28da48;return this[_0x55d4d3(0x255)]===undefined&&(this['_stbTurnOrderGraphicType']=this[_0x55d4d3(0x379)]()),this[_0x55d4d3(0x255)];},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x379)]=function(){const _0x5b7457=_0x28da48;return Window_STB_TurnOrder[_0x5b7457(0x361)]['EnemyBattlerType'];},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x387)]=function(){const _0x2c906d=_0x28da48;return this[_0x2c906d(0x2d8)]===undefined&&(_0x2c906d(0x39f)!==_0x2c906d(0x2bd)?this[_0x2c906d(0x2d8)]=this[_0x2c906d(0x32c)]():_0x15f900[_0x2c906d(0x24a)][_0x2c906d(0x20f)][_0x2c906d(0x32e)](this)),this[_0x2c906d(0x2d8)];},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x32c)]=function(){return Window_STB_TurnOrder['Settings']['EnemyBattlerFaceName'];},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x319)]=function(){const _0x2c6cb9=_0x28da48;return this['_stbTurnOrderFaceIndex']===undefined&&(this['_stbTurnOrderFaceIndex']=this['createTurnOrderSTBGraphicFaceIndex']()),this[_0x2c6cb9(0x309)];},Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x209)]=function(){const _0x124d6d=_0x28da48;return Window_STB_TurnOrder[_0x124d6d(0x361)][_0x124d6d(0x2dc)];},Game_BattlerBase['prototype'][_0x28da48(0x271)]=function(){const _0x537f0d=_0x28da48;return this[_0x537f0d(0x25d)]===undefined&&(this[_0x537f0d(0x25d)]=this[_0x537f0d(0x33a)]()),this[_0x537f0d(0x25d)];},Game_BattlerBase['prototype'][_0x28da48(0x33a)]=function(){const _0x1e8656=_0x28da48;return Window_STB_TurnOrder[_0x1e8656(0x361)][_0x1e8656(0x294)];},Game_BattlerBase[_0x28da48(0x3e6)]['setSTBGraphicIconIndex']=function(_0x10e6cd){this['_stbTurnOrderIconIndex']=_0x10e6cd;},VisuMZ['BattleSystemSTB'][_0x28da48(0x3b2)]=Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x1ff)],Game_BattlerBase['prototype'][_0x28da48(0x1ff)]=function(){const _0x183350=_0x28da48;VisuMZ[_0x183350(0x24a)]['Game_BattlerBase_hide'][_0x183350(0x32e)](this),BattleManager['removeActionBattlersSTB']();},VisuMZ['BattleSystemSTB'][_0x28da48(0x335)]=Game_BattlerBase[_0x28da48(0x3e6)]['appear'],Game_BattlerBase[_0x28da48(0x3e6)][_0x28da48(0x274)]=function(){const _0x253ac7=_0x28da48;VisuMZ[_0x253ac7(0x24a)]['Game_BattlerBase_appear']['call'](this),BattleManager['removeActionBattlersSTB']();},VisuMZ['BattleSystemSTB'][_0x28da48(0x2de)]=Game_Battler[_0x28da48(0x3e6)]['performCollapse'],Game_Battler[_0x28da48(0x3e6)][_0x28da48(0x377)]=function(){const _0x4df16f=_0x28da48;VisuMZ['BattleSystemSTB'][_0x4df16f(0x2de)][_0x4df16f(0x32e)](this),BattleManager[_0x4df16f(0x2c7)]();},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x32d)]=Game_Battler[_0x28da48(0x3e6)]['onBattleStart'],Game_Battler[_0x28da48(0x3e6)][_0x28da48(0x2df)]=function(_0x25f145){const _0x2b2c22=_0x28da48;VisuMZ[_0x2b2c22(0x24a)][_0x2b2c22(0x32d)]['call'](this,_0x25f145),this[_0x2b2c22(0x246)](_0x25f145);},Game_Battler[_0x28da48(0x3e6)]['onBattleStartSTB']=function(_0x203e0f){const _0x4dc836=_0x28da48;if(!BattleManager[_0x4dc836(0x31b)]())return;this[_0x4dc836(0x356)]();const _0x306f53=new Game_Action(this);this[_0x4dc836(0x3cd)](0x0);},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x2fd)]=Game_Battler['prototype'][_0x28da48(0x2da)],Game_Battler[_0x28da48(0x3e6)][_0x28da48(0x2da)]=function(){const _0x3e20b=_0x28da48;VisuMZ['BattleSystemSTB'][_0x3e20b(0x2fd)][_0x3e20b(0x32e)](this),BattleManager['isSTB']()&&VisuMZ[_0x3e20b(0x24a)][_0x3e20b(0x361)][_0x3e20b(0x3e1)][_0x3e20b(0x263)]&&this[_0x3e20b(0x356)]();},VisuMZ['BattleSystemSTB'][_0x28da48(0x3c1)]=Game_Battler[_0x28da48(0x3e6)][_0x28da48(0x227)],Game_Battler['prototype'][_0x28da48(0x227)]=function(){const _0x3e3291=_0x28da48;VisuMZ['BattleSystemSTB'][_0x3e3291(0x3c1)][_0x3e3291(0x32e)](this),BattleManager[_0x3e3291(0x31b)]()&&this[_0x3e3291(0x1f6)]();},Game_Battler['prototype'][_0x28da48(0x1f6)]=function(){const _0x1782e3=_0x28da48;if(this[_0x1782e3(0x384)]()>0x0&&this===BattleManager[_0x1782e3(0x3d1)]){if('CXwfO'===_0x1782e3(0x34d))_0x1c760e(_0x1782e3(0x32b)[_0x1782e3(0x332)](_0x1c706c,_0x52098c)),_0x58f4d6[_0x1782e3(0x287)]();else{const _0x5db55b=BattleManager[_0x1782e3(0x39c)];if(_0x5db55b[_0x1782e3(0x3a8)]>0x0&&_0x5db55b[0x0]!==this)return;const _0x230d97=this['battler']();if(_0x230d97)_0x230d97[_0x1782e3(0x26c)]();}}},Game_Battler[_0x28da48(0x3e6)][_0x28da48(0x3e9)]=function(){const _0x47554e=_0x28da48;return VisuMZ[_0x47554e(0x2b7)]['Settings'][_0x47554e(0x266)][_0x47554e(0x1fb)];},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x208)]=Game_Battler[_0x28da48(0x3e6)]['makeSpeed'],Game_Battler[_0x28da48(0x3e6)][_0x28da48(0x2db)]=function(){const _0x1c00f3=_0x28da48;BattleManager['isSTB']()?this[_0x1c00f3(0x2fc)]():VisuMZ[_0x1c00f3(0x24a)][_0x1c00f3(0x208)]['call'](this);},Game_Battler[_0x28da48(0x3e6)]['makeSTBSpeed']=function(){const _0x481f1d=_0x28da48;this['_speed']=VisuMZ[_0x481f1d(0x24a)][_0x481f1d(0x361)][_0x481f1d(0x29b)][_0x481f1d(0x3dd)][_0x481f1d(0x32e)](this);},Game_Battler[_0x28da48(0x3e6)][_0x28da48(0x25a)]=function(){const _0x400fca=_0x28da48,_0x356d88=this[_0x400fca(0x317)]()?this['currentClass']()['note']:this[_0x400fca(0x3b1)]()[_0x400fca(0x2a5)];if(_0x356d88['match'](VisuMZ[_0x400fca(0x24a)][_0x400fca(0x20a)]['ExploitedStates']))return VisuMZ[_0x400fca(0x24a)]['ParseStateData'](RegExp['$1']);return VisuMZ['BattleSystemSTB'][_0x400fca(0x361)][_0x400fca(0x2f9)]['AddedStates']||[];},Game_Battler[_0x28da48(0x3e6)][_0x28da48(0x273)]=function(){const _0x41d877=_0x28da48,_0x258211=this[_0x41d877(0x317)]()?this[_0x41d877(0x2a1)]()[_0x41d877(0x2a5)]:this['enemy']()[_0x41d877(0x2a5)];if(_0x258211[_0x41d877(0x3ce)](VisuMZ[_0x41d877(0x24a)]['RegExp'][_0x41d877(0x369)])){if(_0x41d877(0x33b)!==_0x41d877(0x222))return VisuMZ[_0x41d877(0x24a)][_0x41d877(0x27e)](RegExp['$1']);else _0x3b7eac['isSTB']()?this[_0x41d877(0x2b2)]():_0x3761ad[_0x41d877(0x24a)][_0x41d877(0x279)][_0x41d877(0x32e)](this);}return VisuMZ[_0x41d877(0x24a)][_0x41d877(0x361)]['Exploiter'][_0x41d877(0x243)]||[];},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x27e)]=function(_0x3628ee){const _0x376121=_0x28da48,_0x14a44e=_0x3628ee['split'](','),_0x30ba74=[];for(let _0x5abab1 of _0x14a44e){_0x5abab1=(String(_0x5abab1)||'')['trim']();const _0xef663d=/^\d+$/[_0x376121(0x3a6)](_0x5abab1);_0xef663d?_0x30ba74[_0x376121(0x22b)](Number(_0x5abab1)):_0x30ba74[_0x376121(0x22b)](DataManager[_0x376121(0x23b)](_0x5abab1));}return _0x30ba74;},Game_Battler['prototype'][_0x28da48(0x37d)]=function(_0x41faf2,_0x105e7d){const _0x129c0f=_0x28da48;if(!BattleManager[_0x129c0f(0x31b)]())return;if(!BattleManager[_0x129c0f(0x3a5)]())return;if(this['isSTBExploited']())return;const _0xbb7595=VisuMZ[_0x129c0f(0x24a)]['Settings'][_0x129c0f(0x2f9)];if(!_0xbb7595['UnlimitedExploits']){if('JNLzq'===_0x129c0f(0x231))this['setSTBExploited'](!![]);else{const _0x54de64=this['enemy']()[_0x129c0f(0x2a5)];if(_0x54de64[_0x129c0f(0x3ce)](/<STB TURN ORDER ICON:[ ](\d+)>/i))return _0x1c82fe(_0x59694c['$1']);return _0x43d5ba[_0x129c0f(0x361)][_0x129c0f(0x294)];}}if(this[_0x129c0f(0x267)]())return;if(this['hp']<=0x0)return;this[_0x129c0f(0x29c)](_0xbb7595);if(this['hp']>0x0||!this['isImmortal']()){if(_0x129c0f(0x20c)===_0x129c0f(0x20c))for(const _0x1c05e8 of this[_0x129c0f(0x25a)]()){if(!$dataStates[_0x1c05e8])continue;this[_0x129c0f(0x36f)](_0x1c05e8);}else return _0x2e317f[_0x129c0f(0x2fb)]()==='STB';}if(_0xbb7595[_0x129c0f(0x224)]){if(_0x129c0f(0x37c)!==_0x129c0f(0x37c))return this[_0x129c0f(0x3ad)]();else _0xbb7595[_0x129c0f(0x224)][_0x129c0f(0x32e)](this,_0x41faf2,_0x105e7d);}if(this[_0x129c0f(0x317)]()&&BattleManager[_0x129c0f(0x3e8)]()){const _0x18bb5c=_0xbb7595[_0x129c0f(0x232)];_0x18bb5c>0x0&&$dataCommonEvents[_0x18bb5c]&&$gameTemp['reserveCommonEvent'](_0x18bb5c);}else{if(this[_0x129c0f(0x289)]()&&BattleManager[_0x129c0f(0x22c)]()){const _0x344c6c=_0xbb7595['vsEnemiesFullExploit'];_0x344c6c>0x0&&$dataCommonEvents[_0x344c6c]&&(_0x129c0f(0x3bc)!==_0x129c0f(0x3cb)?$gameTemp[_0x129c0f(0x3bd)](_0x344c6c):this[_0x129c0f(0x23c)]=_0x5aea80[_0x129c0f(0x3b8)]);}}},Game_Battler[_0x28da48(0x3e6)][_0x28da48(0x2b5)]=function(_0xb5b1ab,_0x1c2a8c){const _0x4b07e3=_0x28da48;if(!BattleManager[_0x4b07e3(0x31b)]())return;if(!BattleManager[_0x4b07e3(0x3a5)]())return;if(_0x1c2a8c['hasSTBExploited']())return;if(_0xb5b1ab['isSTBExploited']())return;const _0x2ca042=VisuMZ[_0x4b07e3(0x24a)][_0x4b07e3(0x361)][_0x4b07e3(0x301)];!_0x2ca042['MultipleExploits']&&_0x1c2a8c[_0x4b07e3(0x2f6)](!![]);if(this[_0x4b07e3(0x23e)]())return;this[_0x4b07e3(0x29c)](_0x2ca042);_0x2ca042[_0x4b07e3(0x2b3)]>0x0&&(_0x4b07e3(0x3e7)===_0x4b07e3(0x2ac)?this[_0x4b07e3(0x2b8)]=!![]:this['stbGainInstant'](_0x2ca042[_0x4b07e3(0x2b3)]));for(const _0x387c1b of this[_0x4b07e3(0x273)]()){if(!$dataStates[_0x387c1b])continue;this['addState'](_0x387c1b);}if(_0x2ca042[_0x4b07e3(0x224)]){if(_0x4b07e3(0x1f8)!=='eExVV'){const _0x2bcf40=this[_0x4b07e3(0x2b4)]();this[_0x4b07e3(0x272)](_0x2bcf40),_0x5aa8d3[_0x4b07e3(0x3e6)][_0x4b07e3(0x352)][_0x4b07e3(0x32e)](this,_0x2bcf40),this[_0x4b07e3(0x240)](),this[_0x4b07e3(0x2be)](),this[_0x4b07e3(0x3e3)]=0x0;}else _0x2ca042[_0x4b07e3(0x224)][_0x4b07e3(0x32e)](this,_0xb5b1ab,_0x1c2a8c);}},Game_Battler[_0x28da48(0x3e6)][_0x28da48(0x29c)]=function(_0x58e6cd){const _0x1e105e=_0x28da48;if(!_0x58e6cd)return;if(_0x58e6cd[_0x1e105e(0x290)]){const _0x590ad1=_0x58e6cd['AnimationID'],_0x4ae297=_0x58e6cd[_0x1e105e(0x2fa)],_0x3248a8=_0x58e6cd[_0x1e105e(0x2f4)];$gameTemp[_0x1e105e(0x357)]([this],_0x590ad1,_0x4ae297,_0x3248a8);}if(this[_0x1e105e(0x27b)]()&&_0x58e6cd['PopupText']['length']>0x0){if(_0x1e105e(0x256)!=='ZakZO'){const _0x2ac739=_0x58e6cd[_0x1e105e(0x39d)],_0x1075ba={'textColor':ColorManager['getColor'](_0x58e6cd[_0x1e105e(0x386)]),'flashColor':_0x58e6cd[_0x1e105e(0x2e2)],'flashDuration':_0x58e6cd[_0x1e105e(0x28f)]};this['setupTextPopup'](_0x2ac739,_0x1075ba);}else _0x4ada4b[_0x1e105e(0x31b)]()?this[_0x1e105e(0x2fc)]():_0x204e5c[_0x1e105e(0x24a)]['Game_Battler_makeSpeed'][_0x1e105e(0x32e)](this);}},Game_Battler[_0x28da48(0x3e6)]['stbGainInstant']=function(_0x2f63d9){const _0x3305e2=_0x28da48;this[_0x3305e2(0x34f)]=this[_0x3305e2(0x34f)]||[];const _0x1e73b6=this['_actions']['length']<=0x0;if(this[_0x3305e2(0x3c7)]()){for(let _0x238701=0x0;_0x238701<_0x2f63d9;_0x238701++){this['_actions'][_0x3305e2(0x22b)](new Game_Action(this));}if(this[_0x3305e2(0x289)]()){const _0x7ebd2b=this['enemy']()[_0x3305e2(0x201)]['filter'](_0x92c641=>this[_0x3305e2(0x38f)](_0x92c641));if(_0x7ebd2b[_0x3305e2(0x3a8)]>0x0){let _0x381e78;if(!_0x1e73b6){if(_0x3305e2(0x302)!=='brgiW')return _0x3305e2(0x234);else _0x381e78=this['_actions'][_0x3305e2(0x31e)]();}this[_0x3305e2(0x27f)](_0x7ebd2b),!_0x1e73b6&&this[_0x3305e2(0x34f)][_0x3305e2(0x2d3)](_0x381e78);}}}},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x226)]=Game_Actor[_0x28da48(0x3e6)]['selectNextCommand'],Game_Actor[_0x28da48(0x3e6)][_0x28da48(0x202)]=function(){const _0x385797=_0x28da48;if(BattleManager[_0x385797(0x31b)]()){if(this[_0x385797(0x27b)]())this['battler']()[_0x385797(0x26c)]();return![];}return VisuMZ['BattleSystemSTB'][_0x385797(0x226)][_0x385797(0x32e)](this);},Game_Actor['prototype'][_0x28da48(0x379)]=function(){const _0x1d07f1=_0x28da48,_0x26d499=this[_0x1d07f1(0x3a3)]()[_0x1d07f1(0x2a5)];if(_0x26d499[_0x1d07f1(0x3ce)](/<STB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return _0x1d07f1(0x234);else{if(_0x26d499[_0x1d07f1(0x3ce)](/<STB TURN ORDER ICON:[ ](\d+)>/i)){if(_0x1d07f1(0x3d3)===_0x1d07f1(0x3d3))return _0x1d07f1(0x2ee);else _0x362d19[_0x1d07f1(0x24a)][_0x1d07f1(0x3d2)]['call'](this);}}return Window_STB_TurnOrder[_0x1d07f1(0x361)]['ActorBattlerType'];},Game_Actor[_0x28da48(0x3e6)][_0x28da48(0x32c)]=function(){const _0x13b5a6=_0x28da48,_0x3759f1=this[_0x13b5a6(0x3a3)]()[_0x13b5a6(0x2a5)];if(_0x3759f1[_0x13b5a6(0x3ce)](/<STB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i)){if(_0x13b5a6(0x2e1)!==_0x13b5a6(0x2cc))return String(RegExp['$1']);else{if(!_0x7f790f[_0x13b5a6(0x3e0)]())return;if(!_0x5bd794[_0x13b5a6(0x31b)]())return;const _0x19ceba=this['item'](),_0x302e79=_0x2b334d[_0x13b5a6(0x24a)][_0x13b5a6(0x20a)],_0x5bb46c=_0x3982b1['BattleSystemSTB'][_0x13b5a6(0x361)]['Speed'];_0x19ceba&&_0x19ceba['note'][_0x13b5a6(0x3ce)](_0x302e79[_0x13b5a6(0x30f)])&&this[_0x13b5a6(0x29a)]()[_0x13b5a6(0x22e)](0x1);const _0x482856=_0x5bb46c[_0x13b5a6(0x37b)][_0x13b5a6(0x32e)](this);this['subject']()[_0x13b5a6(0x293)](_0x482856);}}return this['faceName']();},Game_Actor['prototype'][_0x28da48(0x209)]=function(){const _0x27af08=_0x28da48,_0xa42cfe=this[_0x27af08(0x3a3)]()[_0x27af08(0x2a5)];if(_0xa42cfe[_0x27af08(0x3ce)](/<STB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i)){if(_0x27af08(0x3b9)!==_0x27af08(0x31c))return Number(RegExp['$2']);else _0x93769[_0x27af08(0x24a)][_0x27af08(0x208)][_0x27af08(0x32e)](this);}return this[_0x27af08(0x3dc)]();},Game_Actor[_0x28da48(0x3e6)][_0x28da48(0x33a)]=function(){const _0x211e59=_0x28da48,_0x5ab2bf=this['actor']()[_0x211e59(0x2a5)];if(_0x5ab2bf[_0x211e59(0x3ce)](/<STB TURN ORDER ICON:[ ](\d+)>/i))return Number(RegExp['$1']);return Window_STB_TurnOrder[_0x211e59(0x361)]['ActorBattlerIcon'];},Game_Enemy[_0x28da48(0x3e6)][_0x28da48(0x379)]=function(){const _0x1b45db=_0x28da48,_0x2c8bb7=this['enemy']()[_0x1b45db(0x2a5)];if(_0x2c8bb7['match'](/<STB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i)){if(_0x1b45db(0x354)!=='VOqEg')this['processTurnSTB']();else return _0x1b45db(0x234);}else{if(_0x2c8bb7[_0x1b45db(0x3ce)](/<STB TURN ORDER ICON:[ ](\d+)>/i)){if(_0x1b45db(0x217)!==_0x1b45db(0x36b))return _0x1b45db(0x2ee);else this[_0x1b45db(0x34f)]['push'](new _0x478260(this));}}return Window_STB_TurnOrder[_0x1b45db(0x361)][_0x1b45db(0x295)];},Game_Enemy['prototype'][_0x28da48(0x32c)]=function(){const _0x4f1b7e=_0x28da48,_0x575554=this[_0x4f1b7e(0x3b1)]()[_0x4f1b7e(0x2a5)];if(_0x575554[_0x4f1b7e(0x3ce)](/<STB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return _0x4f1b7e(0x297)===_0x4f1b7e(0x297)?String(RegExp['$1']):_0x39d049[_0x4f1b7e(0x24a)]['Settings']['Exploit'][_0x4f1b7e(0x221)];return Window_STB_TurnOrder[_0x4f1b7e(0x361)][_0x4f1b7e(0x33c)];},Game_Enemy[_0x28da48(0x3e6)][_0x28da48(0x209)]=function(){const _0xc38076=_0x28da48,_0x12cdfd=this['enemy']()[_0xc38076(0x2a5)];if(_0x12cdfd[_0xc38076(0x3ce)](/<STB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return Number(RegExp['$2']);return Window_STB_TurnOrder[_0xc38076(0x361)][_0xc38076(0x2dc)];},Game_Enemy[_0x28da48(0x3e6)][_0x28da48(0x33a)]=function(){const _0x4aae33=_0x28da48,_0x1a6bdf=this[_0x4aae33(0x3b1)]()[_0x4aae33(0x2a5)];if(_0x1a6bdf[_0x4aae33(0x3ce)](/<STB TURN ORDER ICON:[ ](\d+)>/i))return Number(RegExp['$1']);return Window_STB_TurnOrder[_0x4aae33(0x361)][_0x4aae33(0x294)];},VisuMZ['BattleSystemSTB']['Game_Party_removeActor']=Game_Party['prototype']['removeActor'],Game_Party['prototype'][_0x28da48(0x2f5)]=function(_0x17590b){const _0x1380cd=_0x28da48;VisuMZ['BattleSystemSTB']['Game_Party_removeActor'][_0x1380cd(0x32e)](this,_0x17590b),SceneManager[_0x1380cd(0x3e0)]()&&BattleManager[_0x1380cd(0x31b)]()&&BattleManager[_0x1380cd(0x3de)][_0x1380cd(0x3c0)]($gameActors[_0x1380cd(0x3a3)](_0x17590b));},VisuMZ['BattleSystemSTB'][_0x28da48(0x36d)]=Scene_Battle[_0x28da48(0x3e6)][_0x28da48(0x1f2)],Scene_Battle[_0x28da48(0x3e6)][_0x28da48(0x1f2)]=function(){const _0x1d8a77=_0x28da48;VisuMZ['BattleSystemSTB'][_0x1d8a77(0x36d)][_0x1d8a77(0x32e)](this);if(BattleManager[_0x1d8a77(0x31b)]()){if(_0x1d8a77(0x2f7)!==_0x1d8a77(0x38a))this['createActorCommandWindowSTB']();else return 0x0;}},Scene_Battle[_0x28da48(0x3e6)][_0x28da48(0x2a6)]=function(){const _0x2f916e=_0x28da48,_0x4cff54=this[_0x2f916e(0x2a9)];this[_0x2f916e(0x278)]()&&delete _0x4cff54[_0x2f916e(0x20e)]['cancel'];},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x279)]=Scene_Battle[_0x28da48(0x3e6)][_0x28da48(0x304)],Scene_Battle[_0x28da48(0x3e6)][_0x28da48(0x304)]=function(){const _0x2877e1=_0x28da48;BattleManager[_0x2877e1(0x31b)]()?this[_0x2877e1(0x2b2)]():VisuMZ[_0x2877e1(0x24a)][_0x2877e1(0x279)][_0x2877e1(0x32e)](this);},Scene_Battle[_0x28da48(0x3e6)][_0x28da48(0x2b2)]=function(){const _0x25b270=_0x28da48;this[_0x25b270(0x2c6)][_0x25b270(0x36a)](),this[_0x25b270(0x2a9)][_0x25b270(0x2dd)]();},VisuMZ[_0x28da48(0x24a)]['Scene_Battle_commandFight']=Scene_Battle['prototype'][_0x28da48(0x2ad)],Scene_Battle[_0x28da48(0x3e6)][_0x28da48(0x2ad)]=function(){const _0x5695b5=_0x28da48;if(BattleManager[_0x5695b5(0x31b)]())this[_0x5695b5(0x300)]();else{if(_0x5695b5(0x247)===_0x5695b5(0x247))VisuMZ[_0x5695b5(0x24a)][_0x5695b5(0x20f)]['call'](this);else{this['_turnOrderInnerSprite']=new _0x3d45f0(),this[_0x5695b5(0x2ab)](this[_0x5695b5(0x2e9)]),this[_0x5695b5(0x3b6)]=[];for(let _0x576be7=0x0;_0x576be7<_0x8d9ce1['maxBattleMembers']();_0x576be7++){const _0x5528b2=new _0x2ba0dd(_0x393459,_0x576be7);this['_turnOrderInnerSprite'][_0x5695b5(0x257)](_0x5528b2),this['_turnOrderContainer'][_0x5695b5(0x22b)](_0x5528b2);}for(let _0x37c326=0x0;_0x37c326<_0x39eaef[_0x5695b5(0x1fe)]()[_0x5695b5(0x3a8)];_0x37c326++){const _0x301f2f=new _0x16169f(_0x3e366d,_0x37c326);this[_0x5695b5(0x2e9)][_0x5695b5(0x257)](_0x301f2f),this['_turnOrderContainer'][_0x5695b5(0x22b)](_0x301f2f);}}}},VisuMZ[_0x28da48(0x24a)][_0x28da48(0x27c)]=Scene_Battle[_0x28da48(0x3e6)][_0x28da48(0x2a7)],Scene_Battle[_0x28da48(0x3e6)][_0x28da48(0x2a7)]=function(){const _0x14a302=_0x28da48;VisuMZ[_0x14a302(0x24a)][_0x14a302(0x27c)]['call'](this),this[_0x14a302(0x2a2)]();},Scene_Battle[_0x28da48(0x3e6)]['createSTBTurnOrderWindow']=function(){const _0xdac6dc=_0x28da48;if(!BattleManager[_0xdac6dc(0x31b)]())return;this['_stbTurnOrderWindow']=new Window_STB_TurnOrder();const _0x57b9ae=this[_0xdac6dc(0x35d)](this[_0xdac6dc(0x393)]);this[_0xdac6dc(0x311)](this[_0xdac6dc(0x204)],_0x57b9ae),this[_0xdac6dc(0x2a8)](),BattleManager[_0xdac6dc(0x21a)](!![]);},Scene_Battle[_0x28da48(0x3e6)][_0x28da48(0x2a8)]=function(){const _0xe7ad0e=_0x28da48,_0x38cb9f=Window_STB_TurnOrder[_0xe7ad0e(0x361)];if(_0x38cb9f[_0xe7ad0e(0x213)]!=='top')return;if(!_0x38cb9f[_0xe7ad0e(0x285)])return;if(!this[_0xe7ad0e(0x3d9)])return;const _0xbf7f48=this['_stbTurnOrderWindow']['y']-Math['round']((Graphics[_0xe7ad0e(0x3e4)]-Graphics[_0xe7ad0e(0x230)])/0x2),_0x496152=_0xbf7f48+this[_0xe7ad0e(0x204)][_0xe7ad0e(0x3e4)];this[_0xe7ad0e(0x3d9)]['y']=_0x496152+_0x38cb9f[_0xe7ad0e(0x2ed)];};function Sprite_STB_TurnOrder_Battler(){const _0xa8d937=_0x28da48;this[_0xa8d937(0x352)](...arguments);}Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)]=Object[_0x28da48(0x350)](Sprite_Clickable['prototype']),Sprite_STB_TurnOrder_Battler['prototype'][_0x28da48(0x3f0)]=Sprite_STB_TurnOrder_Battler,Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x352)]=function(_0x3d950c,_0x5ef0d5){const _0x191b33=_0x28da48;this[_0x191b33(0x2ec)](_0x3d950c,_0x5ef0d5),Sprite_Clickable[_0x191b33(0x3e6)][_0x191b33(0x352)][_0x191b33(0x32e)](this),this[_0x191b33(0x3e3)]=0x0,this['createChildren'](),this[_0x191b33(0x351)]();},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x2ec)]=function(_0x4e58cb,_0x384e07){const _0x51e0d2=_0x28da48;this[_0x51e0d2(0x2e0)]=_0x4e58cb,this[_0x51e0d2(0x31a)]=_0x384e07;const _0x237622=Window_STB_TurnOrder[_0x51e0d2(0x361)],_0x3d165e=this[_0x51e0d2(0x30a)](),_0x3213cb=this[_0x51e0d2(0x305)]();this['_positionDuration']=0x0,this[_0x51e0d2(0x395)]=_0x3d165e?_0x237622['SpriteThin']*_0x3213cb:0x0,this[_0x51e0d2(0x2f0)]=_0x3d165e?0x0:_0x237622[_0x51e0d2(0x233)]*_0x3213cb,this[_0x51e0d2(0x3d4)]=0x0,this[_0x51e0d2(0x380)]=0xff,this['_isAlive']=![],this[_0x51e0d2(0x310)]=![],this['_containerWidth']=0x0,this[_0x51e0d2(0x22d)]=0x0;},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x21b)]=function(){const _0x2f97b9=_0x28da48;this['createInitialPositions'](),this[_0x2f97b9(0x355)](),this[_0x2f97b9(0x344)](),this['createBorderSprite'](),this[_0x2f97b9(0x24f)]();},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)]['createInitialPositions']=function(){const _0x3636cb=_0x28da48;this['x']=this[_0x3636cb(0x395)],this['y']=this[_0x3636cb(0x2f0)];},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x30a)]=function(){const _0x440dd5=_0x28da48,_0x4baeb8=Window_STB_TurnOrder['Settings'],_0xe2e8f5=[_0x440dd5(0x283),_0x440dd5(0x2e4)][_0x440dd5(0x249)](_0x4baeb8[_0x440dd5(0x213)]);return _0xe2e8f5;},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x3ec)]=function(){const _0x290514=_0x28da48,_0x4db822=Window_STB_TurnOrder[_0x290514(0x361)];return this[_0x290514(0x30a)]()?_0x4db822[_0x290514(0x233)]:_0x4db822[_0x290514(0x2c0)];},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x316)]=function(){const _0x2db94b=_0x28da48,_0x596ca4=Window_STB_TurnOrder[_0x2db94b(0x361)];return this['isHorz']()?_0x596ca4[_0x2db94b(0x2c0)]:_0x596ca4[_0x2db94b(0x233)];},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x336)]=function(){const _0x5c741e=_0x28da48;this[_0x5c741e(0x303)]=new Bitmap(0x48,0x24);const _0x23f758=this[_0x5c741e(0x27b)]()?this['battler']()['name']():_0x5c741e(0x375)[_0x5c741e(0x332)](this['_unit'],this['_index']);this[_0x5c741e(0x303)]['drawText'](_0x23f758,0x0,0x0,0x48,0x24,'center');},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x355)]=function(){const _0x202a3b=_0x28da48;if(!Window_STB_TurnOrder[_0x202a3b(0x361)][_0x202a3b(0x3d6)])return;const _0x4e03d7=Window_STB_TurnOrder['Settings'],_0x3f1399=this[_0x202a3b(0x2e0)]===$gameParty?_0x202a3b(0x2d6):_0x202a3b(0x33d),_0x43a1f9=_0x202a3b(0x28d)['format'](_0x3f1399),_0x56ee65=new Sprite();_0x56ee65['anchor']['x']=this['anchor']['x'],_0x56ee65[_0x202a3b(0x20d)]['y']=this[_0x202a3b(0x20d)]['y'];if(_0x4e03d7[_0x43a1f9])_0x56ee65[_0x202a3b(0x303)]=ImageManager[_0x202a3b(0x353)](_0x4e03d7[_0x43a1f9]);else{if(_0x202a3b(0x2c1)!=='jYRKg'){const _0x57ebba=this['bitmapWidth'](),_0x461389=this['bitmapHeight']();_0x56ee65[_0x202a3b(0x303)]=new Bitmap(_0x57ebba,_0x461389);const _0x4c3d9c=ColorManager[_0x202a3b(0x2e6)](_0x4e03d7[_0x202a3b(0x38b)[_0x202a3b(0x332)](_0x3f1399)]),_0x4cedab=ColorManager[_0x202a3b(0x2e6)](_0x4e03d7['%1BgColor2'[_0x202a3b(0x332)](_0x3f1399)]);_0x56ee65[_0x202a3b(0x303)][_0x202a3b(0x396)](0x0,0x0,_0x57ebba,_0x461389,_0x4c3d9c,_0x4cedab,!![]);}else this['_graphicType']='face';}this[_0x202a3b(0x381)]=_0x56ee65,this[_0x202a3b(0x257)](this[_0x202a3b(0x381)]),this[_0x202a3b(0x3ed)]=this[_0x202a3b(0x381)]['width'],this[_0x202a3b(0x3e4)]=this[_0x202a3b(0x381)][_0x202a3b(0x3e4)];},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x344)]=function(){const _0x228d42=_0x28da48,_0x3c83fe=new Sprite();_0x3c83fe[_0x228d42(0x20d)]['x']=this['anchor']['x'],_0x3c83fe[_0x228d42(0x20d)]['y']=this[_0x228d42(0x20d)]['y'],this[_0x228d42(0x2cd)]=_0x3c83fe,this[_0x228d42(0x257)](this[_0x228d42(0x2cd)]),this[_0x228d42(0x3ad)]();},Sprite_STB_TurnOrder_Battler['prototype'][_0x28da48(0x25b)]=function(){const _0x3526ff=_0x28da48;if(!Window_STB_TurnOrder['Settings']['ShowMarkerBorder'])return;const _0x3491da=Window_STB_TurnOrder['Settings'],_0x36c76b=this[_0x3526ff(0x2e0)]===$gameParty?_0x3526ff(0x2d6):_0x3526ff(0x33d),_0x1e3eae=_0x3526ff(0x340)['format'](_0x36c76b),_0x28773a=new Sprite();_0x28773a[_0x3526ff(0x20d)]['x']=this[_0x3526ff(0x20d)]['x'],_0x28773a[_0x3526ff(0x20d)]['y']=this[_0x3526ff(0x20d)]['y'];if(_0x3491da[_0x1e3eae]){if(_0x3526ff(0x38e)!==_0x3526ff(0x38e)){if(!this['_letterSprite'])return;const _0x2a63cf=this[_0x3526ff(0x27b)]();if(!_0x2a63cf)return;if(this[_0x3526ff(0x2ca)]===_0x2a63cf[_0x3526ff(0x2ca)]&&this[_0x3526ff(0x38c)]===_0x2a63cf[_0x3526ff(0x38c)])return;this[_0x3526ff(0x2ca)]=_0x2a63cf[_0x3526ff(0x2ca)],this[_0x3526ff(0x38c)]=_0x2a63cf['_plural'];const _0x545c22=_0x1dd249[_0x3526ff(0x361)],_0x57928d=this[_0x3526ff(0x30a)](),_0x4e50ff=this[_0x3526ff(0x3ec)](),_0xb4df6a=this[_0x3526ff(0x316)](),_0x385063=this['_letterSprite'][_0x3526ff(0x303)];_0x385063['clear']();if(!this[_0x3526ff(0x38c)])return;_0x385063['fontFace']=_0x545c22['EnemyBattlerFontFace']||_0x2f9c53[_0x3526ff(0x348)](),_0x385063['fontSize']=_0x545c22[_0x3526ff(0x35b)]||0x10,_0x57928d?_0x385063[_0x3526ff(0x23d)](this[_0x3526ff(0x2ca)][_0x3526ff(0x2a0)](),0x0,_0xb4df6a/0x2,_0x4e50ff,_0xb4df6a/0x2,_0x3526ff(0x212)):_0x385063[_0x3526ff(0x23d)](this[_0x3526ff(0x2ca)]['trim'](),0x0,0x2,_0x4e50ff-0x8,_0xb4df6a-0x4,_0x3526ff(0x3cc));}else _0x28773a[_0x3526ff(0x303)]=ImageManager['loadSystem'](_0x3491da[_0x1e3eae]);}else{let _0x562645=this[_0x3526ff(0x3ec)](),_0x863379=this[_0x3526ff(0x316)](),_0x23962d=_0x3491da[_0x3526ff(0x331)];_0x28773a[_0x3526ff(0x303)]=new Bitmap(_0x562645,_0x863379);const _0x6b20ac='#000000',_0x1a346e=ColorManager[_0x3526ff(0x2e6)](_0x3491da[_0x3526ff(0x2e8)['format'](_0x36c76b)]);_0x28773a[_0x3526ff(0x303)]['fillRect'](0x0,0x0,_0x562645,_0x863379,_0x6b20ac),_0x562645-=0x2,_0x863379-=0x2,_0x28773a[_0x3526ff(0x303)][_0x3526ff(0x338)](0x1,0x1,_0x562645,_0x863379,_0x1a346e),_0x562645-=_0x23962d*0x2,_0x863379-=_0x23962d*0x2,_0x28773a[_0x3526ff(0x303)][_0x3526ff(0x338)](0x1+_0x23962d,0x1+_0x23962d,_0x562645,_0x863379,_0x6b20ac),_0x562645-=0x2,_0x863379-=0x2,_0x23962d+=0x1,_0x28773a[_0x3526ff(0x303)][_0x3526ff(0x29e)](0x1+_0x23962d,0x1+_0x23962d,_0x562645,_0x863379);}this[_0x3526ff(0x381)]=_0x28773a,this[_0x3526ff(0x257)](this[_0x3526ff(0x381)]);},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)]['createLetterSprite']=function(){const _0x1b1d6b=_0x28da48,_0x11d09c=Window_STB_TurnOrder[_0x1b1d6b(0x361)];if(!_0x11d09c['EnemyBattlerDrawLetter'])return;if(this['_unit']===$gameParty)return;const _0x151b73=this[_0x1b1d6b(0x3ec)](),_0x56108b=this[_0x1b1d6b(0x316)](),_0x51b5c1=new Sprite();_0x51b5c1[_0x1b1d6b(0x20d)]['x']=this['anchor']['x'],_0x51b5c1[_0x1b1d6b(0x20d)]['y']=this['anchor']['y'],_0x51b5c1[_0x1b1d6b(0x303)]=new Bitmap(_0x151b73,_0x56108b),this['_letterSprite']=_0x51b5c1,this['addChild'](this[_0x1b1d6b(0x3df)]);},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x27b)]=function(){const _0x1b4368=_0x28da48;return this[_0x1b4368(0x2e0)]?this[_0x1b4368(0x2e0)][_0x1b4368(0x1fe)]()[this[_0x1b4368(0x31a)]]:null;},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)]['update']=function(){const _0x4841e8=_0x28da48;Sprite_Clickable['prototype'][_0x4841e8(0x359)]['call'](this),this['checkPosition'](),this[_0x4841e8(0x2a4)](),this[_0x4841e8(0x351)](),this[_0x4841e8(0x2c5)](),this[_0x4841e8(0x39e)](),this[_0x4841e8(0x341)](),this[_0x4841e8(0x370)](),this['updateSelectionEffect']();},Sprite_STB_TurnOrder_Battler['prototype'][_0x28da48(0x307)]=function(){const _0x155983=_0x28da48,_0x49a607=this[_0x155983(0x2c4)]();if(this[_0x155983(0x3af)]===_0x49a607)return;this[_0x155983(0x3af)]=_0x49a607;this[_0x155983(0x3e3)]<0xff&&this[_0x155983(0x27b)]()&&_0x49a607!==this[_0x155983(0x305)]()&&this[_0x155983(0x314)](0xff);if(_0x49a607===this[_0x155983(0x305)]()&&this[_0x155983(0x3d4)]<=0x0&&this[_0x155983(0x3e3)]>0x0)this['startFade'](0x0);else this[_0x155983(0x3d4)]<=0x0&&this[_0x155983(0x3e3)]<0xff&&(_0x155983(0x2bb)!==_0x155983(0x2bb)?this[_0x155983(0x356)]():this[_0x155983(0x351)]());this[_0x155983(0x206)]();},Sprite_STB_TurnOrder_Battler['prototype']['checkTargetPositions']=function(){const _0x29b693=_0x28da48,_0x18497c=this['containerWindow']();if(!_0x18497c)return;let _0x4dc369=![];if(this[_0x29b693(0x32f)]!==_0x18497c[_0x29b693(0x3ed)])_0x4dc369=!![];else{if(this[_0x29b693(0x22d)]!==_0x18497c['height']){if(_0x29b693(0x30e)!==_0x29b693(0x26a))_0x4dc369=!![];else{const _0x36adea=this[_0x29b693(0x3b1)]()['note'];if(_0x36adea['match'](/<STB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return _0x29b693(0x234);else{if(_0x36adea[_0x29b693(0x3ce)](/<STB TURN ORDER ICON:[ ](\d+)>/i))return _0x29b693(0x2ee);}return _0xe7fca2[_0x29b693(0x361)][_0x29b693(0x295)];}}}if(_0x4dc369){if(_0x29b693(0x259)!=='XdAmU')this[_0x29b693(0x206)]();else{if(this[_0x29b693(0x337)]!==_0x32a522[_0x29b693(0x29f)]())return this['processUpdateGraphic']();}}},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x206)]=function(){const _0x37512d=_0x28da48,_0x2900fb=Window_STB_TurnOrder['Settings'],_0x56c9b7=this[_0x37512d(0x30a)](),_0x21b83b=_0x2900fb[_0x37512d(0x264)],_0x2b1177=_0x2900fb[_0x37512d(0x26f)],_0x278b1a=SceneManager[_0x37512d(0x313)]['_stbTurnOrderWindow'];if(!_0x278b1a)return;const _0x3a3c03=this[_0x37512d(0x2c4)]();this[_0x37512d(0x36c)]=_0x2900fb[_0x37512d(0x3b8)],this[_0x37512d(0x395)]=_0x56c9b7?_0x2900fb[_0x37512d(0x233)]*_0x3a3c03:0x0,this[_0x37512d(0x2f0)]=_0x56c9b7?0x0:_0x2900fb[_0x37512d(0x233)]*_0x3a3c03,_0x3a3c03>0x0&&(this[_0x37512d(0x395)]+=_0x56c9b7?_0x2b1177:0x0,this['_positionTargetY']+=_0x56c9b7?0x0:_0x2b1177),_0x21b83b?this[_0x37512d(0x395)]=_0x56c9b7?_0x278b1a[_0x37512d(0x3ed)]-this[_0x37512d(0x395)]-_0x2900fb['SpriteThin']:0x0:_0x37512d(0x31f)===_0x37512d(0x31f)?this[_0x37512d(0x2f0)]=_0x56c9b7?0x0:_0x278b1a[_0x37512d(0x3e4)]-this[_0x37512d(0x2f0)]-_0x2900fb[_0x37512d(0x233)]:_0x46814b[_0x37512d(0x24a)][_0x37512d(0x279)][_0x37512d(0x32e)](this);},Sprite_STB_TurnOrder_Battler['prototype'][_0x28da48(0x2a4)]=function(){const _0x553fc0=_0x28da48;if(this[_0x553fc0(0x3d4)]>0x0)return;if(this['_positionDuration']>0x0){if(_0x553fc0(0x210)===_0x553fc0(0x282)){const _0x1365c4=this['_graphicIconIndex'],_0x37019d=this[_0x553fc0(0x3ec)](),_0x459ccb=this[_0x553fc0(0x316)]();this[_0x553fc0(0x2cd)][_0x553fc0(0x303)]=new _0x3c69f4(_0x37019d,_0x459ccb);const _0x131706=this['_graphicSprite'][_0x553fc0(0x303)],_0x44acce=_0x22b328[_0x553fc0(0x394)],_0x518e72=_0x5819d6['iconHeight'],_0x1210b7=_0x24b65a[_0x553fc0(0x378)](_0x44acce,_0x518e72,_0x37019d,_0x459ccb),_0x4ce9c8=_0x1365c4%0x10*_0x44acce,_0x3be9fd=_0x112e61[_0x553fc0(0x391)](_0x1365c4/0x10)*_0x518e72,_0x45da43=_0x4246e0[_0x553fc0(0x391)](_0x1977ee[_0x553fc0(0x2c9)](_0x37019d-_0x1210b7,0x0)/0x2),_0x188b19=_0x66f217[_0x553fc0(0x391)](_0x4f61f[_0x553fc0(0x2c9)](_0x459ccb-_0x1210b7,0x0)/0x2);_0x131706[_0x553fc0(0x23a)](_0x595c1f,_0x4ce9c8,_0x3be9fd,_0x44acce,_0x518e72,_0x45da43,_0x188b19,_0x1210b7,_0x1210b7);}else{const _0x4687e6=this[_0x553fc0(0x36c)];this['x']=(this['x']*(_0x4687e6-0x1)+this['_positionTargetX'])/_0x4687e6,this['y']=(this['y']*(_0x4687e6-0x1)+this[_0x553fc0(0x2f0)])/_0x4687e6,this[_0x553fc0(0x36c)]--;}}if(this['_positionDuration']<=0x0){this['x']=this[_0x553fc0(0x395)],this['y']=this[_0x553fc0(0x2f0)];if(this[_0x553fc0(0x3e3)]<0xff&&!this[_0x553fc0(0x25c)]&&this['_fadeDuration']<=0x0){const _0x508d20=this[_0x553fc0(0x27b)]();_0x508d20&&(this[_0x553fc0(0x380)]=_0x508d20[_0x553fc0(0x1fd)]()&&_0x508d20[_0x553fc0(0x34b)]()?0xff:0x0);}}},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x305)]=function(){const _0x542a86=_0x28da48,_0x26572f=Window_STB_TurnOrder[_0x542a86(0x361)],_0x2e396f=this['isHorz']()?_0x26572f[_0x542a86(0x24d)]:_0x26572f[_0x542a86(0x2eb)];return _0x2e396f+0x1;},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x218)]=function(){const _0x1dd2d0=_0x28da48;return SceneManager[_0x1dd2d0(0x313)][_0x1dd2d0(0x204)];},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x2c4)]=function(){const _0xae84=_0x28da48,_0x43598b=this[_0xae84(0x27b)]();if(!_0x43598b)return this[_0xae84(0x305)]();if(_0x43598b===BattleManager[_0xae84(0x3d1)])return 0x0;if(BattleManager[_0xae84(0x3de)][_0xae84(0x249)](_0x43598b)){const _0x6755a2=BattleManager[_0xae84(0x3de)][_0xae84(0x265)](_0x43598b)+0x1;return _0x6755a2;}return this[_0xae84(0x305)]();},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x314)]=function(_0x223a30){const _0x1744d3=_0x28da48,_0x4e6138=Window_STB_TurnOrder[_0x1744d3(0x361)];this[_0x1744d3(0x3d4)]=_0x4e6138[_0x1744d3(0x3b8)],this[_0x1744d3(0x380)]=_0x223a30;},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)]['checkOpacity']=function(){const _0x2c286f=_0x28da48,_0x13f5a2=this['battler']();if(!_0x13f5a2)return;if(this[_0x2c286f(0x39a)]===_0x13f5a2[_0x2c286f(0x1fd)]()&&this[_0x2c286f(0x310)]===_0x13f5a2[_0x2c286f(0x34b)]())return;this[_0x2c286f(0x39a)]=_0x13f5a2['isAlive'](),this[_0x2c286f(0x310)]=_0x13f5a2[_0x2c286f(0x34b)]();let _0x293d4f=this[_0x2c286f(0x39a)]&&this[_0x2c286f(0x310)]?0xff:0x0;this['startFade'](_0x293d4f);},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)]['updateOpacity']=function(){const _0x3e292e=_0x28da48;if(this[_0x3e292e(0x3d4)]>0x0){const _0x29af72=this['_fadeDuration'];this[_0x3e292e(0x3e3)]=(this[_0x3e292e(0x3e3)]*(_0x29af72-0x1)+this[_0x3e292e(0x380)])/_0x29af72,this['_fadeDuration']--;if(this[_0x3e292e(0x3d4)]<=0x0){if(_0x3e292e(0x320)===_0x3e292e(0x320))this[_0x3e292e(0x307)](),this[_0x3e292e(0x36c)]=0x0,this[_0x3e292e(0x2a4)](),this['opacity']=this[_0x3e292e(0x380)];else{if(!_0x566802[_0x3e292e(0x361)][_0x3e292e(0x3d6)])return;const _0x331952=_0x509836[_0x3e292e(0x361)],_0x3bb932=this[_0x3e292e(0x2e0)]===_0x36a34e?'Actor':_0x3e292e(0x33d),_0x91df95=_0x3e292e(0x28d)['format'](_0x3bb932),_0x203f6c=new _0xa23852();_0x203f6c[_0x3e292e(0x20d)]['x']=this[_0x3e292e(0x20d)]['x'],_0x203f6c[_0x3e292e(0x20d)]['y']=this[_0x3e292e(0x20d)]['y'];if(_0x331952[_0x91df95])_0x203f6c[_0x3e292e(0x303)]=_0x5f25b4[_0x3e292e(0x353)](_0x331952[_0x91df95]);else{const _0x330c7b=this[_0x3e292e(0x3ec)](),_0x43ef6a=this[_0x3e292e(0x316)]();_0x203f6c['bitmap']=new _0xa6bef7(_0x330c7b,_0x43ef6a);const _0x50a3a4=_0x1499ea[_0x3e292e(0x2e6)](_0x331952['%1BgColor1'[_0x3e292e(0x332)](_0x3bb932)]),_0x46ed49=_0x5ae262[_0x3e292e(0x2e6)](_0x331952[_0x3e292e(0x2d9)['format'](_0x3bb932)]);_0x203f6c[_0x3e292e(0x303)]['gradientFillRect'](0x0,0x0,_0x330c7b,_0x43ef6a,_0x50a3a4,_0x46ed49,!![]);}this[_0x3e292e(0x381)]=_0x203f6c,this[_0x3e292e(0x257)](this[_0x3e292e(0x381)]),this[_0x3e292e(0x3ed)]=this['_backgroundSprite'][_0x3e292e(0x3ed)],this[_0x3e292e(0x3e4)]=this[_0x3e292e(0x381)][_0x3e292e(0x3e4)];}}}if(this['_isBattleOver'])return;BattleManager[_0x3e292e(0x2b0)]==='battleEnd'&&(_0x3e292e(0x2d4)!==_0x3e292e(0x220)?(this[_0x3e292e(0x25c)]=!![],this[_0x3e292e(0x314)](0x0)):this[_0x3e292e(0x22e)](_0x476928['ExtraActions']));},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x39e)]=function(){const _0x4f0c74=_0x28da48,_0x5422ce=this['battler']();if(!_0x5422ce)return;const _0x190a1d=Window_STB_TurnOrder[_0x4f0c74(0x361)],_0x10abf3=this[_0x4f0c74(0x2e0)]===$gameParty?'Actor':_0x4f0c74(0x33d);let _0x114bd0=_0x5422ce['TurnOrderSTBGraphicType']();if(_0x5422ce[_0x4f0c74(0x317)]()&&_0x114bd0===_0x4f0c74(0x3b1))_0x114bd0=_0x4f0c74(0x234);else _0x5422ce[_0x4f0c74(0x289)]()&&_0x114bd0===_0x4f0c74(0x3c2)&&(_0x4f0c74(0x35f)!==_0x4f0c74(0x3a2)?_0x114bd0=_0x4f0c74(0x3b1):(this['x']=this['_homeX']+(_0x289061[_0x4f0c74(0x1f7)]||0x0),this['y']=this[_0x4f0c74(0x24c)]+(_0x494fcd[_0x4f0c74(0x3cf)]||0x0)));if(this[_0x4f0c74(0x329)]!==_0x114bd0)return this[_0x4f0c74(0x3ad)]();switch(this['_graphicType']){case _0x4f0c74(0x234):if(this[_0x4f0c74(0x38d)]!==_0x5422ce[_0x4f0c74(0x387)]())return _0x4f0c74(0x3a9)===_0x4f0c74(0x3a9)?this[_0x4f0c74(0x3ad)]():(this[_0x4f0c74(0x2d8)]===_0x27113d&&(this['_stbTurnOrderFaceName']=this[_0x4f0c74(0x32c)]()),this['_stbTurnOrderFaceName']);if(this[_0x4f0c74(0x2ce)]!==_0x5422ce['TurnOrderSTBGraphicFaceIndex']())return this[_0x4f0c74(0x3ad)]();break;case'icon':if(this[_0x4f0c74(0x399)]!==_0x5422ce[_0x4f0c74(0x271)]())return this[_0x4f0c74(0x3ad)]();break;case _0x4f0c74(0x3b1):if(_0x5422ce[_0x4f0c74(0x260)]()){if(this[_0x4f0c74(0x337)]!==_0x5422ce[_0x4f0c74(0x3ba)]())return this[_0x4f0c74(0x3ad)]();}else{if(this[_0x4f0c74(0x291)]!==_0x5422ce[_0x4f0c74(0x29f)]())return this[_0x4f0c74(0x3ad)]();}break;case _0x4f0c74(0x3c2):if(_0x5422ce[_0x4f0c74(0x317)]()){if(this[_0x4f0c74(0x337)]!==_0x5422ce[_0x4f0c74(0x29f)]())return _0x4f0c74(0x2f2)!=='GtMDg'?this[_0x4f0c74(0x3ad)]():(this[_0x4f0c74(0x255)]===_0x12faaf&&(this[_0x4f0c74(0x255)]=this[_0x4f0c74(0x379)]()),this[_0x4f0c74(0x255)]);}else{if(this['_graphicEnemy']!==_0x5422ce[_0x4f0c74(0x29f)]())return this[_0x4f0c74(0x3ad)]();}break;}},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x3ad)]=function(){const _0x2f1557=_0x28da48,_0x5a5cbd=this[_0x2f1557(0x27b)]();if(!_0x5a5cbd)return;this[_0x2f1557(0x329)]=_0x5a5cbd[_0x2f1557(0x34a)]();if(_0x5a5cbd[_0x2f1557(0x317)]()&&this['_graphicType']==='enemy')_0x2f1557(0x3d7)===_0x2f1557(0x3d7)?this[_0x2f1557(0x329)]=_0x2f1557(0x234):this[_0x2f1557(0x21e)]();else _0x5a5cbd['isEnemy']()&&this[_0x2f1557(0x329)]===_0x2f1557(0x3c2)&&(this[_0x2f1557(0x329)]=_0x2f1557(0x3b1));let _0x25e0f6;switch(this['_graphicType']){case _0x2f1557(0x234):this[_0x2f1557(0x38d)]=_0x5a5cbd[_0x2f1557(0x387)](),this[_0x2f1557(0x2ce)]=_0x5a5cbd[_0x2f1557(0x319)](),_0x25e0f6=ImageManager['loadFace'](this[_0x2f1557(0x38d)]),_0x25e0f6['addLoadListener'](this[_0x2f1557(0x2bc)]['bind'](this,_0x25e0f6));break;case _0x2f1557(0x2ee):this['_graphicIconIndex']=_0x5a5cbd[_0x2f1557(0x33a)](),_0x25e0f6=ImageManager[_0x2f1557(0x353)]('IconSet'),_0x25e0f6[_0x2f1557(0x366)](this[_0x2f1557(0x216)][_0x2f1557(0x3b0)](this,_0x25e0f6));break;case _0x2f1557(0x3b1):if(_0x5a5cbd[_0x2f1557(0x260)]())this[_0x2f1557(0x337)]=_0x5a5cbd['svBattlerName'](),_0x25e0f6=ImageManager[_0x2f1557(0x288)](this['_graphicSv']),_0x25e0f6[_0x2f1557(0x366)](this['changeSvActorGraphicBitmap'][_0x2f1557(0x3b0)](this,_0x25e0f6));else $gameSystem[_0x2f1557(0x339)]()?(this[_0x2f1557(0x291)]=_0x5a5cbd[_0x2f1557(0x29f)](),_0x25e0f6=ImageManager[_0x2f1557(0x315)](this[_0x2f1557(0x291)]),_0x25e0f6[_0x2f1557(0x366)](this['changeEnemyGraphicBitmap'][_0x2f1557(0x3b0)](this,_0x25e0f6))):(this[_0x2f1557(0x291)]=_0x5a5cbd[_0x2f1557(0x29f)](),_0x25e0f6=ImageManager[_0x2f1557(0x200)](this[_0x2f1557(0x291)]),_0x25e0f6[_0x2f1557(0x366)](this['changeEnemyGraphicBitmap']['bind'](this,_0x25e0f6)));break;case'svactor':this[_0x2f1557(0x337)]=_0x5a5cbd[_0x2f1557(0x29f)](),_0x25e0f6=ImageManager[_0x2f1557(0x288)](this[_0x2f1557(0x337)]),_0x25e0f6[_0x2f1557(0x366)](this[_0x2f1557(0x23f)][_0x2f1557(0x3b0)](this,_0x25e0f6));break;}},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x2bc)]=function(_0x3cb885){const _0x42d87a=_0x28da48,_0x23feac=this[_0x42d87a(0x2ce)],_0x3ab0bc=this[_0x42d87a(0x3ec)](),_0x43efcd=this[_0x42d87a(0x316)](),_0x5749de=Math[_0x42d87a(0x2c9)](_0x3ab0bc,_0x43efcd);this['_graphicSprite']['bitmap']=new Bitmap(_0x3ab0bc,_0x43efcd);const _0x215bb7=this['_graphicSprite'][_0x42d87a(0x303)],_0x34859c=ImageManager[_0x42d87a(0x26b)],_0x20c10d=ImageManager[_0x42d87a(0x1f1)],_0xefe944=_0x5749de/Math[_0x42d87a(0x2c9)](_0x34859c,_0x20c10d),_0x1bca65=ImageManager[_0x42d87a(0x26b)],_0x1983b6=ImageManager[_0x42d87a(0x1f1)],_0x359e3c=_0x23feac%0x4*_0x34859c+(_0x34859c-_0x1bca65)/0x2,_0x2cc37b=Math[_0x42d87a(0x391)](_0x23feac/0x4)*_0x20c10d+(_0x20c10d-_0x1983b6)/0x2,_0x5b6d6e=(_0x3ab0bc-_0x34859c*_0xefe944)/0x2,_0x1da7a0=(_0x43efcd-_0x20c10d*_0xefe944)/0x2;_0x215bb7['blt'](_0x3cb885,_0x359e3c,_0x2cc37b,_0x1bca65,_0x1983b6,_0x5b6d6e,_0x1da7a0,_0x5749de,_0x5749de);},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)]['changeIconGraphicBitmap']=function(_0x1865fc){const _0x2e5d4f=_0x28da48,_0x3119e6=this['_graphicIconIndex'],_0x1fe1a9=this['bitmapWidth'](),_0x1a0ba0=this[_0x2e5d4f(0x316)]();this[_0x2e5d4f(0x2cd)]['bitmap']=new Bitmap(_0x1fe1a9,_0x1a0ba0);const _0x8333c9=this['_graphicSprite']['bitmap'],_0x1ccbad=ImageManager[_0x2e5d4f(0x394)],_0x5708c7=ImageManager[_0x2e5d4f(0x3b5)],_0x17dcf1=Math[_0x2e5d4f(0x378)](_0x1ccbad,_0x5708c7,_0x1fe1a9,_0x1a0ba0),_0x487383=_0x3119e6%0x10*_0x1ccbad,_0x191206=Math[_0x2e5d4f(0x391)](_0x3119e6/0x10)*_0x5708c7,_0x244910=Math[_0x2e5d4f(0x391)](Math[_0x2e5d4f(0x2c9)](_0x1fe1a9-_0x17dcf1,0x0)/0x2),_0xc9be2b=Math[_0x2e5d4f(0x391)](Math[_0x2e5d4f(0x2c9)](_0x1a0ba0-_0x17dcf1,0x0)/0x2);_0x8333c9[_0x2e5d4f(0x23a)](_0x1865fc,_0x487383,_0x191206,_0x1ccbad,_0x5708c7,_0x244910,_0xc9be2b,_0x17dcf1,_0x17dcf1);},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x23f)]=function(_0x4418c4){const _0xa3d46=_0x28da48,_0x254bbb=this[_0xa3d46(0x3ec)](),_0x3c99e8=this['bitmapHeight'](),_0x3efb2f=Math[_0xa3d46(0x378)](_0x254bbb,_0x3c99e8);this[_0xa3d46(0x2cd)][_0xa3d46(0x303)]=new Bitmap(_0x254bbb,_0x3c99e8);const _0x4e0d67=this[_0xa3d46(0x2cd)][_0xa3d46(0x303)],_0x1cbfe4=this['_graphicSv'][_0xa3d46(0x3ce)](/\$/i),_0x3da711=_0x1cbfe4?0x1:ImageManager['svActorHorzCells'],_0x58b6e3=_0x1cbfe4?0x1:ImageManager[_0xa3d46(0x349)],_0x581c11=_0x4418c4[_0xa3d46(0x3ed)]/_0x3da711,_0x28483f=_0x4418c4[_0xa3d46(0x3e4)]/_0x58b6e3,_0xb18aef=Math[_0xa3d46(0x378)](0x1,_0x3efb2f/_0x581c11,_0x3efb2f/_0x28483f),_0x42a219=_0x581c11*_0xb18aef,_0x5cd1ed=_0x28483f*_0xb18aef,_0x2908f7=Math[_0xa3d46(0x1f5)]((_0x254bbb-_0x42a219)/0x2),_0x5aef6b=Math[_0xa3d46(0x1f5)]((_0x3c99e8-_0x5cd1ed)/0x2);_0x4e0d67['blt'](_0x4418c4,0x0,0x0,_0x581c11,_0x28483f,_0x2908f7,_0x5aef6b,_0x42a219,_0x5cd1ed);},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x223)]=function(_0x573f5a){const _0x4f2f9d=_0x28da48,_0x3bf416=Window_STB_TurnOrder[_0x4f2f9d(0x361)],_0x4af9b7=this['bitmapWidth'](),_0x25acd0=this[_0x4f2f9d(0x316)](),_0x50daa8=Math['min'](_0x4af9b7,_0x25acd0);this[_0x4f2f9d(0x2cd)][_0x4f2f9d(0x303)]=new Bitmap(_0x4af9b7,_0x25acd0);const _0x5f5abb=this[_0x4f2f9d(0x2cd)][_0x4f2f9d(0x303)],_0xba75a5=Math['min'](0x1,_0x50daa8/_0x573f5a[_0x4f2f9d(0x3ed)],_0x50daa8/_0x573f5a[_0x4f2f9d(0x3e4)]),_0x83ea69=_0x573f5a[_0x4f2f9d(0x3ed)]*_0xba75a5,_0xee1b7e=_0x573f5a[_0x4f2f9d(0x3e4)]*_0xba75a5,_0x25023f=Math['round']((_0x4af9b7-_0x83ea69)/0x2),_0x80d78e=Math[_0x4f2f9d(0x1f5)]((_0x25acd0-_0xee1b7e)/0x2);_0x5f5abb['blt'](_0x573f5a,0x0,0x0,_0x573f5a[_0x4f2f9d(0x3ed)],_0x573f5a['height'],_0x25023f,_0x80d78e,_0x83ea69,_0xee1b7e);},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x341)]=function(){const _0x18a7bc=_0x28da48,_0x24c485=this[_0x18a7bc(0x27b)]();if(!_0x24c485)return;if(!_0x24c485[_0x18a7bc(0x289)]())return;if(this[_0x18a7bc(0x3b3)]===_0x24c485[_0x18a7bc(0x211)]())return;this[_0x18a7bc(0x3b3)]=_0x24c485[_0x18a7bc(0x211)]();if(_0x24c485[_0x18a7bc(0x260)]())this[_0x18a7bc(0x3b3)]=0x0;this[_0x18a7bc(0x2cd)][_0x18a7bc(0x2c2)](this[_0x18a7bc(0x3b3)]);},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x370)]=function(){const _0x465fa3=_0x28da48;if(!this['_letterSprite'])return;const _0xd09455=this[_0x465fa3(0x27b)]();if(!_0xd09455)return;if(this[_0x465fa3(0x2ca)]===_0xd09455[_0x465fa3(0x2ca)]&&this[_0x465fa3(0x38c)]===_0xd09455[_0x465fa3(0x38c)])return;this[_0x465fa3(0x2ca)]=_0xd09455['_letter'],this['_plural']=_0xd09455[_0x465fa3(0x38c)];const _0x3b4bf2=Window_STB_TurnOrder[_0x465fa3(0x361)],_0x4e9487=this['isHorz'](),_0x35e737=this[_0x465fa3(0x3ec)](),_0x482f3c=this['bitmapHeight'](),_0x1e2e6a=this[_0x465fa3(0x3df)][_0x465fa3(0x303)];_0x1e2e6a[_0x465fa3(0x364)]();if(!this[_0x465fa3(0x38c)])return;_0x1e2e6a[_0x465fa3(0x35c)]=_0x3b4bf2[_0x465fa3(0x261)]||$gameSystem[_0x465fa3(0x348)](),_0x1e2e6a[_0x465fa3(0x3da)]=_0x3b4bf2[_0x465fa3(0x35b)]||0x10,_0x4e9487?_0x465fa3(0x36e)!==_0x465fa3(0x382)?_0x1e2e6a[_0x465fa3(0x23d)](this[_0x465fa3(0x2ca)]['trim'](),0x0,_0x482f3c/0x2,_0x35e737,_0x482f3c/0x2,_0x465fa3(0x212)):(_0x396d59[_0x465fa3(0x24a)][_0x465fa3(0x270)][_0x465fa3(0x32e)](this),this[_0x465fa3(0x21e)]()):_0x1e2e6a[_0x465fa3(0x23d)](this[_0x465fa3(0x2ca)][_0x465fa3(0x2a0)](),0x0,0x2,_0x35e737-0x8,_0x482f3c-0x4,_0x465fa3(0x3cc));},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)]['updateSelectionEffect']=function(){const _0xb54340=_0x28da48,_0x1a1992=this[_0xb54340(0x27b)]();if(!_0x1a1992)return;const _0x20bc77=_0x1a1992[_0xb54340(0x27b)]();if(!_0x20bc77)return;const _0x5c12b6=_0x20bc77[_0xb54340(0x327)]();if(!_0x5c12b6)return;this[_0xb54340(0x292)](_0x5c12b6[_0xb54340(0x392)]);},Sprite_STB_TurnOrder_Battler[_0x28da48(0x3e6)][_0x28da48(0x3a4)]=function(){const _0x3107fb=_0x28da48;return this[_0x3107fb(0x27b)]();},VisuMZ['BattleSystemSTB'][_0x28da48(0x3d8)]=Window_Help[_0x28da48(0x3e6)][_0x28da48(0x280)],Window_Help['prototype']['setItem']=function(_0x1bc45e){const _0x573945=_0x28da48;BattleManager[_0x573945(0x31b)]()&&_0x1bc45e&&_0x1bc45e['note']&&_0x1bc45e[_0x573945(0x2a5)][_0x573945(0x3ce)](/<(?:STB) HELP>\s*([\s\S]*)\s*<\/(?:STB) HELP>/i)?this[_0x573945(0x3b4)](String(RegExp['$1'])):VisuMZ['BattleSystemSTB'][_0x573945(0x3d8)]['call'](this,_0x1bc45e);};function Window_STB_TurnOrder(){const _0x2f7d45=_0x28da48;this[_0x2f7d45(0x352)](...arguments);}Window_STB_TurnOrder[_0x28da48(0x3e6)]=Object[_0x28da48(0x350)](Window_Base[_0x28da48(0x3e6)]),Window_STB_TurnOrder[_0x28da48(0x3e6)][_0x28da48(0x3f0)]=Window_STB_TurnOrder,Window_STB_TurnOrder[_0x28da48(0x361)]=VisuMZ[_0x28da48(0x24a)][_0x28da48(0x361)][_0x28da48(0x312)],Window_STB_TurnOrder[_0x28da48(0x3e6)][_0x28da48(0x352)]=function(){const _0x5bd94e=_0x28da48,_0x382b6=this[_0x5bd94e(0x2b4)]();this[_0x5bd94e(0x272)](_0x382b6),Window_Base[_0x5bd94e(0x3e6)][_0x5bd94e(0x352)]['call'](this,_0x382b6),this[_0x5bd94e(0x240)](),this[_0x5bd94e(0x2be)](),this[_0x5bd94e(0x3e3)]=0x0;},Window_STB_TurnOrder['prototype']['windowRect']=function(){return this['createBattlerRect']($gameParty['maxBattleMembers'](),0x9,!![]);},Window_STB_TurnOrder[_0x28da48(0x3e6)]['initHomePositions']=function(_0x19bef7){const _0xfafef3=_0x28da48;this[_0xfafef3(0x3d5)]=this[_0xfafef3(0x241)]=_0x19bef7['x'],this[_0xfafef3(0x251)]=this[_0xfafef3(0x24c)]=_0x19bef7['y'],this[_0xfafef3(0x3a0)]=_0x19bef7['width'],this['_fullHeight']=_0x19bef7[_0xfafef3(0x3e4)],this[_0xfafef3(0x23c)]=0x0;},Window_STB_TurnOrder['prototype']['createBattlerRect']=function(_0x1a5119,_0x3c36a3,_0x2eaaca){const _0x54ff7a=_0x28da48,_0x313151=Window_STB_TurnOrder['Settings'],_0x5b0804=this[_0x54ff7a(0x30a)]()?_0x313151[_0x54ff7a(0x24d)]:_0x313151['MaxVertSprites'],_0x108adb=Math[_0x54ff7a(0x378)](_0x5b0804,_0x1a5119+_0x3c36a3),_0x25d87e=SceneManager['_scene']['_statusWindow'][_0x54ff7a(0x3e4)],_0x2c9810=SceneManager[_0x54ff7a(0x313)][_0x54ff7a(0x325)][_0x54ff7a(0x3e4)],_0x139e80=_0x313151[_0x54ff7a(0x26f)],_0x4dbbab=Graphics[_0x54ff7a(0x3e4)]-_0x25d87e-_0x2c9810;let _0x2c2f36=0x0,_0xc26d13=0x0,_0xfcdacc=0x0,_0x93500d=0x0;switch(_0x313151[_0x54ff7a(0x213)]){case'top':_0x2c2f36=_0x313151[_0x54ff7a(0x233)]*_0x108adb+_0x139e80,_0xc26d13=_0x313151[_0x54ff7a(0x2c0)],_0xfcdacc=Math['ceil']((Graphics[_0x54ff7a(0x3ed)]-_0x2c2f36)/0x2),_0x93500d=_0x313151[_0x54ff7a(0x2ed)];break;case _0x54ff7a(0x2e4):_0x2c2f36=_0x313151[_0x54ff7a(0x233)]*_0x108adb+_0x139e80,_0xc26d13=_0x313151['SpriteLength'],_0xfcdacc=Math[_0x54ff7a(0x343)]((Graphics[_0x54ff7a(0x3ed)]-_0x2c2f36)/0x2),_0x93500d=Graphics[_0x54ff7a(0x3e4)]-_0x25d87e-_0xc26d13-_0x313151[_0x54ff7a(0x2ed)];break;case _0x54ff7a(0x1f9):_0x2c2f36=_0x313151[_0x54ff7a(0x2c0)],_0xc26d13=_0x313151[_0x54ff7a(0x233)]*_0x108adb+_0x139e80,_0xfcdacc=_0x313151[_0x54ff7a(0x2ed)],_0x93500d=Math[_0x54ff7a(0x343)]((_0x4dbbab-_0xc26d13)/0x2),_0x93500d+=_0x2c9810;break;case _0x54ff7a(0x3cc):_0x2c2f36=_0x313151[_0x54ff7a(0x2c0)],_0xc26d13=_0x313151[_0x54ff7a(0x233)]*_0x108adb+_0x139e80,_0xfcdacc=Graphics[_0x54ff7a(0x3ed)]-_0x2c2f36-_0x313151['ScreenBuffer'],_0x93500d=Math[_0x54ff7a(0x343)]((_0x4dbbab-_0xc26d13)/0x2),_0x93500d+=_0x2c9810;break;}if(!_0x2eaaca){const _0x4e6e33=Window_STB_TurnOrder['Settings'][_0x54ff7a(0x264)];let _0x3a572c=Math[_0x54ff7a(0x378)](_0x5b0804,Math[_0x54ff7a(0x378)]($gameParty[_0x54ff7a(0x2b9)]()+0x8)-_0x108adb);switch(_0x313151[_0x54ff7a(0x213)]){case _0x54ff7a(0x283):case'bottom':_0x4e6e33&&('vvVNx'!==_0x54ff7a(0x2ff)?_0xfcdacc-=_0x3a572c*_0x313151['SpriteThin']:this[_0x54ff7a(0x253)]());break;}}return _0xfcdacc+=_0x313151[_0x54ff7a(0x254)],_0x93500d+=_0x313151['DisplayOffsetY'],new Rectangle(_0xfcdacc,_0x93500d,_0x2c2f36,_0xc26d13);},Window_STB_TurnOrder['prototype'][_0x28da48(0x26d)]=function(){this['padding']=0x0;},Window_STB_TurnOrder[_0x28da48(0x3e6)][_0x28da48(0x30a)]=function(){const _0x413b85=_0x28da48,_0x10a6c4=Window_STB_TurnOrder['Settings'],_0x641536=['top','bottom'][_0x413b85(0x249)](_0x10a6c4[_0x413b85(0x213)]);return _0x641536;},Window_STB_TurnOrder['prototype']['createBattlerSprites']=function(){const _0x127966=_0x28da48;this[_0x127966(0x2e9)]=new Sprite(),this[_0x127966(0x2ab)](this[_0x127966(0x2e9)]),this[_0x127966(0x3b6)]=[];for(let _0x33a473=0x0;_0x33a473<$gameParty[_0x127966(0x2b9)]();_0x33a473++){const _0xa9d766=new Sprite_STB_TurnOrder_Battler($gameParty,_0x33a473);this[_0x127966(0x2e9)][_0x127966(0x257)](_0xa9d766),this['_turnOrderContainer'][_0x127966(0x22b)](_0xa9d766);}for(let _0x49f196=0x0;_0x49f196<$gameTroop[_0x127966(0x1fe)]()[_0x127966(0x3a8)];_0x49f196++){const _0x774eb=new Sprite_STB_TurnOrder_Battler($gameTroop,_0x49f196);this[_0x127966(0x2e9)]['addChild'](_0x774eb),this[_0x127966(0x3b6)][_0x127966(0x22b)](_0x774eb);}},Window_STB_TurnOrder[_0x28da48(0x3e6)][_0x28da48(0x359)]=function(){const _0x500071=_0x28da48;Window_Base[_0x500071(0x3e6)][_0x500071(0x359)][_0x500071(0x32e)](this),this[_0x500071(0x27a)](),this['updatePosition'](),this[_0x500071(0x34c)](),this[_0x500071(0x3eb)](),this[_0x500071(0x2be)]();},Window_STB_TurnOrder[_0x28da48(0x3e6)]['updateHomePosition']=function(){const _0x2c9c3e=_0x28da48;if(this[_0x2c9c3e(0x23c)]>0x0){const _0x453478=this[_0x2c9c3e(0x23c)];this['_homeX']=(this[_0x2c9c3e(0x241)]*(_0x453478-0x1)+this[_0x2c9c3e(0x3d5)])/_0x453478,this[_0x2c9c3e(0x24c)]=(this[_0x2c9c3e(0x24c)]*(_0x453478-0x1)+this[_0x2c9c3e(0x251)])/_0x453478,this[_0x2c9c3e(0x23c)]--,this[_0x2c9c3e(0x23c)]<=0x0&&(this['_homeX']=this[_0x2c9c3e(0x3d5)],this[_0x2c9c3e(0x24c)]=this['_targetHomeY']);}},Window_STB_TurnOrder[_0x28da48(0x3e6)][_0x28da48(0x2a4)]=function(){const _0x2052f5=_0x28da48,_0x29d03b=Window_STB_TurnOrder[_0x2052f5(0x361)];if(_0x29d03b[_0x2052f5(0x213)]!=='top')return;if(!_0x29d03b['RepositionTopForHelp'])return;const _0x172323=SceneManager[_0x2052f5(0x313)][_0x2052f5(0x325)];if(!_0x172323)return;_0x172323[_0x2052f5(0x25e)]?_0x2052f5(0x268)===_0x2052f5(0x363)?this[_0x2052f5(0x253)]():(this['x']=this[_0x2052f5(0x241)]+(_0x29d03b[_0x2052f5(0x1f7)]||0x0),this['y']=this['_homeY']+(_0x29d03b[_0x2052f5(0x3cf)]||0x0)):(this['x']=this[_0x2052f5(0x241)],this['y']=this[_0x2052f5(0x24c)]);const _0x139cf0=SceneManager[_0x2052f5(0x313)]['_windowLayer'];Window_STB_TurnOrder[_0x2052f5(0x323)]===undefined&&(Window_STB_TurnOrder[_0x2052f5(0x323)]=Math[_0x2052f5(0x1f5)]((Graphics[_0x2052f5(0x3ed)]-Math[_0x2052f5(0x378)](Graphics['boxWidth'],_0x139cf0['width']))/0x2),Window_STB_TurnOrder['_ogWindowLayerY']=Math[_0x2052f5(0x1f5)]((Graphics[_0x2052f5(0x3e4)]-Math[_0x2052f5(0x378)](Graphics[_0x2052f5(0x230)],_0x139cf0['height']))/0x2)),this['x']+=_0x139cf0['x']-Window_STB_TurnOrder[_0x2052f5(0x323)],this['y']+=_0x139cf0['y']-Window_STB_TurnOrder[_0x2052f5(0x250)];},Window_STB_TurnOrder[_0x28da48(0x3e6)][_0x28da48(0x34c)]=function(){const _0x1fc42c=_0x28da48,_0x1b7fb0=Window_STB_TurnOrder['Settings'];if(['top']['includes'](_0x1b7fb0['DisplayPosition']))return;this['x']=this[_0x1fc42c(0x241)],this['y']=this[_0x1fc42c(0x24c)];const _0x39eca2=SceneManager[_0x1fc42c(0x313)][_0x1fc42c(0x393)];this['x']+=_0x39eca2['x'],this['y']+=_0x39eca2['y'];},Window_STB_TurnOrder[_0x28da48(0x3e6)][_0x28da48(0x3eb)]=function(){const _0x148078=_0x28da48;if(!this[_0x148078(0x2e9)])return;const _0x3eb892=this[_0x148078(0x2e9)][_0x148078(0x245)];if(!_0x3eb892)return;_0x3eb892['sort'](this[_0x148078(0x215)][_0x148078(0x3b0)](this));},Window_STB_TurnOrder[_0x28da48(0x3e6)]['compareBattlerSprites']=function(_0x1b1669,_0x2e3ed5){const _0x2e08cc=_0x28da48,_0x34de10=this['isHorz'](),_0xd64f88=Window_STB_TurnOrder[_0x2e08cc(0x361)][_0x2e08cc(0x264)];if(_0x34de10&&!_0xd64f88)return _0x1b1669['x']-_0x2e3ed5['x'];else{if(_0x34de10&&_0xd64f88)return _0x2e3ed5['x']-_0x1b1669['x'];else{if(!_0x34de10&&_0xd64f88)return _0x1b1669['y']-_0x2e3ed5['y'];else{if(!_0x34de10&&!_0xd64f88){if('ZtjIg'===_0x2e08cc(0x32a)){if(this[_0x2e08cc(0x3d4)]>0x0){const _0x2c3b8f=this[_0x2e08cc(0x3d4)];this[_0x2e08cc(0x3e3)]=(this[_0x2e08cc(0x3e3)]*(_0x2c3b8f-0x1)+this[_0x2e08cc(0x380)])/_0x2c3b8f,this['_fadeDuration']--,this[_0x2e08cc(0x3d4)]<=0x0&&(this[_0x2e08cc(0x307)](),this['_positionDuration']=0x0,this['updatePosition'](),this[_0x2e08cc(0x3e3)]=this[_0x2e08cc(0x380)]);}if(this[_0x2e08cc(0x25c)])return;_0xeec04c[_0x2e08cc(0x2b0)]===_0x2e08cc(0x2d2)&&(this[_0x2e08cc(0x25c)]=!![],this[_0x2e08cc(0x314)](0x0));}else return _0x2e3ed5['y']-_0x1b1669['y'];}}}}},Window_STB_TurnOrder[_0x28da48(0x3e6)]['updateVisibility']=function(){const _0x19602f=_0x28da48;this[_0x19602f(0x25e)]=$gameSystem[_0x19602f(0x2f3)]();},Window_STB_TurnOrder['prototype'][_0x28da48(0x235)]=function(_0x5cfd41){const _0xd918e2=_0x28da48;this[_0xd918e2(0x3b6)][_0xd918e2(0x371)]((_0x56609c,_0x56292a)=>{const _0x55aa32=_0xd918e2;return _0x55aa32(0x2c8)!==_0x55aa32(0x2c8)?(this[_0x55aa32(0x309)]===_0xccc9c8&&(this[_0x55aa32(0x309)]=this[_0x55aa32(0x209)]()),this[_0x55aa32(0x309)]):_0x56609c[_0x55aa32(0x2c4)]()-_0x56292a['containerPosition']();}),this['recalculateHome']();if(!_0x5cfd41)return;for(const _0x58c39e of this[_0xd918e2(0x3b6)]){if(!_0x58c39e)continue;_0x58c39e[_0xd918e2(0x359)](),_0x58c39e['_positionDuration']=0x0;}},Window_STB_TurnOrder[_0x28da48(0x3e6)][_0x28da48(0x2ef)]=function(){const _0x1f5312=_0x28da48;if(!this[_0x1f5312(0x30a)]())return;const _0x29fbfa=VisuMZ['BattleSystemSTB'][_0x1f5312(0x361)][_0x1f5312(0x312)];if(!_0x29fbfa[_0x1f5312(0x219)])return;const _0x40b59c=$gameParty['members']()[_0x1f5312(0x3f2)](_0x2dcdec=>_0x2dcdec&&_0x2dcdec['isAlive']()&&_0x2dcdec[_0x1f5312(0x34b)]())[_0x1f5312(0x3a8)],_0x44a958=$gameTroop['members']()[_0x1f5312(0x3f2)](_0x141242=>_0x141242&&_0x141242[_0x1f5312(0x1fd)]()&&_0x141242['isAppeared']())['length'],_0x348d6a=this[_0x1f5312(0x29d)](_0x40b59c,_0x44a958);this[_0x1f5312(0x3d5)]=_0x348d6a['x'],this[_0x1f5312(0x251)]=_0x348d6a['y'],(this[_0x1f5312(0x3d5)]!==this[_0x1f5312(0x241)]||this[_0x1f5312(0x251)]!==this[_0x1f5312(0x24c)])&&(this[_0x1f5312(0x23c)]=_0x29fbfa[_0x1f5312(0x3b8)]);};