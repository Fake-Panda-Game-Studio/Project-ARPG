//=============================================================================
// VisuStella MZ - Battle System - OTB - Order Turn Battle
// VisuMZ_2_BattleSystemOTB.js
//=============================================================================

var Imported = Imported || {};
Imported.VisuMZ_2_BattleSystemOTB = true;

var VisuMZ = VisuMZ || {};
VisuMZ.BattleSystemOTB = VisuMZ.BattleSystemOTB || {};
VisuMZ.BattleSystemOTB.version = 1.11;

//=============================================================================
 /*:
 * @target MZ
 * @plugindesc [RPG Maker MZ] [Tier 2] [Version 1.11] [BattleSystemOTB]
 * @author VisuStella
 * @url http://www.yanfly.moe/wiki/Battle_System_-_OTB_VisuStella_MZ
 * @base VisuMZ_0_CoreEngine
 * @base VisuMZ_1_BattleCore
 * @orderAfter VisuMZ_1_BattleCore
 *
 * @help
 * ============================================================================
 * Introduction
 * ============================================================================
 *
 * This plugin changes the RPG Maker MZ battle system to "Order Turn Battle",
 * a turn-based battle system where actions are executed immediately and the
 * orders for both the current and next turn are not only visible, but also
 * malleable. New mechanics are introduced where the player can manipulate the
 * turn order of an action's user or action's target in various ways they want.
 * 
 * The two Turn Orders are displayed at the top of the top of the screen to
 * give the player a clear understanding of who's turn it will be when it
 * becomes time to act, making it easier and viable for the player to formulate
 * strategies and adapt to the situation in battle.
 * 
 * *NOTE* To use this battle system, you will need the updated version of
 * VisuStella's Core Engine. Go into its Plugin Parameters and change the
 * "Battle System" plugin parameter to "otb".
 *
 * Features include all (but not limited to) the following:
 * 
 * * Utilizes the balanced AGI nature of the Default Turn Battle system.
 * * Allows for actions to execute immediately upon selection.
 * * Two Turn Order Displays appear at the top of the screen, giving the player
 *   an idea of who's turn it will be and when, for both the current turn and
 *   the next turn.
 * * Skills and Items can have an "Instant Use" effect, which allows them to
 *   perform an action immediately without using up a turn.
 * * Skills and Items can manipulate the turn order of the action's user or the
 *   action's target(s). This can apply to either the current turn or the next
 *   turn, depending on the notetags and/or action effects used.
 * * The Turn Order Display will give a preview on how turn orders will change
 *   upon specific skills and/or items being used.
 *
 * ============================================================================
 * Requirements
 * ============================================================================
 *
 * This plugin is made for RPG Maker MZ. This will not work in other iterations
 * of RPG Maker.
 *
 * ------ Required Plugin List ------
 *
 * * VisuMZ_0_CoreEngine
 * * VisuMZ_1_BattleCore
 *
 * This plugin requires the above listed plugins to be installed inside your
 * game's Plugin Manager list in order to work. You cannot start your game with
 * this plugin enabled without the listed plugins.
 *
 * ------ Tier 2 ------
 *
 * This plugin is a Tier 2 plugin. Place it under other plugins of lower tier
 * value on your Plugin Manager list (ie: 0, 1, 2, 3, 4, 5). This is to ensure
 * that your plugins will have the best compatibility with the rest of the
 * VisuStella MZ library.
 *
 * ============================================================================
 * Major Changes
 * ============================================================================
 *
 * This plugin adds some new hard-coded features to RPG Maker MZ's functions.
 * The following is a list of them.
 *
 * ---
 * 
 * Turn Order Displays
 * 
 * The Two Turn Order Displays will capture the battle's current and next turn
 * orders determined by the BattleManager. This feature does not overwrite any
 * functions, but the Turn Order Displays may or may not conflict with any
 * existing HUD elements that are already positioned on the screen. If so, you
 * can choose to offset the Turn Order Display or move it to a different part
 * of the screen through the plugin parameters.
 * 
 * ---
 * 
 * Agility
 * 
 * Agility behaves slightly different from normal when it comes to the Order
 * Turn Battle system. Aside from the first turn in battle, agility will always
 * calculate the turn order for the "Next Turn" when conducted. This means that
 * any changes to agility values will not have any effect on the next turn's
 * already established turn order.
 * 
 * However, this can be remedied by utilizing the notetags provided by this
 * plugin to alter the Next Turn orders for specific targets. In fact, for
 * skill and item "effects" that add AGI Buffs and/or Debuffs, the target's
 * turn position on the Turn Order Display will be manipulated in accordance.
 * This auto-conversion feature can be disabled in the Plugin Parameters.
 * 
 * ---
 * 
 * Action Speed
 * 
 * Because the Order Turn Battle system already calculates agility speeds
 * before selecting an action to perform, the effects of the actioon speed will
 * not work the same way it did with the default battle system. Instead, the
 * Action Speed will be sent through a formula to determine its effect on the
 * following turn, either pushing the user ahead in next turn's turn order
 * (with a positive speed value) or back (with a negative speed value).
 * 
 * This option can have its formula altered or straight up disabled in the
 * Plugin Parameters.
 * 
 * ---
 * 
 * Infinity Speed and Clamping
 * 
 * Since Action Speeds are decided in such a way, enemies that will survive a
 * stun state past two turns will have "Infinity" speed on the recovery turn,
 * allowing them to act first relative to the rest of the battle participants
 * in order to balance out the turns they've lost.
 * 
 * Enemies with "Infinity" speed cannot be overtaken through turn order
 * manipulation while they are on the "Next Turn" order. If anything, battlers
 * who shift their turn order faster will be just trailing behind them, thus
 * the "clamping" effect. However if this occurs during the "Current Turn"
 * order, all is fair game and any battler can overtake them. Plan out your
 * battle system effects carefully with these rules in mind.
 * 
 * If you do not like the idea of Infinity Speed and/or Clamping, you can turn
 * them off in the Plugin Parameters.
 * 
 * This effect does not affect stun states that last only one turn. The effect
 * will only occur with stun states that last 2 turns or more.
 * 
 * ---
 * 
 * Instant Use
 * 
 * Skills and Items can have an "Instant Use" property which allows them to be
 * used immediately without consuming a turn. This can be used for actions that
 * otherwise do not warrant a whole turn. These can be used for minor buffs,
 * debuffs, toggles, etc.
 * 
 * ---
 * 
 * Force Actions
 * 
 * Due to how OTB behaves, Force Actions have be adjusted to fit the battle
 * system. With other battle systems, force actions are added into a hidden
 * queue that would act upon after the current battler finishes his/her current
 * action. The new changes made with force actions is that they now appear on
 * the queue visibly.
 * 
 * ---
 *
 * ============================================================================
 * VisuStella MZ Compatibility
 * ============================================================================
 *
 * While this plugin is compatible with the majority of the VisuStella MZ
 * plugin library, it is not compatible with specific plugins or specific
 * features. This section will highlight the main plugins/features that will
 * not be compatible with this plugin or put focus on how the make certain
 * features compatible.
 *
 * ---
 * 
 * VisuMZ_2_PartySystem
 * 
 * In battle, the player cannot change entire parties at once from the Party
 * Command Window. The feature will be unaccessible while Order Turn Battle is
 * in play. However, the player can still change party members through the
 * Actor Command Window by having actors replace other actors. Party changing
 * is also available through battle events, Common Events, and script calls.
 * 
 * ---
 *
 * ============================================================================
 * Notetags
 * ============================================================================
 *
 * The following are notetags that have been added through this plugin. These
 * notetags will not work with your game if this plugin is OFF or not present.
 *
 * ---
 * 
 * === General OTB-Related Notetags ===
 * 
 * These notetags are general purpose notetags that have became available
 * through this plugin.
 * 
 * ---
 * 
 * <OTB Help>
 *  description
 *  description
 * </OTB Help>
 *
 * - Used for: Skill, Item Notetags
 * - If your game happens to support the ability to change battle systems, this
 *   notetag lets you change how the skill/item's help description text will
 *   look under OTB.
 * - This is primarily used if the skill behaves differently in OTB versus any
 *   other battle system.
 * - Replace 'description' with help text that's only displayed if the game's
 *   battle system is set to OTB.
 *
 * ---
 * 
 * === OTB Turn Order Display-Related Notetags ===
 * 
 * These notetags affect the OTB Turn Order Display
 * 
 * ---
 *
 * <OTB Turn Order Icon: x>
 *
 * - Used for: Actor, Enemy Notetags
 * - Changes the slot graphic used for the battler to a specific icon.
 * - Replace 'x' with the icon index to be used.
 * 
 * ---
 *
 * <OTB Turn Order Face: filename, index>
 *
 * - Used for: Actor, Enemy Notetags
 * - Changes the slot graphic used for the enemy to a specific face.
 * - Replace 'filename' with the filename of the image.
 *   - Do not include the file extension.
 * - Replace 'index' with the index of the face. Index values start at 0.
 * - Example: <OTB Turn Order Face: Monster, 1>
 * 
 * ---
 * 
 * === Instant Use-Related Notetags ===
 * 
 * ---
 *
 * <OTB Instant>
 * <OTB Instant Use>
 * <OTB Instant Cast>
 *
 * - Used for: Skill, Item Notetags
 * - Allows the skill/item to be used immediately without consuming a turn.
 *
 * ---
 * 
 * === Added Action Notetags ===
 * 
 * ---
 * 
 * <OTB User Add Current Turn Actions: x>
 * <OTB User Add Next Turn Actions: x>
 * 
 * - Used for: Skill, Item Notetags
 * - Adds extra actions for the user to perform during the current/next turn.
 *   - Added actions will go towards the back of the action list.
 *   - Multi-hit skills/items will trigger this effect multiple times.
 * - Replace 'x' with a number representing the amount of actions to add.
 * 
 * ---
 * 
 * <OTB Target Add Current Turn Actions: x>
 * <OTB Target Add Next Turn Actions: x>
 * 
 * - Used for: Skill, Item Notetags
 * - Adds extra actions for the target to perform during the current/next turn.
 *   - Added actions will go towards the back of the action list.
 *   - Multi-hit skills/items will trigger this effect multiple times.
 * - Replace 'x' with a number representing the amount of actions to add.
 * 
 * ---
 * 
 * === Turn Order Manipulation-Related Notetags ===
 * 
 * ---
 *
 * <OTB User Current Turn: +x>
 * <OTB User Next Turn: +x>
 * <OTB User Follow Turn: +x>
 *
 * <OTB User Current Turn: -x>
 * <OTB User Next Turn: -x>
 * <OTB User Follow Turn: -x>
 *
 * - Used for: Skill, Item Notetags
 * - Changes the user's position in the turn order for the current turn, next
 *   turn, or whichever turn is following.
 * - If using the "Follow" variant, if the user has actions left for the
 *   current turn, it will affect the current turn. If not, it affects the
 *   next turn instead.
 * - Replace 'x' with a number representing the number of slots to change.
 *   - Negative numbers move the user closer to the front.
 *   - Positive numbers move the user towards the back.
 * - This effect only occurs once per skill/item use and at the start of the
 *   action when initializing the skill/item.
 *
 * ---
 *
 * <OTB Target Current Turn: +x>
 * <OTB Target Next Turn: +x>
 * <OTB Target Follow Turn: +x>
 *
 * <OTB Target Current Turn: -x>
 * <OTB Target Next Turn: -x>
 * <OTB Target Follow Turn: -x>
 *
 * - Used for: Skill, Item Notetags
 * - Changes the target's position in the turn order for the current turn, next
 *   turn, or whichever turn is following.
 * - If using the "Follow" variant, if the target has actions left for the
 *   current turn, it will affect the current turn. If not, it affects the
 *   next turn instead.
 * - Replace 'x' with a number representing the number of slots to change.
 *   - Negative numbers move the target closer to the front.
 *   - Positive numbers move the target towards the back.
 * - This effect will occur as many times as there are successfully connected
 *   hits for each target, meaning a target can have its turn order shifted
 *   multiple times.
 * - These are best used with single target skills/items as multi-target skills
 *   may shift multiple targets back and forth with each other if they are
 *   adjacent to one another.
 *
 * ---
 *
 * ============================================================================
 * Plugin Commands
 * ============================================================================
 *
 * The following are Plugin Commands that come with this plugin. They can be
 * accessed through the Plugin Command event command.
 *
 * ---
 * 
 * === Actor Plugin Commands ===
 * 
 * ---
 *
 * Actor: Change OTB Turn Order Icon
 * - Changes the icons used for the specific actor(s) on the OTB Turn Order.
 *
 *   Actor ID(s):
 *   - Select which Actor ID(s) to affect.
 *
 *   Icon:
 *   - Changes the graphic to this icon.
 *
 * ---
 *
 * Actor: Change OTB Turn Order Face
 * - Changes the faces used for the specific actor(s) on the OTB Turn Order.
 *
 *   Actor ID(s):
 *   - Select which Actor ID(s) to affect.
 *
 *   Face Name:
 *   - This is the filename for the target face graphic.
 *
 *   Face Index:
 *   - This is the index for the target face graphic.
 *
 * ---
 *
 * Actor: Clear OTB Turn Order Graphic
 * - Clears the OTB Turn Order graphics for the actor(s).
 * - The settings will revert to the Plugin Parameter settings.
 *
 *   Actor ID(s):
 *   - Select which Actor ID(s) to affect.
 *
 * ---
 * 
 * === Enemy Plugin Commands ===
 * 
 * ---
 *
 * Enemy: Change OTB Turn Order Icon
 * - Changes the icons used for the specific enemy(ies) on the OTB Turn Order.
 *
 *   Enemy Index(es):
 *   - Select which enemy index(es) to affect.
 *
 *   Icon:
 *   - Changes the graphic to this icon.
 *
 * ---
 *
 * Enemy: Change OTB Turn Order Face
 * - Changes the faces used for the specific enemy(ies) on the OTB Turn Order.
 *
 *   Enemy Index(es):
 *   - Select which enemy index(es) to affect.
 *
 *   Face Name:
 *   - This is the filename for the target face graphic.
 *
 *   Face Index:
 *   - This is the index for the target face graphic.
 *
 * ---
 *
 * Enemy: Clear OTB Turn Order Graphic
 * - Clears the OTB Turn Order graphics for the enemy(ies).
 * - The settings will revert to the Plugin Parameter settings.
 *
 *   Enemy Index(es):
 *   - Select which enemy index(es) to affect.
 *
 * ---
 * 
 * === System Plugin Commands ===
 * 
 * ---
 *
 * System: OTB Turn Order Visibility
 * - Determine the visibility of the OTB Turn Order Display.
 *
 *   Visibility:
 *   - Changes the visibility of the OTB Turn Order Display.
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Conversion Settings
 * ============================================================================
 *
 * Automatically converts specific mechanics to fit OTB.
 *
 * ---
 *
 * Buffs
 * 
 *   AGI Buff => Current:
 *   - Auto-convert AGI Buff effects for Items/Skills to speed up target's
 *     current Turn Order?
 * 
 *   AGI Buff => Next:
 *   - Auto-convert AGI Buff effects for Items/Skills to speed up target's
 *     next Turn Order?
 *
 * ---
 *
 * Debuffs
 * 
 *   AGI Debuff => Current:
 *   - Auto-convert AGI Debuff effects for Items/Skills to speed up target's
 *     current Turn Order?
 * 
 *   AGI Debuff => Next:
 *   - Auto-convert AGI Debuff effects for Items/Skills to speed up target's
 *     next Turn Order?
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Mechanics Settings
 * ============================================================================
 *
 * Determines the mechanics of Battle System OTB. These range from how Action
 * Times are handled to speed.
 *
 * ---
 *
 * Action Times+
 * 
 *   Enable Action Times?:
 *   - Enable Action Times+ to have an effect on OTB?
 * 
 *     Randomize Order?:
 *     - If enabled, randomize the action order for added actions?
 *
 * ---
 *
 * Speed
 * 
 *   Allow Random Speed?:
 *   - Allow speed to be randomized base off the user's AGI?
 * 
 *   Post-Stun Infinity?:
 *   - After a 2+ turn stun states, battlers have infinity speed for their
 *     recovery turn.
 *   - Once again, this only applies to stun states that last 2+ turns.
 * 
 *     Infinity Clamp?:
 *     - Prevents turn order manipulation from going faster than infinity
 *       speed battlers.
 * 
 *   JS: Initial Speed:
 *   - Code used to calculate initial speed at the start of battle.
 * 
 *   JS: Speed => Order:
 *   - Code used to calculate how action speeds alter next turn's order.
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Turn Order Display
 * ============================================================================
 *
 * Turn Order Display settings used for Battle System OTB. These adjust how the
 * two visible turn orders appears in-game.
 *
 * ---
 *
 * General
 * 
 *   Display Position:
 *   - Select where the Turn Order will appear on the screen.
 *     - Top
 *     - Bottom
 * 
 *     Offset X:
 *     - How much to offset the X coordinate by.
 *     - Negative: left. Positive: right.
 * 
 *     Offset Y:
 *     - How much to offset the Y coordinate by.
 *     - Negative: up. Positive: down.
 * 
 *   Reposition for Help?:
 *   - If the display position is at the top, reposition the display when the
 *     help window is open?
 * 
 *     Offset X:
 *     - Reposition the display's X coordinates by this much when the Help
 *       Window is visible.
 * 
 *     Offset Y:
 *     - Reposition the display's Y coordinates by this much when the Help
 *       Window is visible.
 * 
 *   Forward Direction:
 *   - Decide on the direction of the Turn Order.
 *     - Left to Right
 *     - Right to Left
 * 
 *   Subject Distance:
 *   - How far do you want the currently active battler to distance itself from
 *     the rest of the Turn Order?
 * 
 *   Screen Buffer:
 *   - What distance do you want the display to be away from the edge of the
 *     screen by?
 * 
 * ---
 * 
 * UI Background
 * 
 *   Background Style:
 *   - Select the style you want for the background.
 *     - fill
 *     - gradient
 *     - image
 *     - transparent
 * 
 *   Image Filename:
 *   - When using the "image" style, select an image from /img/system/ as the
 *     background image.
 * 
 *     Offset X:
 *     - How much do you want to offset the Background Image's X position?
 * 
 *     Offset Y:
 *     - How much do you want to offset the Background Image's Y position?
 * 
 * ---
 * 
 * UI Text
 * 
 *   Font Size:
 *   - The font size used for parameter values.
 * 
 *   Active Battler Text:
 *   - Text used to display the active battler.
 *   - This text will always be center aligned.
 * 
 *     Offset X:
 *     - How much do you want to offset the text's X position?
 * 
 *     Offset Y:
 *     - How much do you want to offset the text's Y position?
 * 
 *   Current Turn Text:
 *   - Text used to display the current turn.
 * 
 *     Offset X:
 *     - How much do you want to offset the text's X position?
 * 
 *     Offset Y:
 *     - How much do you want to offset the text's Y position?
 * 
 *   Next Turn Text:
 *   - Text used to display the next turn.
 * 
 *     Offset X:
 *     - How much do you want to offset the text's X position?
 * 
 *     Offset Y:
 *     - How much do you want to offset the text's Y position?
 * 
 *   Text Align:
 *   - Text alignment for the Current and Next Turn texts?
 *     - auto
 *     - left
 *     - center
 *     - right
 * 
 * ---
 * 
 * Slots
 * 
 *   Width:
 *   - How many pixels wide should the slots be on the Turn Order display?
 * 
 *   Height:
 *   - How many pixels tall should the slots be on the Turn Order display?
 * 
 *   Preview Scale:
 *   - How much do you want to scale the preview sprites by?
 *   - Use a number between 0 and 1 for the best results.
 * 
 *     Offset X:
 *     - How much do you want to offset the Preview Sprites' X position?
 * 
 *     Offset Y:
 *     - How much do you want to offset the Preview Sprites' Y position?
 * 
 *   Update Frames:
 *   - How many frames should it take for the slots to update their
 *     positions by?
 *
 * ---
 *
 * Slot Border
 * 
 *   Show Border?:
 *   - Show borders for the slot sprites?
 * 
 *   Border Thickness:
 *   - How many pixels thick should the colored portion of the border be?
 * 
 *   Actors
 *   Enemies
 * 
 *     Border Color:
 *     - Use #rrggbb for custom colors or regular numbers for text colors
 *       from the Window Skin.
 * 
 *       Preview Version:
 *       - A different setting is used for the preview version.
 * 
 *     Border Skin:
 *     - Optional. Place a skin on the actor/enemy borders instead of
 *       rendering them?
 * 
 *       Preview Version:
 *       - A different setting is used for the preview version.
 * 
 * ---
 * 
 * Slot Sprites
 * 
 *   Actors
 * 
 *     Sprite Type:
 *     - Select the type of sprite used for the actor graphic.
 *     - Face Graphic - Show the actor's face.
 *     - Icon - Show a specified icon.
 *     - Sideview Actor - Show the actor's sideview battler.
 * 
 *     Default Icon:
 *     - Which icon do you want to use for actors by default?
 * 
 *   Enemies
 * 
 *     Sprite Type:
 *     - Select the type of sprite used for the enemy graphic.
 *     - Face Graphic - Show a specified face graphic.
 *     - Icon - Show a specified icon.
 *     - Enemy - Show the enemy's graphic or sideview battler.
 * 
 *     Default Face Name:
 *     - Use this default face graphic if there is no specified face.
 * 
 *     Default Face Index:
 *     - Use this default face index if there is no specified index.
 * 
 *     Default Icon:
 *     - Which icon do you want to use for enemies by default?
 * 
 *     Match Hue?:
 *     - Match the hue for enemy battlers?
 *     - Does not apply if there's a sideview battler.
 *
 * ---
 *
 * Slot Letter
 * 
 *   Show Enemy Letter?:
 *   - Show the enemy's letter on the slot sprite?
 * 
 *   Font Name:
 *   - The font name used for the text of the Letter.
 *   - Leave empty to use the default game's font.
 * 
 *   Font Size:
 *   - The font size used for the text of the Letter.
 *
 * ---
 *
 * Slot Background
 * 
 *   Show Background?:
 *   - Show the background on the slot sprite?
 * 
 *   Actors
 *   Enemies
 * 
 *     Background Color 1:
 *     Background Color 2:
 *     - Use #rrggbb for custom colors or regular numbers for text colors
 *       from the Window Skin.
 * 
 *       Preview Version:
 *       - A different setting is used for the preview version.
 * 
 *     Background Skin:
 *     - Optional. Use a skin for the actor background instead of
 *       rendering them?
 * 
 *       Preview Version:
 *       - A different setting is used for the preview version.
 *
 * ---
 *
 * ============================================================================
 * Terms of Use
 * ============================================================================
 *
 * 1. These plugins may be used in free or commercial games provided that they
 * have been acquired through legitimate means at VisuStella.com and/or any
 * other official approved VisuStella sources. Exceptions and special
 * circumstances that may prohibit usage will be listed on VisuStella.com.
 * 
 * 2. All of the listed coders found in the Credits section of this plugin must
 * be given credit in your games or credited as a collective under the name:
 * "VisuStella".
 * 
 * 3. You may edit the source code to suit your needs, so long as you do not
 * claim the source code belongs to you. VisuStella also does not take
 * responsibility for the plugin if any changes have been made to the plugin's
 * code, nor does VisuStella take responsibility for user-provided custom code
 * used for custom control effects including advanced JavaScript notetags
 * and/or plugin parameters that allow custom JavaScript code.
 * 
 * 4. You may NOT redistribute these plugins nor take code from this plugin to
 * use as your own. These plugins and their code are only to be downloaded from
 * VisuStella.com and other official/approved VisuStella sources. A list of
 * official/approved sources can also be found on VisuStella.com.
 *
 * 5. VisuStella is not responsible for problems found in your game due to
 * unintended usage, incompatibility problems with plugins outside of the
 * VisuStella MZ library, plugin versions that aren't up to date, nor
 * responsible for the proper working of compatibility patches made by any
 * third parties. VisuStella is not responsible for errors caused by any
 * user-provided custom code used for custom control effects including advanced
 * JavaScript notetags and/or plugin parameters that allow JavaScript code.
 *
 * 6. If a compatibility patch needs to be made through a third party that is
 * unaffiliated with VisuStella that involves using code from the VisuStella MZ
 * library, contact must be made with a member from VisuStella and have it
 * approved. The patch would be placed on VisuStella.com as a free download
 * to the public. Such patches cannot be sold for monetary gain, including
 * commissions, crowdfunding, and/or donations.
 * 
 * 7. If this VisuStella MZ plugin is a paid product, all project team members
 * must purchase their own individual copies of the paid product if they are to
 * use it. Usage includes working on related game mechanics, managing related
 * code, and/or using related Plugin Commands and features. Redistribution of
 * the plugin and/or its code to other members of the team is NOT allowed
 * unless they own the plugin itself as that conflicts with Article 4.
 * 
 * 8. Any extensions and/or addendums made to this plugin's Terms of Use can be
 * found on VisuStella.com and must be followed.
 *
 * ============================================================================
 * Credits
 * ============================================================================
 * 
 * If you are using this plugin, credit the following people in your game:
 * 
 * Team VisuStella
 * * Yanfly
 * * Arisu
 * * Olivia
 * * Irina
 *
 * ============================================================================
 * Changelog
 * ============================================================================
 * 
 * Version 1.11: August 18, 2022
 * * Bug Fixes!
 * ** Fixed bugs that caused the OTB Turn Order faces and icons to not change
 *    properly for actors and enemies.
 * 
 * Version 1.10: July 7, 2022
 * * Feature Update!
 * ** When the "Recover All" event command revives a dead unit, that revived
 *    unit can gain actions back if all other conditions are met. Update made
 *    by Olivia.
 * 
 * Version 1.09: June 2, 2022
 * * Documentation Update!
 * ** Added "Force Actions" to "Major Updates" section.
 * *** Due to how OTB behaves, Force Actions have be adjusted to fit the battle
 *     system. With other battle systems, force actions are added into a hidden
 *     queue that would act upon after the current battler finishes his/her
 *     current action. The new changes made with force actions is that they now
 *     appear on the queue visibly.
 * * Bug Fixes!
 * ** Fixed a bug that caused Forced Actions to not work properly while in OTB.
 *    Changes made to Forced Actions will now insert new actions at the front
 *    of the current action queue. Fix made by Olivia.
 * 
 * Version 1.08: March 10, 2022
 * * Feature Update!
 * ** OTB Instant Actions should now appear in the turn order in a more
 *    sensible fashion. Update made by Olivia.
 * 
 * Version 1.07: February 24, 2022
 * * Optimization Update!
 * ** Plugin should run more optimized.
 * 
 * Version 1.06: November 11, 2021
 * * Documentation Update!
 * ** Help file updated for new features.
 * * New Features!
 * ** New notetags added by Olivia:
 * *** <OTB User Add Current Turn Actions: x>
 * *** <OTB User Add Next Turn Actions: x>
 * *** <OTB Target Add Current Turn Actions: x>
 * *** <OTB Target Add Next Turn Actions: x>
 * **** Adds extra actions for the user/target to perform during the
 *      current/next turn.
 * **** Added actions will go towards the back of the action list.
 * **** Multi-hit skills/items will trigger this effect multiple times.
 * 
 * Version 1.05: October 28, 2021
 * * Bug Fixes!
 * ** Turn Order display will no longer appear at differing X and Y positions
 *    when using specific battle layouts. Update made by Olivia.
 * 
 * Version 1.04: August 6, 2021
 * * Bug Fixes!
 * ** Enemies with multiple actions will no longer step forward when it's not
 *    their turn. Fix made by Olivia.
 * 
 * Version 1.03: June 25, 2021
 * * Optimization Update!
 * ** Plugin should run more optimized.
 * 
 * Version 1.02: April 16, 2021
 * * Bug Fixes!
 * ** Post-stun infinity clamping should now be adjusted properly for
 *    previewing turn order changes.
 * 
 * Version 1.01: April 9, 2021
 * * Bug Fixes!
 * ** Subsequent battles will properly reset the turn order. Fix by Olivia.
 * 
 * Version 1.00 Official Release Date: April 26, 2021
 * * Finished Plugin!
 *
 * ============================================================================
 * End of Helpfile
 * ============================================================================
 *
 * @ --------------------------------------------------------------------------
 *
 * @command OtbTurnOrderActorIcon
 * @text Actor: Change OTB Turn Order Icon
 * @desc Changes the icons used for the specific actor(s) on the OTB Turn Order.
 *
 * @arg Actors:arraynum
 * @text Actor ID(s)
 * @type actor[]
 * @desc Select which Actor ID(s) to affect.
 * @default ["1"]
 *
 * @arg IconIndex:num
 * @text Icon
 * @desc Changes the graphic to this icon.
 * @default 84
 *
 * @ --------------------------------------------------------------------------
 *
 * @command OtbTurnOrderActorFace
 * @text Actor: Change OTB Turn Order Face
 * @desc Changes the faces used for the specific actor(s) on the OTB Turn Order.
 *
 * @arg Actors:arraynum
 * @text Actor ID(s)
 * @type actor[]
 * @desc Select which Actor ID(s) to affect.
 * @default ["1"]
 *
 * @arg FaceName:str
 * @text Face Name
 * @type file
 * @dir img/faces/
 * @desc This is the filename for the target face graphic.
 * @default Actor1
 *
 * @arg FaceIndex:num
 * @text Face Index
 * @type number
 * @desc This is the index for the target face graphic.
 * @default 0
 *
 * @ --------------------------------------------------------------------------
 *
 * @command OtbTurnOrderClearActorGraphic
 * @text Actor: Clear OTB Turn Order Graphic
 * @desc Clears the OTB Turn Order graphics for the actor(s).
 * The settings will revert to the Plugin Parameter settings.
 *
 * @arg Actors:arraynum
 * @text Actor ID(s)
 * @type actor[]
 * @desc Select which Actor ID(s) to affect.
 * @default ["1"]
 *
 * @ --------------------------------------------------------------------------
 *
 * @command OtbTurnOrderEnemyIcon
 * @text Enemy: Change OTB Turn Order Icon
 * @desc Changes the icons used for the specific enemy(ies) on the OTB Turn Order.
 *
 * @arg Enemies:arraynum
 * @text Enemy Index(es)
 * @type number[]
 * @desc Select which enemy index(es) to affect.
 * @default ["1"]
 *
 * @arg IconIndex:num
 * @text Icon
 * @desc Changes the graphic to this icon.
 * @default 298
 *
 * @ --------------------------------------------------------------------------
 *
 * @command OtbTurnOrderEnemyFace
 * @text Enemy: Change OTB Turn Order Face
 * @desc Changes the faces used for the specific enemy(ies) on the OTB Turn Order.
 *
 * @arg Enemies:arraynum
 * @text Enemy Index(es)
 * @type number[]
 * @desc Select which enemy index(es) to affect.
 * @default ["1"]
 *
 * @arg FaceName:str
 * @text Face Name
 * @parent EnemySprite
 * @type file
 * @dir img/faces/
 * @desc This is the filename for the target face graphic.
 * @default Monster
 *
 * @arg FaceIndex:num
 * @text Face Index
 * @parent EnemySprite
 * @type number
 * @desc This is the index for the target face graphic.
 * @default 1
 *
 * @ --------------------------------------------------------------------------
 *
 * @command OtbTurnOrderClearEnemyGraphic
 * @text Enemy: Clear OTB Turn Order Graphic
 * @desc Clears the OTB Turn Order graphics for the enemy(ies).
 * The settings will revert to the Plugin Parameter settings.
 *
 * @arg Enemies:arraynum
 * @text Enemy Index(es)
 * @type number[]
 * @desc Select which enemy index(es) to affect.
 * @default ["1"]
 *
 * @ --------------------------------------------------------------------------
 *
 * @command SystemTurnOrderVisibility
 * @text System: OTB Turn Order Visibility
 * @desc Determine the visibility of the OTB Turn Order Display.
 *
 * @arg Visible:eval
 * @text Visibility
 * @type boolean
 * @on Visible
 * @off Hidden
 * @desc Changes the visibility of the OTB Turn Order Display.
 * @default true
 *
 * @ --------------------------------------------------------------------------
 *
 * @ ==========================================================================
 * @ Plugin Parameters
 * @ ==========================================================================
 *
 * @param BreakHead
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param BattleSystemOTB
 * @default Plugin Parameters
 *
 * @param ATTENTION
 * @default READ THE HELP FILE
 *
 * @param BreakSettings
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param Conversion:struct
 * @text Conversion Settings
 * @type struct<Conversion>
 * @desc Automatically converts specific mechanics to fit OTB.
 * @default {"Buffs":"","ConvertAgiBuffCurrent:eval":"true","ConvertAgiBuffNext:eval":"true","Debuffs":"","ConvertAgiDebuffCurrent:eval":"true","ConvertAgiDebuffNext:eval":"true"}
 *
 * @param Mechanics:struct
 * @text Mechanics Settings
 * @type struct<Mechanics>
 * @desc Determines the mechanics of Battle System OTB.
 * @default {"Actions":"","EnableActionTimes:eval":"true","RandomizeActionTimesOrder:eval":"true","Speed":"","AllowRandomSpeed:eval":"false","PostStunInfinitySpeed:eval":"true","InfinityClamp:eval":"true","InitialSpeedJS:func":"\"// Declare Constants\\nconst agi = this.subject().agi;\\n\\n// Create Speed\\nlet speed = agi;\\nif (this.allowRandomSpeed()) {\\n    speed += Math.randomInt(Math.floor(5 + agi / 4));\\n}\\n\\n// Return Speed\\nreturn speed;\"","ConvertSpeedJS:func":"\"// Declare Constants\\nconst item = this.item();\\nconst modifier = 50;\\n\\n// Calculate Order Slots Changed\\nlet change = item.speed / (-modifier);\\nchange = (change >= 0) ? Math.ceil(change) : Math.floor(change);\\n\\n// Return Change\\nreturn change || 0;\""}
 *
 * @param TurnOrder:struct
 * @text Turn Order Display
 * @type struct<TurnOrder>
 * @desc Turn Order Display settings used for Battle System OTB.
 * @default {"General":"","DisplayPosition:str":"top","DisplayOffsetX:num":"0","DisplayOffsetY:num":"0","RepositionTopForHelp:eval":"true","RepositionTopHelpX:num":"+0","RepositionTopHelpY:num":"+96","RepositionLogWindow:eval":"true","LogWindowOffsetY:num":"+0","OrderDirection:eval":"false","SubjectDistance:num":"16","ScreenBuffer:num":"36","UiBackground":"","BgDimStyle:str":"gradient","BgImageFilename:str":"","BgImageOffsetX:num":"+0","BgImageOffsetY:num":"+0","UiText":"","UiFontSize:num":"16","UiSubjectText:str":"★","UiSubjectOffsetX:num":"+0","UiSubjectOffsetY:num":"-6","UiCurrentText:str":"✦CURRENT TURN✦","UiCurrentOffsetX:num":"+6","UiCurrentOffsetY:num":"-6","UiNextText:str":"✧NEXT TURN✧","UiNextOffsetX:num":"+6","UiNextOffsetY:num":"-6","UiAlignment:str":"auto","Slots":"","SpriteThin:num":"72","SpriteLength:num":"72","PreviewScale:num":"0.5","PreviewOffsetX:num":"+0","PreviewOffsetY:num":"+0","UpdateFrames:num":"24","Border":"","ShowMarkerBorder:eval":"true","BorderActor":"","ActorBorderColor:str":"4","PreviewActorBorderColor:str":"0","ActorSystemBorder:str":"","PreviewActorSystemBorder:str":"","BorderEnemy":"","EnemyBorderColor:str":"2","PreviewEnemyBorderColor:str":"0","EnemySystemBorder:str":"","PreviewEnemySystemBorder:str":"","BorderThickness:num":"2","Sprite":"","ActorSprite":"","ActorBattlerType:str":"face","ActorBattlerIcon:num":"84","EnemySprite":"","EnemyBattlerType:str":"enemy","EnemyBattlerFaceName:str":"Monster","EnemyBattlerFaceIndex:num":"1","EnemyBattlerIcon:num":"298","EnemyBattlerMatchHue:eval":"true","Letter":"","EnemyBattlerDrawLetter:eval":"true","EnemyBattlerFontFace:str":"","EnemyBattlerFontSize:num":"16","Background":"","ShowMarkerBg:eval":"true","BackgroundActor":"","ActorBgColor1:str":"19","PreviewActorBgColor1:str":"19","ActorBgColor2:str":"9","PreviewActorBgColor2:str":"0","ActorSystemBg:str":"","PreviewActorSystemBg:str":"","BackgroundEnemy":"","EnemyBgColor1:str":"19","PreviewEnemyBgColor1:str":"19","EnemyBgColor2:str":"18","PreviewEnemyBgColor2:str":"0","EnemySystemBg:str":"","PreviewEnemySystemBg:str":""}
 *
 * @param BreakEnd1
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param End Of
 * @default Plugin Parameters
 *
 * @param BreakEnd2
 * @text --------------------------
 * @default ----------------------------------
 *
 */
/* ----------------------------------------------------------------------------
 * Conversion Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Conversion:
 * 
 * @param Buffs
 *
 * @param ConvertAgiBuffCurrent:eval
 * @text AGI Buff => Current
 * @parent Buffs
 * @type boolean
 * @on Convert
 * @off Don't Convert
 * @desc Auto-convert AGI Buff effects for Items/Skills to speed up target's current Turn Order?
 * @default true
 *
 * @param ConvertAgiBuffNext:eval
 * @text AGI Buff => Next
 * @parent Buffs
 * @type boolean
 * @on Convert
 * @off Don't Convert
 * @desc Auto-convert AGI Buff effects for Items/Skills to speed up target's next Turn Order?
 * @default true
 * 
 * @param Debuffs
 *
 * @param ConvertAgiDebuffCurrent:eval
 * @text AGI Debuff => Current
 * @parent Debuffs
 * @type boolean
 * @on Convert
 * @off Don't Convert
 * @desc Auto-convert AGI Debuff effects for Items/Skills to speed up target's current Turn Order?
 * @default true
 *
 * @param ConvertAgiDebuffNext:eval
 * @text AGI Debuff => Next
 * @parent Debuffs
 * @type boolean
 * @on Convert
 * @off Don't Convert
 * @desc Auto-convert AGI Debuff effects for Items/Skills to speed up target's next Turn Order?
 * @default true
 *
 */
/* ----------------------------------------------------------------------------
 * Mechanics Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Mechanics:
 *
 * @param Actions
 * @text Action Times+
 *
 * @param EnableActionTimes:eval
 * @text Enable Action Times?
 * @parent Actions
 * @type boolean
 * @on Enable
 * @off Disable
 * @desc Enable Action Times+ to have an effect on OTB?
 * @default true
 *
 * @param RandomizeActionTimesOrder:eval
 * @text Randomize Order?
 * @parent EnableActionTimes:eval
 * @type boolean
 * @on Randomize
 * @off Clumped
 * @desc If enabled, randomize the action order for added actions?
 * @default true
 * 
 * @param Speed
 *
 * @param AllowRandomSpeed:eval
 * @text Allow Random Speed?
 * @parent Speed
 * @type boolean
 * @on Allow
 * @off Disable
 * @desc Allow speed to be randomized base off the user's AGI?
 * @default false
 *
 * @param PostStunInfinitySpeed:eval
 * @text Post-Stun Infinity?
 * @parent Speed
 * @type boolean
 * @on Infinity
 * @off Normal
 * @desc After a 2+ turn stun states, battlers have infinity speed for their recovery turn.
 * @default true
 *
 * @param InfinityClamp:eval
 * @text Infinity Clamp?
 * @parent PostStunInfinitySpeed:eval
 * @type boolean
 * @on Enable Clamp
 * @off Disable Clamp
 * @desc Prevents turn order manipulation from going faster than infinity speed battlers.
 * @default true
 *
 * @param InitialSpeedJS:func
 * @text JS: Initial Speed
 * @parent Speed
 * @type note
 * @desc Code used to calculate initial speed at the start of battle.
 * @default "// Declare Constants\nconst agi = this.subject().agi;\n\n// Create Speed\nlet speed = agi;\nif (this.allowRandomSpeed()) {\n    speed += Math.randomInt(Math.floor(5 + agi / 4));\n}\n\n// Return Speed\nreturn speed;"
 *
 * @param ConvertSpeedJS:func
 * @text JS: Speed => Order
 * @parent Speed
 * @type note
 * @desc Code used to calculate how action speeds alter next turn's order.
 * @default "// Declare Constants\nconst item = this.item();\nconst modifier = 50;\n\n// Calculate Order Slots Changed\nlet change = item.speed / (-modifier);\nchange = (change >= 0) ? Math.ceil(change) : Math.floor(change);\n\n// Return Change\nreturn change || 0;"
 * 
 */
/* ----------------------------------------------------------------------------
 * Turn Order Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~TurnOrder:
 *
 * @param General
 *
 * @param DisplayPosition:str
 * @text Display Position
 * @parent General
 * @type select
 * @option top
 * @option bottom
 * @desc Select where the Turn Order will appear on the screen.
 * @default top
 * 
 * @param DisplayOffsetX:num
 * @text Offset X
 * @parent DisplayPosition:str
 * @desc How much to offset the X coordinate by.
 * Negative: left. Positive: right.
 * @default 0
 * 
 * @param DisplayOffsetY:num
 * @text Offset Y
 * @parent DisplayPosition:str
 * @desc How much to offset the Y coordinate by.
 * Negative: up. Positive: down.
 * @default 0
 *
 * @param RepositionTopForHelp:eval
 * @text Reposition for Help?
 * @parent DisplayPosition:str
 * @type boolean
 * @on Reposition
 * @off Stay
 * @desc If the display position is at the top, reposition the
 * display when the help window is open?
 * @default true
 *
 * @param RepositionTopHelpX:num
 * @text Offset X
 * @parent RepositionTopForHelp:eval
 * @desc Reposition the display's X coordinates by this much when
 * the Help Window is visible.
 * @default +0
 *
 * @param RepositionTopHelpY:num
 * @text Offset Y
 * @parent RepositionTopForHelp:eval
 * @desc Reposition the display's Y coordinates by this much when
 * the Help Window is visible.
 * @default +96
 *
 * @param RepositionLogWindow:eval
 * @text Reposition Log?
 * @parent DisplayPosition:str
 * @type boolean
 * @on Reposition
 * @off Stay
 * @desc If the display position is at the top, reposition the
 * Battle Log Window to be lower?
 * @default true
 *
 * @param LogWindowOffsetY:num
 * @text Offset Y
 * @parent RepositionLogWindow:eval
 * @desc How much do you want to offset the Log Window's Y position?
 * @default +0
 *
 * @param OrderDirection:eval
 * @text Forward Direction
 * @parent General
 * @type boolean
 * @on Left to Right
 * @off Right to Left
 * @desc Decide on the direction of the Turn Order.
 * @default false
 *
 * @param SubjectDistance:num
 * @text Subject Distance
 * @parent General
 * @type number
 * @desc How far do you want the currently active battler to
 * distance itself from the rest of the Turn Order?
 * @default 16
 *
 * @param ScreenBuffer:num
 * @text Screen Buffer
 * @parent General
 * @type number
 * @desc What distance do you want the display to be away
 * from the edge of the screen by?
 * @default 36
 *
 * @param UiBackground
 * @text UI Background
 *
 * @param BgDimStyle:str
 * @text Background Style
 * @parent UiBackground
 * @type select
 * @option fill
 * @option gradient
 * @option image
 * @option transparent
 * @desc Select the style you want for the background.
 * @default gradient
 *
 * @param BgImageFilename:str
 * @text Image Filename
 * @parent UiBackground
 * @type file
 * @dir img/system/
 * @desc When using the "image" style, select an image from /img/system/ as the background image.
 * @default 
 *
 * @param BgImageOffsetX:num
 * @text Offset X
 * @parent BgImageFilename:str
 * @desc How much do you want to offset the Background Image's X position?
 * @default +0
 *
 * @param BgImageOffsetY:num
 * @text Offset Y
 * @parent BgImageFilename:str
 * @desc How much do you want to offset the Background Image's Y position?
 * @default +0
 *
 * @param UiText
 * @text UI Text
 *
 * @param UiFontSize:num
 * @text Font Size
 * @parent UiText
 * @desc The font size used for parameter values.
 * @default 16
 *
 * @param UiSubjectText:str
 * @text Active Battler Text
 * @parent UiText
 * @desc Text used to display the active battler.
 * This text will always be center aligned.
 * @default ★
 *
 * @param UiSubjectOffsetX:num
 * @text Offset X
 * @parent UiSubjectText:str
 * @desc How much do you want to offset the text's X position?
 * @default +0
 *
 * @param UiSubjectOffsetY:num
 * @text Offset Y
 * @parent UiSubjectText:str
 * @desc How much do you want to offset the text's Y position?
 * @default -6
 *
 * @param UiCurrentText:str
 * @text Current Turn Text
 * @parent UiText
 * @desc Text used to display the current turn.
 * @default ✦CURRENT TURN✦
 *
 * @param UiCurrentOffsetX:num
 * @text Offset X
 * @parent UiCurrentText:str
 * @desc How much do you want to offset the text's X position?
 * @default +6
 *
 * @param UiCurrentOffsetY:num
 * @text Offset Y
 * @parent UiCurrentText:str
 * @desc How much do you want to offset the text's Y position?
 * @default -6
 *
 * @param UiNextText:str
 * @text Next Turn Text
 * @parent UiText
 * @desc Text used to display the next turn.
 * @default ✧NEXT TURN✧
 *
 * @param UiNextOffsetX:num
 * @text Offset X
 * @parent UiNextText:str
 * @desc How much do you want to offset the text's X position?
 * @default +6
 *
 * @param UiNextOffsetY:num
 * @text Offset Y
 * @parent UiNextText:str
 * @desc How much do you want to offset the text's Y position?
 * @default -6
 *
 * @param UiAlignment:str
 * @text Text Align
 * @parent UiText
 * @type combo
 * @option auto
 * @option left
 * @option center
 * @option right
 * @desc Text alignment for the Current and Next Turn texts?
 * @default auto
 * 
 * @param Slots
 *
 * @param SpriteThin:num
 * @text Width
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many pixels wide should the slots be on the
 * Turn Order display?
 * @default 72
 *
 * @param SpriteLength:num
 * @text Height
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many pixels tall should the slots be on the
 * Turn Order display?
 * @default 72
 *
 * @param PreviewScale:num
 * @text Preview Scale
 * @parent Slots
 * @desc How much do you want to scale the preview sprites by?
 * Use a number between 0 and 1 for the best results.
 * @default 0.5
 *
 * @param PreviewOffsetX:num
 * @text Offset X
 * @parent PreviewScale:num
 * @desc How much do you want to offset the Preview Sprites' X position?
 * @default +0
 *
 * @param PreviewOffsetY:num
 * @text Offset Y
 * @parent PreviewScale:num
 * @desc How much do you want to offset the Preview Sprites' Y position?
 * @default +0
 *
 * @param UpdateFrames:num
 * @text Update Frames
 * @parent Slots
 * @type number
 * @min 1
 * @desc How many frames should it take for the slots to
 * update their positions by?
 * @default 24
 *
 * @param Border
 * @text Slot Border
 *
 * @param ShowMarkerBorder:eval
 * @text Show Border?
 * @parent Border
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show borders for the slot sprites?
 * @default true
 *
 * @param BorderThickness:num
 * @text Border Thickness
 * @parent Markers
 * @type number
 * @min 1
 * @desc How many pixels thick should the colored portion of the border be?
 * @default 2
 *
 * @param BorderActor
 * @text Actors
 * @parent Border
 *
 * @param ActorBorderColor:str
 * @text Border Color
 * @parent BorderActor
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 4
 *
 * @param PreviewActorBorderColor:str
 * @text Preview Version
 * @parent ActorBorderColor:str
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 0
 *
 * @param ActorSystemBorder:str
 * @text Border Skin
 * @parent BorderActor
 * @type file
 * @dir img/system/
 * @desc Optional. Place a skin on the actor borders instead of rendering them?
 * @default 
 *
 * @param PreviewActorSystemBorder:str
 * @text Preview Version
 * @parent ActorSystemBorder:str
 * @type file
 * @dir img/system/
 * @desc Optional. Place a skin on the actor borders instead of rendering them?
 * @default 
 *
 * @param BorderEnemy
 * @text Enemies
 * @parent Border
 *
 * @param EnemyBorderColor:str
 * @text Border Color
 * @parent BorderEnemy
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 2
 *
 * @param PreviewEnemyBorderColor:str
 * @text Preview Version
 * @parent EnemyBorderColor:str
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 0
 *
 * @param EnemySystemBorder:str
 * @text Border Skin
 * @parent BorderEnemy
 * @type file
 * @dir img/system/
 * @desc Optional. Place a skin on the enemy borders instead of rendering them?
 * @default 
 *
 * @param PreviewEnemySystemBorder:str
 * @text Preview Version
 * @parent EnemySystemBorder:str
 * @type file
 * @dir img/system/
 * @desc Optional. Place a skin on the enemy borders instead of rendering them?
 * @default 
 *
 * @param Sprite
 * @text Slot Sprites
 *
 * @param ActorSprite
 * @text Actors
 * @parent Sprite
 *
 * @param ActorBattlerType:str
 * @text Sprite Type
 * @parent ActorSprite
 * @type select
 * @option Face Graphic - Show the actor's face.
 * @value face
 * @option Icon - Show a specified icon.
 * @value icon
 * @option Sideview Actor - Show the actor's sideview battler.
 * @value svactor
 * @desc Select the type of sprite used for the actor graphic.
 * @default face
 *
 * @param ActorBattlerIcon:num
 * @text Default Icon
 * @parent ActorSprite
 * @desc Which icon do you want to use for actors by default?
 * @default 84
 *
 * @param EnemySprite
 * @text Enemies
 * @parent Sprite
 *
 * @param EnemyBattlerType:str
 * @text Sprite Type
 * @parent EnemySprite
 * @type select
 * @option Face Graphic - Show a specified face graphic.
 * @value face
 * @option Icon - Show a specified icon.
 * @value icon
 * @option Enemy - Show the enemy's graphic or sideview battler.
 * @value enemy
 * @desc Select the type of sprite used for the enemy graphic.
 * @default enemy
 *
 * @param EnemyBattlerFaceName:str
 * @text Default Face Name
 * @parent EnemySprite
 * @type file
 * @dir img/faces/
 * @desc Use this default face graphic if there is no specified face.
 * @default Monster
 *
 * @param EnemyBattlerFaceIndex:num
 * @text Default Face Index
 * @parent EnemySprite
 * @type number
 * @desc Use this default face index if there is no specified index.
 * @default 1
 *
 * @param EnemyBattlerIcon:num
 * @text Default Icon
 * @parent EnemySprite
 * @desc Which icon do you want to use for enemies by default?
 * @default 298
 *
 * @param EnemyBattlerMatchHue:eval
 * @text Match Hue?
 * @parent EnemySprite
 * @type boolean
 * @on Match
 * @off Don't Match
 * @desc Match the hue for enemy battlers?
 * Does not apply if there's a sideview battler.
 * @default true
 *
 * @param Letter
 * @text Slot Letter
 *
 * @param EnemyBattlerDrawLetter:eval
 * @text Show Enemy Letter?
 * @parent Letter
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show the enemy's letter on the slot sprite?
 * @default true
 *
 * @param EnemyBattlerFontFace:str
 * @text Font Name
 * @parent Letter
 * @desc The font name used for the text of the Letter.
 * Leave empty to use the default game's font.
 * @default 
 *
 * @param EnemyBattlerFontSize:num
 * @text Font Size
 * @parent Letter
 * @min 1
 * @desc The font size used for the text of the Letter.
 * @default 16
 *
 * @param Background
 * @text Slot Background
 *
 * @param ShowMarkerBg:eval
 * @text Show Background?
 * @parent Background
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show the background on the slot sprite?
 * @default true
 *
 * @param BackgroundActor
 * @text Actors
 * @parent Background
 *
 * @param ActorBgColor1:str
 * @text Background Color 1
 * @parent BackgroundActor
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 19
 *
 * @param PreviewActorBgColor1:str
 * @text Preview Version
 * @parent ActorBgColor1:str
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 19
 *
 * @param ActorBgColor2:str
 * @text Background Color 2
 * @parent BackgroundActor
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 9
 *
 * @param PreviewActorBgColor2:str
 * @text Preview Version
 * @parent ActorBgColor2:str
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 0
 *
 * @param ActorSystemBg:str
 * @text Background Skin
 * @parent BackgroundActor
 * @type file
 * @dir img/system/
 * @desc Optional. Use a skin for the actor background instead of rendering them?
 * @default 
 *
 * @param PreviewActorSystemBg:str
 * @text Preview Version
 * @parent ActorSystemBg:str
 * @type file
 * @dir img/system/
 * @desc Optional. Use a skin for the actor background instead of rendering them?
 * @default 
 *
 * @param BackgroundEnemy
 * @text Enemies
 * @parent Background
 *
 * @param EnemyBgColor1:str
 * @text Background Color 1
 * @parent BackgroundEnemy
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 19
 *
 * @param PreviewEnemyBgColor1:str
 * @text Preview Version
 * @parent EnemyBgColor1:str
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 19
 *
 * @param EnemyBgColor2:str
 * @text Background Color 2
 * @parent BackgroundEnemy
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 18
 *
 * @param PreviewEnemyBgColor2:str
 * @text Preview Version
 * @parent EnemyBgColor2:str
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default 0
 *
 * @param EnemySystemBg:str
 * @text Background Skin
 * @parent BackgroundEnemy
 * @type file
 * @dir img/system/
 * @desc Optional. Use a skin for the enemy background instead of rendering them?
 * @default 
 *
 * @param PreviewEnemySystemBg:str
 * @text Preview Version
 * @parent EnemySystemBg:str
 * @type file
 * @dir img/system/
 * @desc Optional. Use a skin for the enemy background instead of rendering them?
 * @default 
 *
 */
//=============================================================================

const _0x591529=_0x3c83;(function(_0x7b5690,_0x5121f9){const _0x2bb626=_0x3c83,_0x277d62=_0x7b5690();while(!![]){try{const _0x56d77d=-parseInt(_0x2bb626(0x2a9))/0x1*(-parseInt(_0x2bb626(0x182))/0x2)+parseInt(_0x2bb626(0x250))/0x3+-parseInt(_0x2bb626(0xf3))/0x4+-parseInt(_0x2bb626(0x23a))/0x5*(-parseInt(_0x2bb626(0x1c9))/0x6)+-parseInt(_0x2bb626(0x303))/0x7+parseInt(_0x2bb626(0x18a))/0x8+parseInt(_0x2bb626(0x31f))/0x9;if(_0x56d77d===_0x5121f9)break;else _0x277d62['push'](_0x277d62['shift']());}catch(_0x2eb979){_0x277d62['push'](_0x277d62['shift']());}}}(_0x547b,0x255ce));function _0x3c83(_0x3971b0,_0x41d650){const _0x547b95=_0x547b();return _0x3c83=function(_0x3c8321,_0x55fb78){_0x3c8321=_0x3c8321-0xc0;let _0x2aa97d=_0x547b95[_0x3c8321];return _0x2aa97d;},_0x3c83(_0x3971b0,_0x41d650);}var label='BattleSystemOTB',tier=tier||0x0,dependencies=[],pluginData=$plugins[_0x591529(0x268)](function(_0x53af3e){const _0x15c76c=_0x591529;return _0x53af3e[_0x15c76c(0x163)]&&_0x53af3e[_0x15c76c(0x332)][_0x15c76c(0x1b1)]('['+label+']');})[0x0];VisuMZ[label][_0x591529(0x2cd)]=VisuMZ[label][_0x591529(0x2cd)]||{},VisuMZ[_0x591529(0x304)]=function(_0x291a71,_0x219715){const _0x3fe43c=_0x591529;for(const _0x14a2b1 in _0x219715){if(_0x3fe43c(0x2b8)===_0x3fe43c(0x2b8)){if(_0x14a2b1['match'](/(.*):(.*)/i)){const _0x35a213=String(RegExp['$1']),_0x52d357=String(RegExp['$2'])['toUpperCase']()[_0x3fe43c(0x323)]();let _0x2d89eb,_0x1921b8,_0x454c4f;switch(_0x52d357){case _0x3fe43c(0x33c):_0x2d89eb=_0x219715[_0x14a2b1]!==''?Number(_0x219715[_0x14a2b1]):0x0;break;case _0x3fe43c(0x187):_0x1921b8=_0x219715[_0x14a2b1]!==''?JSON[_0x3fe43c(0xea)](_0x219715[_0x14a2b1]):[],_0x2d89eb=_0x1921b8['map'](_0x1473ef=>Number(_0x1473ef));break;case'EVAL':_0x2d89eb=_0x219715[_0x14a2b1]!==''?eval(_0x219715[_0x14a2b1]):null;break;case _0x3fe43c(0x2da):_0x1921b8=_0x219715[_0x14a2b1]!==''?JSON[_0x3fe43c(0xea)](_0x219715[_0x14a2b1]):[],_0x2d89eb=_0x1921b8[_0x3fe43c(0x241)](_0x27071=>eval(_0x27071));break;case _0x3fe43c(0x2b9):_0x2d89eb=_0x219715[_0x14a2b1]!==''?JSON[_0x3fe43c(0xea)](_0x219715[_0x14a2b1]):'';break;case _0x3fe43c(0x12a):_0x1921b8=_0x219715[_0x14a2b1]!==''?JSON[_0x3fe43c(0xea)](_0x219715[_0x14a2b1]):[],_0x2d89eb=_0x1921b8['map'](_0x571486=>JSON['parse'](_0x571486));break;case _0x3fe43c(0x1b8):_0x2d89eb=_0x219715[_0x14a2b1]!==''?new Function(JSON[_0x3fe43c(0xea)](_0x219715[_0x14a2b1])):new Function('return\x200');break;case _0x3fe43c(0x1bc):_0x1921b8=_0x219715[_0x14a2b1]!==''?JSON['parse'](_0x219715[_0x14a2b1]):[],_0x2d89eb=_0x1921b8[_0x3fe43c(0x241)](_0x18bbc2=>new Function(JSON[_0x3fe43c(0xea)](_0x18bbc2)));break;case _0x3fe43c(0xe9):_0x2d89eb=_0x219715[_0x14a2b1]!==''?String(_0x219715[_0x14a2b1]):'';break;case'ARRAYSTR':_0x1921b8=_0x219715[_0x14a2b1]!==''?JSON[_0x3fe43c(0xea)](_0x219715[_0x14a2b1]):[],_0x2d89eb=_0x1921b8['map'](_0x534d0b=>String(_0x534d0b));break;case _0x3fe43c(0x181):_0x454c4f=_0x219715[_0x14a2b1]!==''?JSON[_0x3fe43c(0xea)](_0x219715[_0x14a2b1]):{},_0x2d89eb=VisuMZ['ConvertParams']({},_0x454c4f);break;case'ARRAYSTRUCT':_0x1921b8=_0x219715[_0x14a2b1]!==''?JSON['parse'](_0x219715[_0x14a2b1]):[],_0x2d89eb=_0x1921b8['map'](_0x514fb5=>VisuMZ[_0x3fe43c(0x304)]({},JSON[_0x3fe43c(0xea)](_0x514fb5)));break;default:continue;}_0x291a71[_0x35a213]=_0x2d89eb;}}else return![];}return _0x291a71;},(_0x43ef1d=>{const _0x17f18d=_0x591529,_0x1158af=_0x43ef1d[_0x17f18d(0x25f)];for(const _0x125cdf of dependencies){if(_0x17f18d(0x279)==='roJus'){if(!Imported[_0x125cdf]){if(_0x17f18d(0x34d)!=='bFlgQ'){alert(_0x17f18d(0x37f)[_0x17f18d(0x276)](_0x1158af,_0x125cdf)),SceneManager['exit']();break;}else{if(this[_0x17f18d(0x307)]()===_0x25ba69)return![];return!![];}}}else _0x394751['BattleSystemOTB'][_0x17f18d(0x20d)][_0x17f18d(0x20a)](this);}const _0x425970=_0x43ef1d[_0x17f18d(0x332)];if(_0x425970[_0x17f18d(0x1d1)](/\[Version[ ](.*?)\]/i)){const _0x280210=Number(RegExp['$1']);_0x280210!==VisuMZ[label][_0x17f18d(0x374)]&&(_0x17f18d(0x2a0)===_0x17f18d(0xca)?(_0x1bc1a4[_0x17f18d(0x109)](_0x526d7f,_0x462980,_0x2f8d69/0x2,_0x3aeed5,_0xb112b6),_0x2dc668[_0x17f18d(0x2bf)](_0x1c40dd+_0x1538ae/0x2,_0x4b3291,_0x2e969e/0x2,_0x30d042,_0x5dea7c,_0x1f8c9b,![]),_0x5621a3[_0x17f18d(0x109)](_0x59f8a3,_0x5aab9b,_0xf20b21/0x2,_0x3af0d1,_0x5a6836),_0x34a4a8['gradientFillRect'](_0x276b10+_0x334c07/0x2,_0x44ea83,_0xc4d655/0x2,_0x191d73,_0x28acea,_0x391b00,![]),_0x2b0d18['fillRect'](_0x5e52b9,_0x84095a,_0x2e8804/0x2,_0x55bf88,_0x173203),_0x4da539[_0x17f18d(0x2bf)](_0x1a5d4a+_0x5389b4/0x2,_0x3a3228,_0x5d69fa/0x2,_0xf675b9,_0x105771,_0x738b9b,![])):(alert(_0x17f18d(0x260)[_0x17f18d(0x276)](_0x1158af,_0x280210)),SceneManager[_0x17f18d(0x25a)]()));}if(_0x425970['match'](/\[Tier[ ](\d+)\]/i)){const _0x4fbb22=Number(RegExp['$1']);_0x4fbb22<tier?(alert(_0x17f18d(0x285)[_0x17f18d(0x276)](_0x1158af,_0x4fbb22,tier)),SceneManager['exit']()):tier=Math[_0x17f18d(0x195)](_0x4fbb22,tier);}VisuMZ[_0x17f18d(0x304)](VisuMZ[label][_0x17f18d(0x2cd)],_0x43ef1d['parameters']);})(pluginData),PluginManager[_0x591529(0x2db)](pluginData['name'],_0x591529(0x104),_0x5cb7cd=>{const _0x2f5b78=_0x591529;VisuMZ[_0x2f5b78(0x304)](_0x5cb7cd,_0x5cb7cd);const _0x2c356d=_0x5cb7cd[_0x2f5b78(0x298)],_0x4e4843=_0x5cb7cd[_0x2f5b78(0x369)];for(const _0x1fd9f8 of _0x2c356d){const _0x44d000=$gameActors[_0x2f5b78(0x12e)](_0x1fd9f8);if(!_0x44d000)continue;_0x44d000['_otbTurnOrderGraphicType']=_0x2f5b78(0x14b),_0x44d000[_0x2f5b78(0x37e)]=_0x4e4843;}}),PluginManager[_0x591529(0x2db)](pluginData[_0x591529(0x25f)],_0x591529(0x1ab),_0x4916e1=>{const _0x3dede6=_0x591529;VisuMZ['ConvertParams'](_0x4916e1,_0x4916e1);const _0x445ed7=_0x4916e1['Actors'],_0x182a22=_0x4916e1[_0x3dede6(0x2ba)],_0x1b6c53=_0x4916e1[_0x3dede6(0x280)];for(const _0x203617 of _0x445ed7){const _0x2fabea=$gameActors['actor'](_0x203617);if(!_0x2fabea)continue;_0x2fabea[_0x3dede6(0x1d7)]=_0x3dede6(0x11d),_0x2fabea[_0x3dede6(0x26c)]=_0x182a22,_0x2fabea[_0x3dede6(0x1c2)]=_0x1b6c53;}}),PluginManager[_0x591529(0x2db)](pluginData[_0x591529(0x25f)],_0x591529(0x2e9),_0x428930=>{const _0x6a1165=_0x591529;VisuMZ['ConvertParams'](_0x428930,_0x428930);const _0x11390d=_0x428930[_0x6a1165(0x298)];for(const _0x215820 of _0x11390d){const _0x8a9fdc=$gameActors[_0x6a1165(0x12e)](_0x215820);if(!_0x8a9fdc)continue;_0x8a9fdc[_0x6a1165(0x2f3)]();}}),PluginManager[_0x591529(0x2db)](pluginData[_0x591529(0x25f)],_0x591529(0x2df),_0x5b2819=>{const _0x43e2c4=_0x591529;VisuMZ[_0x43e2c4(0x304)](_0x5b2819,_0x5b2819);const _0x5345f7=_0x5b2819[_0x43e2c4(0x170)],_0x5a7c30=_0x5b2819[_0x43e2c4(0x369)];for(const _0x143f45 of _0x5345f7){const _0x30c05f=$gameTroop['members']()[_0x143f45];if(!_0x30c05f)continue;_0x30c05f['_otbTurnOrderGraphicType']=_0x43e2c4(0x14b),_0x30c05f['_otbTurnOrderIconIndex']=_0x5a7c30;}}),PluginManager[_0x591529(0x2db)](pluginData[_0x591529(0x25f)],_0x591529(0x1e5),_0x3fa45f=>{const _0x5de205=_0x591529;VisuMZ[_0x5de205(0x304)](_0x3fa45f,_0x3fa45f);const _0x42d1b5=_0x3fa45f[_0x5de205(0x170)],_0x3fb4d1=_0x3fa45f[_0x5de205(0x2ba)],_0x5635ce=_0x3fa45f['FaceIndex'];for(const _0x13f440 of _0x42d1b5){const _0x4dc5eb=$gameTroop['members']()[_0x13f440];if(!_0x4dc5eb)continue;_0x4dc5eb[_0x5de205(0x1d7)]=_0x5de205(0x11d),_0x4dc5eb['_otbTurnOrderFaceName']=_0x3fb4d1,_0x4dc5eb[_0x5de205(0x1c2)]=_0x5635ce;}}),PluginManager[_0x591529(0x2db)](pluginData['name'],_0x591529(0x117),_0x375448=>{const _0x4f4240=_0x591529;VisuMZ[_0x4f4240(0x304)](_0x375448,_0x375448);const _0x56ac13=_0x375448[_0x4f4240(0x170)];for(const _0x4e95ce of _0x56ac13){if('pCLZq'==='nXcpQ')this[_0x4f4240(0x1c7)]=this['_currentTurn'][_0x1fa013],this[_0x4f4240(0x1dc)][_0x2a40a1][_0x4f4240(0x173)](),this['_currentTurn']['splice'](_0x3b9945,0x1);else{const _0x196442=$gameTroop[_0x4f4240(0x1b3)]()[_0x4e95ce];if(!_0x196442)continue;_0x196442['clearTurnOrderOTBGraphics']();}}}),PluginManager['registerCommand'](pluginData[_0x591529(0x25f)],_0x591529(0x14a),_0x209fe1=>{const _0x5bd412=_0x591529;VisuMZ[_0x5bd412(0x304)](_0x209fe1,_0x209fe1);const _0x2a24d1=_0x209fe1[_0x5bd412(0x344)];$gameSystem[_0x5bd412(0x21a)](_0x2a24d1);}),VisuMZ['BattleSystemOTB'][_0x591529(0x24a)]={'Instant':/<OTB (?:INSTANT|INSTANT CAST|INSTANT USE)>/i,'UserFollOrder':/<OTB USER FOLLOW TURN: ([\+\-]\d+)>/i,'UserCurrOrder':/<OTB USER CURRENT TURN: ([\+\-]\d+)>/i,'UserNextOrder':/<OTB USER NEXT TURN: ([\+\-]\d+)>/i,'TargetFollOrder':/<OTB TARGET FOLLOW TURN: ([\+\-]\d+)>/i,'TargetCurrOrder':/<OTB TARGET CURRENT TURN: ([\+\-]\d+)>/i,'TargetNextOrder':/<OTB TARGET NEXT TURN: ([\+\-]\d+)>/i,'UserAddActionCurrent':/<OTB USER ADD CURRENT TURN (?:ACTION|ACTIONS): (\d+)>/i,'UserAddActionNext':/<OTB USER ADD NEXT TURN (?:ACTION|ACTIONS): (\d+)>/i,'TargetAddActionCurrent':/<OTB TARGET ADD CURRENT TURN (?:ACTION|ACTIONS): (\d+)>/i,'TargetAddActionNext':/<OTB TARGET ADD NEXT TURN (?:ACTION|ACTIONS): (\d+)>/i},DataManager[_0x591529(0x300)]=function(_0x2518b2){const _0x307e24=_0x591529;_0x2518b2=_0x2518b2[_0x307e24(0x21d)]()[_0x307e24(0x323)](),this['_stateIDs']=this[_0x307e24(0x223)]||{};if(this[_0x307e24(0x223)][_0x2518b2])return this[_0x307e24(0x223)][_0x2518b2];for(const _0x3c43c7 of $dataStates){if(!_0x3c43c7)continue;this[_0x307e24(0x223)][_0x3c43c7[_0x307e24(0x25f)]['toUpperCase']()[_0x307e24(0x323)]()]=_0x3c43c7['id'];}return this[_0x307e24(0x223)][_0x2518b2]||0x0;},ImageManager[_0x591529(0x13d)]=ImageManager[_0x591529(0x13d)]||0x9,ImageManager[_0x591529(0x321)]=ImageManager[_0x591529(0x321)]||0x6,SceneManager[_0x591529(0x21b)]=function(){const _0xd04210=_0x591529;return this[_0xd04210(0x37c)]&&this[_0xd04210(0x37c)]['constructor']===Scene_Battle;},VisuMZ[_0x591529(0x12b)][_0x591529(0xcd)]=BattleManager['setup'],BattleManager['setup']=function(_0x400ae1,_0x6e117f,_0x4c0fec){const _0x541883=_0x591529;VisuMZ[_0x541883(0x12b)][_0x541883(0xcd)][_0x541883(0x20a)](this,_0x400ae1,_0x6e117f,_0x4c0fec),this[_0x541883(0x1f4)]();},BattleManager[_0x591529(0x1f4)]=function(){const _0x379675=_0x591529;if(!this['isOTB']())return;this[_0x379675(0x229)]=[],this[_0x379675(0x328)]=![];},VisuMZ['BattleSystemOTB']['BattleManager_battleSys']=BattleManager['battleSys'],BattleManager[_0x591529(0x352)]=function(){const _0x234e7b=_0x591529;if(this[_0x234e7b(0xc3)]())return'OTB';return VisuMZ[_0x234e7b(0x12b)][_0x234e7b(0x19b)]['call'](this);},BattleManager['isOTB']=function(){const _0x418b49=_0x591529;return $gameSystem[_0x418b49(0x202)]()==='OTB';},VisuMZ[_0x591529(0x12b)]['BattleManager_isTpb']=BattleManager[_0x591529(0x2e0)],BattleManager[_0x591529(0x2e0)]=function(){const _0x2b7959=_0x591529;if(this[_0x2b7959(0xc3)]())return![];return VisuMZ[_0x2b7959(0x12b)][_0x2b7959(0x175)]['call'](this);},VisuMZ['BattleSystemOTB'][_0x591529(0x13e)]=BattleManager['isActiveTpb'],BattleManager[_0x591529(0x1e1)]=function(){const _0x70d96=_0x591529;if(this[_0x70d96(0xc3)]())return![];return VisuMZ['BattleSystemOTB'][_0x70d96(0x13e)][_0x70d96(0x20a)](this);},VisuMZ['BattleSystemOTB'][_0x591529(0x1f0)]=BattleManager[_0x591529(0x301)],BattleManager['isTurnBased']=function(){const _0x725554=_0x591529;if(this['isOTB']())return!![];return VisuMZ[_0x725554(0x12b)][_0x725554(0x1f0)][_0x725554(0x20a)](this);},VisuMZ[_0x591529(0x12b)][_0x591529(0xce)]=BattleManager['startInput'],BattleManager[_0x591529(0x26b)]=function(){const _0x3b5bcb=_0x591529;VisuMZ[_0x3b5bcb(0x12b)]['BattleManager_startInput'][_0x3b5bcb(0x20a)](this),this['isOTB']()&&$gameParty[_0x3b5bcb(0x281)]()&&!this[_0x3b5bcb(0x333)]&&this[_0x3b5bcb(0x22c)]();},BattleManager[_0x591529(0x22c)]=function(){const _0x90daaa=_0x591529;this[_0x90daaa(0x1ff)]();},VisuMZ['BattleSystemOTB'][_0x591529(0x20d)]=BattleManager['processTurn'],BattleManager[_0x591529(0x140)]=function(){const _0xe0cdc3=_0x591529;if(this[_0xe0cdc3(0xc3)]()){if(_0xe0cdc3(0x338)===_0xe0cdc3(0x338))this[_0xe0cdc3(0x208)]();else return _0x50f68d[_0xe0cdc3(0xc3)]();}else'qRZiZ'!==_0xe0cdc3(0x382)?(_0x1f1655['otbPreviewOrderClear'](),_0x24924b[_0xe0cdc3(0x12b)][_0xe0cdc3(0x383)][_0xe0cdc3(0x20a)](this)):VisuMZ[_0xe0cdc3(0x12b)][_0xe0cdc3(0x20d)][_0xe0cdc3(0x20a)](this);},BattleManager[_0x591529(0x208)]=function(){const _0x2af1f9=_0x591529,_0x19ecce=this[_0x2af1f9(0x1c7)];if(_0x19ecce[_0x2af1f9(0x112)]()&&_0x19ecce[_0x2af1f9(0x281)]()){const _0x36d730=_0x19ecce[_0x2af1f9(0x15e)]();if(!_0x36d730){if(_0x2af1f9(0x18d)===_0x2af1f9(0x18d))VisuMZ[_0x2af1f9(0x12b)][_0x2af1f9(0x20d)][_0x2af1f9(0x20a)](this);else return _0x2af1f9(0x14b);}else _0x36d730[_0x2af1f9(0x19f)]?VisuMZ[_0x2af1f9(0x12b)][_0x2af1f9(0x20d)][_0x2af1f9(0x20a)](this):(this[_0x2af1f9(0x377)]=_0x19ecce,this[_0x2af1f9(0x22b)]());}else _0x2af1f9(0x204)!==_0x2af1f9(0x113)?VisuMZ['BattleSystemOTB']['BattleManager_processTurn']['call'](this):(this['x']=this['_homeX']+(_0x2949ec[_0x2af1f9(0x1b6)]||0x0),this['y']=this[_0x2af1f9(0x126)]+(_0x27cc47[_0x2af1f9(0x302)]||0x0));},VisuMZ['BattleSystemOTB'][_0x591529(0x224)]=BattleManager[_0x591529(0x118)],BattleManager[_0x591529(0x118)]=function(){const _0x30789f=_0x591529;this['isOTB']()?_0x30789f(0x339)===_0x30789f(0x253)?this[_0x30789f(0x2af)]()[_0x30789f(0x1c5)](0x1):VisuMZ['BattleSystemOTB'][_0x30789f(0x20d)]['call'](this):VisuMZ['BattleSystemOTB'][_0x30789f(0x224)][_0x30789f(0x20a)](this);},VisuMZ[_0x591529(0x12b)][_0x591529(0x119)]=BattleManager['selectNextActor'],BattleManager['selectNextActor']=function(){const _0x5645ba=_0x591529;if(this['isOTB']())this['selectNextActorOTB']();else{if(_0x5645ba(0x27a)!=='rTwmW')VisuMZ[_0x5645ba(0x12b)][_0x5645ba(0x119)][_0x5645ba(0x20a)](this);else{if(!_0x5d8941)return;const _0x24ab06=_0x636a20['makeActionTimes']();_0x269032[_0x5645ba(0x2b0)]();if(!this['_actionBattlers'][_0x5645ba(0x1b1)](_0x5a95a1)){const _0x5aac13=_0x280252['max'](0x0,_0x24ab06-(_0x1036b0[_0x5645ba(0x35c)]||0x0));this[_0x5645ba(0x2dc)](_0x54d408,_0x5aac13,this['_actionBattlers']);}if(!this[_0x5645ba(0x229)][_0x5645ba(0x1b1)](_0x445e5f)){const _0x23ed85=_0x24ab06;this['otbAddBattlerToTurnOrderAtEnd'](_0x58d11e,_0x23ed85,this[_0x5645ba(0x229)]);}}}},BattleManager[_0x591529(0xc5)]=function(){const _0x46d72d=_0x591529;this[_0x46d72d(0x377)]=null,this[_0x46d72d(0x2d5)]=![];},VisuMZ[_0x591529(0x12b)]['BattleManager_endAction']=BattleManager[_0x591529(0x342)],BattleManager['endAction']=function(){const _0xd4f61a=_0x591529;this[_0xd4f61a(0x288)](),VisuMZ['BattleSystemOTB'][_0xd4f61a(0x29c)]['call'](this),this[_0xd4f61a(0x1d4)]();},BattleManager[_0x591529(0x288)]=function(){const _0x11bfe4=_0x591529;if(!this['isOTB']())return;this[_0x11bfe4(0x319)]();this[_0x11bfe4(0x1c7)]&&(_0x11bfe4(0x313)!==_0x11bfe4(0x313)?this['makeNextActionOrdersOTB']():this[_0x11bfe4(0x1c7)][_0x11bfe4(0x149)]());if(this[_0x11bfe4(0x1c7)]&&this[_0x11bfe4(0x1c7)][_0x11bfe4(0xf1)]()&&this[_0x11bfe4(0x259)][_0x11bfe4(0x1b1)](this[_0x11bfe4(0x1c7)])){const _0x31e9c6=this['_subject'][_0x11bfe4(0xfd)][_0x11bfe4(0x268)](_0x37f164=>_0x37f164[_0x11bfe4(0x19f)]);this[_0x11bfe4(0x1c7)]['makeActions']();if(_0x31e9c6){if(_0x11bfe4(0x22a)===_0x11bfe4(0x22a)){let _0x17f0df=_0x31e9c6['length'];while(_0x17f0df--){this['_subject'][_0x11bfe4(0xfd)]['pop']();}this[_0x11bfe4(0x1c7)]['_actions']=_0x31e9c6[_0x11bfe4(0x2fa)](this[_0x11bfe4(0x1c7)][_0x11bfe4(0xfd)]);}else{let _0x30d8d8=this[_0x11bfe4(0x324)](),_0x4ddea0=this[_0x11bfe4(0x1fa)](),_0x130847=this['getBorderThickness']();_0x5e630a[_0x11bfe4(0x1c0)]=new _0x4e36a4(_0x30d8d8,_0x4ddea0);const _0xa97612=_0x11bfe4(0x16d),_0x58d7b4=_0x27eac8[_0x11bfe4(0x2fe)](_0x563049[_0x11bfe4(0x130)[_0x11bfe4(0x276)](_0x3ec214)]);_0x4e0385[_0x11bfe4(0x1c0)][_0x11bfe4(0x109)](0x0,0x0,_0x30d8d8,_0x4ddea0,_0xa97612),_0x30d8d8-=0x2,_0x4ddea0-=0x2,_0x2bfe0f[_0x11bfe4(0x1c0)]['fillRect'](0x1,0x1,_0x30d8d8,_0x4ddea0,_0x58d7b4),_0x30d8d8-=_0x130847*0x2,_0x4ddea0-=_0x130847*0x2,_0x81effa[_0x11bfe4(0x1c0)][_0x11bfe4(0x109)](0x1+_0x130847,0x1+_0x130847,_0x30d8d8,_0x4ddea0,_0xa97612),_0x30d8d8-=0x2,_0x4ddea0-=0x2,_0x130847+=0x1,_0x4c0bd5[_0x11bfe4(0x1c0)][_0x11bfe4(0x10a)](0x1+_0x130847,0x1+_0x130847,_0x30d8d8,_0x4ddea0);}}}},BattleManager['postEndActionOTB']=function(){const _0x1297ce=_0x591529;if(!this[_0x1297ce(0xc3)]())return;this[_0x1297ce(0x319)]();if(this['_subject']){if(_0x1297ce(0x11b)!==_0x1297ce(0x11b))return _0x2b90dd[_0x1297ce(0x2cd)][_0x1297ce(0x2c3)];else this[_0x1297ce(0x26a)](this[_0x1297ce(0x1c7)]),this[_0x1297ce(0x1c7)]=null;}this[_0x1297ce(0x218)][_0x1297ce(0x2f7)]>0x0&&(_0x1297ce(0x189)==='srgbi'?this[_0x1297ce(0x1c7)]=this[_0x1297ce(0xf9)]():this['_speed']=_0x5531d9);;},BattleManager[_0x591529(0x15b)]=VisuMZ['BattleSystemOTB'][_0x591529(0x2cd)]['Mechanics'][_0x591529(0x320)],BattleManager['OTB_ADDED_RANDOMIZE_ADDED_ACTION_ORDER']=VisuMZ[_0x591529(0x12b)]['Settings']['Mechanics'][_0x591529(0x2c5)],BattleManager[_0x591529(0x386)]=VisuMZ['BattleSystemOTB'][_0x591529(0x2cd)]['Mechanics'][_0x591529(0x206)],VisuMZ[_0x591529(0x12b)][_0x591529(0x263)]=BattleManager[_0x591529(0x362)],BattleManager[_0x591529(0x362)]=function(){const _0x42f9d4=_0x591529;if(this[_0x42f9d4(0xc3)]())this[_0x42f9d4(0x2de)]();else{if(_0x42f9d4(0x327)!==_0x42f9d4(0x162))VisuMZ[_0x42f9d4(0x12b)][_0x42f9d4(0x263)][_0x42f9d4(0x20a)](this);else{if(_0x86d8f6[_0x42f9d4(0xc3)]())this[_0x42f9d4(0x176)](this['deathStateId']());_0x56cd45[_0x42f9d4(0x12b)][_0x42f9d4(0x36b)]['call'](this);if(_0x43dccb[_0x42f9d4(0xc3)]())this['refresh']();}}},BattleManager[_0x591529(0x2de)]=function(){const _0xb95968=_0x591529;let _0x1eed1a=this[_0xb95968(0x328)]?0x1:0x2;while(_0x1eed1a--){this['makeNextActionOrdersOTB']();}const _0x4f8db2=!this[_0xb95968(0x328)];this[_0xb95968(0x328)]=!![];},BattleManager[_0x591529(0x12f)]=function(){const _0x5c05d0=_0x591529;this['_actionBattlers']=this[_0x5c05d0(0x229)],this[_0x5c05d0(0x29b)]();const _0x22a5ec=[];_0x22a5ec[_0x5c05d0(0x236)](...$gameParty['battleMembers']()),_0x22a5ec[_0x5c05d0(0x236)](...$gameTroop[_0x5c05d0(0x1b3)]());for(const _0x169dbd of _0x22a5ec){_0x169dbd[_0x5c05d0(0x209)]();}_0x22a5ec['sort']((_0x5e002b,_0x5ad786)=>_0x5ad786['speed']()-_0x5e002b[_0x5c05d0(0x307)]()),this[_0x5c05d0(0x229)]=_0x22a5ec,this['otbApplyActionTimes'](),this['removeActionBattlersOTB'](),this['otbCreateNewTurnOrderSprites']();},BattleManager[_0x591529(0x30a)]=function(){const _0x357609=_0x591529;if(!BattleManager[_0x357609(0x15b)])return;const _0x77b196=this[_0x357609(0x229)],_0xd5ee85=this[_0x357609(0x364)]();for(const _0x342807 of _0xd5ee85){if(!_0x342807)continue;if(!_0x342807[_0x357609(0x228)]())continue;if(!_0x342807[_0x357609(0xe5)]())continue;if(!_0x77b196[_0x357609(0x1b1)](_0x342807))continue;const _0x50d519=_0x77b196[_0x357609(0x349)](_0x342807);let _0x594e16=_0x342807['makeActionTimes']()-0x1;while(_0x594e16--){if('GBfwV'!==_0x357609(0x1f2))this[_0x357609(0x29d)](),_0xf206c0&&_0x225a7a[_0x357609(0x2ac)]()!==null&&this[_0x357609(0x197)](_0x3f94e7);else{let _0xaf7e7d=_0x50d519;BattleManager[_0x357609(0x340)]&&(_0x357609(0x25c)===_0x357609(0x366)?this[_0x357609(0x37b)]=!![]:_0xaf7e7d=Math[_0x357609(0x151)](_0x77b196[_0x357609(0x2f7)]-_0x50d519)+_0x50d519),_0x77b196['splice'](_0xaf7e7d,0x0,_0x342807);}}}},BattleManager['removeActionBattlersOTB']=function(){const _0x1992cb=_0x591529;if(!this[_0x1992cb(0xc3)]())return;this['_actionBattlers']=this[_0x1992cb(0x259)]||[],this[_0x1992cb(0x259)][_0x1992cb(0x2ca)](null),this[_0x1992cb(0x259)]['remove'](undefined),this[_0x1992cb(0x259)]=this['_actionBattlers'][_0x1992cb(0x268)](_0x4fe7c0=>_0x4fe7c0[_0x1992cb(0x2ee)]()),this[_0x1992cb(0x259)]=this[_0x1992cb(0x259)][_0x1992cb(0x268)](_0x9e70c7=>VisuMZ[_0x1992cb(0x12b)][_0x1992cb(0x2a4)](_0x9e70c7));if(this[_0x1992cb(0x333)]){if('dBtbH'==='Ibwvu'){if(!_0x198993[_0x1992cb(0x2cd)][_0x1992cb(0xcb)])return;const _0x45dd2b=_0x2eae4e[_0x1992cb(0x2cd)],_0x3688f2=this[_0x1992cb(0x278)](),_0x4a289f='%1SystemBg'[_0x1992cb(0x276)](_0x3688f2),_0x426861=new _0x5a705d();_0x426861[_0x1992cb(0xee)]['x']=this[_0x1992cb(0xee)]['x'],_0x426861[_0x1992cb(0xee)]['y']=this[_0x1992cb(0xee)]['y'];if(_0x45dd2b[_0x4a289f])_0x426861['bitmap']=_0x151f85[_0x1992cb(0x18f)](_0x45dd2b[_0x4a289f]);else{const _0x3596c0=this[_0x1992cb(0x324)](),_0x5179ca=this['bitmapHeight']();_0x426861['bitmap']=new _0x500917(_0x3596c0,_0x5179ca);const _0x529fb7=_0x4e320a[_0x1992cb(0x2fe)](_0x45dd2b['%1BgColor1'[_0x1992cb(0x276)](_0x3688f2)]),_0x34c1f9=_0x279b62['getColor'](_0x45dd2b[_0x1992cb(0x110)[_0x1992cb(0x276)](_0x3688f2)]);_0x426861[_0x1992cb(0x1c0)][_0x1992cb(0x2bf)](0x0,0x0,_0x3596c0,_0x5179ca,_0x529fb7,_0x34c1f9,!![]);}this[_0x1992cb(0x152)]=_0x426861,this['addChild'](this[_0x1992cb(0x152)]),this[_0x1992cb(0x164)]=this[_0x1992cb(0x152)]['width'],this['height']=this[_0x1992cb(0x152)][_0x1992cb(0xfa)];}else this[_0x1992cb(0x259)]=this[_0x1992cb(0x259)][_0x1992cb(0x268)](_0x301eeb=>!_0x301eeb[_0x1992cb(0x112)]());}this[_0x1992cb(0x30d)]&&(this['_actionBattlers']=this[_0x1992cb(0x259)]['filter'](_0x1f7096=>!_0x1f7096[_0x1992cb(0x385)]())),this[_0x1992cb(0x229)]=this[_0x1992cb(0x229)]||[],this[_0x1992cb(0x229)][_0x1992cb(0x2ca)](null),this[_0x1992cb(0x229)]['remove'](undefined),this[_0x1992cb(0x229)]=this[_0x1992cb(0x229)][_0x1992cb(0x268)](_0x5f0294=>_0x5f0294[_0x1992cb(0x2ee)]()),this[_0x1992cb(0x229)]=this[_0x1992cb(0x229)]['filter'](_0x5d4296=>VisuMZ['BattleSystemOTB'][_0x1992cb(0x1f7)](_0x5d4296)),this['otbRemoveUnableTurnOrderSprites'](),this[_0x1992cb(0x180)]();},VisuMZ[_0x591529(0x12b)]['ActionBattlersFilter']=function(_0x3e16d4){const _0x158700=_0x591529;if(!_0x3e16d4)return![];if(!_0x3e16d4[_0x158700(0xe5)]())return![];if(!_0x3e16d4['isAppeared']())return![];return _0x3e16d4[_0x158700(0xf1)]();},VisuMZ[_0x591529(0x12b)][_0x591529(0x1f7)]=function(_0x3acb2e){const _0xbc9fa8=_0x591529;if(!_0x3acb2e)return![];const _0x1c0e9e=JsonEx[_0xbc9fa8(0x2a5)](_0x3acb2e);return _0x1c0e9e[_0xbc9fa8(0x169)]=!![],_0x1c0e9e[_0xbc9fa8(0x25b)]=!![],_0x1c0e9e['updateStateTurns'](),_0x1c0e9e[_0xbc9fa8(0x231)](0x1),_0x1c0e9e['removeStatesAuto'](0x2),_0x1c0e9e[_0xbc9fa8(0x358)](),VisuMZ[_0xbc9fa8(0x12b)][_0xbc9fa8(0x2a4)](_0x1c0e9e);},BattleManager[_0x591529(0x13a)]=function(_0x52cb03,_0x5d9e49,_0x3f16f4){const _0x2f6ccb=_0x591529;if(!_0x5d9e49)return;const _0x9b1fa4=_0x3f16f4?this[_0x2f6ccb(0x229)]:this[_0x2f6ccb(0x259)];if(!_0x9b1fa4)return;if(!_0x9b1fa4['includes'](_0x52cb03))return;const _0x37c9b4=VisuMZ[_0x2f6ccb(0x12b)]['GetAllIndicies'](_0x52cb03,_0x9b1fa4),_0x55810f=_0x3f16f4?VisuMZ[_0x2f6ccb(0x12b)][_0x2f6ccb(0x21f)](_0x9b1fa4):0x0,_0x50f168=_0x37c9b4[_0x2f6ccb(0x2f7)]-0x1;for(let _0x294831=_0x50f168;_0x294831>=0x0;_0x294831--){if('efatc'===_0x2f6ccb(0x348)){const _0x35bbbd=_0x7900c3[_0x2f6ccb(0x2cd)],_0x44cb00=this[_0x2f6ccb(0x324)](),_0x2b45f7=this[_0x2f6ccb(0x1fa)](),_0xe33617=_0xe582dc['min'](_0x44cb00,_0x2b45f7);this['_graphicSprite'][_0x2f6ccb(0x1c0)]=new _0x236d2c(_0x44cb00,_0x2b45f7);const _0x45e50c=this['_graphicSprite'][_0x2f6ccb(0x1c0)],_0x5b99b6=_0x33da2a[_0x2f6ccb(0x235)](0x1,_0xe33617/_0x523a80[_0x2f6ccb(0x164)],_0xe33617/_0x37080a[_0x2f6ccb(0xfa)]),_0x39eb0b=_0x36b4e0['width']*_0x5b99b6,_0x465722=_0x16d586[_0x2f6ccb(0xfa)]*_0x5b99b6,_0x3ebc4b=_0x1c3c5b[_0x2f6ccb(0x2b6)]((_0x44cb00-_0x39eb0b)/0x2),_0x33b914=_0x168765[_0x2f6ccb(0x2b6)]((_0x2b45f7-_0x465722)/0x2);_0x45e50c[_0x2f6ccb(0x172)](_0x3bfde2,0x0,0x0,_0x32bbfd[_0x2f6ccb(0x164)],_0x804a16[_0x2f6ccb(0xfa)],_0x3ebc4b,_0x33b914,_0x39eb0b,_0x465722);}else _0x9b1fa4['splice'](_0x37c9b4[_0x294831],0x1);}for(var _0x1cbd51=0x0;_0x1cbd51<_0x37c9b4[_0x2f6ccb(0x2f7)];_0x1cbd51++){var _0x1d5fba=(_0x37c9b4[_0x1cbd51]-_0x5d9e49)[_0x2f6ccb(0x234)](_0x55810f,_0x9b1fa4[_0x2f6ccb(0x2f7)]);_0x9b1fa4[_0x2f6ccb(0xd0)](_0x1d5fba,0x0,_0x52cb03);}this['removeActionBattlersOTB'](),this[_0x2f6ccb(0x180)]();},VisuMZ[_0x591529(0x12b)][_0x591529(0x203)]=function(_0x45e101,_0x3daa3d){const _0x13b80e=[],_0x54c2be=_0x3daa3d['length'];for(let _0x832fce=0x0;_0x832fce<_0x54c2be;_0x832fce++){if(_0x3daa3d[_0x832fce]===_0x45e101)_0x13b80e['push'](_0x832fce);}return _0x13b80e;},VisuMZ[_0x591529(0x12b)][_0x591529(0x21f)]=function(_0x2a25e7){const _0x1620df=_0x591529;if(!BattleManager[_0x1620df(0x386)])return 0x0;if(!_0x2a25e7)return 0x0;let _0x2b5e03=0x0;const _0x29f26b=_0x2a25e7[_0x1620df(0x2f7)];for(let _0x4ec453=0x0;_0x4ec453<_0x29f26b;_0x4ec453++){const _0x522410=_0x2a25e7[_0x4ec453];if(!_0x522410)continue;if(_0x522410[_0x1620df(0x307)]()!==Infinity){if(_0x1620df(0x2fb)==='YboYw')this[_0x1620df(0xc3)]()?this[_0x1620df(0xc5)]():_0x1f1217[_0x1620df(0x12b)][_0x1620df(0x119)][_0x1620df(0x20a)](this);else return _0x4ec453;}else _0x2b5e03++;}return _0x2b5e03;},BattleManager[_0x591529(0x29b)]=function(){const _0x43100d=_0x591529;if(!this['isOTB']())return;const _0x3f0999=SceneManager[_0x43100d(0x37c)][_0x43100d(0x158)];if(!_0x3f0999)return;_0x3f0999[_0x43100d(0x27e)]();},BattleManager[_0x591529(0x1ea)]=function(){const _0x36c680=_0x591529;if(!this[_0x36c680(0xc3)]())return;const _0x48d8c0=SceneManager[_0x36c680(0x37c)][_0x36c680(0x158)];if(!_0x48d8c0)return;_0x48d8c0[_0x36c680(0xc2)]();},VisuMZ[_0x591529(0x12b)][_0x591529(0x20f)]=BattleManager[_0x591529(0xf9)],BattleManager[_0x591529(0xf9)]=function(){const _0x4d631f=_0x591529;return this[_0x4d631f(0x1c7)]=VisuMZ[_0x4d631f(0x12b)][_0x4d631f(0x20f)]['call'](this),this[_0x4d631f(0xc3)]()&&this['_subject']&&this[_0x4d631f(0x20c)](this[_0x4d631f(0x1c7)]),this[_0x4d631f(0x1c7)];},BattleManager[_0x591529(0x20c)]=function(_0x5b5d68){const _0x506a2e=_0x591529;if(!this[_0x506a2e(0xc3)]())return;const _0x5336cb=SceneManager['_scene'][_0x506a2e(0x158)];if(!_0x5336cb)return;if(!_0x5b5d68)return;_0x5336cb[_0x506a2e(0x1de)](_0x5b5d68);},BattleManager[_0x591529(0x180)]=function(){const _0x182d2a=_0x591529;if(!this[_0x182d2a(0xc3)]())return;const _0x180f8c=SceneManager[_0x182d2a(0x37c)][_0x182d2a(0x158)];if(!_0x180f8c)return;_0x180f8c[_0x182d2a(0x2fc)]();},VisuMZ[_0x591529(0x12b)]['BattleManager_endTurn']=BattleManager['endTurn'],BattleManager[_0x591529(0x116)]=function(){const _0x4bcf51=_0x591529;VisuMZ[_0x4bcf51(0x12b)]['BattleManager_endTurn']['call'](this),this[_0x4bcf51(0xc3)]()&&this[_0x4bcf51(0x1a0)]();},BattleManager['otbRemoveCurrentSubject']=function(){const _0x41c05b=_0x591529;if(!this[_0x41c05b(0xc3)]())return;const _0x2252fb=SceneManager['_scene'][_0x41c05b(0x158)];if(!_0x2252fb)return;_0x2252fb[_0x41c05b(0xfb)]();},BattleManager[_0x591529(0x2e2)]=function(){const _0x3db6cb=_0x591529;if(!this[_0x3db6cb(0xc3)]())return;const _0x2176fc=SceneManager[_0x3db6cb(0x37c)][_0x3db6cb(0x158)];if(!_0x2176fc)return;_0x2176fc['removeUnableTurnOrderSprites']();},BattleManager[_0x591529(0x128)]=function(_0x132b5c){const _0x39fd8=_0x591529;if(!_0x132b5c)return;const _0xe38868=_0x132b5c[_0x39fd8(0x23e)]();_0x132b5c['makeActions']();if(!this['_actionBattlers'][_0x39fd8(0x1b1)](_0x132b5c)){const _0x87d2b1=Math[_0x39fd8(0x195)](0x0,_0xe38868-(_0x132b5c[_0x39fd8(0x35c)]||0x0));this[_0x39fd8(0x2dc)](_0x132b5c,_0x87d2b1,this['_actionBattlers']);}if(!this['_otb_actionBattlersNext']['includes'](_0x132b5c)){const _0x20baa2=_0xe38868;this['otbAddBattlerToTurnOrderAtEnd'](_0x132b5c,_0x20baa2,this[_0x39fd8(0x229)]);}},BattleManager['otbAddBattlerToTurnOrderAtEnd']=function(_0x34ebad,_0x520444,_0x75f20){const _0x782963=_0x591529;if(!this[_0x782963(0xc3)]())return;const _0x14cd5b=SceneManager['_scene']['_otbTurnOrderWindow'];while(_0x520444--){_0x75f20[_0x782963(0x236)](_0x34ebad);if(_0x14cd5b){if('ZXHYj'==='ZXHYj')_0x14cd5b[_0x782963(0x30e)](_0x34ebad,_0x75f20);else return 0x1;}}},BattleManager[_0x591529(0x33a)]=function(_0x503fb0){const _0xa647fa=_0x591529;if(!_0x503fb0)return;const _0x39677b=_0x503fb0[_0xa647fa(0x23e)]();_0x503fb0[_0xa647fa(0x2b0)]();if(!this[_0xa647fa(0x259)][_0xa647fa(0x1b1)](_0x503fb0)){const _0x2171ed=Math[_0xa647fa(0x195)](0x0,_0x39677b-(_0x503fb0[_0xa647fa(0x35c)]||0x0));this[_0xa647fa(0x142)](_0x503fb0,_0x2171ed,this['_actionBattlers']);}if(!this['_otb_actionBattlersNext'][_0xa647fa(0x1b1)](_0x503fb0)){if(_0xa647fa(0x2b2)!==_0xa647fa(0x2b2)){if(!this[_0xa647fa(0xc3)]())return;const _0x2b676b=_0x44c9fd['_scene'][_0xa647fa(0x158)];if(!_0x2b676b)return;_0x2b676b['requestUpdateTurnOrders']();}else{const _0xee1a8e=_0x39677b;this[_0xa647fa(0x142)](_0x503fb0,_0xee1a8e,this[_0xa647fa(0x229)]);}}},BattleManager[_0x591529(0x29a)]=function(_0xa101e7,_0xd9fe70,_0x28defd){const _0x1f449b=_0x591529;if(!this[_0x1f449b(0xc3)]())return;const _0x337aee=SceneManager[_0x1f449b(0x37c)]['_otbTurnOrderWindow'];while(_0xd9fe70--){_0x28defd[_0x1f449b(0x17b)](_0xa101e7),_0x337aee&&_0x337aee[_0x1f449b(0x142)](_0xa101e7,_0x28defd);}},BattleManager[_0x591529(0x1ef)]=function(_0x5722ef){const _0x1c6bfd=_0x591529;if(!this[_0x1c6bfd(0xc3)]())return;const _0x471804=this[_0x1c6bfd(0x259)],_0x33f5e0=_0x5722ef===this[_0x1c6bfd(0x1c7)]?0x1:0x0;let _0x283f83=0x0;for(let _0x20d8fc=0x0;_0x20d8fc<_0x471804[_0x1c6bfd(0x2f7)];_0x20d8fc++){const _0x18115a=_0x471804[_0x20d8fc];if(!_0x18115a)continue;if(!_0x18115a[_0x1c6bfd(0xfd)])continue;if(!_0x18115a[_0x1c6bfd(0xfd)][_0x33f5e0])continue;if(!_0x18115a[_0x1c6bfd(0xfd)][_0x33f5e0]['_forceAction'])continue;_0x283f83=_0x20d8fc;}this['_actionBattlers'][_0x1c6bfd(0xd0)](_0x283f83,0x0,_0x5722ef);const _0x17fe40=SceneManager[_0x1c6bfd(0x37c)][_0x1c6bfd(0x158)];_0x17fe40&&_0x17fe40[_0x1c6bfd(0x380)](_0x5722ef,_0x283f83);},BattleManager[_0x591529(0x246)]=function(){const _0x153403=_0x591529;if(!this[_0x153403(0xc3)]())return;const _0x3c246c=SceneManager[_0x153403(0x37c)]['_otbTurnOrderWindow'];if(!_0x3c246c)return;_0x3c246c[_0x153403(0x102)](null);},BattleManager[_0x591529(0x2f2)]=function(){const _0x42455e=_0x591529;if(!this['isOTB']())return;const _0x58c88c=SceneManager[_0x42455e(0x37c)][_0x42455e(0x158)];if(!_0x58c88c)return;_0x58c88c['previewOrderByAction'](this['inputtingAction']());},VisuMZ[_0x591529(0x12b)][_0x591529(0x252)]=Game_System[_0x591529(0x217)][_0x591529(0x347)],Game_System[_0x591529(0x217)][_0x591529(0x347)]=function(){const _0x5c7ec0=_0x591529;VisuMZ[_0x5c7ec0(0x12b)][_0x5c7ec0(0x252)][_0x5c7ec0(0x20a)](this),this[_0x5c7ec0(0x25d)]();},Game_System[_0x591529(0x217)][_0x591529(0x25d)]=function(){const _0x12fab0=_0x591529;this[_0x12fab0(0x245)]=!![];},Game_System[_0x591529(0x217)][_0x591529(0x365)]=function(){const _0x2dba26=_0x591529;if(this['_otbTurnOrderVisible']===undefined){if(_0x2dba26(0x28e)==='qNpHc')this['initBattleSystemOTB']();else return this['_unit']===_0x3f61a7?_0x2dba26(0x18e):_0x2dba26(0x2a3);}return this[_0x2dba26(0x245)];},Game_System[_0x591529(0x217)][_0x591529(0x21a)]=function(_0x94c4e8){const _0x583af6=_0x591529;this[_0x583af6(0x245)]===undefined&&this[_0x583af6(0x25d)](),this[_0x583af6(0x245)]=_0x94c4e8;},Game_Action['OTB_CONVERT_AGI_BUFF_CURRENT_TURN']=VisuMZ['BattleSystemOTB'][_0x591529(0x2cd)][_0x591529(0x361)][_0x591529(0x107)],Game_Action['OTB_CONVERT_AGI_DEBUFF_CURRENT_TURN']=VisuMZ[_0x591529(0x12b)][_0x591529(0x2cd)][_0x591529(0x361)]['ConvertAgiDebuffCurrent'],Game_Action[_0x591529(0x309)]=VisuMZ[_0x591529(0x12b)][_0x591529(0x2cd)][_0x591529(0x361)][_0x591529(0x242)],Game_Action[_0x591529(0x273)]=VisuMZ[_0x591529(0x12b)][_0x591529(0x2cd)][_0x591529(0x361)][_0x591529(0x18b)],VisuMZ[_0x591529(0x12b)][_0x591529(0x1f3)]=Game_Action['prototype']['speed'],Game_Action[_0x591529(0x217)]['speed']=function(){const _0x296938=_0x591529;if(BattleManager[_0x296938(0xc3)]()){if(_0x296938(0x120)!=='zsscJ')this[_0x296938(0x26c)]=this[_0x296938(0x150)]();else return 0x0;}else return VisuMZ[_0x296938(0x12b)]['Game_Action_speed'][_0x296938(0x20a)](this);},VisuMZ['BattleSystemOTB'][_0x591529(0x256)]=Game_Action['prototype'][_0x591529(0x227)],Game_Action[_0x591529(0x217)][_0x591529(0x227)]=function(){const _0x1b6799=_0x591529;VisuMZ[_0x1b6799(0x12b)][_0x1b6799(0x256)][_0x1b6799(0x20a)](this),this[_0x1b6799(0x1a1)]();},Game_Action[_0x591529(0x217)][_0x591529(0x1a1)]=function(){const _0x16e895=_0x591529;if(!SceneManager[_0x16e895(0x21b)]())return;if(!BattleManager['isOTB']())return;if(!this[_0x16e895(0x2ac)]())return;if(!this['subject']())return;const _0x4a5952=VisuMZ[_0x16e895(0x12b)][_0x16e895(0x24a)],_0x216fe9=this[_0x16e895(0x2ac)]()['note'];_0x216fe9[_0x16e895(0x1d1)](_0x4a5952[_0x16e895(0x156)])&&this[_0x16e895(0x2af)]()[_0x16e895(0x1c5)](0x1);let _0x1e95a3=this[_0x16e895(0x373)](),_0x234b5c=this[_0x16e895(0x271)]();_0x1e95a3!==0x0&&(_0x16e895(0x287)!==_0x16e895(0x33f)?BattleManager[_0x16e895(0x13a)](this[_0x16e895(0x2af)](),-_0x1e95a3,![]):this[_0x16e895(0x15f)](_0x5dd712(_0x358f8d['$1']))),_0x234b5c!==0x0&&(_0x16e895(0x367)===_0x16e895(0x134)?_0x516b95['BattleSystemOTB'][_0x16e895(0x20d)][_0x16e895(0x20a)](this):BattleManager[_0x16e895(0x13a)](this['subject'](),-_0x234b5c,!![]));},Game_Action[_0x591529(0x217)]['otbCalcUserCurrentOrderChange']=function(){const _0x2ac585=_0x591529;if(!SceneManager['isSceneBattle']())return 0x0;if(!BattleManager['isOTB']())return 0x0;if(!this[_0x2ac585(0x2ac)]())return 0x0;if(!this['subject']())return 0x0;if(!this[_0x2ac585(0x2af)]()[_0x2ac585(0x186)]())return 0x0;const _0x39843c=VisuMZ[_0x2ac585(0x12b)][_0x2ac585(0x24a)],_0x19c984=this[_0x2ac585(0x2ac)]()['note'],_0x208fad=BattleManager[_0x2ac585(0x259)]||[];let _0x2681cd=0x0;_0x19c984[_0x2ac585(0x1d1)](_0x39843c[_0x2ac585(0x32d)])&&(_0x208fad[_0x2ac585(0x1b1)](this[_0x2ac585(0x2af)]())&&(_0x2ac585(0x329)===_0x2ac585(0x329)?_0x2681cd+=Number(RegExp['$1']):(this['_graphicSv']=_0x493a82[_0x2ac585(0x1d9)](),_0x302267=_0x31bb0b[_0x2ac585(0x34b)](this[_0x2ac585(0xe1)]),_0x573223[_0x2ac585(0x21c)](this['changeSvActorGraphicBitmap'][_0x2ac585(0x123)](this,_0x5ea1e4)))));if(_0x19c984[_0x2ac585(0x1d1)](_0x39843c[_0x2ac585(0x139)])){if(_0x2ac585(0x240)===_0x2ac585(0x272)){if(!_0xd0fa8e)return;if(_0x69ae6e===0x0)return;const _0x58ae59=_0x57fc34?_0x130f4a[_0x2ac585(0x229)]:_0x5f4fcf[_0x2ac585(0x259)],_0x554b3e=_0x7c848c[_0x2ac585(0x12b)][_0x2ac585(0x203)](_0x456e77,_0x58ae59),_0x451306=_0x227ecc?this[_0x2ac585(0x16b)]:this[_0x2ac585(0x1dc)],_0x146c16=_0x41a144?this[_0x2ac585(0x20b)]:this[_0x2ac585(0x1db)];if(_0x554b3e[_0x2ac585(0x2f7)]<=0x0)return;for(let _0x4f8794=0x0;_0x4f8794<_0x554b3e[_0x2ac585(0x2f7)];_0x4f8794++){const _0x158b04=new _0x3f5082(_0x30b243,_0x4f8794,_0x451306,_0x211ee2);this['_previewContainer'][_0x2ac585(0x2bb)](_0x158b04),_0x146c16[_0x2ac585(0x236)](_0x158b04),_0x158b04[_0x2ac585(0x173)](),_0x158b04[_0x2ac585(0x15d)](0xff);}}else _0x2681cd+=Number(RegExp['$1']);}return _0x2681cd;},Game_Action[_0x591529(0x217)][_0x591529(0x271)]=function(){const _0x9f8cd3=_0x591529;if(!SceneManager[_0x9f8cd3(0x21b)]())return 0x0;if(!BattleManager[_0x9f8cd3(0xc3)]())return 0x0;if(!this[_0x9f8cd3(0x2ac)]())return 0x0;if(!this['subject']())return 0x0;if(!this['subject']()[_0x9f8cd3(0x186)]())return 0x0;const _0x313918=VisuMZ[_0x9f8cd3(0x12b)]['Settings'][_0x9f8cd3(0x1c1)],_0x2f9d17=VisuMZ[_0x9f8cd3(0x12b)][_0x9f8cd3(0x24a)],_0x8f1008=this['item']()[_0x9f8cd3(0xc6)],_0x338bf7=BattleManager['_otb_actionBattlersNext']||[];let _0x30dbdc=0x0;_0x313918[_0x9f8cd3(0x1a3)]&&(_0x30dbdc+=_0x313918['ConvertSpeedJS']['call'](this));if(_0x8f1008[_0x9f8cd3(0x1d1)](_0x2f9d17['UserFollOrder'])){if(_0x9f8cd3(0x111)===_0x9f8cd3(0x111))_0x338bf7[_0x9f8cd3(0x1b1)](this[_0x9f8cd3(0x2af)]())&&(_0x30dbdc+=Number(RegExp['$1']));else{if(!this['isOTB']())return;const _0x1b7055=_0xcad9f4['_scene'][_0x9f8cd3(0x158)];if(!_0x1b7055)return;_0x1b7055[_0x9f8cd3(0x27e)]();}}return _0x8f1008[_0x9f8cd3(0x1d1)](_0x2f9d17[_0x9f8cd3(0x2b4)])&&(_0x30dbdc+=Number(RegExp['$1'])),_0x30dbdc;},VisuMZ[_0x591529(0x12b)][_0x591529(0x17c)]=Game_Action[_0x591529(0x217)][_0x591529(0x210)],Game_Action[_0x591529(0x217)][_0x591529(0x210)]=function(_0x193868){const _0x4b6ca2=_0x591529;VisuMZ[_0x4b6ca2(0x12b)][_0x4b6ca2(0x17c)]['call'](this,_0x193868),this['applyItemAddedActionOTB'](_0x193868),this[_0x4b6ca2(0x14e)](_0x193868);},Game_Action[_0x591529(0x217)][_0x591529(0x1d5)]=function(_0x427093){const _0x136fc4=_0x591529;if(!SceneManager[_0x136fc4(0x21b)]())return;if(!BattleManager[_0x136fc4(0xc3)]())return;if(!this[_0x136fc4(0x2ac)]())return;if(!_0x427093)return;const _0x533fdc=VisuMZ[_0x136fc4(0x12b)][_0x136fc4(0x24a)],_0x5d7f94=this[_0x136fc4(0x2ac)]()['note'];if(_0x5d7f94[_0x136fc4(0x1d1)](_0x533fdc['UserAddActionCurrent'])){if(_0x136fc4(0x155)===_0x136fc4(0x155)){const _0x5ad8ec=!![],_0x4a0ef3=Number(RegExp['$1'])||0x0;this[_0x136fc4(0x2af)]()[_0x136fc4(0x2d6)](_0x4a0ef3,_0x5ad8ec);}else return _0x771a1c['BattleSystemOTB']['Game_Action_speed'][_0x136fc4(0x20a)](this);}if(_0x5d7f94[_0x136fc4(0x1d1)](_0x533fdc[_0x136fc4(0xfe)])){if(_0x136fc4(0x1b0)!==_0x136fc4(0x1b0))return-_0x1ff0d3;else{const _0x48e594=![],_0x22f125=Number(RegExp['$1'])||0x0;this[_0x136fc4(0x2af)]()[_0x136fc4(0x2d6)](_0x22f125,_0x48e594);}}if(_0x5d7f94[_0x136fc4(0x1d1)](_0x533fdc[_0x136fc4(0x136)])){const _0x546606=!![],_0x540f46=Number(RegExp['$1'])||0x0;_0x427093[_0x136fc4(0x2d6)](_0x540f46,_0x546606);}if(_0x5d7f94['match'](_0x533fdc[_0x136fc4(0x32b)])){const _0xb8945f=![],_0x513fc2=Number(RegExp['$1'])||0x0;_0x427093['otbAddActions'](_0x513fc2,_0xb8945f);}},Game_Action[_0x591529(0x217)]['applyItemTargetEffectOTB']=function(_0xdfdd9b){const _0xa80048=_0x591529;if(!SceneManager[_0xa80048(0x21b)]())return;if(!BattleManager[_0xa80048(0xc3)]())return;if(!this['item']())return;if(!_0xdfdd9b)return;if(!_0xdfdd9b[_0xa80048(0x186)]())return 0x0;let _0x444a9c=this[_0xa80048(0x31e)](_0xdfdd9b),_0x295849=this[_0xa80048(0x10e)](_0xdfdd9b);_0x444a9c!==0x0&&BattleManager[_0xa80048(0x13a)](_0xdfdd9b,-_0x444a9c,![]),_0x295849!==0x0&&BattleManager[_0xa80048(0x13a)](_0xdfdd9b,-_0x295849,!![]);},Game_Action['prototype'][_0x591529(0x31e)]=function(_0x2b95b1){const _0x1ebf82=_0x591529;if(!SceneManager[_0x1ebf82(0x21b)]())return 0x0;if(!BattleManager[_0x1ebf82(0xc3)]())return 0x0;if(!this[_0x1ebf82(0x2ac)]())return 0x0;if(!_0x2b95b1)return 0x0;if(!_0x2b95b1['canChangeOtbTurnOrder']())return 0x0;const _0x54cd89=VisuMZ['BattleSystemOTB'][_0x1ebf82(0x24a)],_0x5b945c=this['item']()[_0x1ebf82(0xc6)],_0xbc5651=BattleManager[_0x1ebf82(0x259)]||[];let _0x84fb70=0x0;_0x5b945c[_0x1ebf82(0x1d1)](_0x54cd89[_0x1ebf82(0x211)])&&(_0xbc5651[_0x1ebf82(0x1b1)](_0x2b95b1)&&(_0x84fb70+=Number(RegExp['$1'])));_0x5b945c['match'](_0x54cd89[_0x1ebf82(0xdc)])&&(_0x84fb70+=Number(RegExp['$1']));const _0x328b3c=this[_0x1ebf82(0x2ac)]()[_0x1ebf82(0x1b7)];for(const _0x5cad1f of _0x328b3c){if(_0x1ebf82(0x2e6)==='Ozlwf'){if(!_0x5cad1f)continue;if(_0x5cad1f[_0x1ebf82(0x1a9)]===Game_Action['EFFECT_ADD_BUFF']&&_0x5cad1f[_0x1ebf82(0x370)]===0x6){if(Game_Action[_0x1ebf82(0x2a1)])_0x84fb70-=0x1;}if(_0x5cad1f[_0x1ebf82(0x1a9)]===Game_Action[_0x1ebf82(0xc7)]&&_0x5cad1f[_0x1ebf82(0x370)]===0x6){if(_0x1ebf82(0x316)===_0x1ebf82(0x316)){if(Game_Action[_0x1ebf82(0x28a)])_0x84fb70+=0x1;}else this['_graphicEnemy']=_0x47e44c[_0x1ebf82(0x2ec)](),_0xefdc6a=_0x3b2008['loadSvEnemy'](this[_0x1ebf82(0x350)]),_0xab208f['addLoadListener'](this[_0x1ebf82(0x306)]['bind'](this,_0x302d52));}}else{if(!this[_0x1ebf82(0x1c7)])return;this[_0x1ebf82(0x124)](this[_0x1ebf82(0x1c7)]);}}return _0x84fb70;},Game_Action['prototype'][_0x591529(0x10e)]=function(_0x497402){const _0x49c01d=_0x591529;if(!SceneManager['isSceneBattle']())return 0x0;if(!BattleManager[_0x49c01d(0xc3)]())return 0x0;if(!this['item']())return 0x0;if(!_0x497402)return 0x0;if(!_0x497402[_0x49c01d(0x186)]())return 0x0;const _0x500a1c=VisuMZ[_0x49c01d(0x12b)][_0x49c01d(0x24a)],_0x1e43ea=this[_0x49c01d(0x2ac)]()[_0x49c01d(0xc6)],_0x4fdd50=BattleManager[_0x49c01d(0x229)]||[];let _0x3349d0=0x0;_0x1e43ea[_0x49c01d(0x1d1)](_0x500a1c[_0x49c01d(0x211)])&&(_0x4fdd50['includes'](_0x497402)&&(_0x3349d0+=Number(RegExp['$1'])));_0x1e43ea[_0x49c01d(0x1d1)](_0x500a1c[_0x49c01d(0x34f)])&&('sXxYL'!==_0x49c01d(0x1ed)?(_0x1557af[_0x49c01d(0x236)](_0x331cf9),_0x1f3de7&&_0x2f770b[_0x49c01d(0x30e)](_0x461c55,_0x320c56)):_0x3349d0+=Number(RegExp['$1']));const _0x508129=this[_0x49c01d(0x2ac)]()[_0x49c01d(0x1b7)];for(const _0x56b34d of _0x508129){if('GOeRr'!==_0x49c01d(0x145)){const _0x14890d=this[_0x49c01d(0xe7)]();if(!_0x14890d)return;if(this[_0x49c01d(0xd3)]===_0x14890d[_0x49c01d(0xe5)]()&&this['_isAppeared']===_0x14890d[_0x49c01d(0x228)]())return;this[_0x49c01d(0xd3)]=_0x14890d[_0x49c01d(0xe5)](),this['_isAppeared']=_0x14890d[_0x49c01d(0x228)]();let _0x554890=this['_isAlive']&&this[_0x49c01d(0x2c8)]?0xff:0x0;this[_0x49c01d(0x15d)](_0x554890);}else{if(!_0x56b34d)continue;if(_0x56b34d[_0x49c01d(0x1a9)]===Game_Action['EFFECT_ADD_BUFF']&&_0x56b34d['dataId']===0x6){if(_0x49c01d(0x222)===_0x49c01d(0x314))_0x4c92a5['includes'](_0x5f4326)&&(_0x32e4ac+=_0x5b38e0(_0x35e368['$1']));else{if(Game_Action[_0x49c01d(0x309)])_0x3349d0-=0x1;}}if(_0x56b34d['code']===Game_Action[_0x49c01d(0xc7)]&&_0x56b34d[_0x49c01d(0x370)]===0x6){if('anovy'!=='anovy')this[_0x49c01d(0xd8)]='enemy';else{if(Game_Action[_0x49c01d(0x273)])_0x3349d0+=0x1;}}}}return _0x3349d0;},Game_BattlerBase[_0x591529(0x217)][_0x591529(0x2f3)]=function(){const _0x1e57d0=_0x591529;delete this[_0x1e57d0(0x1d7)],delete this['_otbTurnOrderFaceName'],delete this[_0x1e57d0(0x1c2)],delete this['_otbTurnOrderIconIndex'];},Game_BattlerBase[_0x591529(0x217)][_0x591529(0x356)]=function(){const _0x30b710=_0x591529;if(this[_0x30b710(0x1d7)]===undefined){if(_0x30b710(0x1a7)===_0x30b710(0x13b))return this[_0x30b710(0x1c2)]===_0x2d5d86&&(this[_0x30b710(0x1c2)]=this[_0x30b710(0xeb)]()),this[_0x30b710(0x1c2)];else this['_otbTurnOrderGraphicType']=this[_0x30b710(0x12d)]();}return this[_0x30b710(0x1d7)];},Game_BattlerBase[_0x591529(0x217)][_0x591529(0x12d)]=function(){const _0x4c2f89=_0x591529;return Window_OTB_TurnOrder[_0x4c2f89(0x2cd)][_0x4c2f89(0x2f8)];},Game_BattlerBase[_0x591529(0x217)][_0x591529(0x144)]=function(){const _0x111ebc=_0x591529;return this['_otbTurnOrderFaceName']===undefined&&(this[_0x111ebc(0x26c)]=this[_0x111ebc(0x150)]()),this[_0x111ebc(0x26c)];},Game_BattlerBase[_0x591529(0x217)][_0x591529(0x150)]=function(){const _0x306077=_0x591529;return Window_OTB_TurnOrder[_0x306077(0x2cd)][_0x306077(0x232)];},Game_BattlerBase[_0x591529(0x217)]['TurnOrderOTBGraphicFaceIndex']=function(){const _0x33cfba=_0x591529;if(this[_0x33cfba(0x1c2)]===undefined){if(_0x33cfba(0x264)===_0x33cfba(0x2d3)){const _0x4a4647=new _0x4b222f(_0x24d35a,-0x1,null);this['_spriteContainer'][_0x33cfba(0x2bb)](_0x4a4647),this[_0x33cfba(0x1c7)]=_0x4a4647,_0x4a4647[_0x33cfba(0x15d)](0xff),_0x4a4647[_0x33cfba(0x1e6)]=0x258,_0x4a4647['x']=this[_0x33cfba(0x265)],_0x4a4647[_0x33cfba(0x34c)]=this[_0x33cfba(0x265)],_0x462721&&(_0x4a4647[_0x33cfba(0x2c6)]=0xff);}else this[_0x33cfba(0x1c2)]=this['createTurnOrderOTBGraphicFaceIndex']();}return this[_0x33cfba(0x1c2)];},Game_BattlerBase[_0x591529(0x217)][_0x591529(0xeb)]=function(){const _0x2ae27b=_0x591529;return Window_OTB_TurnOrder[_0x2ae27b(0x2cd)][_0x2ae27b(0x1fc)];},Game_BattlerBase[_0x591529(0x217)][_0x591529(0x2b3)]=function(){const _0x4f8928=_0x591529;if(this['_otbTurnOrderIconIndex']===undefined){if(_0x4f8928(0x2aa)!==_0x4f8928(0x33e))this[_0x4f8928(0x37e)]=this[_0x4f8928(0xf8)]();else{const _0x2ab093=_0x17c189[_0x4f8928(0x2cd)];return _0x2ab093[_0x4f8928(0x28f)];}}return this[_0x4f8928(0x37e)];},Game_BattlerBase[_0x591529(0x217)]['createTurnOrderOTBGraphicIconIndex']=function(){const _0x1eb004=_0x591529;return Window_OTB_TurnOrder['Settings'][_0x1eb004(0x2c3)];},Game_BattlerBase[_0x591529(0x217)][_0x591529(0x10d)]=function(_0x5b880b){const _0x42978e=_0x591529;this[_0x42978e(0x37e)]=_0x5b880b;},VisuMZ[_0x591529(0x12b)][_0x591529(0x334)]=Game_BattlerBase[_0x591529(0x217)][_0x591529(0x1a8)],Game_BattlerBase[_0x591529(0x217)]['hide']=function(){const _0x414f57=_0x591529;VisuMZ[_0x414f57(0x12b)][_0x414f57(0x334)][_0x414f57(0x20a)](this),BattleManager['removeActionBattlersOTB']();},VisuMZ[_0x591529(0x12b)][_0x591529(0x159)]=Game_BattlerBase[_0x591529(0x217)][_0x591529(0xdf)],Game_BattlerBase['prototype'][_0x591529(0xdf)]=function(){const _0x50fae6=_0x591529,_0x30cf15=this['_hidden'];VisuMZ[_0x50fae6(0x12b)]['Game_BattlerBase_appear'][_0x50fae6(0x20a)](this),BattleManager['isOTB']()&&SceneManager['isSceneBattle']()&&_0x30cf15&&!this[_0x50fae6(0x103)]&&BattleManager['otbReturnBattlerToTurnOrders'](this);},VisuMZ[_0x591529(0x12b)][_0x591529(0x294)]=Game_Battler[_0x591529(0x217)][_0x591529(0x1a5)],Game_Battler['prototype'][_0x591529(0x1a5)]=function(){const _0x3e98db=_0x591529;VisuMZ[_0x3e98db(0x12b)]['Game_Battler_performCollapse']['call'](this),BattleManager[_0x3e98db(0x319)]();},Game_Battler[_0x591529(0x31a)]=VisuMZ[_0x591529(0x12b)][_0x591529(0x2cd)][_0x591529(0x1c1)][_0x591529(0x2cf)],VisuMZ[_0x591529(0x12b)][_0x591529(0x2bd)]=Game_Battler[_0x591529(0x217)][_0x591529(0x14d)],Game_Battler[_0x591529(0x217)][_0x591529(0x14d)]=function(_0x34d3f8){const _0x5035ec=_0x591529;VisuMZ[_0x5035ec(0x12b)][_0x5035ec(0x2bd)][_0x5035ec(0x20a)](this,_0x34d3f8),this[_0x5035ec(0xde)](_0x34d3f8);},Game_Battler[_0x591529(0x217)][_0x591529(0xde)]=function(_0x10e991){const _0x58acce=_0x591529;if(!BattleManager['isOTB']())return;this[_0x58acce(0x35c)]=0x0;},VisuMZ['BattleSystemOTB']['Game_Battler_onBattleEnd']=Game_Battler[_0x591529(0x217)][_0x591529(0x32e)],Game_Battler[_0x591529(0x217)][_0x591529(0x32e)]=function(){const _0x9f9089=_0x591529;VisuMZ['BattleSystemOTB'][_0x9f9089(0x131)][_0x9f9089(0x20a)](this),this[_0x9f9089(0x312)]();},Game_Battler[_0x591529(0x217)][_0x591529(0x312)]=function(){const _0x5ce928=_0x591529;if(!BattleManager[_0x5ce928(0xc3)]())return;this[_0x5ce928(0x35c)]=0x0;},Game_Battler[_0x591529(0x217)][_0x591529(0x149)]=function(){const _0x2a76c2=_0x591529;if(!BattleManager[_0x2a76c2(0xc3)]())return;this['_otbTimesActedThisTurn']=this[_0x2a76c2(0x35c)]||0x0,this['_otbTimesActedThisTurn']++;if(this[_0x2a76c2(0x185)]()>0x0&&this===BattleManager[_0x2a76c2(0x1c7)]){if('REnaG'===_0x2a76c2(0x2be)){if(!_0x42bd0d[_0x2a76c2(0x31a)])return![];if(!this[_0x2a76c2(0xe5)]())return![];if(!this[_0x2a76c2(0x228)]())return![];if(this[_0x2a76c2(0xf1)]())return![];const _0x15690f=_0x3c18ee[_0x2a76c2(0x2a5)](this);return _0x15690f['_tempActor']=!![],_0x15690f[_0x2a76c2(0x25b)]=!![],_0x15690f[_0x2a76c2(0x335)](),_0x15690f[_0x2a76c2(0x231)](0x1),_0x15690f[_0x2a76c2(0x231)](0x2),_0x15690f[_0x2a76c2(0x358)](),_0x15690f[_0x2a76c2(0xf1)]();}else{const _0x1b5dbf=BattleManager[_0x2a76c2(0x218)];if(_0x1b5dbf[_0x2a76c2(0x2f7)]>0x0&&_0x1b5dbf[0x0]!==this){if(_0x2a76c2(0x311)!==_0x2a76c2(0x2cb))return;else{const _0x2faf10=_0xc51f03===_0x3b1f69[_0x2a76c2(0x259)]?this['_currentTurn']:this[_0x2a76c2(0x16b)];if(!_0x2faf10)return;const _0x3d6cba=_0x5e9d85[_0x2a76c2(0x12b)][_0x2a76c2(0x203)](_0x2b08bc,_0xf9e962),_0x58c50e=_0x3d6cba[_0x2a76c2(0x2f7)]-0x1,_0x5e0164=new _0xc2e997(_0x7c3833,_0x58c50e,_0x2faf10);this[_0x2a76c2(0x249)][_0x2a76c2(0x2bb)](_0x5e0164),_0x2faf10[_0x2a76c2(0x236)](_0x5e0164),_0x5e0164['startFade'](0xff),this[_0x2a76c2(0x2fc)]();}}const _0x188377=this[_0x2a76c2(0xe7)]();if(_0x188377&&BattleManager[_0x2a76c2(0x267)](this))_0x188377['stepForward']();}}},BattleManager[_0x591529(0x267)]=function(_0x4103c3){const _0x628e50=_0x591529;if(!_0x4103c3)return![];return this[_0x628e50(0x259)][0x0]===_0x4103c3;},VisuMZ[_0x591529(0x12b)][_0x591529(0xdd)]=Game_Battler['prototype'][_0x591529(0x299)],Game_Battler[_0x591529(0x217)][_0x591529(0x299)]=function(){const _0x407c3a=_0x591529;VisuMZ[_0x407c3a(0x12b)][_0x407c3a(0xdd)][_0x407c3a(0x20a)](this),this['onTurnEndOTB']();},Game_Battler[_0x591529(0x217)]['onTurnEndOTB']=function(){const _0x2d3b57=_0x591529;if(!BattleManager[_0x2d3b57(0xc3)]())return;this[_0x2d3b57(0x35c)]=0x0;},VisuMZ[_0x591529(0x12b)]['Game_Battler_makeSpeed']=Game_Battler[_0x591529(0x217)]['makeSpeed'],Game_Battler[_0x591529(0x217)]['makeSpeed']=function(){const _0x51a0c5=_0x591529;if(BattleManager[_0x51a0c5(0xc3)]())this[_0x51a0c5(0x191)]();else{if('zjKPK'!=='zjKPK'){if(!_0x8269b[_0x51a0c5(0xc3)]())return;this[_0x51a0c5(0x158)]=new _0x5b613b();const _0x232eba=this[_0x51a0c5(0xd1)](this[_0x51a0c5(0xc1)]);this['addChildAt'](this[_0x51a0c5(0x158)],_0x232eba),this[_0x51a0c5(0x1e0)](),_0x1c004c[_0x51a0c5(0x1ca)]()&&this['_otbTurnOrderWindow'][_0x51a0c5(0x247)]();}else VisuMZ[_0x51a0c5(0x12b)][_0x51a0c5(0x1e4)][_0x51a0c5(0x20a)](this);}},Game_Battler[_0x591529(0x217)][_0x591529(0x191)]=function(){const _0x8634b8=_0x591529;if(this[_0x8634b8(0x16a)]())this['_speed']=Infinity;else{if(_0x8634b8(0xc4)===_0x8634b8(0x129)){const _0x40918e=this[_0x8634b8(0xf1)](),_0x439239=this[_0x8634b8(0x23e)]();_0x438850[_0x8634b8(0x12b)]['Game_Battler_addState'][_0x8634b8(0x20a)](this,_0x2b8c58),this[_0x8634b8(0x24d)](_0x40918e,_0x439239);}else{const _0x197b8b=this[_0x8634b8(0x15e)]()||new Game_Action(this);this[_0x8634b8(0x331)]=VisuMZ[_0x8634b8(0x12b)][_0x8634b8(0x2cd)]['Mechanics'][_0x8634b8(0x22e)][_0x8634b8(0x20a)](_0x197b8b);}}},Game_Battler[_0x591529(0x217)][_0x591529(0x16a)]=function(){const _0x303af1=_0x591529;if(!Game_Battler[_0x303af1(0x31a)])return![];if(!this[_0x303af1(0xe5)]())return![];if(!this[_0x303af1(0x228)]())return![];if(this['canMove']())return![];const _0x3ed454=JsonEx['makeDeepCopy'](this);return _0x3ed454[_0x303af1(0x169)]=!![],_0x3ed454[_0x303af1(0x25b)]=!![],_0x3ed454[_0x303af1(0x335)](),_0x3ed454['removeStatesAuto'](0x1),_0x3ed454[_0x303af1(0x231)](0x2),_0x3ed454[_0x303af1(0x358)](),_0x3ed454[_0x303af1(0xf1)]();},VisuMZ[_0x591529(0x12b)][_0x591529(0x239)]=Game_Action[_0x591529(0x217)][_0x591529(0x21e)],Game_Action[_0x591529(0x217)][_0x591529(0x21e)]=function(){const _0x144350=_0x591529;if(BattleManager[_0x144350(0xc3)]()){if(_0x144350(0x1b5)!=='UXpaP')return VisuMZ[_0x144350(0x12b)][_0x144350(0x2cd)][_0x144350(0x1c1)][_0x144350(0x277)];else this[_0x144350(0x158)][_0x144350(0x247)]();}else return VisuMZ['BattleSystemOTB']['Game_Action_allowRandomSpeed'][_0x144350(0x20a)](this);},Game_Battler['prototype'][_0x591529(0x1c5)]=function(_0x42ba01){const _0xa0e28e=_0x591529;if(!this['canMove']())return;this['_otbTimesActedThisTurn']=this[_0xa0e28e(0x35c)]||0x0,this['_otbTimesActedThisTurn']--,BattleManager['otbAddBattlerToTurnOrderAtStart'](this,_0x42ba01,BattleManager['_actionBattlers']);},Game_Battler[_0x591529(0x217)][_0x591529(0x2d6)]=function(_0x441792,_0x52a81a){const _0x2247f0=_0x591529;if(!this[_0x2247f0(0xf1)]())return;if(_0x52a81a)BattleManager[_0x2247f0(0x2dc)](this,_0x441792,BattleManager['_actionBattlers']);else{if(_0x2247f0(0x157)!==_0x2247f0(0x157))return this[_0x2247f0(0xdb)]?this[_0x2247f0(0xdb)][_0x2247f0(0x1b3)]()[this[_0x2247f0(0xc0)]]:null;else BattleManager['otbAddBattlerToTurnOrderAtEnd'](this,_0x441792,BattleManager[_0x2247f0(0x229)]);}},Game_Battler['prototype']['canChangeOtbTurnOrder']=function(){const _0x37d4f8=_0x591529;if(this[_0x37d4f8(0x307)]()===Infinity)return![];return!![];},Game_Battler['prototype'][_0x591529(0x24d)]=function(_0x4c7dc5,_0x2778e1){const _0x342164=_0x591529;if(this[_0x342164(0x25b)]||this[_0x342164(0x169)])return;if(!SceneManager['isSceneBattle']())return;if(!BattleManager[_0x342164(0xc3)]())return;if(_0x4c7dc5&&!this[_0x342164(0xf1)]())BattleManager[_0x342164(0x319)]();else!_0x4c7dc5&&this[_0x342164(0xf1)]()&&(_0x342164(0x1da)!==_0x342164(0x2ce)?BattleManager[_0x342164(0x128)](this):this[_0x342164(0x1d7)]=this[_0x342164(0x12d)]());if(this[_0x342164(0xf1)]()){if(_0x342164(0x359)===_0x342164(0x359)){const _0x4d162e=this[_0x342164(0x23e)]()-_0x2778e1;_0x4d162e>0x0&&(BattleManager[_0x342164(0x2dc)](this,_0x4d162e,BattleManager[_0x342164(0x259)]),BattleManager['otbAddBattlerToTurnOrderAtEnd'](this,_0x4d162e,BattleManager[_0x342164(0x229)]));}else _0x2675cf[_0x342164(0x246)](),_0x202535[_0x342164(0x12b)][_0x342164(0x310)][_0x342164(0x20a)](this);}},VisuMZ[_0x591529(0x12b)][_0x591529(0x230)]=Game_Battler[_0x591529(0x217)][_0x591529(0x216)],Game_Battler[_0x591529(0x217)][_0x591529(0x216)]=function(_0x1689af){const _0x36184c=_0x591529,_0x4f6b8b=this[_0x36184c(0xf1)](),_0x1996bd=this[_0x36184c(0x23e)]();VisuMZ[_0x36184c(0x12b)][_0x36184c(0x230)][_0x36184c(0x20a)](this,_0x1689af),this[_0x36184c(0x24d)](_0x4f6b8b,_0x1996bd);},VisuMZ[_0x591529(0x12b)][_0x591529(0x2e5)]=Game_Battler['prototype']['removeState'],Game_Battler[_0x591529(0x217)][_0x591529(0x176)]=function(_0x7348a8){const _0x4d3a8f=_0x591529,_0x252a09=this['canMove'](),_0x17fd70=this[_0x4d3a8f(0x23e)]();VisuMZ[_0x4d3a8f(0x12b)][_0x4d3a8f(0x2e5)][_0x4d3a8f(0x20a)](this,_0x7348a8),this[_0x4d3a8f(0x24d)](_0x252a09,_0x17fd70);},VisuMZ[_0x591529(0x12b)][_0x591529(0x36b)]=Game_BattlerBase[_0x591529(0x217)][_0x591529(0x2a6)],Game_BattlerBase['prototype']['recoverAll']=function(){const _0x512341=_0x591529;if(BattleManager[_0x512341(0xc3)]())this[_0x512341(0x176)](this[_0x512341(0x353)]());VisuMZ[_0x512341(0x12b)][_0x512341(0x36b)][_0x512341(0x20a)](this);if(BattleManager[_0x512341(0xc3)]())this['refresh']();},VisuMZ[_0x591529(0x12b)]['Game_Battler_forceAction']=Game_Battler[_0x591529(0x217)][_0x591529(0x1fd)],Game_Battler[_0x591529(0x217)][_0x591529(0x1fd)]=function(_0x2d2a1c,_0x305fb3){const _0x438ec5=_0x591529;if(BattleManager[_0x438ec5(0xc3)]()){if(_0x438ec5(0x19d)===_0x438ec5(0x1e3)){const _0x11b766=_0x4199ed[_0x438ec5(0x205)][_0x438ec5(0x2cd)][_0x438ec5(0x12c)];_0x3d2149-=_0x11b766[_0x438ec5(0x315)]+_0x11b766[_0x438ec5(0x1cc)],_0x561d1b-=_0x5b01f5[_0x438ec5(0x1ad)];}else this[_0x438ec5(0x11f)](_0x2d2a1c,_0x305fb3);}else VisuMZ[_0x438ec5(0x12b)][_0x438ec5(0x2d4)][_0x438ec5(0x20a)](this,_0x2d2a1c,_0x305fb3);},Game_Battler[_0x591529(0x217)][_0x591529(0x11f)]=function(_0x5193ad,_0x129289){const _0x7363b0=_0x591529,_0xabf0c2=new Game_Action(this,!![]);_0xabf0c2['setSkill'](_0x5193ad),_0xabf0c2[_0x7363b0(0x19f)]=!![];if(_0x129289===-0x2){if(_0x7363b0(0x381)!==_0x7363b0(0x381)){if(!_0x504cfa[_0x7363b0(0xc3)]())return;this[_0x7363b0(0x35c)]=0x0;}else _0xabf0c2[_0x7363b0(0x2c7)](this[_0x7363b0(0x360)]);}else _0x129289===-0x1?_0xabf0c2[_0x7363b0(0x1e9)]():_0xabf0c2[_0x7363b0(0x2c7)](_0x129289);this[_0x7363b0(0xfd)][_0x7363b0(0x236)](_0xabf0c2);},VisuMZ[_0x591529(0x12b)][_0x591529(0x24c)]=BattleManager[_0x591529(0x1fd)],BattleManager['forceAction']=function(_0x1ad018){const _0x14aaa6=_0x591529;BattleManager[_0x14aaa6(0xc3)]()?this['forceActionOTB'](_0x1ad018):VisuMZ['BattleSystemOTB'][_0x14aaa6(0x24c)][_0x14aaa6(0x20a)](this,_0x1ad018);},BattleManager[_0x591529(0x11f)]=function(_0x4840d8){BattleManager['otbAddForceActionBattler'](_0x4840d8);},VisuMZ[_0x591529(0x12b)][_0x591529(0x26d)]=Game_Actor[_0x591529(0x217)]['selectNextCommand'],Game_Actor[_0x591529(0x217)][_0x591529(0x292)]=function(){const _0x413dc9=_0x591529;if(BattleManager[_0x413dc9(0xc3)]()){if('iuyAW'===_0x413dc9(0x384)){if(this['battler']())this['battler']()[_0x413dc9(0x330)]();return![];}else _0x525e0f['_ogWindowLayerX']=_0x1dc3b2[_0x413dc9(0x2b6)]((_0x39bbf0[_0x413dc9(0x164)]-_0x349cec[_0x413dc9(0x235)](_0x1701e7[_0x413dc9(0x34a)],_0x4a030d['width']))/0x2);}return VisuMZ[_0x413dc9(0x12b)][_0x413dc9(0x26d)]['call'](this);},Game_Actor['prototype'][_0x591529(0x12d)]=function(){const _0x3887fb=_0x591529,_0x4abdc9=this[_0x3887fb(0x12e)]()[_0x3887fb(0xc6)];if(_0x4abdc9[_0x3887fb(0x1d1)](/<OTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i)){if(_0x3887fb(0x1d8)!==_0x3887fb(0x1d8))_0x21c1ad['otbPreviewOrderClear'](),_0x5b2b5a[_0x3887fb(0x12b)][_0x3887fb(0x368)]['call'](this);else return _0x3887fb(0x11d);}else{if(_0x4abdc9[_0x3887fb(0x1d1)](/<OTB TURN ORDER ICON:[ ](\d+)>/i))return _0x3887fb(0x14b);}return Window_OTB_TurnOrder['Settings'][_0x3887fb(0x37d)];},Game_Actor[_0x591529(0x217)][_0x591529(0x150)]=function(){const _0x137946=_0x591529,_0x43c146=this[_0x137946(0x12e)]()[_0x137946(0xc6)];if(_0x43c146[_0x137946(0x1d1)](/<OTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i)){if(_0x137946(0x30b)===_0x137946(0x14f)){const _0x2e3269=this['_currentTurn'][_0x137946(0x106)]();_0x2e3269[_0x137946(0x15d)](0x0);}else return String(RegExp['$1']);}return this[_0x137946(0x2d1)]();},Game_Actor[_0x591529(0x217)][_0x591529(0xeb)]=function(){const _0x1f8875=_0x591529,_0x62c160=this[_0x1f8875(0x12e)]()[_0x1f8875(0xc6)];if(_0x62c160[_0x1f8875(0x1d1)](/<OTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return _0x1f8875(0xe6)!==_0x1f8875(0x378)?Number(RegExp['$2']):_0x22f5ce[_0x1f8875(0xc3)]();return this[_0x1f8875(0x261)]();},Game_Actor[_0x591529(0x217)][_0x591529(0xf8)]=function(){const _0x1a001b=_0x591529,_0x14b113=this['actor']()[_0x1a001b(0xc6)];if(_0x14b113[_0x1a001b(0x1d1)](/<OTB TURN ORDER ICON:[ ](\d+)>/i))return Number(RegExp['$1']);return Window_OTB_TurnOrder[_0x1a001b(0x2cd)][_0x1a001b(0x188)];},Game_Enemy['prototype'][_0x591529(0x12d)]=function(){const _0x3d3d11=_0x591529,_0x36c52a=this['enemy']()[_0x3d3d11(0xc6)];if(_0x36c52a[_0x3d3d11(0x1d1)](/<OTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return _0x3d3d11(0x11d);else{if(_0x36c52a['match'](/<OTB TURN ORDER ICON:[ ](\d+)>/i)){if('vYpzk'!==_0x3d3d11(0xd5))_0x190405=_0xf02b92[_0x3d3d11(0x151)](_0x298e09[_0x3d3d11(0x2f7)]-_0x4314f5)+_0x590079;else return _0x3d3d11(0x14b);}}return Window_OTB_TurnOrder[_0x3d3d11(0x2cd)][_0x3d3d11(0x2f8)];},Game_Enemy[_0x591529(0x217)][_0x591529(0x150)]=function(){const _0x339ac4=_0x591529,_0x5455cb=this['enemy']()['note'];if(_0x5455cb[_0x339ac4(0x1d1)](/<OTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i)){if(_0x339ac4(0xf4)!==_0x339ac4(0xf4))this[_0x339ac4(0xd9)]/=0x2,this['_fadeDuration']=_0xfaa2d9[_0x339ac4(0x2e4)](this['_fadeDuration']);else return String(RegExp['$1']);}return Window_OTB_TurnOrder[_0x339ac4(0x2cd)][_0x339ac4(0x232)];},Game_Enemy[_0x591529(0x217)][_0x591529(0xeb)]=function(){const _0x145db8=_0x591529,_0x4e8101=this[_0x145db8(0x1fe)]()['note'];if(_0x4e8101[_0x145db8(0x1d1)](/<OTB TURN ORDER FACE:[ ](.*),[ ](\d+)>/i))return Number(RegExp['$2']);return Window_OTB_TurnOrder[_0x145db8(0x2cd)][_0x145db8(0x1fc)];},Game_Enemy['prototype'][_0x591529(0xf8)]=function(){const _0x23429b=_0x591529,_0x5c21df=this[_0x23429b(0x1fe)]()['note'];if(_0x5c21df[_0x23429b(0x1d1)](/<OTB TURN ORDER ICON:[ ](\d+)>/i))return Number(RegExp['$1']);return Window_OTB_TurnOrder[_0x23429b(0x2cd)][_0x23429b(0x2c3)];},VisuMZ[_0x591529(0x12b)][_0x591529(0x26f)]=Game_Party['prototype'][_0x591529(0x322)],Game_Party['prototype'][_0x591529(0x322)]=function(_0x376149){const _0x406090=_0x591529;VisuMZ['BattleSystemOTB']['Game_Party_addActor'][_0x406090(0x20a)](this,_0x376149);if(Imported[_0x406090(0x1a4)])return;if(SceneManager['isSceneBattle']()&&BattleManager[_0x406090(0xc3)]()){if(_0x406090(0x257)!==_0x406090(0x257)){const _0x5dad60=[],_0x9f8733=_0x1e7c15[_0x406090(0x2f7)];for(let _0x3b369f=0x0;_0x3b369f<_0x9f8733;_0x3b369f++){if(_0x201f6e[_0x3b369f]===_0x5b0c61)_0x5dad60[_0x406090(0x236)](_0x3b369f);}return _0x5dad60;}else BattleManager['removeActionBattlersOTB'](),BattleManager['otbReturnBattlerToTurnOrders']($gameActors[_0x406090(0x12e)](_0x376149));}},VisuMZ[_0x591529(0x12b)][_0x591529(0x132)]=Game_Party[_0x591529(0x217)]['removeActor'],Game_Party[_0x591529(0x217)]['removeActor']=function(_0x62e43){const _0x334f37=_0x591529;VisuMZ[_0x334f37(0x12b)][_0x334f37(0x132)][_0x334f37(0x20a)](this,_0x62e43);if(SceneManager[_0x334f37(0x21b)]()&&BattleManager[_0x334f37(0xc3)]()){if(_0x334f37(0x2b7)==='dTYYl'){const _0x2065eb=_0x5a3c65[_0x334f37(0x15e)]();if(!_0x2065eb)_0x15a8cc['BattleSystemOTB'][_0x334f37(0x20d)][_0x334f37(0x20a)](this);else _0x2065eb[_0x334f37(0x19f)]?_0x3ec098[_0x334f37(0x12b)][_0x334f37(0x20d)][_0x334f37(0x20a)](this):(this[_0x334f37(0x377)]=_0x93264b,this[_0x334f37(0x22b)]());}else BattleManager[_0x334f37(0x319)]();}},VisuMZ['BattleSystemOTB'][_0x591529(0x1bd)]=Scene_Battle['prototype'][_0x591529(0x177)],Scene_Battle['prototype'][_0x591529(0x177)]=function(){const _0x1a67df=_0x591529;VisuMZ[_0x1a67df(0x12b)][_0x1a67df(0x1bd)]['call'](this),BattleManager[_0x1a67df(0xc3)]()&&this[_0x1a67df(0x284)]();},Scene_Battle[_0x591529(0x217)][_0x591529(0x284)]=function(){const _0xab6d1=_0x591529,_0x128661=this[_0xab6d1(0x238)];if(this[_0xab6d1(0x275)]()){if(_0xab6d1(0x19c)!==_0xab6d1(0x19c)){var _0x227e52=(_0x26a6ea[_0x467bae]-_0x29f70d)[_0xab6d1(0x234)](_0x34237c,_0x3bec13['length']);_0x5dd029[_0xab6d1(0xd0)](_0x227e52,0x0,_0x117a6e);}else delete _0x128661[_0xab6d1(0x2b1)][_0xab6d1(0x23b)];}},VisuMZ[_0x591529(0x12b)]['Scene_Battle_commandCancel']=Scene_Battle[_0x591529(0x217)]['commandCancel'],Scene_Battle['prototype'][_0x591529(0x35b)]=function(){const _0x3674fe=_0x591529;if(BattleManager[_0x3674fe(0xc3)]())this[_0x3674fe(0xd6)]();else{if('ziEDN'!==_0x3674fe(0x345))VisuMZ[_0x3674fe(0x12b)][_0x3674fe(0xcf)][_0x3674fe(0x20a)](this);else{if(_0x2b35a1[_0x3674fe(0x309)])_0x36bb99-=0x1;}}},Scene_Battle[_0x591529(0x217)]['commandCancelOTB']=function(){const _0x52accf=_0x591529;BattleManager[_0x52accf(0x246)](),this[_0x52accf(0x372)][_0x52accf(0x17d)](),this['_actorCommandWindow']['close']();},VisuMZ['BattleSystemOTB']['Scene_Battle_commandFight']=Scene_Battle['prototype']['commandFight'],Scene_Battle[_0x591529(0x217)][_0x591529(0x2bc)]=function(){const _0x78491=_0x591529;if(BattleManager['isOTB']())_0x78491(0x308)!=='AuZcn'?(_0x1b533e['otbPreviewOrderClear'](),_0x2386c2[_0x78491(0x12b)][_0x78491(0x1ac)][_0x78491(0x20a)](this)):this[_0x78491(0x30c)]();else{if(_0x78491(0x2fd)!==_0x78491(0x17a))VisuMZ[_0x78491(0x12b)]['Scene_Battle_commandFight'][_0x78491(0x20a)](this);else{const _0x18d65d=this[_0x78491(0x1ee)]();this[_0x78491(0x233)](_0x18d65d),_0x336d57['prototype']['initialize'][_0x78491(0x20a)](this,_0x18d65d),this[_0x78491(0x2c6)]=0x0,this[_0x78491(0x137)](),this['drawUiText'](),this[_0x78491(0x351)](),this[_0x78491(0x1d3)]();}}},VisuMZ[_0x591529(0x12b)]['Scene_Battle_createAllWindows']=Scene_Battle[_0x591529(0x217)]['createAllWindows'],Scene_Battle[_0x591529(0x217)][_0x591529(0x18c)]=function(){const _0x581864=_0x591529;VisuMZ[_0x581864(0x12b)][_0x581864(0x153)]['call'](this),this[_0x581864(0x295)]();},Scene_Battle['prototype'][_0x591529(0x295)]=function(){const _0x32bd0b=_0x591529;if(!BattleManager[_0x32bd0b(0xc3)]())return;this['_otbTurnOrderWindow']=new Window_OTB_TurnOrder();const _0x324c82=this[_0x32bd0b(0xd1)](this[_0x32bd0b(0xc1)]);this[_0x32bd0b(0x36f)](this[_0x32bd0b(0x158)],_0x324c82),this[_0x32bd0b(0x1e0)]();if(SceneManager[_0x32bd0b(0x1ca)]()){if(_0x32bd0b(0xf6)!=='bajbz')this[_0x32bd0b(0x158)][_0x32bd0b(0x247)]();else return _0x2fb402(_0x179463['$1']);}},Scene_Battle[_0x591529(0x217)][_0x591529(0x1e0)]=function(){const _0x349ae0=_0x591529,_0x3c7f30=Window_OTB_TurnOrder['Settings'];if(_0x3c7f30['DisplayPosition']!==_0x349ae0(0x35a))return;if(!_0x3c7f30[_0x349ae0(0x2c9)])return;if(!this[_0x349ae0(0x2a2)])return;const _0x2d5e05=this[_0x349ae0(0x158)]['y']-Math[_0x349ae0(0x2b6)]((Graphics[_0x349ae0(0xfa)]-Graphics[_0x349ae0(0x1cf)])/0x2),_0x4610bc=_0x2d5e05+this[_0x349ae0(0x158)][_0x349ae0(0xfa)];this['_logWindow']['y']=_0x4610bc+(_0x3c7f30[_0x349ae0(0xec)]||0x0);},VisuMZ[_0x591529(0x12b)][_0x591529(0x14c)]=Scene_Battle['prototype'][_0x591529(0x19a)],Scene_Battle[_0x591529(0x217)][_0x591529(0x19a)]=function(){const _0x183411=_0x591529;BattleManager[_0x183411(0x246)](),VisuMZ[_0x183411(0x12b)][_0x183411(0x14c)][_0x183411(0x20a)](this);},VisuMZ[_0x591529(0x12b)][_0x591529(0x337)]=Scene_Battle[_0x591529(0x217)][_0x591529(0x25e)],Scene_Battle[_0x591529(0x217)][_0x591529(0x25e)]=function(){const _0x478689=_0x591529;BattleManager['otbPreviewOrderClear'](),VisuMZ[_0x478689(0x12b)][_0x478689(0x337)][_0x478689(0x20a)](this);},VisuMZ[_0x591529(0x12b)][_0x591529(0x310)]=Scene_Battle[_0x591529(0x217)][_0x591529(0x183)],Scene_Battle[_0x591529(0x217)]['onActorOk']=function(){const _0x1f8b11=_0x591529;BattleManager['otbPreviewOrderClear'](),VisuMZ[_0x1f8b11(0x12b)][_0x1f8b11(0x310)][_0x1f8b11(0x20a)](this);},VisuMZ['BattleSystemOTB'][_0x591529(0x1fb)]=Scene_Battle['prototype'][_0x591529(0x2f1)],Scene_Battle[_0x591529(0x217)][_0x591529(0x2f1)]=function(){const _0x1d3df2=_0x591529;BattleManager['otbPreviewOrderClear'](),VisuMZ['BattleSystemOTB']['Scene_Battle_onActorCancel'][_0x1d3df2(0x20a)](this);},VisuMZ[_0x591529(0x12b)][_0x591529(0x220)]=Scene_Battle[_0x591529(0x217)]['onEnemyOk'],Scene_Battle['prototype'][_0x591529(0x290)]=function(){const _0x9ef101=_0x591529;BattleManager['otbPreviewOrderClear'](),VisuMZ[_0x9ef101(0x12b)]['Scene_Battle_onEnemyOk']['call'](this);},VisuMZ['BattleSystemOTB']['Scene_Battle_onEnemyCancel']=Scene_Battle[_0x591529(0x217)]['onEnemyCancel'],Scene_Battle[_0x591529(0x217)][_0x591529(0x2c1)]=function(){const _0x2a3104=_0x591529;BattleManager[_0x2a3104(0x246)](),VisuMZ[_0x2a3104(0x12b)][_0x2a3104(0x368)][_0x2a3104(0x20a)](this);},VisuMZ[_0x591529(0x12b)][_0x591529(0x383)]=Scene_Battle[_0x591529(0x217)][_0x591529(0x10b)],Scene_Battle['prototype'][_0x591529(0x10b)]=function(){const _0x30b275=_0x591529;BattleManager[_0x30b275(0x246)](),VisuMZ[_0x30b275(0x12b)][_0x30b275(0x383)][_0x30b275(0x20a)](this);},VisuMZ['BattleSystemOTB']['Scene_Battle_onSkillCancel']=Scene_Battle['prototype'][_0x591529(0xf7)],Scene_Battle[_0x591529(0x217)][_0x591529(0xf7)]=function(){const _0x36ea12=_0x591529;BattleManager[_0x36ea12(0x246)](),VisuMZ[_0x36ea12(0x12b)]['Scene_Battle_onSkillCancel'][_0x36ea12(0x20a)](this);},VisuMZ[_0x591529(0x12b)][_0x591529(0x1ac)]=Scene_Battle[_0x591529(0x217)]['onItemOk'],Scene_Battle[_0x591529(0x217)][_0x591529(0x286)]=function(){const _0x1af6c7=_0x591529;BattleManager[_0x1af6c7(0x246)](),VisuMZ[_0x1af6c7(0x12b)]['Scene_Battle_onItemOk']['call'](this);},VisuMZ['BattleSystemOTB'][_0x591529(0x343)]=Scene_Battle[_0x591529(0x217)]['onItemCancel'],Scene_Battle[_0x591529(0x217)][_0x591529(0x305)]=function(){const _0x1c47d6=_0x591529;BattleManager['otbPreviewOrderClear'](),VisuMZ[_0x1c47d6(0x12b)][_0x1c47d6(0x343)][_0x1c47d6(0x20a)](this);},VisuMZ['BattleSystemOTB']['Scene_Battle_actorCommandSingleSkill']=Scene_Battle['prototype'][_0x591529(0x127)],Scene_Battle['prototype'][_0x591529(0x127)]=function(){const _0x33686a=_0x591529;BattleManager['otbPreviewOrderClear'](),VisuMZ[_0x33686a(0x12b)][_0x33686a(0x198)][_0x33686a(0x20a)](this);};function Sprite_OTB_TurnOrder_Battler(){const _0x15228e=_0x591529;this[_0x15228e(0x347)](...arguments);}Sprite_OTB_TurnOrder_Battler['prototype']=Object['create'](Sprite_Clickable[_0x591529(0x217)]),Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x2d0)]=Sprite_OTB_TurnOrder_Battler,Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x347)]=function(_0x45126f,_0x4ff12c,_0xa6855a){const _0x1a7b5e=_0x591529;this[_0x1a7b5e(0x213)](_0x45126f,_0x4ff12c,_0xa6855a),Sprite_Clickable[_0x1a7b5e(0x217)][_0x1a7b5e(0x347)][_0x1a7b5e(0x20a)](this),this[_0x1a7b5e(0x2c6)]=0x0,this[_0x1a7b5e(0x212)](),this[_0x1a7b5e(0x346)]();},Sprite_OTB_TurnOrder_Battler['prototype'][_0x591529(0x213)]=function(_0x3c3d28,_0x452d10,_0x41e9c2){const _0x3831e8=_0x591529;this[_0x3831e8(0xdb)]=_0x3c3d28[_0x3831e8(0x112)]()?$gameParty:$gameTroop,this['_index']=_0x3c3d28[_0x3831e8(0x1bf)](),this[_0x3831e8(0x190)]=_0x452d10,this[_0x3831e8(0x143)]=_0x41e9c2;const _0x508a20=Window_OTB_TurnOrder[_0x3831e8(0x2cd)],_0xeadb9e=this[_0x3831e8(0x2ea)]();this[_0x3831e8(0x1e6)]=0x0,this[_0x3831e8(0x34c)]=_0x508a20[_0x3831e8(0x2e8)]?-_0x508a20[_0x3831e8(0x28f)]:this[_0x3831e8(0x1af)]()[_0x3831e8(0x164)],this['_positionTargetY']=0x0,this[_0x3831e8(0xd9)]=0x0,this[_0x3831e8(0x258)]=0xff,this[_0x3831e8(0xd3)]=![],this[_0x3831e8(0x2c8)]=![],this[_0x3831e8(0x262)]=0x0,this[_0x3831e8(0x13f)]=0x0;},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x212)]=function(){const _0x3fe8b2=_0x591529;this['createInitialPositions'](),this[_0x3fe8b2(0x2e3)](),this[_0x3fe8b2(0x32f)](),this[_0x3fe8b2(0x16f)](),this[_0x3fe8b2(0x27b)]();},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x1eb)]=function(){const _0x4fd838=_0x591529;this['x']=this['_positionTargetX'],this['y']=this[_0x4fd838(0x122)];},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x2ea)]=function(){return!![];},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x324)]=function(){const _0x5d8f98=_0x591529,_0x8ee5c2=Window_OTB_TurnOrder[_0x5d8f98(0x2cd)];return _0x8ee5c2[_0x5d8f98(0x28f)];},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x1fa)]=function(){const _0x37916a=_0x591529,_0x10b633=Window_OTB_TurnOrder['Settings'];return _0x10b633[_0x37916a(0x336)];},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)]['getUnitSideSide']=function(){const _0x345daf=_0x591529;return this[_0x345daf(0xdb)]===$gameParty?_0x345daf(0x18e):_0x345daf(0x2a3);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x2e3)]=function(){const _0x4d3d57=_0x591529;if(!Window_OTB_TurnOrder[_0x4d3d57(0x2cd)][_0x4d3d57(0xcb)])return;const _0x331aac=Window_OTB_TurnOrder[_0x4d3d57(0x2cd)],_0xabd3fa=this['getUnitSideSide'](),_0xf71c0f=_0x4d3d57(0x297)[_0x4d3d57(0x276)](_0xabd3fa),_0x36d4c3=new Sprite();_0x36d4c3[_0x4d3d57(0xee)]['x']=this['anchor']['x'],_0x36d4c3[_0x4d3d57(0xee)]['y']=this[_0x4d3d57(0xee)]['y'];if(_0x331aac[_0xf71c0f])_0x4d3d57(0x37a)!==_0x4d3d57(0x2d8)?_0x36d4c3[_0x4d3d57(0x1c0)]=ImageManager['loadSystem'](_0x331aac[_0xf71c0f]):this[_0x4d3d57(0x25d)]();else{const _0x359f56=this['bitmapWidth'](),_0x12da1b=this['bitmapHeight']();_0x36d4c3[_0x4d3d57(0x1c0)]=new Bitmap(_0x359f56,_0x12da1b);const _0x102b9d=ColorManager['getColor'](_0x331aac[_0x4d3d57(0xff)['format'](_0xabd3fa)]),_0x4f9c35=ColorManager[_0x4d3d57(0x2fe)](_0x331aac[_0x4d3d57(0x110)[_0x4d3d57(0x276)](_0xabd3fa)]);_0x36d4c3[_0x4d3d57(0x1c0)][_0x4d3d57(0x2bf)](0x0,0x0,_0x359f56,_0x12da1b,_0x102b9d,_0x4f9c35,!![]);}this[_0x4d3d57(0x152)]=_0x36d4c3,this['addChild'](this[_0x4d3d57(0x152)]),this[_0x4d3d57(0x164)]=this[_0x4d3d57(0x152)][_0x4d3d57(0x164)],this[_0x4d3d57(0xfa)]=this[_0x4d3d57(0x152)][_0x4d3d57(0xfa)];},Sprite_OTB_TurnOrder_Battler['prototype'][_0x591529(0x32f)]=function(){const _0x41bc0c=_0x591529,_0x59a21a=new Sprite();_0x59a21a[_0x41bc0c(0xee)]['x']=this['anchor']['x'],_0x59a21a[_0x41bc0c(0xee)]['y']=this['anchor']['y'],this['_graphicSprite']=_0x59a21a,this['addChild'](this[_0x41bc0c(0x1ae)]),this[_0x41bc0c(0x24e)]();},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x16f)]=function(){const _0x477999=_0x591529;if(!Window_OTB_TurnOrder[_0x477999(0x2cd)][_0x477999(0x147)])return;const _0x4decc1=Window_OTB_TurnOrder[_0x477999(0x2cd)],_0x1c9967=this[_0x477999(0x278)](),_0x8298d8=_0x477999(0x11e)['format'](_0x1c9967),_0x1f245e=new Sprite();_0x1f245e['anchor']['x']=this['anchor']['x'],_0x1f245e[_0x477999(0xee)]['y']=this[_0x477999(0xee)]['y'];if(_0x4decc1[_0x8298d8]){if(_0x477999(0x1d0)===_0x477999(0x1d0))_0x1f245e[_0x477999(0x1c0)]=ImageManager[_0x477999(0x18f)](_0x4decc1[_0x8298d8]);else{const _0x33adb2=this['_actorCommandWindow'];this[_0x477999(0x275)]()&&delete _0x33adb2[_0x477999(0x2b1)]['cancel'];}}else{if(_0x477999(0x2cc)===_0x477999(0x2cc)){let _0xa08eab=this[_0x477999(0x324)](),_0x105d33=this['bitmapHeight'](),_0x2aba7d=this[_0x477999(0x28b)]();_0x1f245e[_0x477999(0x1c0)]=new Bitmap(_0xa08eab,_0x105d33);const _0x2e9da2=_0x477999(0x16d),_0x248c4d=ColorManager[_0x477999(0x2fe)](_0x4decc1[_0x477999(0x130)[_0x477999(0x276)](_0x1c9967)]);_0x1f245e['bitmap'][_0x477999(0x109)](0x0,0x0,_0xa08eab,_0x105d33,_0x2e9da2),_0xa08eab-=0x2,_0x105d33-=0x2,_0x1f245e[_0x477999(0x1c0)][_0x477999(0x109)](0x1,0x1,_0xa08eab,_0x105d33,_0x248c4d),_0xa08eab-=_0x2aba7d*0x2,_0x105d33-=_0x2aba7d*0x2,_0x1f245e[_0x477999(0x1c0)][_0x477999(0x109)](0x1+_0x2aba7d,0x1+_0x2aba7d,_0xa08eab,_0x105d33,_0x2e9da2),_0xa08eab-=0x2,_0x105d33-=0x2,_0x2aba7d+=0x1,_0x1f245e['bitmap']['clearRect'](0x1+_0x2aba7d,0x1+_0x2aba7d,_0xa08eab,_0x105d33);}else this[_0x477999(0x2de)]();}this['_backgroundSprite']=_0x1f245e,this[_0x477999(0x2bb)](this['_backgroundSprite']);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x28b)]=function(){const _0x1af86a=_0x591529,_0x4293aa=Window_OTB_TurnOrder['Settings'];return _0x4293aa[_0x1af86a(0x2d9)];},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)]['createLetterSprite']=function(){const _0xab56eb=_0x591529,_0x18e2b4=Window_OTB_TurnOrder['Settings'];if(!_0x18e2b4['EnemyBattlerDrawLetter'])return;if(this[_0xab56eb(0xdb)]===$gameParty)return;const _0x24a482=this[_0xab56eb(0x324)](),_0x3d8749=this[_0xab56eb(0x1fa)](),_0x4e2f96=new Sprite();_0x4e2f96[_0xab56eb(0xee)]['x']=this[_0xab56eb(0xee)]['x'],_0x4e2f96[_0xab56eb(0xee)]['y']=this['anchor']['y'],_0x4e2f96[_0xab56eb(0x1c0)]=new Bitmap(_0x24a482,_0x3d8749),this[_0xab56eb(0x167)]=_0x4e2f96,this[_0xab56eb(0x2bb)](this[_0xab56eb(0x167)]);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)]['battler']=function(){const _0x4b7146=_0x591529;return this[_0x4b7146(0xdb)]?this['_unit']['members']()[this[_0x4b7146(0xc0)]]:null;},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)]['update']=function(){const _0x1ba830=_0x591529;Sprite_Clickable[_0x1ba830(0x217)][_0x1ba830(0x35d)][_0x1ba830(0x20a)](this),this[_0x1ba830(0x1bb)](),this[_0x1ba830(0x346)](),this[_0x1ba830(0x2a8)](),this['updateGraphic'](),this[_0x1ba830(0x296)](),this[_0x1ba830(0x29e)](),this[_0x1ba830(0x19e)]();},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x1e7)]=function(_0x1ea570,_0x473b7d){const _0x5ccf66=_0x591529,_0x2d72f1=Window_OTB_TurnOrder[_0x5ccf66(0x2cd)];this[_0x5ccf66(0x1e6)]=_0x2d72f1[_0x5ccf66(0x375)],this[_0x5ccf66(0x34c)]=_0x1ea570,this[_0x5ccf66(0x122)]=_0x473b7d;},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x1bb)]=function(){const _0xe90a17=_0x591529;if(this[_0xe90a17(0x1e6)]>0x0){const _0x18f0aa=this[_0xe90a17(0x1e6)];this['x']=(this['x']*(_0x18f0aa-0x1)+this['_positionTargetX'])/_0x18f0aa,this['y']=(this['y']*(_0x18f0aa-0x1)+this[_0xe90a17(0x122)])/_0x18f0aa,this[_0xe90a17(0x1e6)]--;}if(this[_0xe90a17(0x1e6)]<=0x0){if(_0xe90a17(0xe3)===_0xe90a17(0xe3)){this['x']=this['_positionTargetX'],this['y']=this[_0xe90a17(0x122)];if(this[_0xe90a17(0x2c6)]<0xff&&!this['_isBattleOver']&&this[_0xe90a17(0xd9)]<=0x0){const _0x2ad2e3=this[_0xe90a17(0xe7)]();if(_0x2ad2e3){if('eWfAw'!==_0xe90a17(0x15a))return this[_0xe90a17(0x24e)]();else this[_0xe90a17(0x258)]=_0x2ad2e3[_0xe90a17(0xe5)]()&&_0x2ad2e3[_0xe90a17(0x228)]()?0xff:0x0;}}}else{let _0x2209e0=this['_otb_createdFirstTurnOrders']?0x1:0x2;while(_0x2209e0--){this['makeNextActionOrdersOTB']();}const _0x2f5f19=!this[_0xe90a17(0x328)];this[_0xe90a17(0x328)]=!![];}}},Sprite_OTB_TurnOrder_Battler['prototype'][_0x591529(0x354)]=function(){return 0x1;},Sprite_OTB_TurnOrder_Battler['prototype'][_0x591529(0x1af)]=function(){const _0xa8dfca=_0x591529;return SceneManager[_0xa8dfca(0x37c)][_0xa8dfca(0x158)];},Sprite_OTB_TurnOrder_Battler['prototype'][_0x591529(0x1f1)]=function(){const _0x1ead4d=_0x591529,_0x2912ef=this[_0x1ead4d(0xe7)]();if(!_0x2912ef)return this['defaultPosition']();if(_0x2912ef===BattleManager[_0x1ead4d(0x1c7)]){if(_0x1ead4d(0x148)!=='qyjLj')return 0x0;else _0x35e2ef=_0x7b1566[_0x1ead4d(0x195)](_0x3c3621,_0x46ff81);}if(BattleManager[_0x1ead4d(0x259)][_0x1ead4d(0x1b1)](_0x2912ef)){if('EhVHH'===_0x1ead4d(0x2ff))this[_0x1ead4d(0x143)]=_0x219eb0,this[_0x1ead4d(0x173)](),this[_0x1ead4d(0x143)]===null&&(this['_instance']=-0x1);else{const _0x5ef64c=BattleManager['_actionBattlers'][_0x1ead4d(0x349)](_0x2912ef)+0x1;return _0x5ef64c;}}return this[_0x1ead4d(0x354)]();},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x15d)]=function(_0x31e86b){const _0x4ca28d=_0x591529,_0x314da9=Window_OTB_TurnOrder[_0x4ca28d(0x2cd)];this[_0x4ca28d(0xd9)]=_0x314da9[_0x4ca28d(0x375)],this[_0x4ca28d(0x258)]=_0x31e86b;},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)]['checkOpacity']=function(){const _0x36b6cd=_0x591529,_0x4c8f26=this[_0x36b6cd(0xe7)]();if(!_0x4c8f26)return;if(this[_0x36b6cd(0xd3)]===_0x4c8f26['isAlive']()&&this[_0x36b6cd(0x2c8)]===_0x4c8f26[_0x36b6cd(0x228)]())return;this[_0x36b6cd(0xd3)]=_0x4c8f26[_0x36b6cd(0xe5)](),this[_0x36b6cd(0x2c8)]=_0x4c8f26[_0x36b6cd(0x228)]();let _0x1bbe02=this[_0x36b6cd(0xd3)]&&this[_0x36b6cd(0x2c8)]?0xff:0x0;this[_0x36b6cd(0x15d)](_0x1bbe02);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)]['updateOpacity']=function(){const _0x2898fb=_0x591529;if(this[_0x2898fb(0xd9)]>0x0){if('PoyMw'!==_0x2898fb(0x133)){const _0x2bc5bf=this[_0x2898fb(0xd9)];this[_0x2898fb(0x2c6)]=(this[_0x2898fb(0x2c6)]*(_0x2bc5bf-0x1)+this[_0x2898fb(0x258)])/_0x2bc5bf,this['_fadeDuration']--;if(this[_0x2898fb(0xd9)]<=0x0){if(_0x2898fb(0x1be)!=='YhjPc'){const _0x1abeb1=![],_0x47c158=_0x4d540b(_0x423499['$1'])||0x0;_0x46f72a[_0x2898fb(0x2d6)](_0x47c158,_0x1abeb1);}else this['opacity']=this[_0x2898fb(0x258)];}}else{const _0xedaede=_0x2898fb(0x34e)['format'](_0x109864[_0x2898fb(0x112)]()?_0x2898fb(0x12e):_0x2898fb(0x1fe),_0x55c150[_0x2898fb(0x1bf)]());_0x339efa[_0xedaede]=_0x5b8f14[_0xedaede]||0x0;const _0x2a2e46=_0x16ff39[_0xedaede]++,_0x342602=new _0x52dfb8(_0x2be8e9,_0x2a2e46,_0x118b24);this['_spriteContainer'][_0x2898fb(0x2bb)](_0x342602),_0x571505[_0x2898fb(0x236)](_0x342602);}}if(this['_isBattleOver'])return;BattleManager[_0x2898fb(0x251)]===_0x2898fb(0x283)&&(_0x2898fb(0x36a)!==_0x2898fb(0x36a)?_0x420aa0[_0x2898fb(0x2c7)](this[_0x2898fb(0x360)]):(this[_0x2898fb(0x36e)]=!![],this[_0x2898fb(0x15d)](0x0)));},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x371)]=function(){const _0x71b365=_0x591529,_0x42cbc8=this[_0x71b365(0xe7)]();if(!_0x42cbc8)return;const _0x26b4d5=Window_OTB_TurnOrder[_0x71b365(0x2cd)],_0x42bb4c=this[_0x71b365(0xdb)]===$gameParty?_0x71b365(0x18e):'Enemy';let _0x2d9841=_0x42cbc8[_0x71b365(0x356)]();if(_0x42cbc8[_0x71b365(0x112)]()&&_0x2d9841===_0x71b365(0x1fe))_0x71b365(0x1ba)===_0x71b365(0x2ab)?_0x1d1149['otbAddForceActionBattler'](_0x2e06f1):_0x2d9841='face';else _0x42cbc8['isEnemy']()&&_0x2d9841===_0x71b365(0x100)&&(_0x71b365(0x219)===_0x71b365(0x219)?_0x2d9841='enemy':_0x4dcd12[_0x71b365(0x143)][_0x71b365(0x2ca)](_0x535aff));if(this[_0x71b365(0xd8)]!==_0x2d9841){if(_0x71b365(0x30f)!==_0x71b365(0x166))return this[_0x71b365(0x24e)]();else this[_0x71b365(0x249)]['children'][_0x71b365(0x24b)]((_0x4aab31,_0x5b3957)=>_0x4aab31['x']-_0x5b3957['x']);}switch(this[_0x71b365(0xd8)]){case _0x71b365(0x11d):if(this['_graphicFaceName']!==_0x42cbc8[_0x71b365(0x144)]()){if(_0x71b365(0x121)!==_0x71b365(0x121)){const _0x398509=_0x56a089(_0x4c8b50['$1']);_0x398509!==_0x21ae78[_0x206e6e][_0x71b365(0x374)]&&(_0x480141(_0x71b365(0x260)['format'](_0x2db2c6,_0x398509)),_0x3613b1[_0x71b365(0x25a)]());}else return this[_0x71b365(0x24e)]();}if(this[_0x71b365(0x171)]!==_0x42cbc8[_0x71b365(0x1b9)]())return this[_0x71b365(0x24e)]();break;case _0x71b365(0x14b):if(this['_graphicIconIndex']!==_0x42cbc8[_0x71b365(0x2b3)]())return'ZiiLM'!=='UGYqB'?this[_0x71b365(0x24e)]():this[_0x71b365(0x24e)]();break;case'enemy':if(_0x42cbc8[_0x71b365(0x15c)]()){if(_0x71b365(0x270)==='cuwtN'){if(this[_0x71b365(0xe1)]!==_0x42cbc8[_0x71b365(0x1d9)]())return this['processUpdateGraphic']();}else this[_0x71b365(0x1e2)]=_0x1d4c3b,_0x3f60af[_0x71b365(0x217)]['initialize']['call'](this,_0x4f77c1,_0x1f8cea,_0x295de2),this[_0x71b365(0xc9)]();}else{if(this['_graphicEnemy']!==_0x42cbc8[_0x71b365(0x2ec)]())return _0x71b365(0x2f0)==='QAkbS'?this[_0x71b365(0x24e)]():_0x49bd07[_0x71b365(0xc3)]();}break;case _0x71b365(0x100):if(_0x42cbc8[_0x71b365(0x112)]()){if(_0x71b365(0x1dd)!==_0x71b365(0x1dd)){const _0x4893fc=_0x2b1eaa;this[_0x71b365(0x142)](_0x439b87,_0x4893fc,this['_otb_actionBattlersNext']);}else{if(this[_0x71b365(0xe1)]!==_0x42cbc8[_0x71b365(0x2ec)]())return this[_0x71b365(0x24e)]();}}else{if(this[_0x71b365(0x350)]!==_0x42cbc8[_0x71b365(0x2ec)]()){if('pwkSe'!=='pwkSe'){const _0x32cc90=this[_0x71b365(0x103)];_0x4c4ee2[_0x71b365(0x12b)]['Game_BattlerBase_appear'][_0x71b365(0x20a)](this),_0xe0b00b['isOTB']()&&_0x4b5369[_0x71b365(0x21b)]()&&_0x32cc90&&!this[_0x71b365(0x103)]&&_0x5b75ad[_0x71b365(0x128)](this);}else return this[_0x71b365(0x24e)]();}}break;}},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x24e)]=function(){const _0x22c674=_0x591529,_0x3f3911=this['battler']();if(!_0x3f3911)return;this[_0x22c674(0xd8)]=_0x3f3911[_0x22c674(0x356)]();if(_0x3f3911[_0x22c674(0x112)]()&&this[_0x22c674(0xd8)]==='enemy'){if(_0x22c674(0x1e8)!==_0x22c674(0x1e8)){if(!this[_0x22c674(0xc3)]())return;const _0x2eec29=_0x70a308['_scene'][_0x22c674(0x158)];while(_0x381d03--){_0x292132[_0x22c674(0x236)](_0xaad9e),_0x2eec29&&_0x2eec29[_0x22c674(0x30e)](_0x3e1e03,_0x26e37b);}}else this['_graphicType']=_0x22c674(0x11d);}else _0x3f3911['isEnemy']()&&this[_0x22c674(0xd8)]===_0x22c674(0x100)&&(this['_graphicType']=_0x22c674(0x1fe));let _0x5d417a;switch(this['_graphicType']){case _0x22c674(0x11d):this[_0x22c674(0x274)]=_0x3f3911['TurnOrderOTBGraphicFaceName'](),this[_0x22c674(0x171)]=_0x3f3911[_0x22c674(0x1b9)](),_0x5d417a=ImageManager[_0x22c674(0x248)](this['_graphicFaceName']),_0x5d417a[_0x22c674(0x21c)](this['changeFaceGraphicBitmap']['bind'](this,_0x5d417a));break;case _0x22c674(0x14b):this[_0x22c674(0x341)]=_0x3f3911[_0x22c674(0xf8)](),_0x5d417a=ImageManager[_0x22c674(0x18f)](_0x22c674(0x105)),_0x5d417a[_0x22c674(0x21c)](this['changeIconGraphicBitmap']['bind'](this,_0x5d417a));break;case _0x22c674(0x1fe):if(_0x3f3911['hasSvBattler']())_0x22c674(0xf2)!==_0x22c674(0x11c)?(this[_0x22c674(0xe1)]=_0x3f3911[_0x22c674(0x1d9)](),_0x5d417a=ImageManager[_0x22c674(0x34b)](this[_0x22c674(0xe1)]),_0x5d417a[_0x22c674(0x21c)](this[_0x22c674(0x135)][_0x22c674(0x123)](this,_0x5d417a))):_0x57fcef[_0x22c674(0x12b)][_0x22c674(0x24c)][_0x22c674(0x20a)](this,_0x501a2d);else $gameSystem[_0x22c674(0xe2)]()?(this[_0x22c674(0x350)]=_0x3f3911['battlerName'](),_0x5d417a=ImageManager[_0x22c674(0x114)](this[_0x22c674(0x350)]),_0x5d417a[_0x22c674(0x21c)](this[_0x22c674(0x306)][_0x22c674(0x123)](this,_0x5d417a))):(this[_0x22c674(0x350)]=_0x3f3911[_0x22c674(0x2ec)](),_0x5d417a=ImageManager[_0x22c674(0x2f5)](this[_0x22c674(0x350)]),_0x5d417a[_0x22c674(0x21c)](this['changeEnemyGraphicBitmap'][_0x22c674(0x123)](this,_0x5d417a)));break;case _0x22c674(0x100):this[_0x22c674(0xe1)]=_0x3f3911['battlerName'](),_0x5d417a=ImageManager[_0x22c674(0x34b)](this['_graphicSv']),_0x5d417a[_0x22c674(0x21c)](this[_0x22c674(0x135)][_0x22c674(0x123)](this,_0x5d417a));break;}},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x325)]=function(_0x3d4618){const _0x5663af=_0x591529,_0x13d641=this[_0x5663af(0x171)],_0x48bfe9=this[_0x5663af(0x324)](),_0x2223fc=this[_0x5663af(0x1fa)](),_0x20beb1=Math[_0x5663af(0x195)](_0x48bfe9,_0x2223fc);this[_0x5663af(0x1ae)][_0x5663af(0x1c0)]=new Bitmap(_0x48bfe9,_0x2223fc);const _0x14eb1d=this['_graphicSprite'][_0x5663af(0x1c0)],_0x3bb981=ImageManager[_0x5663af(0x32a)],_0x4adc15=ImageManager[_0x5663af(0xf0)],_0xb44d55=_0x20beb1/Math[_0x5663af(0x195)](_0x3bb981,_0x4adc15),_0x1243eb=ImageManager['faceWidth'],_0x239ce9=ImageManager['faceHeight'],_0x476673=_0x13d641%0x4*_0x3bb981+(_0x3bb981-_0x1243eb)/0x2,_0x4d3420=Math[_0x5663af(0x2e4)](_0x13d641/0x4)*_0x4adc15+(_0x4adc15-_0x239ce9)/0x2,_0x18466a=(_0x48bfe9-_0x3bb981*_0xb44d55)/0x2,_0x421aaa=(_0x2223fc-_0x4adc15*_0xb44d55)/0x2;_0x14eb1d['blt'](_0x3d4618,_0x476673,_0x4d3420,_0x1243eb,_0x239ce9,_0x18466a,_0x421aaa,_0x20beb1,_0x20beb1);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x2c2)]=function(_0x438b32){const _0x2359d4=_0x591529,_0x3e30ec=this['_graphicIconIndex'],_0x27a66c=this[_0x2359d4(0x324)](),_0x2f4bd2=this['bitmapHeight']();this[_0x2359d4(0x1ae)][_0x2359d4(0x1c0)]=new Bitmap(_0x27a66c,_0x2f4bd2);const _0x3173b6=this[_0x2359d4(0x1ae)][_0x2359d4(0x1c0)],_0x47c6ab=ImageManager['iconWidth'],_0x2a147e=ImageManager[_0x2359d4(0x326)],_0xaa99c5=Math[_0x2359d4(0x235)](_0x47c6ab,_0x2a147e,_0x27a66c,_0x2f4bd2),_0x54f52c=_0x3e30ec%0x10*_0x47c6ab,_0x27ef7b=Math[_0x2359d4(0x2e4)](_0x3e30ec/0x10)*_0x2a147e,_0x5ae0b5=Math[_0x2359d4(0x2e4)](Math[_0x2359d4(0x195)](_0x27a66c-_0xaa99c5,0x0)/0x2),_0x47f707=Math[_0x2359d4(0x2e4)](Math['max'](_0x2f4bd2-_0xaa99c5,0x0)/0x2);_0x3173b6[_0x2359d4(0x172)](_0x438b32,_0x54f52c,_0x27ef7b,_0x47c6ab,_0x2a147e,_0x5ae0b5,_0x47f707,_0xaa99c5,_0xaa99c5);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x135)]=function(_0x34fa57){const _0x3f1f80=_0x591529,_0x107b1b=this['bitmapWidth'](),_0x4a9d9a=this[_0x3f1f80(0x1fa)](),_0x340194=Math[_0x3f1f80(0x235)](_0x107b1b,_0x4a9d9a);this['_graphicSprite'][_0x3f1f80(0x1c0)]=new Bitmap(_0x107b1b,_0x4a9d9a);const _0x112a98=this[_0x3f1f80(0x1ae)][_0x3f1f80(0x1c0)],_0x22f2a7=this[_0x3f1f80(0xe1)][_0x3f1f80(0x1d1)](/\$/i),_0x5977d4=_0x22f2a7?0x1:ImageManager['svActorHorzCells'],_0x51408a=_0x22f2a7?0x1:ImageManager[_0x3f1f80(0x321)],_0x5abec2=_0x34fa57[_0x3f1f80(0x164)]/_0x5977d4,_0x3793ea=_0x34fa57[_0x3f1f80(0xfa)]/_0x51408a,_0xb29e82=Math['min'](0x1,_0x340194/_0x5abec2,_0x340194/_0x3793ea),_0x597b86=_0x5abec2*_0xb29e82,_0x22c834=_0x3793ea*_0xb29e82,_0x28949d=Math[_0x3f1f80(0x2b6)]((_0x107b1b-_0x597b86)/0x2),_0xeb82c3=Math[_0x3f1f80(0x2b6)]((_0x4a9d9a-_0x22c834)/0x2);_0x112a98[_0x3f1f80(0x172)](_0x34fa57,0x0,0x0,_0x5abec2,_0x3793ea,_0x28949d,_0xeb82c3,_0x597b86,_0x22c834);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x306)]=function(_0x1faeed){const _0x4891d9=_0x591529,_0x50fd39=Window_OTB_TurnOrder[_0x4891d9(0x2cd)],_0x134392=this['bitmapWidth'](),_0x2e15e7=this[_0x4891d9(0x1fa)](),_0xfbe73b=Math[_0x4891d9(0x235)](_0x134392,_0x2e15e7);this[_0x4891d9(0x1ae)][_0x4891d9(0x1c0)]=new Bitmap(_0x134392,_0x2e15e7);const _0x283c44=this[_0x4891d9(0x1ae)][_0x4891d9(0x1c0)],_0x519865=Math[_0x4891d9(0x235)](0x1,_0xfbe73b/_0x1faeed[_0x4891d9(0x164)],_0xfbe73b/_0x1faeed[_0x4891d9(0xfa)]),_0x539c55=_0x1faeed[_0x4891d9(0x164)]*_0x519865,_0x2c15f9=_0x1faeed[_0x4891d9(0xfa)]*_0x519865,_0x4ea568=Math[_0x4891d9(0x2b6)]((_0x134392-_0x539c55)/0x2),_0x55f270=Math[_0x4891d9(0x2b6)]((_0x2e15e7-_0x2c15f9)/0x2);_0x283c44[_0x4891d9(0x172)](_0x1faeed,0x0,0x0,_0x1faeed['width'],_0x1faeed[_0x4891d9(0xfa)],_0x4ea568,_0x55f270,_0x539c55,_0x2c15f9);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x296)]=function(){const _0x443442=_0x591529,_0x10bede=this['battler']();if(!_0x10bede)return;if(!_0x10bede[_0x443442(0x385)]())return;if(this[_0x443442(0x141)]===_0x10bede[_0x443442(0x1cb)]())return;this[_0x443442(0x141)]=_0x10bede['battlerHue']();if(_0x10bede[_0x443442(0x15c)]())this[_0x443442(0x141)]=0x0;this[_0x443442(0x1ae)][_0x443442(0x1d2)](this[_0x443442(0x141)]);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x29e)]=function(){const _0x4a734d=_0x591529;if(!this[_0x4a734d(0x167)])return;const _0x38a6aa=this[_0x4a734d(0xe7)]();if(!_0x38a6aa)return;if(this[_0x4a734d(0xda)]===_0x38a6aa['_letter']&&this[_0x4a734d(0x1c6)]===_0x38a6aa[_0x4a734d(0x1c6)])return;this[_0x4a734d(0xda)]=_0x38a6aa['_letter'],this['_plural']=_0x38a6aa[_0x4a734d(0x1c6)];const _0x555aa0=Window_OTB_TurnOrder[_0x4a734d(0x2cd)],_0x11e244=this['bitmapWidth'](),_0x1004b5=this[_0x4a734d(0x1fa)](),_0x36cdd0=this[_0x4a734d(0x167)]['bitmap'];_0x36cdd0[_0x4a734d(0x282)]();if(!this['_plural'])return;_0x36cdd0['fontFace']=_0x555aa0[_0x4a734d(0xe0)]||$gameSystem['mainFontFace'](),_0x36cdd0[_0x4a734d(0x226)]=_0x555aa0[_0x4a734d(0x255)]||0x10;if(_0x555aa0[_0x4a734d(0x2e8)])_0x36cdd0['drawText'](this[_0x4a734d(0xda)][_0x4a734d(0x323)](),_0x11e244*0x1/0x8,_0x1004b5/0x2,_0x11e244,_0x1004b5/0x2,'left');else{if(_0x4a734d(0x165)===_0x4a734d(0x165))_0x36cdd0['drawText'](this['_letter']['trim'](),0x0,_0x1004b5/0x2,_0x11e244*0x7/0x8,_0x1004b5/0x2,_0x4a734d(0x201));else return this[_0x4a734d(0x24e)]();}},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x19e)]=function(){const _0xd0b7d7=_0x591529,_0x226440=this[_0xd0b7d7(0xe7)]();if(!_0x226440)return;const _0x360e87=_0x226440['battler']();if(!_0x360e87)return;const _0x409619=_0x360e87['mainSprite']();if(!_0x409619)return;this[_0xd0b7d7(0x318)](_0x409619[_0xd0b7d7(0xf5)]);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x2dd)]=function(){return null;},Sprite_OTB_TurnOrder_Battler['prototype']['changeSourceArray']=function(_0x4dac8a){const _0x52e941=_0x591529;this[_0x52e941(0x143)]=_0x4dac8a,this[_0x52e941(0x173)](),this[_0x52e941(0x143)]===null&&(this[_0x52e941(0x190)]=-0x1);},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x173)]=function(){const _0x55168d=_0x591529,_0x1e78d4=this[_0x55168d(0x1af)]();if(!_0x1e78d4)return;const _0x30e1ee=Window_OTB_TurnOrder[_0x55168d(0x2cd)],_0x3c0031=_0x30e1ee[_0x55168d(0x2e8)],_0x53bd2c=this[_0x55168d(0x143)]===_0x1e78d4['_nextTurn']?!![]:![],_0x296f6e=this[_0x55168d(0x190)]===-0x1&&BattleManager[_0x55168d(0x1c7)]===this[_0x55168d(0xe7)](),_0x3ca44a=_0x1e78d4[_0x55168d(0x2eb)]-_0x30e1ee[_0x55168d(0x28f)];let _0x2f268f=Math[_0x55168d(0x23c)](_0x3ca44a/(this[_0x55168d(0x143)][_0x55168d(0x2f7)]-0x1||0x1));_0x2f268f=Math[_0x55168d(0x235)](_0x30e1ee[_0x55168d(0x28f)],_0x2f268f);let _0x2904cc=0x0,_0xacea45=0x0,_0x1c275c=_0x296f6e?-0x1:this[_0x55168d(0x143)][_0x55168d(0x349)](this);!_0x296f6e&&(_0x1c275c=this[_0x55168d(0x27f)]());if(_0x296f6e)_0x2904cc=_0x1e78d4['_subjectX'];else{if(_0x3c0031){if('veMCG'!==_0x55168d(0x376)){const _0x59a660=_0x11ff4a[_0x55168d(0x2cd)];this['_fadeDuration']=_0x59a660[_0x55168d(0x375)],this['_fadeTarget']=_0x59e262;}else _0x2904cc=(_0x53bd2c?_0x1e78d4['_nextX']:_0x1e78d4[_0x55168d(0x1ec)])+_0x3ca44a,_0x2904cc-=_0x1c275c*_0x2f268f;}else _0x55168d(0x28c)==='OaRcu'?(_0x2904cc=_0x53bd2c?_0x1e78d4[_0x55168d(0xe4)]:_0x1e78d4[_0x55168d(0x1ec)],_0x2904cc+=_0x1c275c*_0x2f268f):_0x5b1278+=_0x4264ab(_0x87f358['$1']);}_0x2904cc+=this[_0x55168d(0x2c4)](_0x1c275c,_0x30e1ee[_0x55168d(0x28f)]-_0x2f268f),!_0x296f6e&&_0x1c275c<0x0&&(_0x55168d(0x22f)===_0x55168d(0x2ad)?_0x1af45e[_0x55168d(0x12b)][_0x55168d(0x2d4)]['call'](this,_0x42154d,_0x236981):(_0x2904cc=this['x'],_0xacea45=this['y'],this[_0x55168d(0x15d)](0x0))),this[_0x55168d(0x1e7)](_0x2904cc,_0xacea45);},Sprite_OTB_TurnOrder_Battler['prototype'][_0x591529(0x2c4)]=function(_0xb34bb4,_0x482f7b){return 0x0;},Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)][_0x591529(0x27f)]=function(){const _0x4f2c41=_0x591529,_0x37dc0f=this['containerWindow']();if(!_0x37dc0f)return 0x0;const _0x158ca3=this[_0x4f2c41(0x143)]===_0x37dc0f[_0x4f2c41(0x16b)]?!![]:![],_0x35f29d=_0x158ca3?BattleManager['_otb_actionBattlersNext']:BattleManager['_actionBattlers'],_0x46168d=this['battler'](),_0x32988e=VisuMZ[_0x4f2c41(0x12b)][_0x4f2c41(0x203)](_0x46168d,_0x35f29d);return _0x32988e[this[_0x4f2c41(0x190)]]??_0x32988e[_0x32988e[_0x4f2c41(0x2f7)]-0x1]??-0x1;};function _0x547b(){const _0x3fa096=['PpYZQ','zbZLv','OTB_CONVERT_AGI_BUFF_CURRENT_TURN','_logWindow','Enemy','ActionBattlersFilter','makeDeepCopy','recoverAll','PreviewOffsetY','updateOpacity','1082egOKLl','sZAeB','AMLTD','item','RGqDl','xDeWi','subject','makeActions','_handlers','unDjh','TurnOrderOTBGraphicIconIndex','UserNextOrder','contentsOpacity','round','UyyQb','vBiYK','JSON','FaceName','addChild','commandFight','Game_Battler_onBattleStart','jKTRN','gradientFillRect','drawBgImage','onEnemyCancel','changeIconGraphicBitmap','EnemyBattlerIcon','additionalTargetXAdjustments','RandomizeActionTimesOrder','opacity','setTarget','_isAppeared','RepositionLogWindow','remove','AGgTg','Fjqxd','Settings','OXFtl','PostStunInfinitySpeed','constructor','faceName','image','rHMUB','Game_Battler_forceAction','_inputting','otbAddActions','VxOPt','WoWKQ','BorderThickness','ARRAYEVAL','registerCommand','otbAddBattlerToTurnOrderAtEnd','getStateTooltipBattler','makeActionOrdersOTB','OtbTurnOrderEnemyIcon','isTpb','applyBattleItemWindowOTB','otbRemoveUnableTurnOrderSprites','createBackgroundSprite','floor','Game_Battler_removeState','Ozlwf','scale','OrderDirection','OtbTurnOrderClearActorGraphic','isHorz','_spriteGroupWidth','battlerName','BgImageOffsetX','isBattleMember','changeSourceArray','QAkbS','onActorCancel','otbPreviewOrderChange','clearTurnOrderOTBGraphics','active','loadEnemy','SubjectDistance','length','EnemyBattlerType','rGeXV','concat','QviTj','requestUpdateTurnOrders','VVOUV','getColor','USlUe','getStateIdWithName','isTurnBased','RepositionTopHelpY','2110108MGsCcb','ConvertParams','onItemCancel','changeEnemyGraphicBitmap','speed','AuZcn','OTB_CONVERT_AGI_BUFF_NEXT_TURN','otbApplyActionTimes','pFefa','startActorCommandSelection','_preemptive','addBattlerToTurnOrderAtEnd','hMSZx','Scene_Battle_onActorOk','HGQjR','onBattleEndOTB','FYnRx','tMQlg','WidthBase','cXnAF','PreviewEnemy','setBlendColor','removeActionBattlersOTB','OTB_STUN_INFINITY_SPEED','left','UiAlignment','hUyHz','otbCalcTargetCurrentOrderChange','122256FqrRIi','EnableActionTimes','svActorVertCells','addActor','trim','bitmapWidth','changeFaceGraphicBitmap','iconHeight','ahymN','_otb_createdFirstTurnOrders','KfdTd','faceWidth','TargetAddActionNext','processSpriteRemoval','UserFollOrder','onBattleEnd','createGraphicSprite','stepForward','_speed','description','_surprise','Game_BattlerBase_hide','updateStateTurns','SpriteLength','Scene_Battle_commandGuard','QukXG','zttMR','otbUnshiftBattlerToTurnOrders','KgEGy','NUM','CnXXx','uoXNg','xcnnX','OTB_ADDED_RANDOMIZE_ADDED_ACTION_ORDER','_graphicIconIndex','endAction','Scene_Battle_onItemCancel','Visible','viwEo','checkOpacity','initialize','dnUhU','indexOf','boxWidth','loadSvActor','_positionTargetX','VurpU','%1-%2','TargetNextOrder','_graphicEnemy','createSpriteContainers','battleSys','deathStateId','defaultPosition','hCERA','TurnOrderOTBGraphicType','KjiHR','refresh','oyHJg','top','commandCancel','_otbTimesActedThisTurn','update','DisplayPosition','_helpWindow','_lastTargetIndex','Conversion','makeActionOrders','attack','allBattleMembers','isBattleSystemOTBTurnOrderVisible','kkjMf','GGbnr','Scene_Battle_onEnemyCancel','IconIndex','aUTSQ','Game_BattlerBase_recoverAll','BgImageOffsetY','xSYGU','_isBattleOver','addChildAt','dataId','updateGraphic','_partyCommandWindow','otbCalcUserCurrentOrderChange','version','UpdateFrames','veMCG','_currentActor','pPUGI','zVmkr','oLXaf','_requestTurnOrderUpdate','_scene','ActorBattlerType','_otbTurnOrderIconIndex','%1\x20is\x20missing\x20a\x20required\x20plugin.\x0aPlease\x20install\x20%2\x20into\x20the\x20Plugin\x20Manager.','addForceActionBattler','VXKtu','qRZiZ','Scene_Battle_onSkillOk','iuyAW','isEnemy','OTB_STUN_INFINITY_CLAMP','_index','_windowLayer','createNewTurnOrderSprites','isOTB','TqMQD','selectNextActorOTB','note','EFFECT_ADD_DEBUFF','nhQYa','adjustForPreview','tCLZR','ShowMarkerBg','select','BattleManager_setup','BattleManager_startInput','Scene_Battle_commandCancel','splice','getChildIndex','RepositionTopForHelp','_isAlive','drawText','vYpzk','commandCancelOTB','IAPlh','_graphicType','_fadeDuration','_letter','_unit','TargetCurrOrder','Game_Battler_onTurnEnd','onBattleStartOTB','appear','EnemyBattlerFontFace','_graphicSv','isSideView','SjaPl','_nextX','isAlive','ftDJi','battler','TurnOrder','STR','parse','createTurnOrderOTBGraphicFaceIndex','LogWindowOffsetY','iZsPu','anchor','_homeX','faceHeight','canMove','XuTYP','1063680uKXcwB','wavgS','_blendColor','aUpAD','onSkillCancel','createTurnOrderOTBGraphicIconIndex','getNextSubject','height','removeCurrentSubject','PreviewScale','_actions','UserAddActionNext','%1BgColor1','svactor','BgImageFilename','previewOrderByAction','_hidden','OtbTurnOrderActorIcon','IconSet','shift','ConvertAgiBuffCurrent','HOTZm','fillRect','clearRect','onSkillOk','dimColor2','setOTBGraphicIconIndex','otbCalcTargetNextOrderChange','removeChild','%1BgColor2','IAsJB','isActor','ZIxxx','loadSvEnemy','ezOXB','endTurn','OtbTurnOrderClearEnemyGraphic','finishActorInput','BattleManager_selectNextActor','isBattleItemWindowOTB','HuTLd','GCNuq','face','%1SystemBorder','forceActionOTB','zsscJ','siTYW','_positionTargetY','bind','removeSprite','_ogWindowLayerY','_homeY','actorCommandSingleSkill','otbReturnBattlerToTurnOrders','ohWEY','ARRAYJSON','BattleSystemOTB','StatusWindow','createTurnOrderOTBGraphicType','actor','makeNextActionOrdersOTB','%1BorderColor','Game_Battler_onBattleEnd','Game_Party_removeActor','gpIYR','GDzqE','changeSvActorGraphicBitmap','TargetAddActionCurrent','drawDimmedArea','_ogWindowLayerX','UserCurrOrder','turnOrderChangeOTB','msTaN','sortContainer','svActorHorzCells','BattleManager_isActiveTpb','_containerHeight','processTurn','_graphicHue','addBattlerToTurnOrderAtStart','_sourceArray','TurnOrderOTBGraphicFaceName','GOeRr','Window_Help_setItem','ShowMarkerBorder','KSnxZ','performActionEndOTB','SystemTurnOrderVisibility','icon','Scene_Battle_commandAttack','onBattleStart','applyItemTargetEffectOTB','PJoXZ','createTurnOrderOTBGraphicFaceName','randomInt','_backgroundSprite','Scene_Battle_createAllWindows','drawUiText','kqaii','Instant','XdyVE','_otbTurnOrderWindow','Game_BattlerBase_appear','eWfAw','OTB_ADDED_ACTION_TIMES','hasSvBattler','startFade','currentAction','setText','_statusWindow','_targetHomeY','FQCQR','status','width','CbVuh','ZtEth','_letterSprite','BgDimStyle','_tempActor','isInfinitySpeedOTB','_nextTurn','GJLkZ','#000000','children','createBorderSprite','Enemies','_graphicFaceIndex','blt','calculateTargetPositions','IYAXl','BattleManager_isTpb','removeState','createActorCommandWindow','currentSymbol','wvWzm','AGAVo','unshift','Game_Action_applyItemUserEffect','setup','_previewContainer','visible','refreshTurnOrder','STRUCT','302WwaYNk','onActorOk','UiCurrentText','numActions','canChangeOtbTurnOrder','ARRAYNUM','ActorBattlerIcon','srgbi','1064728Ggaozn','ConvertAgiDebuffNext','createAllWindows','WQWiz','Actor','loadSystem','_instance','makeOTBSpeed','EeZIZ','FLfcG','currentExt','max','setGuard','createOrderPreview','Scene_Battle_actorCommandSingleSkill','updatePadding','commandAttack','BattleManager_battleSys','XZizL','aZlxK','updateSelectionEffect','_forceAction','otbRemoveCurrentSubject','applyGlobalBattleSystemOTB','Window_Selectable_select','ConvertSpeedJS','VisuMZ_2_PartySystem','performCollapse','wmTOX','HBigH','hide','code','center','OtbTurnOrderActorFace','Scene_Battle_onItemOk','ScreenBuffer','_graphicSprite','containerWindow','BgKpl','includes','removeUnableTurnOrderSprites','members','gradient','vytaX','RepositionTopHelpX','effects','FUNC','TurnOrderOTBGraphicFaceIndex','XUdts','updatePosition','ARRAYFUNC','Scene_Battle_createActorCommandWindow','YhjPc','index','bitmap','Mechanics','_otbTurnOrderFaceIndex','contentsBack','PreviewOffsetX','otbGainInstant','_plural','_subject','KwDbB','1246878cpGcHa','isPreviousSceneBattleTransitionable','battlerHue','MoveDistance','ioTYV','_contentsBackSprite','boxHeight','Xefow','match','setHue','updateVisibility','postEndActionOTB','applyItemAddedActionOTB','create','_otbTurnOrderGraphicType','lQGzl','svBattlerName','pKGoc','_previewCurrent','_currentTurn','tYkBA','shiftTurnOrderForSubject','bottom','repositionLogWindowOTB','isActiveTpb','_offset','jaKur','Game_Battler_makeSpeed','OtbTurnOrderEnemyFace','_positionDuration','moveToPosition','YdKHW','decideRandomTarget','otbCreateNewTurnOrderSprites','createInitialPositions','_currentX','sXxYL','windowRect','otbAddForceActionBattler','BattleManager_isTurnBased','containerPosition','GBfwV','Game_Action_speed','initMembersOTB','DisplayOffsetX','guard','ActionBattlersNextFilter','mWYuL','setItem','bitmapHeight','Scene_Battle_onActorCancel','EnemyBattlerFaceIndex','forceAction','enemy','startTurn','qIqsa','right','getBattleSystem','GetAllIndicies','IaOey','SideviewBattleUI','InfinityClamp','CRXZO','processTurnOTB','makeSpeed','call','_previewNext','otbShiftTurnOrderForSubject','BattleManager_processTurn','UiSubjectOffsetY','BattleManager_getNextSubject','applyItemUserEffect','TargetFollOrder','createChildren','initMembers','_enemyWindow','createOrderPreviewSprite','addState','prototype','_forcedBattlers','DXSGS','setBattleSystemOTBTurnOrderVisible','isSceneBattle','addLoadListener','toUpperCase','allowRandomSpeed','getInfinityClamp','Scene_Battle_onEnemyOk','setSkill','jnFVL','_stateIDs','BattleManager_finishActorInput','ehuDl','fontSize','applyGlobal','isAppeared','_otb_actionBattlersNext','FXWqg','startActorInput','startInputOTB','UiSubjectText','InitialSpeedJS','tFllb','Game_Battler_addState','removeStatesAuto','EnemyBattlerFaceName','initHomePositions','clamp','min','push','inputtingAction','_actorCommandWindow','Game_Action_allowRandomSpeed','5WYjvQk','cancel','ceil','XWNPZ','makeActionTimes','VisuMZ_3_SideviewBattleUI','JNNGK','map','ConvertAgiBuffNext','UiFontSize','_targetHomeX','_otbTurnOrderVisible','otbPreviewOrderClear','resumeTurnOrderSprites','loadFace','_spriteContainer','RegExp','sort','BattleManager_forceAction','otbProcessActionCheck','processUpdateGraphic','findIndex','607596GxeroO','_phase','Game_System_initialize','wKfKw','resetFontSettings','EnemyBattlerFontSize','Game_Action_applyGlobal','vMlSK','_fadeTarget','_actionBattlers','exit','_tempBattler','lAFEZ','initBattleSystemOTB','commandGuard','name','%1\x27s\x20version\x20does\x20not\x20match\x20plugin\x27s.\x20Please\x20update\x20it\x20in\x20the\x20Plugin\x20Manager.','faceIndex','_containerWidth','BattleManager_makeActionOrders','zeHsr','_subjectX','contents','isNextOtbSubject','filter','UiNextText','endBattlerActions','startInput','_otbTurnOrderFaceName','Game_Actor_selectNextCommand','transparent','Game_Party_addActor','cuwtN','otbCalcUserNextOrderChange','JWAiV','OTB_CONVERT_AGI_DEBUFF_NEXT_TURN','_graphicFaceName','isPartyCommandWindowDisabled','format','AllowRandomSpeed','getUnitSideSide','roJus','FvyQU','createLetterSprite','_actorWindow','_fadeSpeed','shiftNextTurnSpritesToCurrentTurn','calculateTargetIndex','FaceIndex','canInput','clear','battleEnd','createActorCommandWindowOTB','%1\x20is\x20incorrectly\x20placed\x20on\x20the\x20plugin\x20list.\x0aIt\x20is\x20a\x20Tier\x20%2\x20plugin\x20placed\x20over\x20other\x20Tier\x20%3\x20plugins.\x0aPlease\x20reorder\x20the\x20plugin\x20list\x20from\x20smallest\x20to\x20largest\x20tier\x20numbers.','onItemOk','JtrUO','preEndActionOTB','padding','OTB_CONVERT_AGI_DEBUFF_CURRENT_TURN','getBorderThickness','OaRcu','createTurnOrderSprites','qNpHc','SpriteThin','onEnemyOk','needsSelection','selectNextCommand','_bgImageSprite','Game_Battler_performCollapse','createOTBTurnOrderWindow','updateGraphicHue','%1SystemBg','Actors','onTurnEnd','otbAddBattlerToTurnOrderAtStart','otbShiftNextTurnSpritesToCurrentTurn','BattleManager_endAction','clearOrderPreview','updateLetter'];_0x547b=function(){return _0x3fa096;};return _0x547b();}function Sprite_OTB_TurnOrder_Preview(){const _0x4ac239=_0x591529;this[_0x4ac239(0x347)](...arguments);}Sprite_OTB_TurnOrder_Preview[_0x591529(0x217)]=Object[_0x591529(0x1d6)](Sprite_OTB_TurnOrder_Battler[_0x591529(0x217)]),Sprite_OTB_TurnOrder_Preview[_0x591529(0x217)][_0x591529(0x2d0)]=Sprite_OTB_TurnOrder_Preview,Sprite_OTB_TurnOrder_Preview[_0x591529(0x217)]['initialize']=function(_0x1ba096,_0x45e86f,_0x558594,_0x180d81){const _0xb0c0f2=_0x591529;this[_0xb0c0f2(0x1e2)]=_0x180d81,Sprite_OTB_TurnOrder_Battler[_0xb0c0f2(0x217)]['initialize'][_0xb0c0f2(0x20a)](this,_0x1ba096,_0x45e86f,_0x558594),this[_0xb0c0f2(0xc9)]();},Sprite_OTB_TurnOrder_Preview[_0x591529(0x217)][_0x591529(0xc9)]=function(){const _0x5ad82f=_0x591529,_0x3b538e=Window_OTB_TurnOrder[_0x5ad82f(0x2cd)];this[_0x5ad82f(0x2e7)]['x']=this[_0x5ad82f(0x2e7)]['y']=_0x3b538e[_0x5ad82f(0xfc)];},Sprite_OTB_TurnOrder_Preview[_0x591529(0x217)][_0x591529(0x278)]=function(){const _0x42bd2b=_0x591529;return this[_0x42bd2b(0xdb)]===$gameParty?'PreviewActor':_0x42bd2b(0x317);},Sprite_OTB_TurnOrder_Preview['prototype'][_0x591529(0x28b)]=function(){const _0x1dff31=_0x591529,_0x2a831a=Window_OTB_TurnOrder[_0x1dff31(0x2cd)];return Math['ceil'](_0x2a831a['BorderThickness']/(_0x2a831a[_0x1dff31(0xfc)]||0.01));},Sprite_OTB_TurnOrder_Preview[_0x591529(0x217)][_0x591529(0x1e7)]=function(_0x31da62,_0x346aa9){const _0x401050=_0x591529;Sprite_OTB_TurnOrder_Battler['prototype'][_0x401050(0x1e7)][_0x401050(0x20a)](this,_0x31da62,_0x346aa9),this['x']=this[_0x401050(0x34c)],this['y']=this[_0x401050(0x122)];},Sprite_OTB_TurnOrder_Preview[_0x591529(0x217)][_0x591529(0x15d)]=function(_0x21a3a1){const _0x34c24c=_0x591529;Sprite_OTB_TurnOrder_Battler[_0x34c24c(0x217)][_0x34c24c(0x15d)][_0x34c24c(0x20a)](this,_0x21a3a1),_0x21a3a1>0x0?this[_0x34c24c(0xd9)]=0x1:_0x34c24c(0x16c)===_0x34c24c(0x16c)?(this[_0x34c24c(0xd9)]/=0x2,this[_0x34c24c(0xd9)]=Math[_0x34c24c(0x2e4)](this[_0x34c24c(0xd9)])):(_0x582e2f['gradientFillRect'](_0x4f5128,_0x7d56d,_0x10b51a/0x2,_0x5927bc,_0x212d78,_0x59ff30,![]),_0x45f3e1[_0x34c24c(0x109)](_0x539e14+_0x54e280/0x2,_0x4710f1,_0x3579f7/0x2,_0x325d11,_0x39472d),_0x145773[_0x34c24c(0x2bf)](_0x36d070,_0x53cb5d,_0x9fd9fc/0x2,_0x5afaf4,_0x26fc21,_0x1f0035,![]),_0x1abcb9[_0x34c24c(0x109)](_0x28cd9e+_0x38bf1b/0x2,_0x45bb41,_0x5f5c44/0x2,_0x518c0c,_0x18d810),_0xc82a6f[_0x34c24c(0x2bf)](_0x491575,_0x17c872,_0x2638cd/0x2,_0x40a1b0,_0x430a47,_0x34f5b1,![]),_0x191b25[_0x34c24c(0x109)](_0x46b821+_0x503e5f/0x2,_0x2699d5,_0x4095b8/0x2,_0x9d67e7,_0x376d1f));},Sprite_OTB_TurnOrder_Preview[_0x591529(0x217)]['additionalTargetXAdjustments']=function(_0x3de747,_0x134055){const _0x4a90ec=_0x591529,_0x504573=Window_OTB_TurnOrder[_0x4a90ec(0x2cd)];if(_0x3de747>0x0){if(_0x4a90ec(0x2f9)!==_0x4a90ec(0x23d)){if(this['_offset']>0x0)return _0x4a90ec(0x379)!==_0x4a90ec(0x36d)?_0x504573[_0x4a90ec(0x2e8)]?-_0x504573[_0x4a90ec(0x28f)]:_0x504573[_0x4a90ec(0x28f)]:_0x3c7d6d(_0x2ed928['$1']);else{if(this['_offset']<0x0)return _0x504573['OrderDirection']?-_0x134055:_0x134055;}}else this['initialize'](...arguments);}return 0x0;},Sprite_OTB_TurnOrder_Preview['prototype'][_0x591529(0x27f)]=function(){const _0x2d41f6=_0x591529,_0x458fef=this[_0x2d41f6(0x1af)](),_0x43b06d=this[_0x2d41f6(0x143)]===_0x458fef[_0x2d41f6(0x16b)]?!![]:![],_0x418529=_0x43b06d?BattleManager[_0x2d41f6(0x229)]:BattleManager[_0x2d41f6(0x259)];let _0x21a7dd=0x0,_0x4c33d8=_0x418529[_0x2d41f6(0x2f7)]-0x1;if(_0x43b06d){if(_0x2d41f6(0xed)===_0x2d41f6(0x115))return this['_subject']=_0x12d192[_0x2d41f6(0x12b)][_0x2d41f6(0x20f)][_0x2d41f6(0x20a)](this),this[_0x2d41f6(0xc3)]()&&this[_0x2d41f6(0x1c7)]&&this[_0x2d41f6(0x20c)](this[_0x2d41f6(0x1c7)]),this[_0x2d41f6(0x1c7)];else _0x21a7dd=Math[_0x2d41f6(0x195)](0x0,VisuMZ['BattleSystemOTB']['getInfinityClamp'](_0x418529));}let _0x2c5011=Sprite_OTB_TurnOrder_Battler['prototype']['calculateTargetIndex'][_0x2d41f6(0x20a)](this);return _0x2c5011+=this['_offset'],_0x2c5011[_0x2d41f6(0x234)](_0x21a7dd,_0x4c33d8);},Sprite_OTB_TurnOrder_Preview['prototype'][_0x591529(0x19e)]=function(){},Window_Selectable[_0x591529(0x217)][_0x591529(0x11a)]=function(){return![];},VisuMZ['BattleSystemOTB'][_0x591529(0x1a2)]=Window_Selectable[_0x591529(0x217)]['select'],Window_Selectable[_0x591529(0x217)][_0x591529(0xcc)]=function(_0x4084a6){const _0x1edb47=_0x591529;VisuMZ['BattleSystemOTB'][_0x1edb47(0x1a2)][_0x1edb47(0x20a)](this,_0x4084a6),this[_0x1edb47(0x11a)]()&&this['active']&&(_0x1edb47(0x200)!==_0x1edb47(0x200)?(this[_0x1edb47(0x377)]=_0x3fd1db,this[_0x1edb47(0x22b)]()):this[_0x1edb47(0x2e1)]());},Window_Selectable[_0x591529(0x217)][_0x591529(0x2e1)]=function(){const _0x5464c7=_0x591529;BattleManager[_0x5464c7(0x2f2)]();},VisuMZ[_0x591529(0x12b)][_0x591529(0x146)]=Window_Help[_0x591529(0x217)][_0x591529(0x1f9)],Window_Help[_0x591529(0x217)]['setItem']=function(_0x9e26c){const _0x3450ed=_0x591529;BattleManager['isOTB']()&&_0x9e26c&&_0x9e26c[_0x3450ed(0xc6)]&&_0x9e26c[_0x3450ed(0xc6)]['match'](/<(?:OTB) HELP>\s*([\s\S]*)\s*<\/(?:OTB) HELP>/i)?_0x3450ed(0x31d)!==_0x3450ed(0x33d)?this[_0x3450ed(0x15f)](String(RegExp['$1'])):this[_0x3450ed(0xc3)]()?_0x3854a0[_0x3450ed(0x12b)]['BattleManager_processTurn'][_0x3450ed(0x20a)](this):_0x3778c9[_0x3450ed(0x12b)]['BattleManager_finishActorInput'][_0x3450ed(0x20a)](this):VisuMZ['BattleSystemOTB'][_0x3450ed(0x146)][_0x3450ed(0x20a)](this,_0x9e26c);},Window_ActorCommand[_0x591529(0x217)][_0x591529(0x11a)]=function(){const _0x54ae2c=_0x591529;return BattleManager[_0x54ae2c(0xc3)]();},Window_ActorCommand[_0x591529(0x217)]['applyBattleItemWindowOTB']=function(){const _0x4fe1e1=_0x591529,_0x1a9bbd=BattleManager[_0x4fe1e1(0x237)]();if(_0x1a9bbd){const _0x53a279=this[_0x4fe1e1(0x178)]();switch(_0x53a279){case _0x4fe1e1(0x363):_0x1a9bbd['setAttack']();break;case _0x4fe1e1(0x1f6):_0x1a9bbd[_0x4fe1e1(0x196)]();break;case'singleSkill':_0x1a9bbd[_0x4fe1e1(0x221)](this[_0x4fe1e1(0x194)]());break;default:_0x1a9bbd['setSkill'](null);break;}}Window_Command[_0x4fe1e1(0x217)][_0x4fe1e1(0x2e1)][_0x4fe1e1(0x20a)](this);},Window_BattleSkill[_0x591529(0x217)][_0x591529(0x11a)]=function(){const _0x23a5f8=_0x591529;return BattleManager[_0x23a5f8(0xc3)]();},Window_BattleSkill['prototype'][_0x591529(0x2e1)]=function(){const _0x519389=_0x591529,_0x106a5e=this[_0x519389(0x2ac)](),_0x269528=BattleManager[_0x519389(0x237)]();if(_0x269528)_0x269528[_0x519389(0x221)](_0x106a5e?_0x106a5e['id']:null);Window_SkillList[_0x519389(0x217)][_0x519389(0x2e1)][_0x519389(0x20a)](this);},Window_BattleItem[_0x591529(0x217)][_0x591529(0x11a)]=function(){const _0x57d79a=_0x591529;return BattleManager[_0x57d79a(0xc3)]();},Window_BattleItem[_0x591529(0x217)][_0x591529(0x2e1)]=function(){const _0x2dc537=_0x591529,_0x8fb3ed=this[_0x2dc537(0x2ac)](),_0x54f4c9=BattleManager[_0x2dc537(0x237)]();if(_0x54f4c9)_0x54f4c9[_0x2dc537(0x1f9)](_0x8fb3ed?_0x8fb3ed['id']:null);Window_ItemList[_0x2dc537(0x217)][_0x2dc537(0x2e1)][_0x2dc537(0x20a)](this);},Window_BattleActor[_0x591529(0x217)][_0x591529(0x11a)]=function(){const _0x20ad87=_0x591529;return BattleManager[_0x20ad87(0xc3)]();},Window_BattleEnemy[_0x591529(0x217)][_0x591529(0x11a)]=function(){const _0x10ee31=_0x591529;return BattleManager[_0x10ee31(0xc3)]();};function Window_OTB_TurnOrder(){const _0x196e83=_0x591529;this[_0x196e83(0x347)](...arguments);}Window_OTB_TurnOrder[_0x591529(0x217)]=Object[_0x591529(0x1d6)](Window_Base[_0x591529(0x217)]),Window_OTB_TurnOrder[_0x591529(0x217)]['constructor']=Window_OTB_TurnOrder,Window_OTB_TurnOrder[_0x591529(0x2cd)]=VisuMZ['BattleSystemOTB']['Settings'][_0x591529(0xe8)],Window_OTB_TurnOrder[_0x591529(0x217)]['initialize']=function(){const _0x5a1e91=_0x591529,_0x28904c=this[_0x5a1e91(0x1ee)]();this[_0x5a1e91(0x233)](_0x28904c),Window_Base[_0x5a1e91(0x217)][_0x5a1e91(0x347)][_0x5a1e91(0x20a)](this,_0x28904c),this[_0x5a1e91(0x2c6)]=0x0,this['drawDimmedArea'](),this[_0x5a1e91(0x154)](),this[_0x5a1e91(0x351)](),this[_0x5a1e91(0x1d3)]();},Window_OTB_TurnOrder[_0x591529(0x217)]['windowRect']=function(){const _0x555959=_0x591529,_0x4c7dcd=Window_OTB_TurnOrder[_0x555959(0x2cd)],_0x427f8a=SceneManager[_0x555959(0x37c)][_0x555959(0x160)][_0x555959(0xfa)];let _0x2f7d17=Graphics['width']-_0x4c7dcd[_0x555959(0x1ad)]*0x2,_0x243620=_0x4c7dcd['SpriteLength']+this['lineHeight'](),_0x1447be=_0x4c7dcd[_0x555959(0x1ad)],_0x30c882=0x0;switch(_0x4c7dcd[_0x555959(0x35e)]){case _0x555959(0x1df):_0x30c882=Graphics[_0x555959(0xfa)]-_0x427f8a-_0x4c7dcd[_0x555959(0x1ad)]-_0x243620;break;default:_0x30c882=_0x4c7dcd[_0x555959(0x1ad)];break;}if(Imported[_0x555959(0x23f)]&&BattleManager['isUsingSideviewUiLayout']()){const _0x197e57=VisuMZ[_0x555959(0x205)][_0x555959(0x2cd)]['StatusWindow'];_0x2f7d17-=_0x197e57[_0x555959(0x315)]+_0x197e57[_0x555959(0x1cc)],_0x2f7d17-=_0x4c7dcd[_0x555959(0x1ad)];}return _0x1447be+=_0x4c7dcd[_0x555959(0x1f5)]||0x0,_0x30c882+=_0x4c7dcd['DisplayOffsetY']||0x0,new Rectangle(_0x1447be,_0x30c882,_0x2f7d17,_0x243620);},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x233)]=function(_0x5129fe){const _0xc0e060=_0x591529;this[_0xc0e060(0x244)]=this[_0xc0e060(0xef)]=_0x5129fe['x'],this[_0xc0e060(0x161)]=this[_0xc0e060(0x126)]=_0x5129fe['y'],this['_homeDuration']=0x0;const _0xd45961=Window_OTB_TurnOrder[_0xc0e060(0x2cd)];this[_0xc0e060(0x2eb)]=Math['ceil']((_0x5129fe[_0xc0e060(0x164)]-_0xd45961[_0xc0e060(0x28f)]-_0xd45961['SubjectDistance']*0x2)/0x2),_0xd45961[_0xc0e060(0x2e8)]?(this[_0xc0e060(0x265)]=_0x5129fe[_0xc0e060(0x164)]-_0xd45961[_0xc0e060(0x28f)],this[_0xc0e060(0x1ec)]=this[_0xc0e060(0x2eb)]+_0xd45961[_0xc0e060(0x2f6)],this[_0xc0e060(0xe4)]=0x0):_0xc0e060(0x2ae)!==_0xc0e060(0x2ae)?(_0x2f616a[_0xc0e060(0x12b)]['Game_Action_applyItemUserEffect'][_0xc0e060(0x20a)](this,_0x49bc1a),this[_0xc0e060(0x1d5)](_0x5f2fb8),this['applyItemTargetEffectOTB'](_0x57c8fb)):(this[_0xc0e060(0x265)]=0x0,this[_0xc0e060(0x1ec)]=_0xd45961['SpriteThin']+_0xd45961['SubjectDistance'],this[_0xc0e060(0xe4)]=this[_0xc0e060(0x1ec)]+_0xd45961[_0xc0e060(0x2f6)]+this[_0xc0e060(0x2eb)]);},Window_OTB_TurnOrder['prototype'][_0x591529(0x199)]=function(){const _0x118724=_0x591529;this[_0x118724(0x289)]=0x0;},Window_OTB_TurnOrder['prototype']['drawDimmedArea']=function(){const _0x248acc=_0x591529,_0x587eaa=Window_OTB_TurnOrder['Settings'];if(_0x587eaa[_0x248acc(0x168)]===_0x248acc(0x26e))return;if(_0x587eaa[_0x248acc(0x168)]===_0x248acc(0x2d2)&&_0x587eaa[_0x248acc(0x101)]!==''){const _0x16ab7d=ImageManager['loadSystem'](_0x587eaa[_0x248acc(0x101)]);_0x16ab7d[_0x248acc(0x21c)](this[_0x248acc(0x2c0)][_0x248acc(0x123)](this,_0x16ab7d));return;};const _0x10dabe=this[_0x248acc(0x1c3)],_0x59535b=ColorManager['dimColor1'](),_0x85c9a1=ColorManager[_0x248acc(0x10c)](),_0x1da253=this[_0x248acc(0x265)],_0x22e6c6=_0x587eaa[_0x248acc(0x28f)],_0x146f4a=0x0,_0x56dd63=_0x587eaa[_0x248acc(0x336)],_0x4d0552=this['_currentX'],_0x41dd4f=this[_0x248acc(0xe4)],_0x527e70=this[_0x248acc(0x2eb)];switch(_0x587eaa[_0x248acc(0x168)]){case _0x248acc(0x1b4):_0x587eaa[_0x248acc(0x2e8)]?(_0x10dabe[_0x248acc(0x2bf)](_0x1da253,_0x146f4a,_0x22e6c6/0x2,_0x56dd63,_0x85c9a1,_0x59535b,![]),_0x10dabe[_0x248acc(0x109)](_0x1da253+_0x22e6c6/0x2,_0x146f4a,_0x22e6c6/0x2,_0x56dd63,_0x59535b),_0x10dabe[_0x248acc(0x2bf)](_0x4d0552,_0x146f4a,_0x527e70/0x2,_0x56dd63,_0x85c9a1,_0x59535b,![]),_0x10dabe[_0x248acc(0x109)](_0x4d0552+_0x527e70/0x2,_0x146f4a,_0x527e70/0x2,_0x56dd63,_0x59535b),_0x10dabe[_0x248acc(0x2bf)](_0x41dd4f,_0x146f4a,_0x527e70/0x2,_0x56dd63,_0x85c9a1,_0x59535b,![]),_0x10dabe[_0x248acc(0x109)](_0x41dd4f+_0x527e70/0x2,_0x146f4a,_0x527e70/0x2,_0x56dd63,_0x59535b)):'FlcZO'!=='FlcZO'?(this[_0x248acc(0x36e)]=!![],this['startFade'](0x0)):(_0x10dabe[_0x248acc(0x109)](_0x1da253,_0x146f4a,_0x22e6c6/0x2,_0x56dd63,_0x59535b),_0x10dabe[_0x248acc(0x2bf)](_0x1da253+_0x22e6c6/0x2,_0x146f4a,_0x22e6c6/0x2,_0x56dd63,_0x59535b,_0x85c9a1,![]),_0x10dabe[_0x248acc(0x109)](_0x4d0552,_0x146f4a,_0x527e70/0x2,_0x56dd63,_0x59535b),_0x10dabe[_0x248acc(0x2bf)](_0x4d0552+_0x527e70/0x2,_0x146f4a,_0x527e70/0x2,_0x56dd63,_0x59535b,_0x85c9a1,![]),_0x10dabe[_0x248acc(0x109)](_0x41dd4f,_0x146f4a,_0x527e70/0x2,_0x56dd63,_0x59535b),_0x10dabe['gradientFillRect'](_0x41dd4f+_0x527e70/0x2,_0x146f4a,_0x527e70/0x2,_0x56dd63,_0x59535b,_0x85c9a1,![]));break;default:_0x10dabe[_0x248acc(0x109)](_0x1da253,_0x146f4a,_0x22e6c6,_0x56dd63,_0x59535b),_0x10dabe[_0x248acc(0x109)](_0x4d0552,_0x146f4a,_0x527e70,_0x56dd63,_0x59535b),_0x10dabe['fillRect'](_0x41dd4f,_0x146f4a,_0x527e70,_0x56dd63,_0x59535b);break;}},Window_OTB_TurnOrder['prototype'][_0x591529(0x2c0)]=function(_0x456a3f){const _0x1f6a74=_0x591529;this[_0x1f6a74(0x293)]=new Sprite(),this[_0x1f6a74(0x293)][_0x1f6a74(0x1c0)]=_0x456a3f,this['addChildToBack'](this['_bgImageSprite']);const _0x5659d0=Window_OTB_TurnOrder['Settings'];this[_0x1f6a74(0x293)]['x']=_0x5659d0[_0x1f6a74(0x2ed)],this[_0x1f6a74(0x293)]['y']=_0x5659d0[_0x1f6a74(0x36c)];},Window_OTB_TurnOrder['prototype'][_0x591529(0x154)]=function(){const _0x510081=_0x591529;this[_0x510081(0x266)][_0x510081(0x282)](),this[_0x510081(0x254)]();const _0xbc00d1=Window_OTB_TurnOrder[_0x510081(0x2cd)];this['contents']['fontSize']=_0xbc00d1[_0x510081(0x243)];let _0x1f8e80=_0xbc00d1[_0x510081(0x31c)];_0x1f8e80==='auto'&&(_0x1f8e80=_0xbc00d1[_0x510081(0x2e8)]?'right':_0x510081(0x31b));let _0x27a5b7=_0xbc00d1['SpriteLength'];if(_0xbc00d1['UiSubjectText']!==''){if('PaCDk'===_0x510081(0xc8))_0x3354b0['otbPreviewOrderClear'](),_0x2f07cb[_0x510081(0x12b)][_0x510081(0x14c)]['call'](this);else{const _0x5d16be=this[_0x510081(0x265)]+_0xbc00d1['UiSubjectOffsetX'],_0x36789d=_0x27a5b7+_0xbc00d1[_0x510081(0x20e)],_0x51c1d7=_0xbc00d1[_0x510081(0x28f)];this['drawText'](_0xbc00d1[_0x510081(0x22d)],_0x5d16be,_0x36789d,_0x51c1d7,_0x510081(0x1aa));}}if(_0xbc00d1[_0x510081(0x184)]!==''){const _0x3f4124=this[_0x510081(0x1ec)]+_0xbc00d1['UiCurrentOffsetX'],_0x4284e7=_0x27a5b7+_0xbc00d1['UiCurrentOffsetY'],_0x236f78=this[_0x510081(0x2eb)];this[_0x510081(0xd4)](_0xbc00d1[_0x510081(0x184)],_0x3f4124,_0x4284e7,_0x236f78,_0x1f8e80);}if(_0xbc00d1['UiNextText']!==''){const _0x55ca33=this['_nextX']+_0xbc00d1['UiNextOffsetX'],_0x598d3a=_0x27a5b7+_0xbc00d1['UiNextOffsetY'],_0x36b224=this['_spriteGroupWidth'];this[_0x510081(0xd4)](_0xbc00d1[_0x510081(0x269)],_0x55ca33,_0x598d3a,_0x36b224,_0x1f8e80);}},Window_OTB_TurnOrder['prototype']['createSpriteContainers']=function(){const _0x3eca06=_0x591529,_0x4031fb=Window_OTB_TurnOrder['Settings'];this[_0x3eca06(0x249)]=new Sprite(),this[_0x3eca06(0x2bb)](this[_0x3eca06(0x249)]),this[_0x3eca06(0x1c7)]=null,this[_0x3eca06(0x1dc)]=[],this[_0x3eca06(0x16b)]=[],this['_previewContainer']=new Sprite(),this[_0x3eca06(0x17e)]['x']=_0x4031fb[_0x3eca06(0x1c4)],this[_0x3eca06(0x17e)]['y']=_0x4031fb[_0x3eca06(0x2a7)],this['_previewContainer']['x']-=Math[_0x3eca06(0x23c)](_0x4031fb[_0x3eca06(0x28f)]*0.5*_0x4031fb[_0x3eca06(0xfc)]);if(_0x4031fb['OrderDirection']){if('ZSnHI'===_0x3eca06(0x174)){if(!_0xd49772)return;const _0x468228=_0x44a95e[_0x3eca06(0x23e)]();_0x3b864c[_0x3eca06(0x2b0)]();if(!this['_actionBattlers'][_0x3eca06(0x1b1)](_0x3b01ae)){const _0x93cfb2=_0x8b390[_0x3eca06(0x195)](0x0,_0x468228-(_0x14082a['_otbTimesActedThisTurn']||0x0));this[_0x3eca06(0x142)](_0x103225,_0x93cfb2,this[_0x3eca06(0x259)]);}if(!this['_otb_actionBattlersNext'][_0x3eca06(0x1b1)](_0x2e41bc)){const _0x18bc68=_0x468228;this[_0x3eca06(0x142)](_0x1a71d4,_0x18bc68,this[_0x3eca06(0x229)]);}}else this[_0x3eca06(0x17e)]['x']+=_0x4031fb[_0x3eca06(0x28f)];}this['_previewContainer']['y']-=Math[_0x3eca06(0x23c)](_0x4031fb['SpriteLength']*0.5*_0x4031fb[_0x3eca06(0xfc)]),this[_0x3eca06(0x2bb)](this['_previewContainer']),this[_0x3eca06(0x1db)]=[],this['_previewNext']=[];},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x35d)]=function(){const _0x284020=_0x591529;Window_Base['prototype']['update'][_0x284020(0x20a)](this),this['updateTurnOrders'](),this[_0x284020(0x1bb)](),this[_0x284020(0x1d3)](),this['sortContainer']();},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x2fc)]=function(){const _0x263a2a=_0x591529;this[_0x263a2a(0x37b)]=!![];},Window_OTB_TurnOrder['prototype']['updateTurnOrders']=function(){const _0x5ea879=_0x591529;if(!this['_requestTurnOrderUpdate'])return;this[_0x5ea879(0x37b)]=![];for(const _0x4b0426 of this[_0x5ea879(0x1dc)]){if(!_0x4b0426)continue;_0x4b0426[_0x5ea879(0x173)]();}for(const _0x34b571 of this['_nextTurn']){if(!_0x34b571)continue;_0x34b571[_0x5ea879(0x173)]();}},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x1bb)]=function(){const _0x5a32c6=_0x591529,_0x1fb788=Window_OTB_TurnOrder[_0x5a32c6(0x2cd)];if(_0x1fb788[_0x5a32c6(0x35e)]!==_0x5a32c6(0x35a))return;if(!_0x1fb788[_0x5a32c6(0xd2)])return;const _0x36d7dc=SceneManager[_0x5a32c6(0x37c)][_0x5a32c6(0x35f)];if(!_0x36d7dc)return;_0x36d7dc[_0x5a32c6(0x17f)]?(this['x']=this[_0x5a32c6(0xef)]+(_0x1fb788[_0x5a32c6(0x1b6)]||0x0),this['y']=this[_0x5a32c6(0x126)]+(_0x1fb788[_0x5a32c6(0x302)]||0x0)):(this['x']=this[_0x5a32c6(0xef)],this['y']=this[_0x5a32c6(0x126)]);const _0x2afeb0=SceneManager[_0x5a32c6(0x37c)][_0x5a32c6(0xc1)];Window_OTB_TurnOrder[_0x5a32c6(0x138)]===undefined&&(_0x5a32c6(0x2d7)===_0x5a32c6(0x179)?this['createOrderPreviewSprite'](_0x435e87,![],_0x882568):Window_OTB_TurnOrder['_ogWindowLayerX']=Math[_0x5a32c6(0x2b6)]((Graphics[_0x5a32c6(0x164)]-Math['min'](Graphics['boxWidth'],_0x2afeb0['width']))/0x2));Window_OTB_TurnOrder[_0x5a32c6(0x125)]===undefined&&(Window_OTB_TurnOrder['_ogWindowLayerY']=Math[_0x5a32c6(0x2b6)]((Graphics[_0x5a32c6(0xfa)]-Math[_0x5a32c6(0x235)](Graphics[_0x5a32c6(0x1cf)],_0x2afeb0[_0x5a32c6(0xfa)]))/0x2));;this['x']+=_0x2afeb0['x']-Window_OTB_TurnOrder['_ogWindowLayerX'],this['y']+=_0x2afeb0['y']-Window_OTB_TurnOrder[_0x5a32c6(0x125)];},Window_OTB_TurnOrder['prototype'][_0x591529(0x1d3)]=function(){const _0xfbabb0=_0x591529;this[_0xfbabb0(0x17f)]=$gameSystem[_0xfbabb0(0x365)]();if(BattleManager['_phase']===_0xfbabb0(0x283)){if(!this[_0xfbabb0(0x27d)]){const _0x10ac28=Window_OTB_TurnOrder[_0xfbabb0(0x2cd)];this['_fadeSpeed']=Math['ceil'](0xff/(_0x10ac28[_0xfbabb0(0x375)]||0x1));}this[_0xfbabb0(0x2c6)]-=this[_0xfbabb0(0x27d)],this['contentsOpacity']-=this[_0xfbabb0(0x27d)],this['_contentsBackSprite']['opacity']-=this[_0xfbabb0(0x27d)];}},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x13c)]=function(){const _0x10d630=_0x591529;if(!this[_0x10d630(0x249)])return;const _0x1f73a8=Window_OTB_TurnOrder[_0x10d630(0x2cd)],_0x522a4a=_0x1f73a8['OrderDirection'];_0x522a4a?this[_0x10d630(0x249)][_0x10d630(0x16e)][_0x10d630(0x24b)]((_0x45a2e9,_0x1c1bbc)=>_0x45a2e9['x']-_0x1c1bbc['x']):this[_0x10d630(0x249)][_0x10d630(0x16e)][_0x10d630(0x24b)]((_0x36c4b4,_0x536a68)=>_0x536a68['x']-_0x36c4b4['x']);},Window_OTB_TurnOrder['prototype'][_0x591529(0x124)]=function(_0x456ac4){const _0x1757b9=_0x591529;if(!_0x456ac4)return;_0x456ac4[_0x1757b9(0x143)]&&_0x456ac4[_0x1757b9(0x143)][_0x1757b9(0x2ca)](_0x456ac4);const _0x4afe08=Window_OTB_TurnOrder[_0x1757b9(0x2cd)],_0x31546d=0x3e8/0x3c*_0x4afe08[_0x1757b9(0x375)]+0x1f4;_0x456ac4[_0x1757b9(0x15d)](0x0),setTimeout(this[_0x1757b9(0x32c)][_0x1757b9(0x123)](this,_0x456ac4),_0x31546d);},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x32c)]=function(_0x239ad0){const _0x2a27cb=_0x591529;if(_0x239ad0[_0x2a27cb(0x143)]){if(_0x2a27cb(0x1cd)===_0x2a27cb(0x1cd))_0x239ad0[_0x2a27cb(0x143)]['remove'](_0x239ad0);else{const _0x5de559=this[_0x2a27cb(0xf1)](),_0x416c6f=this[_0x2a27cb(0x23e)]();_0x4e7b36[_0x2a27cb(0x12b)][_0x2a27cb(0x2e5)][_0x2a27cb(0x20a)](this,_0x5cbf65),this[_0x2a27cb(0x24d)](_0x5de559,_0x416c6f);}}this[_0x2a27cb(0x249)][_0x2a27cb(0x10f)](_0x239ad0),this['_previewContainer']['removeChild'](_0x239ad0);},Window_OTB_TurnOrder['prototype']['removeCurrentSubject']=function(){const _0x4f2913=_0x591529;if(!this[_0x4f2913(0x1c7)])return;this[_0x4f2913(0x124)](this['_subject']);},Window_OTB_TurnOrder[_0x591529(0x217)]['shiftNextTurnSpritesToCurrentTurn']=function(){const _0xa154e3=_0x591529;while(this[_0xa154e3(0x1dc)][_0xa154e3(0x2f7)]){const _0x786b2f=this[_0xa154e3(0x1dc)][_0xa154e3(0x106)]();_0x786b2f[_0xa154e3(0x15d)](0x0);}while(this[_0xa154e3(0x16b)][_0xa154e3(0x2f7)]){const _0x283a09=this[_0xa154e3(0x16b)]['shift']();if(!_0x283a09)continue;this[_0xa154e3(0x1dc)]['push'](_0x283a09);}for(const _0x4fe7b2 of this['_currentTurn']){if(_0xa154e3(0x1a6)!=='wmTOX'){if(!this['_fadeSpeed']){const _0x86c336=_0x785816[_0xa154e3(0x2cd)];this[_0xa154e3(0x27d)]=_0x258d29[_0xa154e3(0x23c)](0xff/(_0x86c336[_0xa154e3(0x375)]||0x1));}this['opacity']-=this[_0xa154e3(0x27d)],this[_0xa154e3(0x2b5)]-=this[_0xa154e3(0x27d)],this[_0xa154e3(0x1ce)][_0xa154e3(0x2c6)]-=this[_0xa154e3(0x27d)];}else{if(!_0x4fe7b2)continue;_0x4fe7b2[_0xa154e3(0x2ef)](this[_0xa154e3(0x1dc)]);}}},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x28d)]=function(_0x10c000,_0xaa4c01){const _0x1e9876=_0x591529,_0x14ef32=_0x10c000===BattleManager[_0x1e9876(0x259)]?this[_0x1e9876(0x1dc)]:this[_0x1e9876(0x16b)],_0x225b8c={};for(const _0x154769 of _0x10c000){const _0x347647=_0x1e9876(0x34e)['format'](_0x154769[_0x1e9876(0x112)]()?'actor':_0x1e9876(0x1fe),_0x154769['index']());_0x225b8c[_0x347647]=_0x225b8c[_0x347647]||0x0;const _0x402dda=_0x225b8c[_0x347647]++,_0x45e2af=new Sprite_OTB_TurnOrder_Battler(_0x154769,_0x402dda,_0x14ef32);this[_0x1e9876(0x249)][_0x1e9876(0x2bb)](_0x45e2af),_0x14ef32[_0x1e9876(0x236)](_0x45e2af);}for(const _0x52adc0 of _0x14ef32){if(!_0x52adc0)continue;_0x52adc0[_0x1e9876(0x15d)](0xff),_0x52adc0[_0x1e9876(0x173)](),_0xaa4c01&&(_0x52adc0[_0x1e9876(0x2c6)]=0xff,_0x52adc0['x']=_0x52adc0['_positionTargetX'],_0x52adc0[_0x1e9876(0x1e6)]=0x0);}},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0xc2)]=function(){const _0x5f4af5=_0x591529,_0x2e9627=BattleManager[_0x5f4af5(0x229)];this[_0x5f4af5(0x28d)](_0x2e9627);},Window_OTB_TurnOrder['prototype'][_0x591529(0x1de)]=function(_0x5e263d,_0xcae89d){const _0x737069=_0x591529;this[_0x737069(0xfb)]();for(const _0x552a41 of this['_currentTurn']){if(_0x737069(0x357)!=='bdHxS'){if(!_0x552a41)continue;_0x552a41[_0x737069(0xe7)]()===_0x5e263d&&(_0x552a41['_instance']=_0x552a41[_0x737069(0x190)]||0x0,_0x552a41[_0x737069(0x190)]--);}else return this[_0x737069(0x24e)]();}const _0x742081=this[_0x737069(0x1dc)][_0x737069(0x24f)](_0x1b43e4=>_0x1b43e4['battler']()===_0x5e263d);if(this['_currentTurn'][_0x742081])_0x737069(0x1c8)==='KwDbB'?(this[_0x737069(0x1c7)]=this[_0x737069(0x1dc)][_0x742081],this[_0x737069(0x1dc)][_0x742081][_0x737069(0x173)](),this[_0x737069(0x1dc)][_0x737069(0xd0)](_0x742081,0x1)):(_0x1d06d1[_0x737069(0x217)][_0x737069(0x1e7)][_0x737069(0x20a)](this,_0x32aeb2,_0x83238),this['x']=this[_0x737069(0x34c)],this['y']=this[_0x737069(0x122)]);else{if(_0x5e263d){const _0x3cc685=new Sprite_OTB_TurnOrder_Battler(_0x5e263d,-0x1,null);this[_0x737069(0x249)][_0x737069(0x2bb)](_0x3cc685),this[_0x737069(0x1c7)]=_0x3cc685,_0x3cc685[_0x737069(0x15d)](0xff),_0x3cc685['_positionDuration']=0x258,_0x3cc685['x']=this[_0x737069(0x265)],_0x3cc685[_0x737069(0x34c)]=this[_0x737069(0x265)],_0xcae89d&&(_0x3cc685[_0x737069(0x2c6)]=0xff);}}for(const _0x531075 of this['_currentTurn']){if(_0x737069(0xd7)===_0x737069(0xd7)){if(!_0x531075)continue;_0x531075[_0x737069(0x173)]();}else _0x285394[_0x737069(0xc3)]()?this[_0x737069(0x11f)](_0x29c094,_0x33649a):_0x44e742[_0x737069(0x12b)][_0x737069(0x2d4)][_0x737069(0x20a)](this,_0x5be5ec,_0x175aec);}},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x1b2)]=function(){const _0x5261a7=_0x591529;for(const _0x208d97 of this[_0x5261a7(0x1dc)]){if(_0x5261a7(0x355)===_0x5261a7(0x355)){if(!_0x208d97)continue;const _0x1ffce3=_0x208d97[_0x5261a7(0xe7)]();if(BattleManager[_0x5261a7(0x259)][_0x5261a7(0x1b1)](_0x1ffce3))continue;this[_0x5261a7(0x124)](_0x208d97);}else _0x2adad1['drawText'](this[_0x5261a7(0xda)][_0x5261a7(0x323)](),_0x26d7dd*0x1/0x8,_0x5a8f20/0x2,_0xb8a64,_0x1dc2b3/0x2,_0x5261a7(0x31b));}for(const _0x5c2dcb of this['_nextTurn']){if(_0x5261a7(0x33b)===_0x5261a7(0x192))return _0x3a0253[_0x5261a7(0x12b)][_0x5261a7(0x2cd)][_0x5261a7(0x1c1)][_0x5261a7(0x277)];else{if(!_0x5c2dcb)continue;const _0x298cab=_0x5c2dcb[_0x5261a7(0xe7)]();if(BattleManager[_0x5261a7(0x229)][_0x5261a7(0x1b1)](_0x298cab))continue;this[_0x5261a7(0x124)](_0x5c2dcb);}}},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x30e)]=function(_0x2e0085,_0xc75f1){const _0x1c0875=_0x591529,_0x42e064=_0xc75f1===BattleManager[_0x1c0875(0x259)]?this[_0x1c0875(0x1dc)]:this[_0x1c0875(0x16b)];if(!_0x42e064)return;const _0x251386=VisuMZ[_0x1c0875(0x12b)]['GetAllIndicies'](_0x2e0085,_0xc75f1),_0x185f40=_0x251386[_0x1c0875(0x2f7)]-0x1,_0x46b88e=new Sprite_OTB_TurnOrder_Battler(_0x2e0085,_0x185f40,_0x42e064);this['_spriteContainer'][_0x1c0875(0x2bb)](_0x46b88e),_0x42e064[_0x1c0875(0x236)](_0x46b88e),_0x46b88e['startFade'](0xff),this['requestUpdateTurnOrders']();},Window_OTB_TurnOrder[_0x591529(0x217)]['addBattlerToTurnOrderAtStart']=function(_0x3f4a0c,_0x205ec1){const _0x5bb0c8=_0x591529,_0x19cdc8=_0x205ec1===BattleManager[_0x5bb0c8(0x259)]?this[_0x5bb0c8(0x1dc)]:this[_0x5bb0c8(0x16b)];if(!_0x19cdc8)return;for(const _0x4dc292 of _0x19cdc8){if(_0x5bb0c8(0x29f)!==_0x5bb0c8(0x225)){if(!_0x4dc292)continue;_0x4dc292[_0x5bb0c8(0xe7)]()===_0x3f4a0c&&('TpybP'===_0x5bb0c8(0x193)?_0x11f264[_0x5bb0c8(0x1c0)]=_0x3ea8ce[_0x5bb0c8(0x18f)](_0x1df376[_0x403567]):(_0x4dc292[_0x5bb0c8(0x190)]=_0x4dc292[_0x5bb0c8(0x190)]||0x0,_0x4dc292[_0x5bb0c8(0x190)]++));}else{if(!this[_0x5bb0c8(0xc3)]())return;const _0x384042=_0x53df1a[_0x5bb0c8(0x37c)][_0x5bb0c8(0x158)];if(!_0x384042)return;_0x384042[_0x5bb0c8(0x1b2)]();}}const _0x58d05c=0x0,_0x5817e3=new Sprite_OTB_TurnOrder_Battler(_0x3f4a0c,_0x58d05c,_0x19cdc8);this[_0x5bb0c8(0x249)]['addChild'](_0x5817e3),_0x19cdc8[_0x5bb0c8(0x17b)](_0x5817e3),_0x5817e3[_0x5bb0c8(0x15d)](0xff),_0x5817e3[_0x5bb0c8(0x1e6)]=0x258,_0x5817e3['x']=this['_subjectX'],this[_0x5bb0c8(0x2fc)]();},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x380)]=function(_0x39106a,_0x19cee8){const _0x2ec6c7=_0x591529,_0x288100=this[_0x2ec6c7(0x1dc)];if(!_0x288100)return;let _0x508a72=0x0;for(let _0x26cf84=0x0;_0x26cf84<_0x19cee8;_0x26cf84++){if('CRXZO'!==_0x2ec6c7(0x207))_0x1a3468[_0x2ec6c7(0x246)](),_0x224eb6[_0x2ec6c7(0x12b)]['Scene_Battle_commandGuard']['call'](this);else{const _0x93befc=_0x288100[_0x26cf84];if(!_0x93befc)continue;if(_0x93befc[_0x2ec6c7(0xe7)]()!==_0x39106a)continue;_0x508a72=_0x93befc[_0x2ec6c7(0x190)]+0x1;}}for(let _0x4ce9d4=_0x19cee8;_0x4ce9d4<_0x288100[_0x2ec6c7(0x2f7)];_0x4ce9d4++){const _0x3cb8ca=_0x288100[_0x4ce9d4];if(!_0x3cb8ca)continue;if(_0x3cb8ca[_0x2ec6c7(0xe7)]()!==_0x39106a)continue;_0x3cb8ca['_instance']=_0x3cb8ca['_instance']||0x0,_0x3cb8ca[_0x2ec6c7(0x190)]++;}const _0x448aa2=new Sprite_OTB_TurnOrder_Battler(_0x39106a,_0x508a72,_0x288100);this[_0x2ec6c7(0x249)][_0x2ec6c7(0x2bb)](_0x448aa2),_0x288100[_0x2ec6c7(0xd0)](_0x19cee8,0x0,_0x448aa2),_0x448aa2['startFade'](0xff),_0x448aa2['_positionDuration']=0x258,_0x448aa2['x']=this[_0x2ec6c7(0x265)],this['requestUpdateTurnOrders']();},Window_OTB_TurnOrder['prototype']['resumeTurnOrderSprites']=function(){const _0x4223cf=_0x591529;this[_0x4223cf(0x28d)](BattleManager[_0x4223cf(0x259)],!![]),this[_0x4223cf(0x28d)](BattleManager[_0x4223cf(0x229)],!![]),this[_0x4223cf(0x1de)](BattleManager[_0x4223cf(0x1c7)],!![]),this[_0x4223cf(0x13c)]();},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x102)]=function(_0x26d79e){const _0x4409c5=_0x591529;this[_0x4409c5(0x29d)](),_0x26d79e&&_0x26d79e[_0x4409c5(0x2ac)]()!==null&&this[_0x4409c5(0x197)](_0x26d79e);},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x29d)]=function(){const _0x19d5f4=_0x591529;for(const _0x52cef9 of this[_0x19d5f4(0x17e)][_0x19d5f4(0x16e)]){if(!_0x52cef9)continue;this[_0x19d5f4(0x124)](_0x52cef9);}},Window_OTB_TurnOrder[_0x591529(0x217)][_0x591529(0x197)]=function(_0x4b75a4){const _0x25dbca=_0x591529,_0x5eedff=_0x4b75a4[_0x25dbca(0x2af)](),_0x2b4315=_0x4b75a4['otbCalcUserCurrentOrderChange'](),_0x359629=_0x4b75a4[_0x25dbca(0x271)]();_0x2b4315!==0x0&&this[_0x25dbca(0x215)](_0x5eedff,![],_0x2b4315);_0x359629!==0x0&&this[_0x25dbca(0x215)](_0x5eedff,!![],_0x359629);if(!_0x4b75a4[_0x25dbca(0x291)]())return;const _0x1b1ee7=SceneManager[_0x25dbca(0x37c)][_0x25dbca(0x27c)],_0x268a63=SceneManager['_scene'][_0x25dbca(0x214)];let _0x1e7395=null;if(_0x1b1ee7&&_0x1b1ee7['active'])_0x1e7395=_0x1b1ee7[_0x25dbca(0x12e)](_0x1b1ee7[_0x25dbca(0x1bf)]());else _0x268a63&&_0x268a63[_0x25dbca(0x2f4)]&&(_0x1e7395=_0x268a63[_0x25dbca(0x1fe)]());if(!_0x1e7395)return;const _0x2aa841=_0x4b75a4['otbCalcTargetCurrentOrderChange'](_0x1e7395),_0x20a44b=_0x4b75a4['otbCalcTargetNextOrderChange'](_0x1e7395);_0x2aa841!==0x0&&this['createOrderPreviewSprite'](_0x1e7395,![],_0x2aa841),_0x20a44b!==0x0&&(_0x25dbca(0x108)!==_0x25dbca(0x1f8)?this[_0x25dbca(0x215)](_0x1e7395,!![],_0x20a44b):this[_0x25dbca(0x215)](_0x3acde1,![],_0x174c39));},Window_OTB_TurnOrder['prototype'][_0x591529(0x215)]=function(_0x5b28aa,_0x8032e2,_0x3153ff){const _0x137874=_0x591529;if(!_0x5b28aa)return;if(_0x3153ff===0x0)return;const _0x24f9e4=_0x8032e2?BattleManager[_0x137874(0x229)]:BattleManager[_0x137874(0x259)],_0x510043=VisuMZ['BattleSystemOTB']['GetAllIndicies'](_0x5b28aa,_0x24f9e4),_0x106bbd=_0x8032e2?this['_nextTurn']:this[_0x137874(0x1dc)],_0x147cac=_0x8032e2?this[_0x137874(0x20b)]:this[_0x137874(0x1db)];if(_0x510043[_0x137874(0x2f7)]<=0x0)return;for(let _0x5b61e7=0x0;_0x5b61e7<_0x510043['length'];_0x5b61e7++){const _0x3a9f6d=new Sprite_OTB_TurnOrder_Preview(_0x5b28aa,_0x5b61e7,_0x106bbd,_0x3153ff);this[_0x137874(0x17e)]['addChild'](_0x3a9f6d),_0x147cac[_0x137874(0x236)](_0x3a9f6d),_0x3a9f6d[_0x137874(0x173)](),_0x3a9f6d[_0x137874(0x15d)](0xff);}};