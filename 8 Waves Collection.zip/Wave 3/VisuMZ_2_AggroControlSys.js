//=============================================================================
// VisuStella MZ - Aggro Control System
// VisuMZ_2_AggroControlSystem.js
//=============================================================================

var Imported = Imported || {};
Imported.VisuMZ_2_AggroControlSystem = true;

var VisuMZ = VisuMZ || {};
VisuMZ.AggroControlSystem = VisuMZ.AggroControlSystem || {};
VisuMZ.AggroControlSystem.version = 1.10;

//=============================================================================
 /*:
 * @target MZ
 * @plugindesc [RPG Maker MZ] [Tier 2] [Version 1.10] [AggroControlSystem]
 * @author VisuStella
 * @url http://www.yanfly.moe/wiki/Aggro_Control_System_VisuStella_MZ
 * @orderAfter VisuMZ_1_BattleCore
 *
 * @help
 * ============================================================================
 * Introduction
 * ============================================================================
 *
 * A common mechanic found in many RPG's nowadays is the ability to steer the
 * way enemies target party members. This can be in the form of provocations, 
 * taunts, and aggro.
 *
 * Provocations come in the form of states, where when a unit applies a provoke
 * state on a target, the target must attack the provoker when using single
 * target skills. This plugin provides support for multiple provocations and
 * such provocations will be given focus based on the state's priority value.
 *
 * Taunts are a third way to steer an opponent to focus on a party member. The
 * taunt effects can be split up into global, physical, magical, or certain hit
 * only taunts and these can be applied to almost any trait object.
 *
 * Aggro is a numeric value that determines the likelihood and/or priority
 * level of how often a target party member is to be attacked by an enemy unit.
 * The higher the aggro value, the more likely the chances of being targeted.
 * A option can be turned on (or through notetags) to set enemies to always
 * target the party member with the highest aggro.
 *
 * Features include all (but not limited to) the following:
 * 
 * * Three different ways to influencing which targets enemies should attack:
 *   Provoke, taunt, and aggro.
 * * Provoke and taunt effects work both ways for actors and enemies.
 * * Aggro effects accumulate through battle and can be manipulated through
 *   notetag values, Plugin Commands, and/or Plugin Parameters.
 * * Provoked battlers can have provoke lines displayed to indicate which
 *   unit has provoked them.
 * * Taunting units can have animations played on them repeatedly to quickly
 *   relay information to the player about their taunt properties.
 * * Gauges that can be displayed over the heads of actor sprites to display
 *   how much aggro that actor holds in comparison to the other actors.
 *
 * ============================================================================
 * Requirements
 * ============================================================================
 *
 * This plugin is made for RPG Maker MZ. This will not work in other iterations
 * of RPG Maker.
 *
 * ------ Tier 2 ------
 *
 * This plugin is a Tier 2 plugin. Place it under other plugins of lower tier
 * value on your Plugin Manager list (ie: 0, 1, 2, 3, 4, 5). This is to ensure
 * that your plugins will have the best compatibility with the rest of the
 * VisuStella MZ library.
 *
 * ============================================================================
 * Extra Features
 * ============================================================================
 *
 * There are some extra features found if other VisuStella MZ plugins are found
 * present in the Plugin Manager list.
 *
 * ---
 *
 * VisuMZ_0_CoreEngine
 * VisuMZ_1_BattleCore
 *
 * - Provoke Priority Lines and Taunt animations become available if these
 *   plugins are installed.
 *
 * ---
 *
 * ============================================================================
 * How Aggro, Provoke, and Taunts Work
 * ============================================================================
 *
 * This section will explain how aggro, provoke, and taunts work.
 *
 * ---
 *
 * Provoke
 *
 * - Provocations come in the form of states, where when a unit applies a
 * provoke state on a target, the target must attack the provoker when using
 * single target skills. This plugin provides support for multiple provocations
 * and such provocations will be given focus based on the state's database
 * priority value.
 *
 * - The provoke will last only as long as the duration of the state itself. If
 * the state's duration is refreshed by reapplying the Provoke state, then the
 * provoker of that state will then switch over to the one applying the newly
 * added state.
 *
 * - When an actor selects a target for an action and the actor is provoked by
 * an enemy on the other team, the player's choice selection becomes limited to
 * only the provoker.
 *
 * - Provoke can be bypassed through the <Bypass Provoke> notetag.
 *
 * ---
 *
 * Taunts
 *
 * - Taunts are a third way to steer an opponent to focus on a party member.
 * The taunt effects can be split up into global, physical, magical, or certain
 * hit only taunts and these can be applied to almost any trait object.
 *
 * - When an actor selects a target and the enemy team has a taunting unit,
 * the player's choice selection becomes limited to only the targets with the
 * associated taunt type.
 *
 * - Taunts can be bypassed through the <Bypass Taunt> notetag.
 *
 * ---
 *
 * Aggro
 *
 * - Aggro is a numeric value that determines the likelihood and/or priority
 * level of how often a target party member is to be attacked by an enemy unit.
 * The higher the aggro value, the more likely the chances of being targeted.
 * A option can be turned on (or through notetags) to set enemies to always
 * target the party member with the highest aggro.
 *
 * - Skills and items can raise its user's aggro value through notetags and/or
 * how much damage they've dealt or healed. Skills and items can also change a
 * target's aggro value through notetags, too.
 *
 * - Through the Plugin Parameters, you can set Aggro to automatically raised
 * based on how much damage or healing dealt by a user.
 *
 * - Some enemies can be bypass forced aggro target through the <Bypass Aggro>
 * notetag while other enemies can be forced to target the highest aggro target
 * through the <Target Highest Aggro> notetag;
 *
 * ---
 *
 * Priorities
 *
 * - Priority will be given in the order of provokes, taunts, and then aggro.
 * This means if an enemy is provoked, the opposing side has a taunt, and there
 * is a member with high aggro, then the enemy will always attack the provoker
 * first before targeting a taunting unit before targeting the unit with high
 * aggro values.
 *
 * ---
 *
 * ============================================================================
 * Notetags
 * ============================================================================
 *
 * The following are notetags that have been added through this plugin. These
 * notetags will not work with your game if this plugin is OFF or not present.
 *
 * === Provoke-Related Notetags ===
 *
 * The following notetags enable you to utilize the Provoke effects added by
 * this plugin. Provoked targets can only attack the provoking unit for single
 * target actions.
 *
 * ---
 *
 * <Provoke>
 *
 * - Used for: State Notetags
 * - Causes the state affected unit to be able to only attack the caster of the
 *   provoke state for single target actions.
 * - If multiple provoke states are applied, then the provoker is the one who
 *   applied the highest priority provoke state.
 *
 * ---
 *
 * <Bypass Provoke>
 *
 * - Used for: Actor, Class, Weapon, Armor, Enemy, State Notetags
 * - Makes the affected unit to ignore any and all provoke effects applied by
 *   any provoke states, allowing them to target foes as if they are unaffected
 *   by provoke states altogether.
 *
 * ---
 * 
 * <Bypass Provoke>
 * - Used for: Skill and Item Notetags
 * - Makes the action bypass provoke effects applied by any provoke states,
 *   allowing this action to target foes as if the user is unaffected by any
 *   provoke effects altogether.
 * 
 * ---
 * 
 * <Provoke Height Origin: x%>
 * 
 * - Used for: Actor, Enemy Notetags
 * - Sets the provoke height origin point to x% of the sprite's height.
 * - This is the landing point for the provoke trails.
 * - Replace 'x' with a number presenting what rate of the sprite's height to
 *   set as the provoke height origin point.
 * 
 * ---
 *
 * === Taunt-Related Notetags ===
 *
 * ---
 *
 * <Taunt>
 * <All Taunt>
 *
 * - Used for: Actor, Class, Weapon, Armor, Enemy, State Notetags
 * - Causes the taunting unit to become the target of the opposing team's
 *   single target actions for physical, magical, and certain hit actions.
 * - If multiple taunters exist, then the opposing team can select between any
 *   of the taunters for targets.
 *
 * ---
 *
 * <Physical Taunt>
 * <Magical Taunt>
 * <Certain Taunt>
 *
 * - Used for: Actor, Class, Weapon, Armor, Enemy, State Notetags
 * - Causes the taunting unit to become the target of the opposing team's
 *   single target actions for physical, magical, and certain hit actions
 *   respectively.
 * - Add/remove any combination of the above to cause the affected unit to
 *   become the target of those types of actions.
 * - If multiple taunters exist, then the opposing team can select between any
 *   of the taunters for targets.
 *
 * ---
 *
 * <Bypass Taunt>
 *
 * - Used for: Actor, Class, Weapon, Armor, Enemy, State Notetags
 * - The affected unit will ignore any and all taunt effects created by the
 *   opposing team, allowing them to use single target actions as if no
 *   taunters exist on the opposing team.
 *
 * ---
 * 
 * <Bypass Taunt>
 * - Used for: Skill and Item Notetags
 * - Makes the action bypass taunt effects created by the opposing team,
 *   allowing the user to use single target actions as if no taunters exist on
 *   the opposing team.
 * 
 * ---
 *
 * === Aggro-Related Notetags ===
 *
 * ---
 *
 * <User Aggro: +x>
 * <User Aggro: -x>
 *
 * - Used for: Skill, Item
 * - Upon using this action, raise the user's battle aggro value by 'x'.
 * - Replace 'x' with the amount of battle aggro to increase/decrease by.
 * - This effect will only apply once per usage regardless of the number of
 *   successful hits landed by the action.
 *
 * ---
 *
 * <Target Aggro: +x>
 * <Target Aggro: -x>
 *
 * - Used for: Skill, Item
 * - Upon using this action, raise the target's battle aggro value by 'x'.
 * - Replace 'x' with the amount of battle aggro to increase/decrease by.
 * - This effect will apply multiple times based on the number of successful
 *   hits landed by the action.
 *
 * ---
 *
 * <Aggro: +x>
 * <Aggro: -x>
 *
 * - Used for: Actor, Class, Weapon, Armor, Enemy, State Notetags
 * - Causes the affected unit to passively have increased/decreased aggro
 *   values independent of the amount of aggro it earns in battle.
 * - Replace 'x' with the amount of aggro this object increases/decreases by.
 *
 * ---
 *
 * <Aggro Multiplier: x%>
 *
 * - Used for: Actor, Class, Weapon, Armor, Enemy, State Notetags
 * - Causes the affected unit to increase the amount of perceived aggro it has
 *   by the aggro multiplier.
 * - Replace 'x' with a number representing the percentage to increase/decrease
 *   the perceived aggro by.
 * - If multiple of these traits exist across different trait objects, the
 *   effects are increased multiplicatively.
 *
 * ---
 *
 * <Bypass Highest Aggro>
 *
 * - Used for: Actor, Class, Skill, Item, Weapon, Armor, Enemy, State Notetags
 * - If used on skills or items, the action will decide targets by aggro weight
 *   instead of always picking the highest aggro unit(s).
 * - If used on trait objects, the affected unit will decide targets by aggro
 *   weight instead of always picking the highest aggro unit(s).
 * - This is used for enemy A.I. or Actor auto battle A.I.
 *
 * ---
 * 
 * <Bypass Highest Aggro>
 * - Used for: Skill and Item Notetags
 * - Makes the action bypass highest aggro effects and instead focuses on
 *   targets by aggro weight instead.
 * - This is used for enemy A.I. or Actor auto battle A.I.
 * 
 * ---
 *
 * <Target Highest Aggro>
 *
 * - Used for: Actor, Class, Skill, Item, Weapon, Armor, Enemy, State Notetags
 * - If used on skills or items, the action will always decide its targets by
 *   the highest aggro value.
 * - If used on trait objects, the affected unit will always decide on targets
 *   by the highest aggro value.
 * - If the <Bypass Highest Aggro> notetag exists, this effect is ignored.
 * - This is used for enemy A.I. or Actor auto battle A.I.
 *
 * ---
 *
 * === JavaScript Notetags: Aggro-Related ===
 *
 * ---
 *
 * <JS User Aggro>
 *  code
 *  code
 *  value = code
 * </JS User Aggro>
 *
 * - Used for: Skill, Item
 * - Replace 'code' with JavaScript code to determine the final 'value' to
 *   change the user's battle aggro to upon using this skill.
 * - The 'user' variable represents the one using the skill/item.
 * - The 'target' variable represents the one receiving the skill/item hit.
 * - This effect will only apply once per usage regardless of the number of
 *   successful hits landed by the action.
 *
 * ---
 *
 * <JS Target Aggro>
 *  code
 *  code
 *  value = code
 * </JS Target Aggro>
 *
 * - Used for: Skill, Item
 * - Replace 'code' with JavaScript code to determine the final 'value' to
 *   change target's battle aggro to upon using this skill.
 * - The 'user' variable represents the one using the skill/item.
 * - The 'target' variable represents the one receiving the skill/item hit.
 * - This effect will apply multiple times based on the number of successful
 *   hits landed by the action.
 *
 * ---
 *
 * ============================================================================
 * Plugin Commands
 * ============================================================================
 *
 * The following are Plugin Commands that come with this plugin. They can be
 * accessed through the Plugin Command event command.
 *
 * ---
 * 
 * === Actor Plugin Commands ===
 * 
 * ---
 *
 * Actor: Change Aggro
 * - Changes target actor's aggro value.
 *
 *   Actor ID:
 *   - Select which Actor ID to affect.
 *
 *   Change Aggro By:
 *   - Change aggro by this amount.
 *   - Use negative numbers to reduce aggro.
 *
 * ---
 *
 * Actor: Set Aggro
 * - Set target actor's aggro value.
 *
 *   Actor ID:
 *   - Select which Actor ID to affect.
 *
 *   Set Aggro To:
 *   - Sets target's aggro to this amount.
 *   - Aggro must be at least a value of 1.
 *
 * ---
 * 
 * === Enemy Plugin Commands ===
 * 
 * ---
 *
 * Enemy: Change Aggro
 * - Changes target enemy's aggro value.
 *
 *   Enemy Index:
 *   - Select which Enemy Index to affect.
 *
 *   Change Aggro By:
 *   - Change aggro by this amount.
 *   - Use negative numbers to reduce aggro.
 *
 * ---
 *
 * Enemy: Set Aggro
 * - Set target enemy's aggro value.
 *
 *   Enemy Index:
 *   - Select which Enemy Index to affect.
 *
 *   Set Aggro To:
 *   - Sets target's aggro to this amount.
 *   - Aggro must be at least a value of 1.
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Provoke Settings
 * ============================================================================
 *
 * The Provoke Settings Plugin Parameters adjust the visual aspects related to
 * the provoke effect. These settings will require VisuMZ_1_BattleCore to be
 * installed in order for them to work due to dependencies. 
 *
 * ---
 *
 * VisuMZ_1_BattleCore
 * 
 *   Show Priority Lines?:
 *   - Show priority target lines for this plugin?
 *   - Requires VisuMZ_1_BattleCore.
 *
 * ---
 *
 * Line Settings
 * 
 *   Arc Height:
 *   - How tall should the line arc in pixels?
 * 
 *   Blend Mode:
 *   - The blend mode used for the sprite.
 * 
 *   Height Origin:
 *   - The rate from the battler's sprite base to determine where the line
 *     starts from.
 * 
 *   Line Color:
 *   - Use #rrggbb for custom colors or regular numbers for text colors from
 *     the Window Skin.
 * 
 *   Opacity:
 *   - The highest possible opacity for active provoke lines.
 * 
 *   Opacity Speed:
 *   - The speed at which opacity fluctuates for the line sprite.
 * 
 *   Parts:
 *   - The number of joint parts to split up the sprite as.
 * 
 *   Parts Size:
 *   - The number in pixels for the diameter of each part.
 *
 * ---
 * 
 * Options
 * 
 *   Add Provoke Option?
 *   - Add the 'Show Provoke Origin' option to the Options menu?
 * 
 *   Adjust Window Height
 *   - Automatically adjust the options window height?
 * 
 *   Option Name
 *   - Command name of the option.
 * 
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Taunt Settings
 * ============================================================================
 *
 * Battlers with specific taunt types can have animations playing on them over
 * and over to relay information to the player. These settings require you to
 * have both VisuMZ_0_CoreEngine and VisuMZ_1_BattleCore installed in your
 * project's plugin list in order to use.
 *
 * ---
 *
 * VisuMZ_0_CoreEngine & VisuMZ_1_BattleCore
 * 
 *   Show Animations?:
 *   - Show animations for each of the taunt effects?
 *   - Requires VisuMZ_0_CoreEngine and VisuMZ_1_BattleCore.
 *
 * ---
 *
 * Animation ID's
 * 
 *   Physical Taunt:
 *   - The animation ID used for physical taunts.
 *   - Use 0 or 'None' to bypass this type.
 * 
 *   Magical Taunt:
 *   - The animation ID used for magical taunts.
 *   - Use 0 or 'None' to bypass this type.
 * 
 *   Certain Hit Taunt:
 *   - The animation ID used for certain hit taunts.
 *   - Use 0 or 'None' to bypass this type.
 *
 * ---
 *
 * Animation Settings
 * 
 *   Cycle Time:
 *   - The amount of frames to wait before each animation cycle.
 *   - WARNING: Lower numbers can jeopardize game performance.
 * 
 *   Mirror Actor Ani?:
 *   - Mirror animations played on actors?
 * 
 *   Mute Animation SFX?:
 *   - Mute sounds played by animations?
 *
 * ---
 *
 * ============================================================================
 * Plugin Parameters: Aggro Settings
 * ============================================================================
 *
 * This lets you adjust the settings for this plugin's Aggro mechanics. Most of
 * these settings focus on the visual gauge display of the Aggro gauge, but you
 * can also change up the settings for how aggro is utilized.
 *
 * ---
 *
 * General
 * 
 *   Priority: Highest TGR:
 *   - When enemies target actors for an single target attack, always target
 *     the highest members or make it weighted?
 *
 *   Aggro Per Damage:
 *   - The amount of aggro generated per point of HP damage dealt to an enemy.
 *
 *   Aggro Per Heal:
 *   - The amount of aggro generated per point of HP recovered to an ally.
 *
 * ---
 *
 * Gauge
 * 
 *   Visible Battler Gauge:
 *   - Display an aggro gauge over an SV actor's head to show current aggro
 *     level compared to other party members.
 * 
 *   Visible Status Gauge:
 *   - Display an aggro gauge in the Battle Status Window to show the current
 *     aggro level compared to others.
 * 
 *   Gauge Color 1:
 *   - Use #rrggbb for custom colors or regular numbers for text colors from
 *     the Window Skin.
 * 
 *   Gauge Color 2:
 *   - Use #rrggbb for custom colors or regular numbers for text colors from
 *     the Window Skin.
 * 
 *   Gauge Width:
 *   - Width in pixels you want the gauge to be.
 * 
 *   Anchor X:
 *   Anchor Y:
 *   - Where do you want the Aggro Gauge sprite's anchor X/Y to be?
 *   - Use values between 0 and 1 to be safe.
 * 
 *   Scale:
 *   - How large/small do you want the Aggro Gauge to be scaled?
 * 
 *   Battler Gauge
 * 
 *     Offset X:
 *     Offset Y:
 *     - How many pixels to offset the Aggro Gauge's X/Y by?
 * 
 *   Battle Status Gauge
 * 
 *     Offset X:
 *     Offset Y:
 *     - How many pixels to offset the Aggro Gauge's X/Y by?
 *
 * ---
 * 
 * Options
 * 
 *   Add Provoke Option?
 *   - Add the 'Show Aggro Gauge' option to the Options menu?
 * 
 *   Adjust Window Height
 *   - Automatically adjust the options window height?
 * 
 *   Option Name
 *   - Command name of the option.
 * 
 * ---
 *
 * ============================================================================
 * Terms of Use
 * ============================================================================
 *
 * 1. These plugins may be used in free or commercial games provided that they
 * have been acquired through legitimate means at VisuStella.com and/or any
 * other official approved VisuStella sources. Exceptions and special
 * circumstances that may prohibit usage will be listed on VisuStella.com.
 * 
 * 2. All of the listed coders found in the Credits section of this plugin must
 * be given credit in your games or credited as a collective under the name:
 * "VisuStella".
 * 
 * 3. You may edit the source code to suit your needs, so long as you do not
 * claim the source code belongs to you. VisuStella also does not take
 * responsibility for the plugin if any changes have been made to the plugin's
 * code, nor does VisuStella take responsibility for user-provided custom code
 * used for custom control effects including advanced JavaScript notetags
 * and/or plugin parameters that allow custom JavaScript code.
 * 
 * 4. You may NOT redistribute these plugins nor take code from this plugin to
 * use as your own. These plugins and their code are only to be downloaded from
 * VisuStella.com and other official/approved VisuStella sources. A list of
 * official/approved sources can also be found on VisuStella.com.
 *
 * 5. VisuStella is not responsible for problems found in your game due to
 * unintended usage, incompatibility problems with plugins outside of the
 * VisuStella MZ library, plugin versions that aren't up to date, nor
 * responsible for the proper working of compatibility patches made by any
 * third parties. VisuStella is not responsible for errors caused by any
 * user-provided custom code used for custom control effects including advanced
 * JavaScript notetags and/or plugin parameters that allow JavaScript code.
 *
 * 6. If a compatibility patch needs to be made through a third party that is
 * unaffiliated with VisuStella that involves using code from the VisuStella MZ
 * library, contact must be made with a member from VisuStella and have it
 * approved. The patch would be placed on VisuStella.com as a free download
 * to the public. Such patches cannot be sold for monetary gain, including
 * commissions, crowdfunding, and/or donations.
 * 
 * 7. If this VisuStella MZ plugin is a paid product, all project team members
 * must purchase their own individual copies of the paid product if they are to
 * use it. Usage includes working on related game mechanics, managing related
 * code, and/or using related Plugin Commands and features. Redistribution of
 * the plugin and/or its code to other members of the team is NOT allowed
 * unless they own the plugin itself as that conflicts with Article 4.
 * 
 * 8. Any extensions and/or addendums made to this plugin's Terms of Use can be
 * found on VisuStella.com and must be followed.
 *
 * ============================================================================
 * Credits
 * ============================================================================
 * 
 * If you are using this plugin, credit the following people in your game:
 * 
 * Team VisuStella
 * * Yanfly
 * * Arisu
 * * Olivia
 * * Irina
 *
 * ============================================================================
 * Changelog
 * ============================================================================
 * 
 * Version 1.10: August 25, 2022
 * * Documentation Update!
 * ** Added note to the <Provoke> notetag:
 * *** States with <Provoke> on them will automatically remove themselves if
 *     the provoker dies. Update made by Arisu.
 * * Feature Update!
 * ** States with <Provoke> on them will automatically remove themselves if the
 *    provoker dies. Update made by Arisu.
 * 
 * Version 1.09: June 2, 2022
 * * Bug Fixes!
 * ** Filename has been shortened from VisuMZ_2_AggroControlSystem.js to
 *    VisuMZ_2_AggroControlSys.js due to deployment reasons. For some mobile
 *    devices, keeping the name as long as VisuMZ_2_AggroControlSystem.js
 *    causes problems, but VisuMZ_2_AggroControlSys.js is fine. Take note of
 *    this while you are updating.
 * ** 'user' and 'target' now works properly with the JS notetags.
 *    Fix made by Irina.
 * 
 * Version 1.08: April 16, 2021
 * * Feature Update!
 * ** Highest and lowest TGR members are now cached on an action by action
 *    basis for reduce needed computations. Update made by Irina.
 * 
 * Version 1.07: April 9, 2021
 * * Bug Fixes!
 * ** Provoke effect now takes into consideration when Provoke is applied by
 *    a weapon effect that comes off a counter attack from an actor. Fix made
 *    by Olivia.
 * 
 * Version 1.06: March 12, 2021
 * * Bug Fixes!
 * ** Subsequent battles or changing scenes should no longer clear the custom
 *    rendered bitmap used for the provoke trail. Fix made by Irina.
 * * Documentation Update!
 * ** Added documentation for the Skill and Item versions of the following
 *    notetags into the help file and wiki:
 * *** <Bypass Provoke>
 * *** <Bypass Taunt>
 * *** <Bypass Highest Aggro>
 * 
 * Version 1.05: March 5, 2021
 * * Documentation Update!
 * ** Help file updated for new features.
 * * New Features!
 * ** New Plugin Parameters added by Irina:
 * *** Plugin Parameters > Aggro Settings > Battle Status Gauge
 * **** These settings allow you to offset the Aggro Gauge in the Battle Status
 *      Window from its original position.
 * 
 * Version 1.04: February 26, 2021
 * * Bug Fixes!
 * ** Fixed positioning of gauge for List Style battle layouts without faces.
 *    Fix made by Olivia.
 * 
 * Version 1.03: February 5, 2021
 * * Feature Update!
 * ** Aggro is now cleared at the end of each battle in addition to the start
 *    of each battle. Update made by Olivia.
 *
 * Version 1.02: November 1, 2020
 * * Compatibility Update!
 * ** Plugin is made more compatible with other plugins.
 * 
 * Version 1.01: October 4, 2020
 * * Bug Fixes!
 * ** Provoke lines should now be placed correctly if the UI area is smaller
 *    than the resolution area.
 * ** The Plugin Commands should no longer cause crashes. Fix made by Irina.
 *
 * Version 1.00: September 28, 2020
 * * Finished Plugin!
 *
 * ============================================================================
 * End of Helpfile
 * ============================================================================
 *
 * @ --------------------------------------------------------------------------
 *
 * @command ActorChangeAggro
 * @text Actor: Change Aggro
 * @desc Changes target actor's aggro value.
 *
 * @arg ActorID:num
 * @text Actor ID
 * @type actor
 * @desc Select which Actor ID to affect.
 * @default 1
 *
 * @arg Aggro:num
 * @text Change Aggro By
 * @desc Change aggro by this amount.
 * Use negative numbers to reduce aggro.
 * @default +1
 *
 * @ --------------------------------------------------------------------------
 *
 * @command ActorSetAggro
 * @text Actor: Set Aggro
 * @desc Set target actor's aggro value.
 *
 * @arg ActorID:num
 * @text Actor ID
 * @type actor
 * @desc Select which Actor ID to affect.
 * @default 1
 *
 * @arg Aggro:num
 * @text Set Aggro To
 * @desc Sets target's aggro to this amount.
 * Aggro must be at least a value of 1.
 * @default 1
 *
 * @ --------------------------------------------------------------------------
 *
 * @command EnemyChangeAggro
 * @text Enemy: Change Aggro
 * @desc Changes target enemy's aggro value.
 *
 * @arg EnemyIndex:num
 * @text Enemy Index
 * @type actor
 * @desc Select which Enemy Index to affect.
 * @default 0
 *
 * @arg Aggro:num
 * @text Change Aggro By
 * @desc Change aggro by this amount.
 * Use negative numbers to reduce aggro.
 * @default +1
 *
 * @ --------------------------------------------------------------------------
 *
 * @command EnemySetAggro
 * @text Enemy: Set Aggro
 * @desc Set target enemy's aggro value.
 *
 * @arg EnemyIndex:num
 * @text Enemy Index
 * @type actor
 * @desc Select which Enemy Index to affect.
 * @default 0
 *
 * @arg Aggro:num
 * @text Set Aggro To
 * @desc Sets target's aggro to this amount.
 * Aggro must be at least a value of 1.
 * @default 1
 *
 * @ --------------------------------------------------------------------------
 *
 * @ ==========================================================================
 * @ Plugin Parameters
 * @ ==========================================================================
 *
 * @param BreakHead
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param AggroControl
 * @default Plugin Parameters
 *
 * @param ATTENTION
 * @default READ THE HELP FILE
 *
 * @param BreakSettings
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param Provoke:struct
 * @text Provoke Settings
 * @type struct<Provoke>
 * @desc Settings related to the Provoke mechanic.
 * These settings require VisuMZ_1_BattleCore.
 * @default {"VisuMZ_1_BattleCore":"","ShowLines:eval":"true","LineSettings":"","ArcHeight:num":"125","BlendMode:num":"1","HeightOrigin:num":"0.8","LineColor:str":"#ff0000","Opacity:num":"255","OpacitySpeed:num":"4","Parts:num":"256","PartsSize:num":"5","Options":"","AddOption:eval":"true","AdjustOptionsRect:eval":"true","OptionName:str":"Show Provoke Origin"}
 *
 * @param Taunt:struct
 * @text Taunt Settings
 * @type struct<Taunt>
 * @desc Settings related to the Taunt mechanic.
 * @default {"Dependency":"VisuMZ_1_BattleCore","ShowAnimation:eval":"true","AnimationID":"","AniPhysical:num":"1","AniMagical:num":"2","AniCertain:num":"3","AnimationSettings":"","CycleTime:num":"60","MirrorActorAni:eval":"true","MuteAnimations:eval":"true"}
 *
 * @param Aggro:struct
 * @text Aggro Settings
 * @type struct<Aggro>
 * @desc Settings related to the Aggro mechanic.
 * @default {"General":"","PriorityHighest:eval":"true","AggroPerDmg:num":"0.1","AggroPerHeal:num":"0.5","Gauge":"","VisibleGauge:eval":"false","StatusGauge:eval":"true","GaugeColor1:str":"#959595","GaugeColor2:str":"#ffffff","AnchorX:num":"0.5","AnchorY:num":"1.0","Scale:num":"0.5","OffsetX:num":"+0","OffsetY:num":"+2","Options":"","AddOption:eval":"true","AdjustOptionsRect:eval":"true","OptionName:str":"Show Aggro Gauge"}
 *
 * @param BreakEnd1
 * @text --------------------------
 * @default ----------------------------------
 *
 * @param End Of
 * @default Plugin Parameters
 *
 * @param BreakEnd2
 * @text --------------------------
 * @default ----------------------------------
 *
 */
/* ----------------------------------------------------------------------------
 * Provoke Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Provoke:
 *
 * @param VisuMZ_1_BattleCore
 *
 * @param ShowLines:eval
 * @text Show Priority Lines?
 * @parent VisuMZ_1_BattleCore
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show priority target lines for this plugin?
 * Requires VisuMZ_1_BattleCore.
 * @default true
 *
 * @param LineSettings
 * @text Line Settings
 *
 * @param ArcHeight:num
 * @text Arc Height
 * @parent LineSettings
 * @type number
 * @desc How tall should the line arc in pixels?
 * @default 125
 *
 * @param BlendMode:num
 * @text Blend Mode
 * @parent LineSettings
 * @type select
 * @option Normal
 * @value 0
 * @option Additive
 * @value 1
 * @option Multiply
 * @value 2
 * @option Screen
 * @value 3
 * @desc The blend mode used for the sprite.
 * @default 1
 *
 * @param HeightOrigin:num
 * @text Height Origin
 * @parent LineSettings
 * @desc The rate from the battler's sprite base to determine where the line starts from.
 * @default 0.8
 *
 * @param LineColor:str
 * @text Line Color
 * @parent LineSettings
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default #ff0000
 *
 * @param Opacity:num
 * @text Opacity
 * @parent LineSettings
 * @type number
 * @min 1
 * @max 255
 * @desc The highest possible opacity for active provoke lines.
 * @default 255
 *
 * @param OpacitySpeed:num
 * @text Opacity Speed
 * @parent Opacity:num
 * @type number
 * @min 1
 * @desc The speed at which opacity fluctuates for the line sprite.
 * @default 4
 *
 * @param Parts:num
 * @text Parts
 * @parent LineSettings
 * @type number
 * @min 1
 * @desc The number of joint parts to split up the sprite as.
 * @default 256
 *
 * @param PartsSize:num
 * @text Parts Size
 * @parent Parts:num
 * @type number
 * @min 1
 * @desc The number in pixels for the diameter of each part.
 * @default 5
 *
 * @param Options
 * @text Options
 *
 * @param AddOption:eval
 * @text Add Provoke Option?
 * @parent Options
 * @type boolean
 * @on Add
 * @off Don't Add
 * @desc Add the 'Show Provoke Origin' option to the Options menu?
 * @default true
 *
 * @param AdjustOptionsRect:eval
 * @text Adjust Window Height
 * @parent Options
 * @type boolean
 * @on Adjust
 * @off Don't
 * @desc Automatically adjust the options window height?
 * @default true
 *
 * @param OptionName:str
 * @text Option Name
 * @parent Options
 * @desc Command name of the option.
 * @default Show Provoke Origin
 *
 */
/* ----------------------------------------------------------------------------
 * Taunt Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Taunt:
 *
 * @param Dependency
 * @text VisuMZ_0_CoreEngine
 * @default VisuMZ_1_BattleCore
 *
 * @param ShowAnimation:eval
 * @text Show Animations?
 * @parent Dependency
 * @type boolean
 * @on Show
 * @off Hide
 * @desc Show animations for each of the taunt effects?
 * Requires VisuMZ_0_CoreEngine and VisuMZ_1_BattleCore.
 * @default true
 *
 * @param AnimationID
 * @text Animation ID's
 *
 * @param AniPhysical:num
 * @text Physical Taunt
 * @parent AnimationID
 * @type animation
 * @desc The animation ID used for physical taunts.
 * Use 0 or 'None' to bypass this type.
 * @default 13
 *
 * @param AniMagical:num
 * @text Magical Taunt
 * @parent AnimationID
 * @type animation
 * @desc The animation ID used for magical taunts.
 * Use 0 or 'None' to bypass this type.
 * @default 14
 *
 * @param AniCertain:num
 * @text Certain Hit Taunt
 * @parent AnimationID
 * @type animation
 * @desc The animation ID used for certain hit taunts.
 * Use 0 or 'None' to bypass this type.
 * @default 15
 *
 * @param AnimationSettings
 * @text Animation Settings
 *
 * @param CycleTime:num
 * @text Cycle Time
 * @parent AnimationSettings
 * @type number
 * @min 1
 * @desc The amount of frames to wait before each animation cycle.
 * WARNING: Lower numbers can jeopardize game performance.
 * @default 60
 *
 * @param MirrorActorAni:eval
 * @text Mirror Actor Ani?
 * @parent AnimationSettings
 * @type boolean
 * @on Mirror
 * @off Don't
 * @desc Mirror animations played on actors?
 * @default true
 *
 * @param MuteAnimations:eval
 * @text Mute Animation SFX?
 * @parent AnimationSettings
 * @type boolean
 * @on Mute
 * @off Don't
 * @desc Mute sounds played by animations?
 * @default true
 *
 */
/* ----------------------------------------------------------------------------
 * Aggro Settings
 * ----------------------------------------------------------------------------
 */
/*~struct~Aggro:
 *
 * @param General
 *
 * @param PriorityHighest:eval
 * @text Priority: Highest TGR
 * @parent General
 * @type boolean
 * @on Always
 * @off Weighted
 * @desc When enemies target actors for an single target attack,
 * always target the highest members or make it weighted?
 * @default true
 *
 * @param AggroPerDmg:num
 * @text Aggro Per Damage
 * @parent General
 * @desc The amount of aggro generated per point of HP damage dealt to an enemy.
 * @default 0.1
 *
 * @param AggroPerHeal:num
 * @text Aggro Per Heal
 * @parent General
 * @desc The amount of aggro generated per point of HP recovered to an ally.
 * @default 0.5
 *
 * @param Gauge
 *
 * @param VisibleGauge:eval
 * @text Visible Battler Gauge
 * @parent Gauge
 * @type boolean
 * @on Visible
 * @off None
 * @desc Display an aggro gauge over an SV actor's head to show
 * current aggro level compared to other party members.
 * @default false
 *
 * @param StatusGauge:eval
 * @text Visible Status Gauge
 * @parent Gauge
 * @type boolean
 * @on Visible
 * @off None
 * @desc Display an aggro gauge in the Battle Status Window
 * to show the current aggro level compared to others.
 * @default true
 *
 * @param GaugeColor1:str
 * @text Gauge Color 1
 * @parent Gauge
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default #959595
 *
 * @param GaugeColor2:str
 * @text Gauge Color 2
 * @parent Gauge
 * @desc Use #rrggbb for custom colors or regular numbers
 * for text colors from the Window Skin.
 * @default #ffffff
 *
 * @param AnchorX:num
 * @text Anchor X
 * @parent Gauge
 * @desc Where do you want the Aggro Gauge sprite's anchor X to be?
 * Use values between 0 and 1 to be safe.
 * @default 0.5
 *
 * @param AnchorY:num
 * @text Anchor Y
 * @parent Gauge
 * @desc Where do you want the Aggro Gauge sprite's anchor Y to be?
 * Use values between 0 and 1 to be safe.
 * @default 1.0
 *
 * @param Scale:num
 * @text Scale
 * @parent Gauge
 * @desc How large/small do you want the Aggro Gauge to be scaled?
 * @default 0.5
 * 
 * @param BattlerGauge
 * @text Battler Gauge
 * @parent Gauge
 *
 * @param OffsetX:num
 * @text Offset X
 * @parent BattlerGauge
 * @desc How many pixels to offset the Aggro Gauge's X by?
 * Negative goes left. Positive goes right.
 * @default +0
 *
 * @param OffsetY:num
 * @text Offset Y
 * @parent BattlerGauge
 * @desc How many pixels to offset the Aggro Gauge's Y by?
 * Negative goes up. Positive goes down.
 * @default +2
 * 
 * @param BattleStatus
 * @text Battle Status Gauge
 * @parent Gauge
 *
 * @param BattleStatusOffsetX:num
 * @text Offset X
 * @parent BattleStatus
 * @desc How many pixels to offset the Aggro Gauge's X by?
 * Negative goes left. Positive goes right.
 * @default +0
 *
 * @param BattleStatusOffsetY:num
 * @text Offset Y
 * @parent BattleStatus
 * @desc How many pixels to offset the Aggro Gauge's Y by?
 * Negative goes up. Positive goes down.
 * @default +0
 *
 * @param Options
 * @text Options
 *
 * @param AddOption:eval
 * @text Add Option?
 * @parent Options
 * @type boolean
 * @on Add
 * @off Don't Add
 * @desc Add the 'Show Aggro Gauge' option to the Options menu?
 * @default true
 *
 * @param AdjustOptionsRect:eval
 * @text Adjust Window Height
 * @parent Options
 * @type boolean
 * @on Adjust
 * @off Don't
 * @desc Automatically adjust the options window height?
 * @default true
 *
 * @param OptionName:str
 * @text Option Name
 * @parent Options
 * @desc Command name of the option.
 * @default Show Aggro Gauge
 *
 */
//=============================================================================

const _0x20bac4=_0x33c1;(function(_0x5a9a54,_0x35ba35){const _0x15f3d5=_0x33c1,_0x3cbd11=_0x5a9a54();while(!![]){try{const _0x577336=parseInt(_0x15f3d5(0x171))/0x1*(-parseInt(_0x15f3d5(0x19a))/0x2)+parseInt(_0x15f3d5(0x25f))/0x3+-parseInt(_0x15f3d5(0x100))/0x4*(-parseInt(_0x15f3d5(0x253))/0x5)+-parseInt(_0x15f3d5(0x250))/0x6+-parseInt(_0x15f3d5(0xf2))/0x7*(parseInt(_0x15f3d5(0x259))/0x8)+-parseInt(_0x15f3d5(0x21e))/0x9*(-parseInt(_0x15f3d5(0xd8))/0xa)+-parseInt(_0x15f3d5(0x13a))/0xb*(-parseInt(_0x15f3d5(0x158))/0xc);if(_0x577336===_0x35ba35)break;else _0x3cbd11['push'](_0x3cbd11['shift']());}catch(_0x1f8c20){_0x3cbd11['push'](_0x3cbd11['shift']());}}}(_0x548a,0x4049c));var label=_0x20bac4(0x22d),tier=tier||0x0,dependencies=[],pluginData=$plugins['filter'](function(_0x20cee9){const _0x5deedc=_0x20bac4;return _0x20cee9['status']&&_0x20cee9[_0x5deedc(0x207)][_0x5deedc(0x163)]('['+label+']');})[0x0];VisuMZ[label][_0x20bac4(0x1e3)]=VisuMZ[label]['Settings']||{},VisuMZ[_0x20bac4(0x122)]=function(_0x5e4e32,_0x54f4ea){const _0x138179=_0x20bac4;for(const _0x2024c0 in _0x54f4ea){if(_0x2024c0[_0x138179(0x145)](/(.*):(.*)/i)){const _0x4e43fe=String(RegExp['$1']),_0x562189=String(RegExp['$2'])[_0x138179(0x198)]()[_0x138179(0x153)]();let _0x427d2d,_0x1787af,_0x3cd81c;switch(_0x562189){case _0x138179(0xd5):_0x427d2d=_0x54f4ea[_0x2024c0]!==''?Number(_0x54f4ea[_0x2024c0]):0x0;break;case _0x138179(0x1a6):_0x1787af=_0x54f4ea[_0x2024c0]!==''?JSON[_0x138179(0x22c)](_0x54f4ea[_0x2024c0]):[],_0x427d2d=_0x1787af['map'](_0x23b14c=>Number(_0x23b14c));break;case _0x138179(0x182):_0x427d2d=_0x54f4ea[_0x2024c0]!==''?eval(_0x54f4ea[_0x2024c0]):null;break;case _0x138179(0xc5):_0x1787af=_0x54f4ea[_0x2024c0]!==''?JSON['parse'](_0x54f4ea[_0x2024c0]):[],_0x427d2d=_0x1787af[_0x138179(0x1f1)](_0x53fb24=>eval(_0x53fb24));break;case _0x138179(0x11e):_0x427d2d=_0x54f4ea[_0x2024c0]!==''?JSON['parse'](_0x54f4ea[_0x2024c0]):'';break;case _0x138179(0xe5):_0x1787af=_0x54f4ea[_0x2024c0]!==''?JSON[_0x138179(0x22c)](_0x54f4ea[_0x2024c0]):[],_0x427d2d=_0x1787af[_0x138179(0x1f1)](_0x1a3921=>JSON['parse'](_0x1a3921));break;case _0x138179(0xed):_0x427d2d=_0x54f4ea[_0x2024c0]!==''?new Function(JSON['parse'](_0x54f4ea[_0x2024c0])):new Function(_0x138179(0xc6));break;case _0x138179(0xf3):_0x1787af=_0x54f4ea[_0x2024c0]!==''?JSON['parse'](_0x54f4ea[_0x2024c0]):[],_0x427d2d=_0x1787af[_0x138179(0x1f1)](_0x11d04f=>new Function(JSON['parse'](_0x11d04f)));break;case'STR':_0x427d2d=_0x54f4ea[_0x2024c0]!==''?String(_0x54f4ea[_0x2024c0]):'';break;case'ARRAYSTR':_0x1787af=_0x54f4ea[_0x2024c0]!==''?JSON[_0x138179(0x22c)](_0x54f4ea[_0x2024c0]):[],_0x427d2d=_0x1787af[_0x138179(0x1f1)](_0x1b75b7=>String(_0x1b75b7));break;case'STRUCT':_0x3cd81c=_0x54f4ea[_0x2024c0]!==''?JSON[_0x138179(0x22c)](_0x54f4ea[_0x2024c0]):{},_0x427d2d=VisuMZ[_0x138179(0x122)]({},_0x3cd81c);break;case _0x138179(0x104):_0x1787af=_0x54f4ea[_0x2024c0]!==''?JSON[_0x138179(0x22c)](_0x54f4ea[_0x2024c0]):[],_0x427d2d=_0x1787af[_0x138179(0x1f1)](_0x5d8c9c=>VisuMZ[_0x138179(0x122)]({},JSON[_0x138179(0x22c)](_0x5d8c9c)));break;default:continue;}_0x5e4e32[_0x4e43fe]=_0x427d2d;}}return _0x5e4e32;},(_0x2cd3c2=>{const _0x45088e=_0x20bac4,_0x163d20=_0x2cd3c2[_0x45088e(0x190)];for(const _0x42a806 of dependencies){if(!Imported[_0x42a806]){if(_0x45088e(0x15c)===_0x45088e(0x15c)){alert(_0x45088e(0x151)[_0x45088e(0x1ff)](_0x163d20,_0x42a806)),SceneManager[_0x45088e(0x101)]();break;}else this[_0x45088e(0xde)][_0x2f6707]=this[_0x45088e(0x1d2)](_0x1fc83e(_0x86fd89));}}const _0x140adf=_0x2cd3c2[_0x45088e(0x207)];if(_0x140adf[_0x45088e(0x145)](/\[Version[ ](.*?)\]/i)){const _0xdf1cbc=Number(RegExp['$1']);_0xdf1cbc!==VisuMZ[label][_0x45088e(0x26a)]&&(alert(_0x45088e(0x1dd)[_0x45088e(0x1ff)](_0x163d20,_0xdf1cbc)),SceneManager['exit']());}if(_0x140adf[_0x45088e(0x145)](/\[Tier[ ](\d+)\]/i)){const _0x5e7c21=Number(RegExp['$1']);_0x5e7c21<tier?(alert('%1\x20is\x20incorrectly\x20placed\x20on\x20the\x20plugin\x20list.\x0aIt\x20is\x20a\x20Tier\x20%2\x20plugin\x20placed\x20over\x20other\x20Tier\x20%3\x20plugins.\x0aPlease\x20reorder\x20the\x20plugin\x20list\x20from\x20smallest\x20to\x20largest\x20tier\x20numbers.'[_0x45088e(0x1ff)](_0x163d20,_0x5e7c21,tier)),SceneManager['exit']()):tier=Math[_0x45088e(0xe4)](_0x5e7c21,tier);}VisuMZ[_0x45088e(0x122)](VisuMZ[label][_0x45088e(0x1e3)],_0x2cd3c2['parameters']);})(pluginData),PluginManager[_0x20bac4(0x23a)](pluginData[_0x20bac4(0x190)],_0x20bac4(0x1de),_0x442e91=>{const _0x4c3011=_0x20bac4;if(!$gameParty[_0x4c3011(0x130)]())return;VisuMZ['ConvertParams'](_0x442e91,_0x442e91);const _0x22e7fd=$gameActors[_0x4c3011(0x17d)](_0x442e91[_0x4c3011(0x269)]),_0x199f71=_0x442e91['Aggro'];if(_0x22e7fd)_0x22e7fd['gainAggro'](_0x199f71);}),PluginManager[_0x20bac4(0x23a)](pluginData[_0x20bac4(0x190)],_0x20bac4(0x1b1),_0x515279=>{const _0x4c2ffc=_0x20bac4;if(!$gameParty[_0x4c2ffc(0x130)]())return;VisuMZ['ConvertParams'](_0x515279,_0x515279);const _0x4db834=$gameActors[_0x4c2ffc(0x17d)](_0x515279['ActorID']),_0x292c74=_0x515279[_0x4c2ffc(0x230)];if(_0x4db834)_0x4db834['setAggro'](_0x292c74);}),PluginManager['registerCommand'](pluginData[_0x20bac4(0x190)],'EnemyChangeAggro',_0x127b70=>{const _0x5257f8=_0x20bac4;if(!$gameParty[_0x5257f8(0x130)]())return;VisuMZ[_0x5257f8(0x122)](_0x127b70,_0x127b70);const _0x12cbb2=$gameTroop[_0x5257f8(0x23e)]()[_0x127b70[_0x5257f8(0x1cd)]],_0x2d12b2=_0x127b70['Aggro'];if(_0x12cbb2)_0x12cbb2[_0x5257f8(0x103)](_0x2d12b2);}),PluginManager['registerCommand'](pluginData[_0x20bac4(0x190)],_0x20bac4(0x196),_0x5d4d39=>{const _0x3537e9=_0x20bac4;if(!$gameParty[_0x3537e9(0x130)]())return;VisuMZ[_0x3537e9(0x122)](_0x5d4d39,_0x5d4d39);const _0x432517=$gameTroop[_0x3537e9(0x23e)]()[_0x5d4d39[_0x3537e9(0x1cd)]],_0x936a86=_0x5d4d39[_0x3537e9(0x230)];if(_0x432517)_0x432517[_0x3537e9(0x1a1)](_0x936a86);}),DataManager[_0x20bac4(0x21d)]=function(_0x3b1c94){const _0x488a92=_0x20bac4;if(!_0x3b1c94)return![];return _0x3b1c94[_0x488a92(0x232)]['match'](/<PROVOKE>/i);},DataManager['isBypassProvoke']=function(_0x1babe2){const _0xd77aa9=_0x20bac4;if(!_0x1babe2)return![];return _0x1babe2[_0xd77aa9(0x232)][_0xd77aa9(0x145)](/<BYPASS PROVOKE>/i);},DataManager[_0x20bac4(0x19f)]=function(_0x1c6607){const _0x4c6218=_0x20bac4;if(!_0x1c6607)return![];return _0x1c6607[_0x4c6218(0x232)][_0x4c6218(0x145)](/<BYPASS TAUNT>/i);},DataManager[_0x20bac4(0x1be)]=function(_0x26d037){const _0x1daae7=_0x20bac4;if(!_0x26d037)return![];return _0x26d037[_0x1daae7(0x232)][_0x1daae7(0x145)](/<BYPASS HIGHEST (?:AGGRO|ENMITY|THREAT)>/i);},DataManager[_0x20bac4(0x1a3)]=function(_0x3f846d){const _0x19d3e1=_0x20bac4;if(!_0x3f846d)return![];return _0x3f846d[_0x19d3e1(0x232)][_0x19d3e1(0x145)](/<TARGET HIGHEST (?:AGGRO|ENMITY|THREAT)>/i);},ImageManager[_0x20bac4(0x201)]=function(){const _0x28cff9=_0x20bac4;if(this[_0x28cff9(0x117)])return this[_0x28cff9(0x117)];return this[_0x28cff9(0x117)]=new Bitmap(0x64,0x64),this['_provokeBitmap'][_0x28cff9(0x1b6)](0x32,0x32,0x32,ColorManager[_0x28cff9(0x23f)]()),this[_0x28cff9(0x117)][_0x28cff9(0x195)]=![],this[_0x28cff9(0x117)];},ConfigManager[_0x20bac4(0x14e)]=!![],ConfigManager[_0x20bac4(0x12c)]=!![],VisuMZ[_0x20bac4(0x22d)]['ConfigManager_makeData']=ConfigManager[_0x20bac4(0xef)],ConfigManager['makeData']=function(){const _0x3cc9a4=_0x20bac4,_0x10cbe9=VisuMZ[_0x3cc9a4(0x22d)][_0x3cc9a4(0x19c)]['call'](this);return _0x10cbe9[_0x3cc9a4(0x14e)]=this['aggroGauge'],_0x10cbe9[_0x3cc9a4(0x12c)]=this[_0x3cc9a4(0x12c)],_0x10cbe9;},VisuMZ[_0x20bac4(0x22d)]['ConfigManager_applyData']=ConfigManager[_0x20bac4(0xce)],ConfigManager[_0x20bac4(0xce)]=function(_0x1e943e){const _0x48670b=_0x20bac4;VisuMZ['AggroControlSystem'][_0x48670b(0x205)][_0x48670b(0x1b0)](this,_0x1e943e);if(_0x48670b(0x14e)in _0x1e943e){if(_0x48670b(0x236)===_0x48670b(0x236))this['aggroGauge']=_0x1e943e[_0x48670b(0x14e)];else{if(!_0xc2cf83)return null;if(_0x370278[_0x48670b(0x145)](/BATTLE ACTOR (\d+)/i))return _0x372530[_0x48670b(0x17d)](_0x144246(_0x2d1c1b['$1']));else{if(_0x3b0485[_0x48670b(0x145)](/BATTLE ENEMY (\d+)/i))return _0x640cfe[_0x48670b(0x23e)]()[_0x56e06f(_0x4c69ad['$1'])];}return null;}}else this[_0x48670b(0x14e)]=!![];if(_0x48670b(0x12c)in _0x1e943e)this[_0x48670b(0x12c)]=_0x1e943e[_0x48670b(0x12c)];else{if(_0x48670b(0x1f0)!==_0x48670b(0x1f0)){const _0x369595=_0x950f00[_0x48670b(0x1f1)](_0x5f044c=>_0x5f044c[_0x48670b(0x107)]),_0x26f2a7=_0x1d0e3e?_0x22e692[_0x48670b(0xe4)](..._0x369595):_0x1941c0[_0x48670b(0xc7)](..._0x369595),_0x13c1a7=_0x884240[_0x48670b(0x266)](_0x4959ab=>_0x4959ab[_0x48670b(0x107)]===_0x26f2a7);return _0x13c1a7[_0xf743ea['randomInt'](_0x13c1a7[_0x48670b(0x1bb)])]||this['randomTarget']();}else this[_0x48670b(0x12c)]=!![];}},TextManager[_0x20bac4(0x14e)]=VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x1e3)][_0x20bac4(0x230)][_0x20bac4(0x184)],TextManager[_0x20bac4(0x12c)]=VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x1e3)][_0x20bac4(0x1c0)][_0x20bac4(0x184)],ColorManager[_0x20bac4(0x143)]=function(_0xb2d311,_0x32ecf5){const _0x1518d0=_0x20bac4;return _0x32ecf5=String(_0x32ecf5),this[_0x1518d0(0xde)]=this[_0x1518d0(0xde)]||{},_0x32ecf5[_0x1518d0(0x145)](/#(.*)/i)?this[_0x1518d0(0xde)][_0xb2d311]=_0x1518d0(0xe0)[_0x1518d0(0x1ff)](String(RegExp['$1'])):this[_0x1518d0(0xde)][_0xb2d311]=this[_0x1518d0(0x1d2)](Number(_0x32ecf5)),this['_colorCache'][_0xb2d311];},ColorManager[_0x20bac4(0x119)]=function(_0x53cc60){const _0x216351=_0x20bac4;_0x53cc60=String(_0x53cc60);if(_0x53cc60['match'](/#(.*)/i)){if(_0x216351(0x1e1)===_0x216351(0x23b))this['opacity']=0x0;else return _0x216351(0xe0)[_0x216351(0x1ff)](String(RegExp['$1']));}else{if('swZxc'==='swZxc')return this[_0x216351(0x1d2)](Number(_0x53cc60));else{if(!_0x28deea['inBattle']())return;_0x66f87b['ConvertParams'](_0x5d2629,_0x4ea9fc);const _0x8257e3=_0x1e7aeb[_0x216351(0x17d)](_0x58a712[_0x216351(0x269)]),_0x193868=_0x593386[_0x216351(0x230)];if(_0x8257e3)_0x8257e3[_0x216351(0x103)](_0x193868);}}},ColorManager[_0x20bac4(0x23f)]=function(){const _0x14eb05=_0x20bac4,_0x2d3329=_0x14eb05(0x1bc);this['_colorCache']=this[_0x14eb05(0xde)]||{};if(this[_0x14eb05(0xde)][_0x2d3329])return this[_0x14eb05(0xde)][_0x2d3329];const _0x49da4c=VisuMZ['AggroControlSystem']['Settings'][_0x14eb05(0x1c0)][_0x14eb05(0x212)];return this[_0x14eb05(0x143)](_0x2d3329,_0x49da4c);},ColorManager[_0x20bac4(0x133)]=function(){const _0x28844c=_0x20bac4,_0x56b8db=_0x28844c(0x204);this['_colorCache']=this[_0x28844c(0xde)]||{};if(this['_colorCache'][_0x56b8db])return this['_colorCache'][_0x56b8db];const _0x45fe53=VisuMZ['AggroControlSystem'][_0x28844c(0x1e3)][_0x28844c(0x230)]['GaugeColor1'];return this[_0x28844c(0x143)](_0x56b8db,_0x45fe53);},ColorManager[_0x20bac4(0x10f)]=function(){const _0x56a2a0=_0x20bac4,_0x249d5b=_0x56a2a0(0x24b);this[_0x56a2a0(0xde)]=this[_0x56a2a0(0xde)]||{};if(this[_0x56a2a0(0xde)][_0x249d5b])return this[_0x56a2a0(0xde)][_0x249d5b];const _0x106139=VisuMZ['AggroControlSystem'][_0x56a2a0(0x1e3)][_0x56a2a0(0x230)][_0x56a2a0(0xeb)];return this[_0x56a2a0(0x143)](_0x249d5b,_0x106139);},SceneManager[_0x20bac4(0x240)]=function(){const _0x134c8e=_0x20bac4;return this['_scene']&&this[_0x134c8e(0x226)][_0x134c8e(0x214)]===Scene_Battle;},BattleManager[_0x20bac4(0x126)]=function(_0x3d3182){const _0x26dd40=_0x20bac4;let _0x4dee4d=this['_subject'];if(this['_counterAttackingTarget']){if(_0x26dd40(0x257)!==_0x26dd40(0x257))return!!this[_0x26dd40(0x1df)]();else _0x4dee4d=this[_0x26dd40(0xd7)];}if(!_0x4dee4d)return _0x26dd40(0x203)!==_0x26dd40(0x203)?_0x1df603[_0x26dd40(0x22d)]['Settings'][_0x26dd40(0x1c0)][_0x26dd40(0x1c1)]/0x64:null;if(_0x4dee4d[_0x26dd40(0x113)]()&&_0x3d3182[_0x26dd40(0x18a)]()){if(_0x26dd40(0x26d)===_0x26dd40(0xdf))_0x46c1e8[_0x26dd40(0x22d)][_0x26dd40(0x188)][_0x26dd40(0x1b0)](this),this['updateAggroGaugeSprite']();else return _0x26dd40(0x10e)[_0x26dd40(0x1ff)](_0x4dee4d[_0x26dd40(0x1a0)]());}else{if(_0x4dee4d[_0x26dd40(0x18a)]()&&_0x3d3182[_0x26dd40(0x113)]())return _0x26dd40(0x13e)[_0x26dd40(0x1ff)](_0x4dee4d[_0x26dd40(0x255)]());}return null;},BattleManager['convertStringToBattleTarget']=function(_0x3e2be6){const _0x3a7a8d=_0x20bac4;if(!_0x3e2be6)return null;if(_0x3e2be6['match'](/BATTLE ACTOR (\d+)/i))return $gameActors[_0x3a7a8d(0x17d)](Number(RegExp['$1']));else{if(_0x3e2be6[_0x3a7a8d(0x145)](/BATTLE ENEMY (\d+)/i)){if(_0x3a7a8d(0x1e0)===_0x3a7a8d(0x23d)){if(this['_aggro']===_0x5dce45)this[_0x3a7a8d(0x167)]();this[_0x3a7a8d(0x11b)]=_0x2268dc[_0x3a7a8d(0xe4)](0x1,_0x410b8b[_0x3a7a8d(0x1e2)](this[_0x3a7a8d(0x11b)]));}else return $gameTroop[_0x3a7a8d(0x23e)]()[Number(RegExp['$1'])];}}return null;},BattleManager[_0x20bac4(0x229)]=function(){const _0x1f7c99=_0x20bac4;return VisuMZ['AggroControlSystem'][_0x1f7c99(0x1e3)]['Aggro'][_0x1f7c99(0x115)];},VisuMZ['AggroControlSystem'][_0x20bac4(0x172)]=Game_Action['prototype'][_0x20bac4(0x108)],Game_Action[_0x20bac4(0x106)][_0x20bac4(0x108)]=function(_0x5cec5f){const _0x2715b7=_0x20bac4;if(this[_0x2715b7(0xf5)]()){if(_0x2715b7(0x183)!==_0x2715b7(0x20c))return this['makeProvokeTarget']();else{if(this[_0x2715b7(0x1d9)]()[_0x2715b7(0x118)]!==0x1)return![];if(_0x4f50eb['isBypassProvoke'](this[_0x2715b7(0x1d9)]()))return![];if(this[_0x2715b7(0x18c)]()[_0x2715b7(0xfc)]())return![];return this[_0x2715b7(0x18c)]()[_0x2715b7(0xf5)]();}}else{if(this[_0x2715b7(0x173)]())return this['tauntTargetsForAlive'](_0x5cec5f);else return this[_0x2715b7(0xd9)]()?[_0x5cec5f[_0x2715b7(0x1f6)]()]:VisuMZ[_0x2715b7(0x22d)][_0x2715b7(0x172)][_0x2715b7(0x1b0)](this,_0x5cec5f);}},Game_Action[_0x20bac4(0x106)][_0x20bac4(0xf5)]=function(){const _0x47a087=_0x20bac4;if(this[_0x47a087(0x1d9)]()['scope']!==0x1)return![];if(DataManager[_0x47a087(0x15f)](this[_0x47a087(0x1d9)]()))return![];if(this[_0x47a087(0x18c)]()[_0x47a087(0xfc)]())return![];return this['subject']()[_0x47a087(0xf5)]();},Game_Action[_0x20bac4(0x106)][_0x20bac4(0x225)]=function(){const _0x59347b=_0x20bac4;return[this[_0x59347b(0x18c)]()['provoker']()];},Game_Action['prototype'][_0x20bac4(0x173)]=function(){const _0x497ca1=_0x20bac4;if(this['item']()[_0x497ca1(0x118)]!==0x1)return![];if(DataManager[_0x497ca1(0x19f)](this[_0x497ca1(0x1d9)]()))return![];if(this[_0x497ca1(0x18c)]()['bypassTaunt']())return![];const _0x51e6af=this[_0x497ca1(0x139)]();if(this[_0x497ca1(0x23c)]()&&_0x51e6af['physicalTauntMembers']()['length']>0x0)return!![];if(this[_0x497ca1(0x1a9)]()&&_0x51e6af[_0x497ca1(0x1cf)]()[_0x497ca1(0x1bb)]>0x0)return!![];if(this[_0x497ca1(0x26f)]()&&_0x51e6af['certainHitTauntMembers']()[_0x497ca1(0x1bb)]>0x0)return!![];return![];},Game_Action[_0x20bac4(0x106)][_0x20bac4(0x227)]=function(_0x34ef77){const _0x46e361=_0x20bac4;if(this[_0x46e361(0x1aa)]<0x0)return[_0x34ef77[_0x46e361(0x1dc)](this['item']()['hitType'])];else{const _0x1287c7=_0x34ef77[_0x46e361(0x22b)](this[_0x46e361(0x1aa)]);return _0x1287c7[_0x46e361(0x174)](this['item']()[_0x46e361(0x268)])?[_0x1287c7]:[_0x34ef77[_0x46e361(0x1dc)]()];}},Game_Action['prototype'][_0x20bac4(0xd9)]=function(){const _0x313183=_0x20bac4;if(this[_0x313183(0x1d9)]()['scope']!==0x1)return![];if(this[_0x313183(0x1aa)]>=0x0)return![];if(DataManager[_0x313183(0x1be)](this['item']()))return![];if(this[_0x313183(0x18c)]()['bypassHighestAggro']())return![];if(DataManager[_0x313183(0x1a3)](this['item']()))return!![];if(this[_0x313183(0x18c)]()['alwaysTargetHighestAggro']())return!![];return BattleManager[_0x313183(0x229)]();},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x13d)]=Game_Action[_0x20bac4(0x106)][_0x20bac4(0x16f)],Game_Action['prototype']['applyGlobal']=function(){const _0x2f5653=_0x20bac4;VisuMZ[_0x2f5653(0x22d)][_0x2f5653(0x13d)][_0x2f5653(0x1b0)](this),this[_0x2f5653(0x154)]();},Game_Action['prototype']['applySubjectAggro']=function(){const _0x34fa08=_0x20bac4,_0x36fa5a=this[_0x34fa08(0x1d9)]()['note'];if(_0x36fa5a[_0x34fa08(0x145)](/<(?:USER AGGRO|AGGRO|USER ENMITY|ENMITY|USER THREAT|THREAT): ([\+\-]\d+)>/i)){const _0xae4d01=Number(RegExp['$1']);this[_0x34fa08(0x18c)]()[_0x34fa08(0x103)](_0xae4d01);}if(_0x36fa5a[_0x34fa08(0x145)](/<JS (?:USER AGGRO|AGGRO|USER ENMITY|ENMITY|USER THREAT|THREAT)>\s*([\s\S]*)\s*<\/JS (?:USER AGGRO|AGGRO|USER ENMITY|ENMITY|USER THREAT|THREAT)>/i)){if('vImoL'!=='VHwIA'){const _0x58c68c=String(RegExp['$1']);window[_0x34fa08(0x1f3)]=this['subject'](),window[_0x34fa08(0x1d9)]=this[_0x34fa08(0x1d9)](),window['a']=this['subject'](),window['b']=a;let _0x3c2919=user[_0x34fa08(0x16a)]();try{eval(_0x58c68c);}catch(_0x1e2d61){if($gameTemp[_0x34fa08(0xf7)]())console[_0x34fa08(0x1ef)](_0x1e2d61);}user['setAggro'](_0x3c2919),window[_0x34fa08(0x1f3)]=undefined,window[_0x34fa08(0x14d)]=undefined,window[_0x34fa08(0x1d9)]=undefined,window['a']=undefined,window['b']=undefined;}else{const _0x235e12=this['isActor']()?this[_0x34fa08(0x17d)]()['note']:this[_0x34fa08(0x18a)]()?this[_0x34fa08(0x12e)]()[_0x34fa08(0x232)]:'';if(_0x235e12['match'](/<PROVOKE HEIGHT ORIGIN: (\d+)([%％])>/i))return _0x57e840(_0x18021a['$1'])*0.01;return _0x31b74d[_0x34fa08(0x22d)][_0x34fa08(0x1e3)][_0x34fa08(0x1c0)]['HeightOrigin'];}}},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x20e)]=Game_Action['prototype'][_0x20bac4(0x1e6)],Game_Action[_0x20bac4(0x106)]['applyItemUserEffect']=function(_0x357680){const _0x268a0b=_0x20bac4;VisuMZ[_0x268a0b(0x22d)][_0x268a0b(0x20e)][_0x268a0b(0x1b0)](this,_0x357680),this['applyItemUserEffectAggroControl'](_0x357680);},Game_Action['prototype'][_0x20bac4(0x1ce)]=function(_0x427a6e){const _0x4810d2=_0x20bac4;if(!this[_0x4810d2(0x1d9)]())return;if(!SceneManager['isSceneBattle']())return;const _0x3b3a78=this['item']()[_0x4810d2(0x232)];if(_0x3b3a78['match'](/<TARGET (?:AGGRO|ENMITY|THREAT): ([\+\-]\d+)>/i)){if('iXlAc'===_0x4810d2(0x249)){const _0x54a922=Number(RegExp['$1']);_0x427a6e[_0x4810d2(0x103)](_0x54a922);}else _0x5ddb5a[_0x4810d2(0x22d)][_0x4810d2(0x15d)][_0x4810d2(0x1b0)](this,_0x1bae6f),this[_0x4810d2(0x166)](_0x3b2a4e);}if(_0x3b3a78['match'](/<JS TARGET (?:AGGRO|ENMITY|THREAT)>\s*([\s\S]*)\s*<\/JS TARGET (?:AGGRO|ENMITY|THREAT)>/i)){if(_0x4810d2(0x21a)!=='DvJhz'){if(!_0x5588e0[_0x4810d2(0x222)])return![];if(![_0x9c8697,_0xc1d2c0]['includes'](this[_0x4810d2(0x214)]))return![];return _0x113dfc['provokeOrigin']&&_0x4a55d6[_0x4810d2(0x22d)][_0x4810d2(0x1e3)][_0x4810d2(0x1c0)]['ShowLines'];}else{const _0x2344b8=String(RegExp['$1']);window['user']=this[_0x4810d2(0x18c)](),window[_0x4810d2(0x14d)]=_0x427a6e,window[_0x4810d2(0x1d9)]=this['item'](),window['a']=this[_0x4810d2(0x18c)](),window['b']=_0x427a6e;let _0x1006bb=_0x427a6e[_0x4810d2(0x16a)]();try{eval(_0x2344b8);}catch(_0x45eb16){if($gameTemp[_0x4810d2(0xf7)]())console[_0x4810d2(0x1ef)](_0x45eb16);}_0x427a6e[_0x4810d2(0x1a1)](_0x1006bb),window[_0x4810d2(0x1f3)]=undefined,window[_0x4810d2(0x14d)]=undefined,window[_0x4810d2(0x1d9)]=undefined,window['a']=undefined,window['b']=undefined;}}},VisuMZ['AggroControlSystem'][_0x20bac4(0x1ee)]=Game_Action[_0x20bac4(0x106)][_0x20bac4(0x135)],Game_Action[_0x20bac4(0x106)][_0x20bac4(0x135)]=function(_0x11c72b,_0x419d1c){const _0x510014=_0x20bac4;VisuMZ[_0x510014(0x22d)][_0x510014(0x1ee)][_0x510014(0x1b0)](this,_0x11c72b,_0x419d1c),this[_0x510014(0x1c4)](_0x11c72b,_0x419d1c);},Game_Action[_0x20bac4(0x106)][_0x20bac4(0x1c4)]=function(_0x685ff1,_0xde7e13){const _0xf8006=_0x20bac4,_0x140558=VisuMZ[_0xf8006(0x22d)][_0xf8006(0x1e3)][_0xf8006(0x230)];if(_0xde7e13>0x0&&_0x685ff1[_0xf8006(0x113)]()!==this[_0xf8006(0x18c)]()[_0xf8006(0x113)]()){const _0x3e1e9b=_0x140558[_0xf8006(0x1c2)];this['subject']()['gainAggro'](_0x3e1e9b*_0xde7e13);}if(_0xde7e13<0x0&&_0x685ff1['isActor']()===this[_0xf8006(0x18c)]()['isActor']()){if(_0xf8006(0x18e)===_0xf8006(0x18e)){const _0x273e3e=_0x140558[_0xf8006(0x123)];this[_0xf8006(0x18c)]()[_0xf8006(0x103)](_0x273e3e*Math[_0xf8006(0x1b2)](_0xde7e13));}else _0x5c595a=!![],this[_0xf8006(0x221)]+=_0x9d8376[_0xf8006(0x226)][_0xf8006(0x1e8)]['x'],this[_0xf8006(0x262)]+=_0x24b51f[_0xf8006(0x226)][_0xf8006(0x1e8)]['y'];}},VisuMZ[_0x20bac4(0x22d)]['Game_BattlerBase_initMembers']=Game_BattlerBase['prototype']['initMembers'],Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x1af)]=function(){const _0x43c2f0=_0x20bac4;this[_0x43c2f0(0x127)]={},VisuMZ[_0x43c2f0(0x22d)][_0x43c2f0(0x10d)][_0x43c2f0(0x1b0)](this),this[_0x43c2f0(0x15a)]();},Game_BattlerBase[_0x20bac4(0x106)]['initAggroControl']=function(){const _0x358cdb=_0x20bac4;this[_0x358cdb(0x21c)](),this[_0x358cdb(0x167)]();},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x21c)]=function(){const _0x1998a2=_0x20bac4;this[_0x1998a2(0x192)]={};},VisuMZ['AggroControlSystem']['Game_BattlerBase_refresh']=Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x170)],Game_BattlerBase['prototype']['refresh']=function(){const _0xf57727=_0x20bac4;this[_0xf57727(0x127)]={},VisuMZ[_0xf57727(0x22d)][_0xf57727(0x258)]['call'](this),this[_0xf57727(0xf9)]();},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x25c)]=function(_0x311079){const _0x3c7f7b=_0x20bac4;return this[_0x3c7f7b(0x127)]=this[_0x3c7f7b(0x127)]||{},this[_0x3c7f7b(0x127)][_0x311079]!==undefined;},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x1df)]=function(){const _0xd1031=_0x20bac4;for(const _0x382736 of this[_0xd1031(0x112)]()){if(DataManager[_0xd1031(0x21d)](_0x382736)){if(_0xd1031(0x102)!=='xLbyU')this[_0xd1031(0x233)]();else{if(this[_0xd1031(0x192)]===undefined)this[_0xd1031(0x21c)]();const _0x331a91=this['_provoker'][_0x382736['id']],_0xd8bb5e=BattleManager[_0xd1031(0x254)](_0x331a91);if(_0xd8bb5e&&_0xd8bb5e['isAlive']())return _0xd8bb5e;}}}return null;},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0xf5)]=function(){const _0x5177b9=_0x20bac4;return!!this[_0x5177b9(0x1df)]();},Game_BattlerBase[_0x20bac4(0x106)]['bypassProvoke']=function(){const _0x40dfef=_0x20bac4;return this['traitObjects']()['some'](_0x445d22=>_0x445d22&&_0x445d22['note'][_0x40dfef(0x145)](/<BYPASS PROVOKE>/i));},Game_BattlerBase['prototype'][_0x20bac4(0x121)]=function(){const _0x2464f0=_0x20bac4;let _0x3ab07d=_0x2464f0(0x121);if(this[_0x2464f0(0x25c)](_0x3ab07d))return this[_0x2464f0(0x127)][_0x3ab07d];return this[_0x2464f0(0x127)][_0x3ab07d]=this[_0x2464f0(0x243)](),this['_cache'][_0x3ab07d];},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x243)]=function(){const _0x3a7648=_0x20bac4,_0x17ba0b=this[_0x3a7648(0x113)]()?this['actor']()['note']:this[_0x3a7648(0x18a)]()?this['enemy']()[_0x3a7648(0x232)]:'';if(_0x17ba0b[_0x3a7648(0x145)](/<PROVOKE HEIGHT ORIGIN: (\d+)([%％])>/i))return Number(RegExp['$1'])*0.01;return VisuMZ['AggroControlSystem'][_0x3a7648(0x1e3)][_0x3a7648(0x1c0)][_0x3a7648(0x11a)];},Game_BattlerBase['prototype'][_0x20bac4(0xf9)]=function(){const _0x2d5c11=_0x20bac4;for(const _0x1d5347 of this[_0x2d5c11(0x112)]()){if(DataManager['stateHasProvoke'](_0x1d5347)){if(_0x2d5c11(0x1fc)!==_0x2d5c11(0x147)){if(this[_0x2d5c11(0x192)]===undefined)this[_0x2d5c11(0x21c)]();const _0x55db7c=this[_0x2d5c11(0x192)][_0x1d5347['id']],_0x575124=BattleManager[_0x2d5c11(0x254)](_0x55db7c);_0x575124&&_0x575124['isDead']()&&this[_0x2d5c11(0x208)](_0x1d5347['id']);}else{if(this[_0x2d5c11(0x241)]()===_0x2d5c11(0x26b)){let _0x13203a=this[_0x2d5c11(0x17c)](_0x4c6d6d);_0x5c617f=_0xe2c32d[_0x2d5c11(0x1e2)](_0x13203a['y']+(_0x13203a[_0x2d5c11(0xf4)]-_0x31ca91[_0x2d5c11(0x106)][_0x2d5c11(0x1f9)]())/0x2);}}}}},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x174)]=function(_0x149a5c){const _0x57993e=_0x20bac4;switch(_0x149a5c){case Game_Action['HITTYPE_PHYSICAL']:return this[_0x57993e(0x1bd)]();break;case Game_Action[_0x57993e(0x1eb)]:return this[_0x57993e(0x15b)]();break;case Game_Action[_0x57993e(0x17f)]:return this['certainHitTaunt']();break;}},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x248)]=function(){const _0x1cd754=_0x20bac4;return this[_0x1cd754(0x1bd)]()||this[_0x1cd754(0x15b)]()||this[_0x1cd754(0x105)]();},Game_BattlerBase['prototype'][_0x20bac4(0x1bd)]=function(){const _0x264cd7=_0x20bac4;return this[_0x264cd7(0x210)]()[_0x264cd7(0x109)](_0x342c57=>_0x342c57&&_0x342c57[_0x264cd7(0x232)][_0x264cd7(0x145)](/<(?:TAUNT|PHYSICAL TAUNT|ALL TAUNT)>/i));},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x15b)]=function(){const _0x58c2bc=_0x20bac4;return this[_0x58c2bc(0x210)]()[_0x58c2bc(0x109)](_0x12c618=>_0x12c618&&_0x12c618[_0x58c2bc(0x232)]['match'](/<(?:TAUNT|MAGICAL TAUNT|ALL TAUNT)>/i));},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x105)]=function(){const _0x8347a9=_0x20bac4;return this[_0x8347a9(0x210)]()['some'](_0x1727d4=>_0x1727d4&&_0x1727d4[_0x8347a9(0x232)]['match'](/<(?:TAUNT|CERTAIN TAUNT|CERTAIN HIT TAUNT|ALL TAUNT)>/i));},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x1a8)]=function(){const _0x13ef2a=_0x20bac4;return this[_0x13ef2a(0x210)]()['some'](_0x16e162=>_0x16e162&&_0x16e162[_0x13ef2a(0x232)][_0x13ef2a(0x145)](/<BYPASS TAUNT>/i));},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x167)]=function(){const _0x33030a=_0x20bac4;this[_0x33030a(0x11b)]=0x1;},VisuMZ['AggroControlSystem'][_0x20bac4(0xfa)]=Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0xf0)],Game_BattlerBase['prototype'][_0x20bac4(0xf0)]=function(_0x1809a4){const _0x1cbacf=_0x20bac4;let _0x6d493e=VisuMZ[_0x1cbacf(0x22d)][_0x1cbacf(0xfa)]['call'](this,_0x1809a4);if(_0x1809a4===0x0){if(_0x1cbacf(0x1c6)===_0x1cbacf(0x1c6)){if(this['_aggro']===undefined)this['clearAggro']();_0x6d493e*=this[_0x1cbacf(0x1b4)]();}else _0x3bad59[_0x1cbacf(0x22d)][_0x1cbacf(0xe3)][_0x1cbacf(0x1b0)](this),this['createAggroGauge']();}return _0x6d493e;},Game_BattlerBase['prototype']['setAggro']=function(_0x1158b4){const _0x48386f=_0x20bac4;if(this[_0x48386f(0x11b)]===undefined)this[_0x48386f(0x167)]();this['_aggro']=Math['max'](0x1,Math[_0x48386f(0x1e2)](this['_aggro']));},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x103)]=function(_0x121c19){const _0x4c3d13=_0x20bac4;if(this[_0x4c3d13(0x11b)]===undefined)this[_0x4c3d13(0x167)]();this[_0x4c3d13(0x11b)]=Math[_0x4c3d13(0xe4)](0x1,this[_0x4c3d13(0x11b)]+Math['round'](_0x121c19));},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x179)]=function(_0x3679a0){const _0x378fd3=_0x20bac4;this[_0x378fd3(0x103)](-_0x3679a0);},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x1b4)]=function(){const _0x1d193a=_0x20bac4;if(this['isDead']())return 0x0;return this[_0x1d193a(0x1ab)]()*this[_0x1d193a(0x1c9)]();},Game_BattlerBase['prototype'][_0x20bac4(0x16a)]=function(){const _0x4f4cd0=_0x20bac4;return this[_0x4f4cd0(0x11b)]===undefined&&this[_0x4f4cd0(0x167)](),this['_aggro'];},Game_BattlerBase[_0x20bac4(0x106)]['baseAggro']=function(){const _0x3af435=_0x20bac4;return this['traitObjects']()['reduce']((_0x1f32c7,_0x1520dd)=>{const _0x250841=_0x33c1;if(_0x1520dd&&_0x1520dd[_0x250841(0x232)]['match'](/<(?:AGGRO|ENMITY|THREAT): ([\+\-]\d+)>/i)){if(_0x250841(0xcc)!==_0x250841(0xcc))this[_0x250841(0xd7)]=_0x365439,_0x30ed2a[_0x250841(0x22d)]['BattleManager_invokeCounterAttack'][_0x250841(0x1b0)](this,_0x5199ba,_0x5e884b),this['_counterAttackingTarget']=_0x516d8a;else return _0x1f32c7+Number(RegExp['$1'])/0x64;}else return _0x1f32c7;},this[_0x3af435(0x16a)]());},Game_BattlerBase[_0x20bac4(0x106)]['aggroMultiplier']=function(){const _0x4ab7c4=_0x20bac4;return this[_0x4ab7c4(0x210)]()[_0x4ab7c4(0x168)]((_0x3e2ad0,_0x4afcdc)=>{const _0x19195e=_0x4ab7c4;if(_0x4afcdc&&_0x4afcdc['note']['match'](/<(?:AGGRO|ENMITY|THREAT) MULTIPLIER: (\d+)%>/i))return _0x3e2ad0+Number(RegExp['$1'])/0x64;else{if('qdgPS'==='EwNWQ'){if(!this[_0x19195e(0x1d0)]){const _0x1406b9=this['tgrMin'](),_0x1693fe=this[_0x19195e(0xfe)]()[_0x19195e(0x266)](_0x5b1efb=>_0x5b1efb['tgr']===_0x1406b9);this[_0x19195e(0x1d0)]=_0x1693fe[_0x1915c5[_0x19195e(0x26c)](_0x1693fe[_0x19195e(0x1bb)])]||this[_0x19195e(0x1fb)]();}return this[_0x19195e(0x1d0)];}else return _0x3e2ad0;}},0x1);},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x1b7)]=function(){const _0x100d93=_0x20bac4;return this['traitObjects']()[_0x100d93(0x109)](_0x4f91c5=>_0x4f91c5&&_0x4f91c5[_0x100d93(0x232)][_0x100d93(0x145)](/<BYPASS HIGHEST (?:AGGRO|ENMITY|THREAT)>/i));},Game_BattlerBase[_0x20bac4(0x106)][_0x20bac4(0x1a3)]=function(){const _0x36dc4f=_0x20bac4;return this[_0x36dc4f(0x210)]()[_0x36dc4f(0x109)](_0x1b2dc8=>_0x1b2dc8&&_0x1b2dc8[_0x36dc4f(0x232)]['match'](/<TARGET HIGHEST (?:AGGRO|ENMITY|THREAT)>/i));},VisuMZ[_0x20bac4(0x22d)]['Game_Battler_onBattleStart']=Game_Battler['prototype'][_0x20bac4(0x1d7)],Game_Battler[_0x20bac4(0x106)]['onBattleStart']=function(_0x4eeab3){const _0x2f19a9=_0x20bac4;VisuMZ[_0x2f19a9(0x22d)][_0x2f19a9(0xdb)][_0x2f19a9(0x1b0)](this,_0x4eeab3),this[_0x2f19a9(0x167)]();},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x22f)]=Game_Battler[_0x20bac4(0x106)][_0x20bac4(0x21f)],Game_Battler[_0x20bac4(0x106)][_0x20bac4(0x21f)]=function(){const _0x385b07=_0x20bac4;VisuMZ[_0x385b07(0x22d)][_0x385b07(0x22f)][_0x385b07(0x1b0)](this),this[_0x385b07(0x167)]();},VisuMZ['AggroControlSystem'][_0x20bac4(0x15d)]=Game_Battler[_0x20bac4(0x106)][_0x20bac4(0x111)],Game_Battler[_0x20bac4(0x106)]['addState']=function(_0x240727){const _0x584e61=_0x20bac4;VisuMZ[_0x584e61(0x22d)][_0x584e61(0x15d)]['call'](this,_0x240727),this[_0x584e61(0x166)](_0x240727);},Game_Battler[_0x20bac4(0x106)][_0x20bac4(0x166)]=function(_0x44009a){const _0x38f2c9=_0x20bac4;if(this['isStateAffected'](_0x44009a)){if(this[_0x38f2c9(0x192)]===undefined)this['clearProvokers']();const _0x11465a=BattleManager['convertBattleTargetToString'](this);this[_0x38f2c9(0x192)][_0x44009a]=_0x11465a,!this[_0x38f2c9(0x192)][_0x44009a]&&delete this[_0x38f2c9(0x192)][_0x44009a];}},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x24d)]=BattleManager['invokeCounterAttack'],BattleManager['invokeCounterAttack']=function(_0x2b1298,_0x46764b){const _0x288c30=_0x20bac4;this[_0x288c30(0xd7)]=_0x46764b,VisuMZ[_0x288c30(0x22d)][_0x288c30(0x24d)][_0x288c30(0x1b0)](this,_0x2b1298,_0x46764b),this[_0x288c30(0xd7)]=undefined;},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x1db)]=BattleManager[_0x20bac4(0x1d3)],BattleManager[_0x20bac4(0x1d3)]=function(_0x455486,_0x3a4329){const _0x56be74=_0x20bac4;this[_0x56be74(0xd7)]=_0x3a4329,VisuMZ[_0x56be74(0x22d)][_0x56be74(0x1db)]['call'](this,_0x455486,_0x3a4329),this[_0x56be74(0xd7)]=undefined;},Game_Unit[_0x20bac4(0x106)][_0x20bac4(0x245)]=function(){const _0x108e9a=_0x20bac4;return this[_0x108e9a(0xfe)]()[_0x108e9a(0x266)](_0x9f7992=>_0x9f7992&&_0x9f7992[_0x108e9a(0x1bd)]());},Game_Unit[_0x20bac4(0x106)][_0x20bac4(0x1cf)]=function(){const _0x12341c=_0x20bac4;return this[_0x12341c(0xfe)]()[_0x12341c(0x266)](_0x2f7f1e=>_0x2f7f1e&&_0x2f7f1e['magicalTaunt']());},Game_Unit[_0x20bac4(0x106)][_0x20bac4(0xf8)]=function(){const _0x1a21b0=_0x20bac4;return this[_0x1a21b0(0xfe)]()[_0x1a21b0(0x266)](_0x344b3b=>_0x344b3b&&_0x344b3b['certainHitTaunt']());},Game_Unit[_0x20bac4(0x106)]['randomTauntTarget']=function(_0x509469){const _0x882b79=_0x20bac4;let _0xbaa545=[];switch(_0x509469){case Game_Action[_0x882b79(0xe7)]:_0xbaa545=this[_0x882b79(0x245)]();break;case Game_Action[_0x882b79(0x1eb)]:_0xbaa545=this['magicalTauntMembers']();break;case Game_Action[_0x882b79(0x17f)]:_0xbaa545=this['certainHitTauntMembers']();break;}let _0x181849=Math[_0x882b79(0x1b3)]()*this['tgrSumFromGroup'](_0xbaa545),_0x1527fd=null;if(BattleManager['isTargetHighestTGR']()){const _0x2bd4e6=!![];return this[_0x882b79(0x1c5)](_0xbaa545,_0x2bd4e6);}else{if('Fzvro'!==_0x882b79(0x1c7)){for(const _0x36dc23 of _0xbaa545){_0x181849-=_0x36dc23[_0x882b79(0x107)],_0x181849<=0x0&&!_0x1527fd&&(_0x1527fd=_0x36dc23);}return _0x1527fd||this['randomTarget']();}else this[_0x882b79(0x103)](-_0x365e00);}},Game_Unit[_0x20bac4(0x106)]['tgrSumFromGroup']=function(_0x8c24ff){const _0x477aef=_0x20bac4;return _0x8c24ff[_0x477aef(0x168)]((_0x2f8dbe,_0x26b486)=>_0x2f8dbe+_0x26b486['tgr'],0x0);},Game_Unit[_0x20bac4(0x106)][_0x20bac4(0x17e)]=function(){const _0x4e71d4=_0x20bac4,_0x3c4fc9=this['aliveMembers']()[_0x4e71d4(0x1f1)](_0x417934=>_0x417934[_0x4e71d4(0x107)]);return Math['max'](..._0x3c4fc9);},Game_Unit[_0x20bac4(0x106)][_0x20bac4(0x138)]=function(){const _0x523a30=_0x20bac4,_0x5b76df=this[_0x523a30(0xfe)]()[_0x523a30(0x1f1)](_0x1ac0de=>_0x1ac0de[_0x523a30(0x107)]);return Math[_0x523a30(0xc7)](..._0x5b76df);},Game_Unit[_0x20bac4(0x106)][_0x20bac4(0x251)]=function(){const _0x492ced=_0x20bac4;this[_0x492ced(0x12d)]=undefined,this['_lowestTgrMember']=undefined;},Game_Unit[_0x20bac4(0x106)][_0x20bac4(0x1f6)]=function(){const _0x4d57ed=_0x20bac4;if(!this[_0x4d57ed(0x12d)]){const _0x4f6558=this['tgrMax'](),_0x4ad793=this['aliveMembers']()['filter'](_0x303147=>_0x303147['tgr']===_0x4f6558);this[_0x4d57ed(0x12d)]=_0x4ad793[Math[_0x4d57ed(0x26c)](_0x4ad793[_0x4d57ed(0x1bb)])]||this[_0x4d57ed(0x1fb)]();}return this[_0x4d57ed(0x12d)];},Game_Unit[_0x20bac4(0x106)][_0x20bac4(0x1ba)]=function(){const _0x5a04a7=_0x20bac4;if(!this[_0x5a04a7(0x1d0)]){const _0xc4dfb5=this[_0x5a04a7(0x138)](),_0x58e5c=this[_0x5a04a7(0xfe)]()['filter'](_0x395b01=>_0x395b01['tgr']===_0xc4dfb5);this[_0x5a04a7(0x1d0)]=_0x58e5c[Math[_0x5a04a7(0x26c)](_0x58e5c[_0x5a04a7(0x1bb)])]||this[_0x5a04a7(0x1fb)]();}return this['_lowestTgrMember'];},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x1a2)]=BattleManager[_0x20bac4(0x146)],BattleManager[_0x20bac4(0x146)]=function(){const _0x1dfd14=_0x20bac4;VisuMZ[_0x1dfd14(0x22d)][_0x1dfd14(0x1a2)]['call'](this),$gameParty['clearTgrCache'](),$gameTroop[_0x1dfd14(0x251)]();},Game_Unit['prototype'][_0x20bac4(0x1c5)]=function(_0x4423bf,_0x3a22d6){const _0x301293=_0x20bac4,_0x39606f=_0x4423bf[_0x301293(0x1f1)](_0x14ad5e=>_0x14ad5e[_0x301293(0x107)]),_0x3d6511=_0x3a22d6?Math[_0x301293(0xe4)](..._0x39606f):Math[_0x301293(0xc7)](..._0x39606f),_0x3cd9=_0x4423bf[_0x301293(0x266)](_0x3f6c80=>_0x3f6c80[_0x301293(0x107)]===_0x3d6511);return _0x3cd9[Math[_0x301293(0x26c)](_0x3cd9[_0x301293(0x1bb)])]||this['randomTarget']();},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x24f)]=Scene_Options[_0x20bac4(0x106)][_0x20bac4(0x137)],Scene_Options[_0x20bac4(0x106)][_0x20bac4(0x137)]=function(){const _0x5e0e7a=_0x20bac4;let _0x5fef15=VisuMZ[_0x5e0e7a(0x22d)][_0x5e0e7a(0x24f)][_0x5e0e7a(0x1b0)](this);const _0x35cb99=VisuMZ['AggroControlSystem']['Settings'];if(_0x35cb99[_0x5e0e7a(0x1c0)][_0x5e0e7a(0x1fa)]&&_0x35cb99[_0x5e0e7a(0x1c0)]['AdjustOptionsRect'])_0x5fef15++;if(_0x35cb99[_0x5e0e7a(0x230)]['AddOption']&&_0x35cb99['Aggro']['AdjustOptionsRect'])_0x5fef15++;return _0x5fef15;},Sprite_Battler[_0x20bac4(0x1ec)]=VisuMZ[_0x20bac4(0x22d)]['Settings'][_0x20bac4(0x12a)][_0x20bac4(0x131)],Sprite_Battler[_0x20bac4(0x187)]=VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x1e3)][_0x20bac4(0x12a)]['AniPhysical'],Sprite_Battler[_0x20bac4(0x216)]=VisuMZ['AggroControlSystem'][_0x20bac4(0x1e3)]['Taunt'][_0x20bac4(0x217)],Sprite_Battler[_0x20bac4(0xc4)]=VisuMZ['AggroControlSystem']['Settings'][_0x20bac4(0x12a)]['AniCertain'],Sprite_Battler['_mirrorActorTauntAnimations']=VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x1e3)][_0x20bac4(0x12a)][_0x20bac4(0x235)],Sprite_Battler[_0x20bac4(0x13f)]=VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x1e3)][_0x20bac4(0x12a)][_0x20bac4(0x124)],VisuMZ['AggroControlSystem'][_0x20bac4(0x16e)]=Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0x175)],Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0x175)]=function(_0x1ac3af){const _0x610519=_0x20bac4;VisuMZ[_0x610519(0x22d)]['Sprite_Battler_initialize'][_0x610519(0x1b0)](this,_0x1ac3af),this['isShowPriorityLines']()&&setTimeout(this['createProvokeSprite'][_0x610519(0x22a)](this),0x3e8);},VisuMZ[_0x20bac4(0x22d)]['Sprite_Battler_initMembers']=Sprite_Battler['prototype'][_0x20bac4(0x1af)],Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0x1af)]=function(){const _0xffe9a0=_0x20bac4;VisuMZ['AggroControlSystem'][_0xffe9a0(0x218)][_0xffe9a0(0x1b0)](this),this[_0xffe9a0(0x144)]();},Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0x144)]=function(){const _0x5822bf=_0x20bac4;this['_tauntAnimationTimer']=VisuMZ[_0x5822bf(0x22d)]['Settings']['Taunt'][_0x5822bf(0x131)],this[_0x5822bf(0x176)]=[_0x5822bf(0x191),'magical',_0x5822bf(0x132)];},Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0x11c)]=function(){const _0x24d337=_0x20bac4;if(!Imported[_0x24d337(0x222)])return![];if(![Sprite_Actor,Sprite_Enemy]['includes'](this[_0x24d337(0x214)]))return![];return ConfigManager['provokeOrigin']&&VisuMZ['AggroControlSystem'][_0x24d337(0x1e3)][_0x24d337(0x1c0)][_0x24d337(0x149)];},Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0x14b)]=function(){const _0x71ac08=_0x20bac4;if(!SceneManager[_0x71ac08(0x240)]())return;this['_provokeSprite']=new Sprite_ProvokeTrail(this),this[_0x71ac08(0xd1)][_0x71ac08(0x1b5)]()[_0x71ac08(0xea)](this[_0x71ac08(0xd1)]);},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x24c)]=Sprite_Battler[_0x20bac4(0x106)]['setBattler'],Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0xd3)]=function(_0x3bfb81){const _0x3b672c=_0x20bac4;VisuMZ[_0x3b672c(0x22d)][_0x3b672c(0x24c)][_0x3b672c(0x1b0)](this,_0x3bfb81);if(this['_aggroGaugeSprite'])this[_0x3b672c(0x13c)]['_battler']=_0x3bfb81;},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x148)]=Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0x1fd)],Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0x1fd)]=function(){const _0x51a21e=_0x20bac4;VisuMZ[_0x51a21e(0x22d)][_0x51a21e(0x148)][_0x51a21e(0x1b0)](this),this[_0x51a21e(0x17a)]();},Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0x17a)]=function(){const _0x4814f2=_0x20bac4;if(!Imported[_0x4814f2(0x1d5)])return;if(!Imported[_0x4814f2(0x222)])return;if(!VisuMZ['AggroControlSystem'][_0x4814f2(0x1e3)]['Taunt'][_0x4814f2(0xc8)])return;if(!this[_0x4814f2(0x211)])return;this[_0x4814f2(0x1d1)]--,this[_0x4814f2(0x1d1)]<=0x0&&this[_0x4814f2(0x186)]();},Sprite_Battler[_0x20bac4(0x106)][_0x20bac4(0x186)]=function(){const _0x4af2d6=_0x20bac4;this[_0x4af2d6(0x1d1)]=Sprite_Battler[_0x4af2d6(0x1ec)];if(!this[_0x4af2d6(0x211)])return;if(!this[_0x4af2d6(0x211)][_0x4af2d6(0x248)]())return;const _0x2f48fd=[this[_0x4af2d6(0x211)]],_0x4c2da3=this[_0x4af2d6(0x199)](),_0x174c3b=this[_0x4af2d6(0x211)][_0x4af2d6(0x113)]()&&Sprite_Battler[_0x4af2d6(0xec)],_0x40fb46=Sprite_Battler[_0x4af2d6(0x13f)];$gameTemp['requestFauxAnimation'](_0x2f48fd,_0x4c2da3,_0x174c3b,_0x40fb46);},Sprite_Battler['prototype'][_0x20bac4(0x199)]=function(){const _0x345b80=_0x20bac4;let _0x43e326=this[_0x345b80(0x176)][_0x345b80(0x1bb)];while(_0x43e326){const _0x27e6e5=this[_0x345b80(0x176)]['shift']();this[_0x345b80(0x176)][_0x345b80(0x25d)](_0x27e6e5);const _0x550e6a='%1Taunt'[_0x345b80(0x1ff)](_0x27e6e5);if(this[_0x345b80(0x211)][_0x550e6a]()){if(_0x345b80(0xe9)===_0x345b80(0x194)){if(!_0x39dcb7)return![];return _0x15c3ce[_0x345b80(0x232)][_0x345b80(0x145)](/<BYPASS HIGHEST (?:AGGRO|ENMITY|THREAT)>/i);}else{const _0x5e92b9=_0x345b80(0x1cc)[_0x345b80(0x1ff)](_0x27e6e5),_0x2dff32=Sprite_Battler[_0x5e92b9];if(_0x2dff32)return _0x2dff32;}}_0x43e326--;}return Sprite_Battler[_0x345b80(0xc4)];},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0xe3)]=Sprite_Actor[_0x20bac4(0x106)]['createStateSprite'],Sprite_Actor[_0x20bac4(0x106)]['createStateSprite']=function(){const _0x3c7ab2=_0x20bac4;VisuMZ[_0x3c7ab2(0x22d)][_0x3c7ab2(0xe3)][_0x3c7ab2(0x1b0)](this),this[_0x3c7ab2(0x1f4)]();},Sprite_Actor[_0x20bac4(0x106)][_0x20bac4(0x1f4)]=function(){const _0x59061c=_0x20bac4;if(this['constructor']!==Sprite_Actor)return;if(!this[_0x59061c(0x13b)]())return;if(!SceneManager[_0x59061c(0x240)]())return;const _0x3a99f0=VisuMZ['AggroControlSystem'][_0x59061c(0x1e3)][_0x59061c(0x230)],_0x50bd5f=new Sprite_Gauge();_0x50bd5f['anchor']['x']=_0x3a99f0[_0x59061c(0xee)],_0x50bd5f[_0x59061c(0xd6)]['y']=_0x3a99f0[_0x59061c(0xe2)];const _0x57374f=Sprite_Gauge[_0x59061c(0x106)][_0x59061c(0xf6)]();_0x50bd5f['scale']['x']=_0x50bd5f[_0x59061c(0x162)]['y']=_0x3a99f0[_0x59061c(0x220)],this[_0x59061c(0x13c)]=_0x50bd5f,this[_0x59061c(0xea)](_0x50bd5f);},Sprite_Actor['prototype'][_0x20bac4(0x13b)]=function(){const _0x39dc2f=_0x20bac4;if(Imported['VisuMZ_1_BattleCore']&&this[_0x39dc2f(0x214)]===Sprite_SvEnemy)return![];return ConfigManager[_0x39dc2f(0x14e)]&&VisuMZ[_0x39dc2f(0x22d)]['Settings'][_0x39dc2f(0x230)][_0x39dc2f(0x1a7)];},VisuMZ['AggroControlSystem'][_0x20bac4(0x188)]=Sprite_Actor['prototype'][_0x20bac4(0x1fd)],Sprite_Actor[_0x20bac4(0x106)][_0x20bac4(0x1fd)]=function(){const _0x3e5ccd=_0x20bac4;VisuMZ[_0x3e5ccd(0x22d)][_0x3e5ccd(0x188)]['call'](this),this['updateAggroGaugeSprite']();},Sprite_Actor['prototype'][_0x20bac4(0xcb)]=function(){const _0xd81616=_0x20bac4;if(!this[_0xd81616(0x211)])return;if(!this[_0xd81616(0x13c)])return;const _0x4a09f2=VisuMZ[_0xd81616(0x22d)]['Settings'][_0xd81616(0x230)],_0x4d0513=this[_0xd81616(0x13c)];let _0x2a2424=_0x4a09f2['OffsetX'];this['_battler'][_0xd81616(0x1ca)]&&(_0xd81616(0x185)===_0xd81616(0x256)?this[_0xd81616(0x142)]=0xff:_0x2a2424+=this[_0xd81616(0x211)][_0xd81616(0x1ca)]());let _0x3a89e5=_0x4a09f2[_0xd81616(0x24e)];this[_0xd81616(0x211)][_0xd81616(0x20b)]&&(_0xd81616(0x11d)===_0xd81616(0x11d)?_0x3a89e5+=this[_0xd81616(0x211)][_0xd81616(0x20b)]():_0x231996[_0xd81616(0x22d)][_0xd81616(0x1cb)][_0xd81616(0x1b0)](this));_0x4d0513['x']=_0x2a2424,_0x4d0513['y']=-this[_0xd81616(0xf4)]+_0x3a89e5;this[_0xd81616(0x211)]&&_0x4d0513[_0xd81616(0x238)]!==_0xd81616(0x1b4)&&(_0x4d0513[_0xd81616(0x260)]=!![],_0x4d0513['setup'](this[_0xd81616(0x211)],_0xd81616(0x1b4)));if(this[_0xd81616(0x162)]['x']<0x0){if(_0xd81616(0xcf)===_0xd81616(0x16b)){const _0x115e0f='provoke-line-color';this[_0xd81616(0xde)]=this[_0xd81616(0xde)]||{};if(this['_colorCache'][_0x115e0f])return this[_0xd81616(0xde)][_0x115e0f];const _0x25d00e=_0x2ced41[_0xd81616(0x22d)][_0xd81616(0x1e3)][_0xd81616(0x1c0)]['LineColor'];return this[_0xd81616(0x143)](_0x115e0f,_0x25d00e);}else _0x4d0513[_0xd81616(0x162)]['x']=-Math[_0xd81616(0x1b2)](_0x4d0513['scale']['x']);}},Sprite_Gauge['prototype'][_0x20bac4(0x155)]=function(){const _0x5b1ca4=_0x20bac4;return this[_0x5b1ca4(0x211)]&&this[_0x5b1ca4(0x238)]==='aggro';},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x1a5)]=Sprite_Gauge[_0x20bac4(0x106)]['gaugeX'],Sprite_Gauge[_0x20bac4(0x106)][_0x20bac4(0x14c)]=function(){const _0x17a9a0=_0x20bac4;return this[_0x17a9a0(0x155)]()?0x0:VisuMZ[_0x17a9a0(0x22d)]['Sprite_Gauge_gaugeX'][_0x17a9a0(0x1b0)](this);},VisuMZ[_0x20bac4(0x22d)]['Sprite_Gauge_gaugeRate']=Sprite_Gauge[_0x20bac4(0x106)][_0x20bac4(0x1e7)],Sprite_Gauge[_0x20bac4(0x106)][_0x20bac4(0x1e7)]=function(){const _0x2d9bde=_0x20bac4;let _0x4dfc0b=VisuMZ[_0x2d9bde(0x22d)]['Sprite_Gauge_gaugeRate'][_0x2d9bde(0x1b0)](this);if(this[_0x2d9bde(0x155)]()&&this[_0x2d9bde(0x211)]){if(_0x2d9bde(0xdc)!==_0x2d9bde(0xdc))return this['traitObjects']()['some'](_0x1f90b1=>_0x1f90b1&&_0x1f90b1[_0x2d9bde(0x232)][_0x2d9bde(0x145)](/<(?:TAUNT|CERTAIN TAUNT|CERTAIN HIT TAUNT|ALL TAUNT)>/i));else{if(this[_0x2d9bde(0x211)][_0x2d9bde(0x1c3)]())return 0x0;if(this[_0x2d9bde(0x211)][_0x2d9bde(0x12f)]()&&this[_0x2d9bde(0x211)][_0x2d9bde(0xd4)]()[_0x2d9bde(0xfe)]()[_0x2d9bde(0x1bb)]===0x1)return 0x1;}}return _0x4dfc0b[_0x2d9bde(0xe8)](0x0,0x1);},VisuMZ['AggroControlSystem'][_0x20bac4(0x16d)]=Sprite_Gauge['prototype'][_0x20bac4(0x14a)],Sprite_Gauge['prototype'][_0x20bac4(0x14a)]=function(){const _0x45cf2b=_0x20bac4;if(this[_0x45cf2b(0x155)]()){if('Cvjlo'!==_0x45cf2b(0x234))this['_mainSprite']=_0x1d2b95,_0x316971['prototype'][_0x45cf2b(0x175)][_0x45cf2b(0x1b0)](this),this[_0x45cf2b(0x1af)](),this[_0x45cf2b(0x25a)]();else return this[_0x45cf2b(0x1b8)]();}else return VisuMZ[_0x45cf2b(0x22d)][_0x45cf2b(0x16d)][_0x45cf2b(0x1b0)](this);},Sprite_Gauge[_0x20bac4(0x106)][_0x20bac4(0x1b8)]=function(){const _0x31045d=_0x20bac4,_0x162ce3=this['_battler']['friendsUnit'](),_0x4087bc=this[_0x31045d(0x211)]['tgr']-_0x162ce3[_0x31045d(0x138)](),_0x5462c2=_0x162ce3[_0x31045d(0x17e)]()-_0x162ce3[_0x31045d(0x138)]();if(_0x4087bc>=_0x5462c2)return 0x64;return _0x4087bc/Math['max'](_0x5462c2,0x1)*0x64;},VisuMZ['AggroControlSystem'][_0x20bac4(0xe6)]=Sprite_Gauge['prototype'][_0x20bac4(0x202)],Sprite_Gauge[_0x20bac4(0x106)][_0x20bac4(0x202)]=function(){const _0x25a030=_0x20bac4;if(this['isAggroType']()){if(_0x25a030(0x22e)!==_0x25a030(0x1d4))return this['currentMaxValueAggroControl']();else{const _0x3b3b0e='aggro-gauge-color-2';this[_0x25a030(0xde)]=this[_0x25a030(0xde)]||{};if(this[_0x25a030(0xde)][_0x3b3b0e])return this[_0x25a030(0xde)][_0x3b3b0e];const _0x501785=_0xbba4b0[_0x25a030(0x22d)][_0x25a030(0x1e3)][_0x25a030(0x230)]['GaugeColor2'];return this[_0x25a030(0x143)](_0x3b3b0e,_0x501785);}}else return VisuMZ[_0x25a030(0x22d)][_0x25a030(0xe6)][_0x25a030(0x1b0)](this);},Sprite_Gauge['prototype'][_0x20bac4(0x181)]=function(){return 0x64;},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x1ed)]=Sprite_Gauge[_0x20bac4(0x106)]['gaugeColor1'],Sprite_Gauge[_0x20bac4(0x106)][_0x20bac4(0x116)]=function(){const _0x2e4810=_0x20bac4;if(this[_0x2e4810(0x155)]()){if(_0x2e4810(0x231)!==_0x2e4810(0x136))return ColorManager[_0x2e4810(0x133)]();else{const _0x54085c=this[_0x2e4810(0x211)][_0x2e4810(0xd4)](),_0x1d98d2=this[_0x2e4810(0x211)][_0x2e4810(0x107)]-_0x54085c[_0x2e4810(0x138)](),_0x101cce=_0x54085c[_0x2e4810(0x17e)]()-_0x54085c[_0x2e4810(0x138)]();if(_0x1d98d2>=_0x101cce)return 0x64;return _0x1d98d2/_0x9d5c08['max'](_0x101cce,0x1)*0x64;}}else return VisuMZ[_0x2e4810(0x22d)]['Sprite_Gauge_gaugeColor1'][_0x2e4810(0x1b0)](this);},VisuMZ['AggroControlSystem'][_0x20bac4(0x252)]=Sprite_Gauge['prototype'][_0x20bac4(0x11f)],Sprite_Gauge[_0x20bac4(0x106)]['gaugeColor2']=function(){const _0x2779e7=_0x20bac4;return this[_0x2779e7(0x155)]()?ColorManager[_0x2779e7(0x10f)]():VisuMZ[_0x2779e7(0x22d)][_0x2779e7(0x252)][_0x2779e7(0x1b0)](this);},VisuMZ['AggroControlSystem'][_0x20bac4(0xda)]=Sprite_Gauge['prototype'][_0x20bac4(0x1fd)],Sprite_Gauge['prototype'][_0x20bac4(0x1fd)]=function(){const _0x2c7abc=_0x20bac4;VisuMZ[_0x2c7abc(0x22d)][_0x2c7abc(0xda)][_0x2c7abc(0x1b0)](this),this[_0x2c7abc(0x206)]();},Sprite_Gauge[_0x20bac4(0x106)][_0x20bac4(0x206)]=function(){const _0x3f23ae=_0x20bac4;if(!this[_0x3f23ae(0x155)]())return;if(!Imported[_0x3f23ae(0x222)])return;const _0xc9a302=this[_0x3f23ae(0x211)][_0x3f23ae(0x21b)]();if(this[_0x3f23ae(0x10a)]){if(_0x3f23ae(0x18d)===_0x3f23ae(0x247))return _0x2845a6(_0x76b59b['$1'])*0.01;else this[_0x3f23ae(0x142)]=0xff;}else _0xc9a302&&_0xc9a302[_0x3f23ae(0x142)]>0x0?_0x3f23ae(0x1d6)!==_0x3f23ae(0x1d6)?this[_0x3f23ae(0x167)]():this[_0x3f23ae(0x142)]=0xff:this['opacity']=0x0;},VisuMZ[_0x20bac4(0x22d)]['Sprite_Gauge_drawValue']=Sprite_Gauge['prototype'][_0x20bac4(0x152)],Sprite_Gauge[_0x20bac4(0x106)][_0x20bac4(0x152)]=function(){const _0x21e6dc=_0x20bac4;if(this[_0x21e6dc(0x155)]())return;VisuMZ['AggroControlSystem'][_0x21e6dc(0x18b)][_0x21e6dc(0x1b0)](this);};function _0x548a(){const _0x2889e3=['VisibleGauge','bypassTaunt','isMagical','_targetIndex','baseAggro','partsSize','_spriteset','BattleLayout','initMembers','call','ActorSetAggro','abs','random','aggro','parentContainer','drawCircle','bypassHighestAggro','currentValueAggroControl','inputtingAction','lowestTgrMember','length','provoke-line-color','physicalTaunt','isBypassHighestAggro','rJsQT','Provoke','PartsSize','AggroPerDmg','isDead','executeHpDamageAggroControl','findTgrMember','euMXr','QkfYi','Window_Options_addGeneralOptions','aggroMultiplier','battleUIOffsetX','Window_BattleEnemy_refresh','_%1TauntAnimation','EnemyIndex','applyItemUserEffectAggroControl','magicalTauntMembers','_lowestTgrMember','_tauntAnimationTimer','textColor','invokeMagicReflection','WwBxf','VisuMZ_0_CoreEngine','uVlgr','onBattleStart','Opacity','item','createBattleField','BattleManager_invokeMagicReflection','randomTauntTarget','%1\x27s\x20version\x20does\x20not\x20match\x20plugin\x27s.\x20Please\x20update\x20it\x20in\x20the\x20Plugin\x20Manager.','ActorChangeAggro','provoker','UKLcj','RmUCm','round','Settings','BDlRG','PnZLp','applyItemUserEffect','gaugeRate','_statusWindow','addAggroControlSystemCommands','_battleField','HITTYPE_MAGICAL','_animationCycleTime','Sprite_Gauge_gaugeColor1','Game_Action_executeHpDamage','log','phpPW','map','itemRectWithPadding','user','createAggroGauge','ZdqAY','highestTgrMember','EvKFU','gaugeHeight','bitmapHeight','AddOption','randomTarget','xtpVb','update','updateSubPositions','format','Vvvlx','provokeBitmap','currentMaxValue','AmFqW','aggro-gauge-color-1','ConfigManager_applyData','updateOpacityAggroControl','description','removeState','_targetX','optDisplayTp','battleUIOffsetY','OgDpm','createBattleFieldAggroControl','Game_Action_applyItemUserEffect','arcHeight','traitObjects','_battler','LineColor','blendMode','constructor','cBsyf','_magicalTauntAnimation','AniMagical','Sprite_Battler_initMembers','fvxYJ','DvJhz','battler','clearProvokers','stateHasProvoke','36WpNSsb','onBattleEnd','Scale','_homeX','VisuMZ_1_BattleCore','magical','createInnerSprite','makeProvokeTarget','_scene','tauntTargetsForAlive','kgGvu','isTargetHighestTGR','bind','smoothTarget','parse','AggroControlSystem','MQcpP','Game_Battler_onBattleEnd','Aggro','SdVNe','note','addAggroControlSystemAggroCommand','Cvjlo','MirrorActorAni','XEQjE','updateOpacity','_statusType','setup','registerCommand','BQnrL','isPhysical','fallu','members','provokeLineColor','isSceneBattle','battleLayoutStyle','_targetY','createProvokeHeightOrigin','_mainSprite','physicalTauntMembers','VisuMZ_2_BattleSystemATB','GWPQn','taunting','iXlAc','ShowFacesListStyle','aggro-gauge-color-2','Sprite_Battler_setBattler','BattleManager_invokeCounterAttack','OffsetY','Scene_Options_maxCommands','2898462wgSVms','clearTgrCache','Sprite_Gauge_gaugeColor2','265lLhqJx','convertStringToBattleTarget','index','uBwhj','jrYyz','Game_BattlerBase_refresh','8KtIRAZ','createChildSprites','_provokeContainer','checkCacheKey','push','addCommand','55260izEMGj','visible','enGMd','_homeY','PhFpi','maxOpacity','actor%1-gauge-aggro','filter','pow','hitType','ActorID','version','list','randomInt','kPXhd','showVisualAtbGauge','isCertainHit','_certainHitTauntAnimation','ARRAYEVAL','return\x200','min','ShowAnimation','Spriteset_Battle_createBattleField','leftwardAnimation','updateAggroGaugeSprite','pZAbQ','updateAggroControl','applyData','FfTmQ','padding','_provokeSprite','placeActorName','setBattler','friendsUnit','NUM','anchor','_counterAttackingTarget','1154850mNwbZn','isAggroAffected','Sprite_Gauge_update','Game_Battler_onBattleStart','cfcQl','XahUu','_colorCache','lNGUM','#%1','width','AnchorY','Sprite_Actor_createStateSprite','max','ARRAYJSON','Sprite_Gauge_currentMaxValue','HITTYPE_PHYSICAL','clamp','VDhFL','addChild','GaugeColor2','_mirrorActorTauntAnimations','FUNC','AnchorX','makeData','sparam','maxSprites','154749juxdpp','ARRAYFUNC','height','isProvokeAffected','bitmapWidth','isPlaytest','certainHitTauntMembers','removeDeadProvokerStates','Game_BattlerBase_sparam','iconWidth','bypassProvoke','addAggroControlSystemProvokeCommand','aliveMembers','isAggroGaugeShown','8056rhiDpJ','exit','xLbyU','gainAggro','ARRAYSTRUCT','certainHitTaunt','prototype','tgr','targetsForAlive','some','_menuAggroType','boxWidth','StatusGauge','Game_BattlerBase_initMembers','Battle\x20Actor\x20%1','aggroGaugeColor2','yEDvS','addState','states','isActor','children','PriorityHighest','gaugeColor1','_provokeBitmap','scope','getColor','HeightOrigin','_aggro','isShowPriorityLines','LStbQ','JSON','gaugeColor2','applyProvokeFilters','provokeHeightOrigin','ConvertParams','AggroPerHeal','MuteAnimations','cHsrm','convertBattleTargetToString','_cache','wqeoM','drawAggroGauge','Taunt','updateChildrenOpacity','provokeOrigin','_highestTgrMember','enemy','isAlive','inBattle','CycleTime','certainHit','aggroGaugeColor1','_opacitySpeed','executeHpDamage','dsIoS','maxCommands','tgrMin','opponentsUnit','11syLEAU','isAggroGaugeVisible','_aggroGaugeSprite','Game_Action_applyGlobal','Battle\x20Enemy\x20%1','_muteTauntAnimations','applyTauntFilters','BEZhq','opacity','getColorDataFromPluginParameters','initTauntAnimations','match','endAction','VaOBY','Sprite_Battler_update','ShowLines','currentValue','createProvokeSprite','gaugeX','target','aggroGauge','Parts','addGeneralOptions','%1\x20is\x20missing\x20a\x20required\x20plugin.\x0aPlease\x20install\x20%2\x20into\x20the\x20Plugin\x20Manager.','drawValue','trim','applySubjectAggro','isAggroType','BlendMode','isSideView','8422560YDYdKL','addChildAt','initAggroControl','magicalTaunt','JjOYw','Game_Battler_addState','placeGauge','isBypassProvoke','nameX','_damageContainer','scale','includes','Spriteset_Battle_update','OpacitySpeed','applyProvokeEffect','clearAggro','reduce','indexOf','battleAggro','VHSIg','BattleCore','Sprite_Gauge_currentValue','Sprite_Battler_initialize','applyGlobal','refresh','2642XCsCTQ','Game_Action_targetsForAlive','isTauntAffected','matchTauntType','initialize','_tauntAnimationCycle','aggroGaugeX','boxHeight','loseAggro','updateTauntAnimations','updateBattlerPositions','itemRect','actor','tgrMax','HITTYPE_CERTAIN','isAtbGaugeVisible','currentMaxValueAggroControl','EVAL','xOivf','OptionName','UpeLv','startNewTauntAnimation','_physicalTauntAnimation','Sprite_Actor_update','nameY','isEnemy','Sprite_Gauge_drawValue','subject','GOUxQ','vaKil','pbLjk','name','physical','_provoker','ABymb','dVshd','_customModified','EnemySetAggro','Window_StatusBase_placeActorName','toUpperCase','getNextTauntAnimation','394unfUda','_sprites','ConfigManager_makeData','sortEnemies','_enemies','isBypassTaunt','actorId','setAggro','BattleManager_endAction','alwaysTargetHighestAggro','lfwNZ','Sprite_Gauge_gaugeX','ARRAYNUM'];_0x548a=function(){return _0x2889e3;};return _0x548a();}function _0x33c1(_0x4d7c26,_0x580452){const _0x548a51=_0x548a();return _0x33c1=function(_0x33c19f,_0x462a28){_0x33c19f=_0x33c19f-0xc4;let _0x3e08d8=_0x548a51[_0x33c19f];return _0x3e08d8;},_0x33c1(_0x4d7c26,_0x580452);}function Sprite_ProvokeTrail(){const _0x3956b8=_0x20bac4;this[_0x3956b8(0x175)](...arguments);}Sprite_ProvokeTrail['prototype']=Object['create'](Sprite[_0x20bac4(0x106)]),Sprite_ProvokeTrail['prototype']['constructor']=Sprite_ProvokeTrail,Sprite_ProvokeTrail[_0x20bac4(0x106)][_0x20bac4(0x175)]=function(_0x215585){const _0xb94924=_0x20bac4;this[_0xb94924(0x244)]=_0x215585,Sprite['prototype'][_0xb94924(0x175)][_0xb94924(0x1b0)](this),this['initMembers'](),this[_0xb94924(0x25a)]();},Sprite_ProvokeTrail[_0x20bac4(0x106)][_0x20bac4(0x1af)]=function(){const _0x2d585e=_0x20bac4,_0x860188=VisuMZ[_0x2d585e(0x22d)][_0x2d585e(0x1e3)][_0x2d585e(0x1c0)];this[_0x2d585e(0xd6)]['x']=0.5,this[_0x2d585e(0xd6)]['y']=0.5,this[_0x2d585e(0x221)]=0x0,this[_0x2d585e(0x262)]=0x0,this[_0x2d585e(0x209)]=0x0,this[_0x2d585e(0x242)]=0x0,this[_0x2d585e(0x142)]=0x0,this['_opacitySpeed']=_0x860188[_0x2d585e(0x165)],this['blendMode']=_0x860188[_0x2d585e(0x156)];},Sprite_ProvokeTrail[_0x20bac4(0x106)][_0x20bac4(0xf1)]=function(){const _0x5e7039=_0x20bac4;return VisuMZ['AggroControlSystem']['Settings'][_0x5e7039(0x1c0)][_0x5e7039(0x14f)];},Sprite_ProvokeTrail[_0x20bac4(0x106)]['partsSize']=function(){const _0x1e6c5c=_0x20bac4;return VisuMZ['AggroControlSystem'][_0x1e6c5c(0x1e3)][_0x1e6c5c(0x1c0)][_0x1e6c5c(0x1c1)]/0x64;},Sprite_ProvokeTrail[_0x20bac4(0x106)]['createChildSprites']=function(){const _0xf4a150=_0x20bac4;this[_0xf4a150(0x19b)]=[];let _0x2b8db0=0x0;for(let _0x3e03cd=0x0;_0x3e03cd<=this[_0xf4a150(0xf1)]();_0x3e03cd++){if(_0xf4a150(0xdd)===_0xf4a150(0x141))return this[_0xf4a150(0x244)]['constructor']===_0x3ca675;else{const _0x1cbda8=new Sprite();_0x1cbda8['bitmap']=ImageManager[_0xf4a150(0x201)](),_0x1cbda8[_0xf4a150(0xd6)]['x']=0.5,_0x1cbda8[_0xf4a150(0xd6)]['y']=0.5,_0x1cbda8[_0xf4a150(0x162)]['x']=_0x1cbda8[_0xf4a150(0x162)]['y']=this[_0xf4a150(0x1ac)](),_0x1cbda8[_0xf4a150(0x142)]=_0x2b8db0,_0x1cbda8[_0xf4a150(0x213)]=this[_0xf4a150(0x213)],this['addChild'](_0x1cbda8),this[_0xf4a150(0x19b)]['push'](_0x1cbda8),_0x2b8db0+=this[_0xf4a150(0x134)];if(_0x2b8db0>=0xff)_0x2b8db0=0x0;}}},Sprite_ProvokeTrail[_0x20bac4(0x106)][_0x20bac4(0xca)]=function(){const _0x2c257d=_0x20bac4;return this[_0x2c257d(0x244)][_0x2c257d(0x214)]===Sprite_Actor;},Sprite_ProvokeTrail[_0x20bac4(0x106)][_0x20bac4(0x1b5)]=function(){const _0x28eb38=_0x20bac4;return SceneManager['_scene'][_0x28eb38(0x1ad)]['_provokeContainer'];},Sprite_ProvokeTrail[_0x20bac4(0x106)]['update']=function(){const _0xd8ed62=_0x20bac4;Sprite[_0xd8ed62(0x106)][_0xd8ed62(0x1fd)][_0xd8ed62(0x1b0)](this),this[_0xd8ed62(0x17b)](),this['updateSubPositions'](),this[_0xd8ed62(0x237)](),this['updateChildrenOpacity']();},Sprite_ProvokeTrail[_0x20bac4(0x106)]['heightOrigin']=function(){const _0x34fcdd=_0x20bac4;return VisuMZ['AggroControlSystem']['Settings'][_0x34fcdd(0x1c0)][_0x34fcdd(0x11a)];},Sprite_ProvokeTrail[_0x20bac4(0x106)][_0x20bac4(0x17b)]=function(){const _0x18a87a=_0x20bac4;if(!this[_0x18a87a(0x244)]['_battler'])return;if(!this[_0x18a87a(0x244)][_0x18a87a(0x211)][_0x18a87a(0x1df)]())return;const _0x53835f=this['_mainSprite'][_0x18a87a(0x211)][_0x18a87a(0x1df)]()[_0x18a87a(0x21b)]();if(!_0x53835f)return;const _0x1f5fd2=this['_mainSprite'][_0x18a87a(0x211)][_0x18a87a(0x121)](),_0xe256b6=this['_mainSprite'][_0x18a87a(0x211)]['provoker']()[_0x18a87a(0x121)]();this[_0x18a87a(0x221)]=this[_0x18a87a(0x244)]['x'],this['_homeY']=this['_mainSprite']['y']-this[_0x18a87a(0x244)][_0x18a87a(0xf4)]*_0x1f5fd2,this[_0x18a87a(0x209)]=_0x53835f['x'],this[_0x18a87a(0x242)]=_0x53835f['y']-_0x53835f[_0x18a87a(0xf4)]*_0xe256b6,this[_0x18a87a(0x221)]+=Math[_0x18a87a(0x1e2)]((Graphics[_0x18a87a(0xe1)]-Graphics[_0x18a87a(0x10b)])/0x2),this[_0x18a87a(0x262)]+=Math[_0x18a87a(0x1e2)]((Graphics['height']-Graphics[_0x18a87a(0x178)])/0x2),this[_0x18a87a(0x209)]+=Math[_0x18a87a(0x1e2)]((Graphics[_0x18a87a(0xe1)]-Graphics[_0x18a87a(0x10b)])/0x2),this['_targetY']+=Math[_0x18a87a(0x1e2)]((Graphics[_0x18a87a(0xf4)]-Graphics[_0x18a87a(0x178)])/0x2);if(!$gameSystem[_0x18a87a(0x157)]()){if(_0x53835f[_0x18a87a(0x211)][_0x18a87a(0x113)]()){if(_0x18a87a(0x215)==='ZxlEC'){const _0x552454=_0x28e19e(_0x2c85e9['$1']);this[_0x18a87a(0x18c)]()['gainAggro'](_0x552454);}else visible=!![],this[_0x18a87a(0x209)]+=SceneManager['_scene'][_0x18a87a(0x1e8)]['x'],this[_0x18a87a(0x242)]+=SceneManager[_0x18a87a(0x226)][_0x18a87a(0x1e8)]['y'];}else _0x53835f['_battler'][_0x18a87a(0x18a)]()&&(_0x18a87a(0x1e4)===_0x18a87a(0x228)?_0x6df468(this[_0x18a87a(0x14b)]['bind'](this),0x3e8):(visible=!![],this[_0x18a87a(0x221)]+=SceneManager[_0x18a87a(0x226)][_0x18a87a(0x1e8)]['x'],this[_0x18a87a(0x262)]+=SceneManager['_scene'][_0x18a87a(0x1e8)]['y']));}},Sprite_ProvokeTrail[_0x20bac4(0x106)][_0x20bac4(0x20f)]=function(){const _0x29322d=_0x20bac4;return VisuMZ[_0x29322d(0x22d)][_0x29322d(0x1e3)][_0x29322d(0x1c0)]['ArcHeight'];},Sprite_ProvokeTrail[_0x20bac4(0x106)][_0x20bac4(0x1fe)]=function(){const _0x11e068=_0x20bac4;if(!this[_0x11e068(0x244)][_0x11e068(0x211)])return;if(!this['_mainSprite'][_0x11e068(0x211)]['provoker']())return;if(!this[_0x11e068(0x19b)])return;if(this[_0x11e068(0x19b)][_0x11e068(0x1bb)]<=0x0)return;const _0x72ef62=(this[_0x11e068(0x209)]-this['_homeX'])/this[_0x11e068(0xf1)](),_0x1173e7=(this[_0x11e068(0x242)]-this[_0x11e068(0x262)])/this['maxSprites']();for(let _0x2209a6=0x0;_0x2209a6<=this[_0x11e068(0xf1)]();_0x2209a6++){if(_0x11e068(0x125)===_0x11e068(0x18f))_0x444fb9(_0x2af0cc);else{const _0x1404ff=this[_0x11e068(0x19b)][_0x2209a6];if(!_0x1404ff)continue;_0x1404ff['x']=this[_0x11e068(0x221)]+_0x72ef62*_0x2209a6;const _0x510fe9=this[_0x11e068(0xf1)]()-_0x2209a6,_0x135d4b=this[_0x11e068(0xf1)]()/0x2,_0x45b3b3=this['arcHeight'](),_0x7b809c=-_0x45b3b3/Math['pow'](_0x135d4b,0x2),_0x4be0fa=_0x7b809c*Math[_0x11e068(0x267)](_0x510fe9-_0x135d4b,0x2)+_0x45b3b3;_0x1404ff['y']=this[_0x11e068(0x262)]+_0x1173e7*_0x2209a6-_0x4be0fa;}}},Sprite_ProvokeTrail[_0x20bac4(0x106)][_0x20bac4(0x264)]=function(){const _0x46d8c5=_0x20bac4;return VisuMZ['AggroControlSystem']['Settings'][_0x46d8c5(0x1c0)][_0x46d8c5(0x1d8)];},Sprite_ProvokeTrail[_0x20bac4(0x106)]['updateOpacity']=function(){const _0x23f84b=_0x20bac4,_0x57b42c=this['_mainSprite'][_0x23f84b(0x211)];if(!_0x57b42c)this[_0x23f84b(0x142)]=0x0;else _0x57b42c[_0x23f84b(0x12f)]()&&_0x57b42c[_0x23f84b(0x1df)]()?this[_0x23f84b(0x142)]=0xff:_0x23f84b(0x261)!==_0x23f84b(0x261)?this[_0x23f84b(0x186)]():this[_0x23f84b(0x142)]=0x0;},Sprite_ProvokeTrail['prototype'][_0x20bac4(0x12b)]=function(){const _0x336a96=_0x20bac4;if(!this[_0x336a96(0x244)]['_battler'])return;if(!this[_0x336a96(0x244)][_0x336a96(0x211)][_0x336a96(0x1df)]())return;if(!this[_0x336a96(0x19b)])return;if(this[_0x336a96(0x19b)][_0x336a96(0x1bb)]<=0x0)return;for(let _0x382a4f=0x0;_0x382a4f<=this[_0x336a96(0xf1)]();_0x382a4f++){const _0x8ce1cd=this[_0x336a96(0x19b)][this[_0x336a96(0xca)]()?this[_0x336a96(0xf1)]()-_0x382a4f:_0x382a4f];if(!_0x8ce1cd)continue;_0x8ce1cd[_0x336a96(0x142)]-=this[_0x336a96(0x134)];if(_0x8ce1cd[_0x336a96(0x142)]<=0x0)_0x8ce1cd['opacity']=0xff;}},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0xc9)]=Spriteset_Battle['prototype']['createBattleField'],Spriteset_Battle[_0x20bac4(0x106)][_0x20bac4(0x1da)]=function(){const _0x2bc876=_0x20bac4;VisuMZ[_0x2bc876(0x22d)][_0x2bc876(0xc9)][_0x2bc876(0x1b0)](this),this[_0x2bc876(0x20d)]();},Spriteset_Battle[_0x20bac4(0x106)][_0x20bac4(0x20d)]=function(){const _0x383394=_0x20bac4;if(!Imported[_0x383394(0x222)])return;const _0x42a7ba=this[_0x383394(0x1ea)]['x'],_0x49e019=this[_0x383394(0x1ea)]['y'],_0x10d9d4=this[_0x383394(0x1ea)][_0x383394(0xe1)],_0x1b75b3=this[_0x383394(0x1ea)][_0x383394(0xf4)];this['_provokeContainer']=new Sprite(),this[_0x383394(0x25b)]['setFrame'](0x0,0x0,_0x10d9d4,_0x1b75b3),this[_0x383394(0x25b)]['x']=_0x42a7ba,this['_provokeContainer']['y']=_0x49e019;if(Imported[_0x383394(0x222)]){const _0x3f60e7=this[_0x383394(0x114)][_0x383394(0x169)](this['_damageContainer']);this[_0x383394(0x159)](this[_0x383394(0x25b)],_0x3f60e7);}else this['addChild'](this[_0x383394(0x25b)]);},VisuMZ[_0x20bac4(0x22d)][_0x20bac4(0x164)]=Spriteset_Battle['prototype']['update'],Spriteset_Battle['prototype']['update']=function(){const _0x536640=_0x20bac4;VisuMZ[_0x536640(0x22d)][_0x536640(0x164)]['call'](this),this[_0x536640(0xcd)]();},Spriteset_Battle[_0x20bac4(0x106)][_0x20bac4(0xcd)]=function(){const _0x524827=_0x20bac4;if(!this[_0x524827(0x25b)])return;if(!this[_0x524827(0x161)])return;this['_provokeContainer']['x']=this['_damageContainer']['x'],this[_0x524827(0x25b)]['y']=this[_0x524827(0x161)]['y'];},VisuMZ['AggroControlSystem'][_0x20bac4(0x1cb)]=Window_BattleEnemy[_0x20bac4(0x106)][_0x20bac4(0x170)],Window_BattleEnemy[_0x20bac4(0x106)]['refresh']=function(){const _0x155d2d=_0x20bac4;if(this[_0x155d2d(0x120)]()){if(_0x155d2d(0x110)!==_0x155d2d(0x110))return[_0x3a9ab5];else Imported[_0x155d2d(0x222)]&&this[_0x155d2d(0x19d)](),Window_Selectable['prototype']['refresh'][_0x155d2d(0x1b0)](this);}else{if(this[_0x155d2d(0x140)]()){if(_0x155d2d(0x219)===_0x155d2d(0x219))Imported[_0x155d2d(0x222)]&&this['sortEnemies'](),Window_Selectable[_0x155d2d(0x106)]['refresh']['call'](this);else{if(this['isAggroType']())return;_0x9bed02[_0x155d2d(0x22d)]['Sprite_Gauge_drawValue'][_0x155d2d(0x1b0)](this);}}else VisuMZ[_0x155d2d(0x22d)][_0x155d2d(0x1cb)]['call'](this);}},Window_BattleEnemy[_0x20bac4(0x106)][_0x20bac4(0x120)]=function(){const _0x3094bc=_0x20bac4,_0x1507fa=BattleManager[_0x3094bc(0x1b9)](),_0x54274a=BattleManager['actor']();if(!_0x1507fa)return![];if(!_0x54274a)return![];if(DataManager['isBypassProvoke'](_0x1507fa['item']()))return![];if(_0x54274a[_0x3094bc(0xfc)]())return![];if(_0x54274a[_0x3094bc(0xf5)]()){if(_0x3094bc(0x128)==='wqeoM')return this[_0x3094bc(0x19e)]=[_0x54274a[_0x3094bc(0x1df)]()],!![];else this[_0x3094bc(0x142)]=0x0;}else return![];},Window_BattleEnemy[_0x20bac4(0x106)][_0x20bac4(0x140)]=function(){const _0x112846=_0x20bac4,_0x4364ce=BattleManager[_0x112846(0x1b9)](),_0x515a20=BattleManager[_0x112846(0x17d)](),_0x2b7b59=$gameTroop;if(!_0x4364ce)return![];if(!_0x515a20)return![];if(!_0x4364ce[_0x112846(0x1d9)]())return![];if(DataManager[_0x112846(0x19f)](_0x4364ce['item']()))return![];if(_0x515a20['bypassTaunt']())return![];if(_0x4364ce[_0x112846(0x23c)]()&&_0x2b7b59['physicalTauntMembers']()['length']>0x0)this[_0x112846(0x19e)]=_0x2b7b59['physicalTauntMembers']();else{if(_0x4364ce[_0x112846(0x1a9)]()&&_0x2b7b59[_0x112846(0x1cf)]()['length']>0x0)this[_0x112846(0x19e)]=_0x2b7b59[_0x112846(0x1cf)]();else{if(_0x4364ce['isCertainHit']()&&_0x2b7b59[_0x112846(0xf8)]()[_0x112846(0x1bb)]>0x0)this[_0x112846(0x19e)]=_0x2b7b59[_0x112846(0xf8)]();else{if(_0x112846(0x200)!==_0x112846(0x200))this[_0x112846(0x175)](...arguments);else return![];}}}return!![];},VisuMZ[_0x20bac4(0x22d)]['Window_Options_addGeneralOptions']=Window_Options[_0x20bac4(0x106)][_0x20bac4(0x150)],Window_Options[_0x20bac4(0x106)][_0x20bac4(0x150)]=function(){const _0x369002=_0x20bac4;VisuMZ['AggroControlSystem'][_0x369002(0x1c8)][_0x369002(0x1b0)](this),this[_0x369002(0x1e9)]();},Window_Options[_0x20bac4(0x106)][_0x20bac4(0x1e9)]=function(){const _0x49686c=_0x20bac4;if(VisuMZ[_0x49686c(0x22d)][_0x49686c(0x1e3)][_0x49686c(0x1c0)][_0x49686c(0x1fa)]){if(_0x49686c(0x1bf)===_0x49686c(0x193)){if(this['_battler'][_0x49686c(0x1c3)]())return 0x0;if(this[_0x49686c(0x211)]['isAlive']()&&this[_0x49686c(0x211)]['friendsUnit']()[_0x49686c(0xfe)]()[_0x49686c(0x1bb)]===0x1)return 0x1;}else this[_0x49686c(0xfd)]();}VisuMZ[_0x49686c(0x22d)][_0x49686c(0x1e3)]['Aggro']['AddOption']&&(_0x49686c(0x1f5)==='ZdqAY'?this[_0x49686c(0x233)]():(this[_0x49686c(0x1d1)]=_0x4e70b2[_0x49686c(0x22d)][_0x49686c(0x1e3)][_0x49686c(0x12a)][_0x49686c(0x131)],this[_0x49686c(0x176)]=[_0x49686c(0x191),_0x49686c(0x223),_0x49686c(0x132)]));},Window_Options[_0x20bac4(0x106)][_0x20bac4(0xfd)]=function(){const _0x48c15a=_0x20bac4,_0x461972=TextManager[_0x48c15a(0x12c)],_0x35cf94=_0x48c15a(0x12c);this[_0x48c15a(0x25e)](_0x461972,_0x35cf94);},Window_Options[_0x20bac4(0x106)][_0x20bac4(0x233)]=function(){const _0xb79bcc=_0x20bac4,_0x3b8aee=TextManager['aggroGauge'],_0x20c4ac=_0xb79bcc(0x14e);this[_0xb79bcc(0x25e)](_0x3b8aee,_0x20c4ac);},VisuMZ[_0x20bac4(0x22d)]['Window_StatusBase_placeActorName']=Window_StatusBase[_0x20bac4(0x106)][_0x20bac4(0xd2)],Window_StatusBase[_0x20bac4(0x106)][_0x20bac4(0xd2)]=function(_0x12507a,_0x5b0cdf,_0xea522d){const _0xdccdf7=_0x20bac4;if(this[_0xdccdf7(0xff)]())this[_0xdccdf7(0x129)](_0x12507a[_0xdccdf7(0x255)]());VisuMZ[_0xdccdf7(0x22d)][_0xdccdf7(0x197)][_0xdccdf7(0x1b0)](this,_0x12507a,_0x5b0cdf,_0xea522d);},Window_StatusBase['prototype'][_0x20bac4(0xff)]=function(){const _0x139c6c=_0x20bac4;if(![Window_BattleActor,Window_BattleStatus][_0x139c6c(0x163)](this[_0x139c6c(0x214)]))return![];if(!SceneManager[_0x139c6c(0x240)]())return![];return ConfigManager[_0x139c6c(0x14e)]&&VisuMZ['AggroControlSystem'][_0x139c6c(0x1e3)][_0x139c6c(0x230)][_0x139c6c(0x10c)];},Window_StatusBase[_0x20bac4(0x106)]['placeAggroGauge']=function(_0x10dd97,_0x1ae5fa,_0x36024b){const _0x10a293=_0x20bac4;this[_0x10a293(0x15e)](_0x10dd97,_0x10a293(0x1b4),_0x1ae5fa,_0x36024b);},Window_BattleStatus[_0x20bac4(0x106)][_0x20bac4(0x129)]=function(_0x5ae56f){const _0x476cc4=_0x20bac4,_0x4ccf64=this['actor'](_0x5ae56f),_0x466d8e=this[_0x476cc4(0x177)](_0x5ae56f),_0x377864=this['aggroGaugeY'](_0x5ae56f),_0x5e78d8=_0x476cc4(0x265)[_0x476cc4(0x1ff)](_0x4ccf64[_0x476cc4(0x1a0)]()),_0x295993=this[_0x476cc4(0x224)](_0x5e78d8,Sprite_Gauge),_0x2ade4d=VisuMZ[_0x476cc4(0x22d)]['Settings']['Aggro'];_0x295993['x']=_0x466d8e+(_0x2ade4d['BattleStatusOffsetX']||0x0),_0x295993['y']=_0x377864+(_0x2ade4d['BattleStatusOffsetY']||0x0),_0x295993[_0x476cc4(0x10a)]=!![],_0x295993[_0x476cc4(0x239)](_0x4ccf64,_0x476cc4(0x1b4)),_0x295993['visible']=!![];},Window_BattleStatus[_0x20bac4(0x106)]['aggroGaugeX']=function(_0x19afec){const _0x47115f=_0x20bac4;let _0xc75e3=this[_0x47115f(0x1f2)](_0x19afec),_0x28a909=this[_0x47115f(0x160)](_0xc75e3);if(Imported[_0x47115f(0x222)]){if(_0x47115f(0x1e5)===_0x47115f(0x263))return _0x4cae30+_0x10fa00(_0x3c3635['$1'])/0x64;else{let _0x417f68=this['itemRect'](_0x19afec);if(this['battleLayoutStyle']()===_0x47115f(0x26b)){const _0x1bc4f2=$dataSystem[_0x47115f(0x20a)]?0x4:0x3,_0x141e62=_0x1bc4f2*0x80+(_0x1bc4f2-0x1)*0x8+0x4,_0x545957=this[_0x47115f(0x17d)](_0x19afec);let _0x5da287=_0x417f68['x']+this[_0x47115f(0xd0)];if(VisuMZ[_0x47115f(0x16c)]['Settings'][_0x47115f(0x1ae)][_0x47115f(0x24a)])_0x5da287=_0x417f68['x']+ImageManager['faceWidth']+0x8;else{if('uJrUQ'!==_0x47115f(0x1f7))_0x5da287+=ImageManager[_0x47115f(0xfb)];else{if(!_0xfb21fe)return![];return _0x1a33af[_0x47115f(0x232)][_0x47115f(0x145)](/<PROVOKE>/i);}}_0x28a909=Math[_0x47115f(0x1e2)](Math[_0x47115f(0xc7)](_0x417f68['x']+_0x417f68[_0x47115f(0xe1)]-_0x141e62,_0x5da287)),_0x28a909-=0x4;}else{if(_0x47115f(0x1a4)!==_0x47115f(0x1a4))return this[_0x47115f(0x1b8)]();else _0x28a909=Math['round'](_0x417f68['x']+(_0x417f68[_0x47115f(0xe1)]-0x80)/0x2);}}}return _0x28a909;},Window_BattleStatus['prototype']['aggroGaugeY']=function(_0x3df08a){const _0x3339fc=_0x20bac4,_0x2a51ef=this[_0x3339fc(0x17c)](_0x3df08a);let _0xceda3b=this[_0x3339fc(0x189)](_0x2a51ef);if(Imported[_0x3339fc(0x222)]){if(this[_0x3339fc(0x241)]()===_0x3339fc(0x26b)){let _0x34447a=this[_0x3339fc(0x17c)](_0x3df08a);_0xceda3b=Math['round'](_0x34447a['y']+(_0x34447a[_0x3339fc(0xf4)]-Sprite_Name['prototype'][_0x3339fc(0x1f9)]())/0x2);}}if(this[_0x3339fc(0x180)]())_0xceda3b-=Sprite_Gauge[_0x3339fc(0x106)][_0x3339fc(0x1f8)]()-0x1;return _0xceda3b;},Window_BattleStatus[_0x20bac4(0x106)][_0x20bac4(0x180)]=function(){const _0x3bbb8a=_0x20bac4;if(!BattleManager['isTpb']())return![];if(Imported[_0x3bbb8a(0x246)])return this[_0x3bbb8a(0x26e)]('time');return!![];};