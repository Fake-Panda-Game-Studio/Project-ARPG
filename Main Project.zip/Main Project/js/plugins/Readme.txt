Alpha ABS Z.js - it's Active Battle system plugin file


PKD_DevOptions.js - it's plugin i used only for this Demo for shown Event's names (not necessary)

PKD_AnimaX_MZ.js - AnimaX plugin, it's Optional

PKD_ExtendedLoot.js - Extended Loot plugin, it's Optional (but recommended)

